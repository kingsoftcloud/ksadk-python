# OpenClaw WPS Xiezuo Plugin

Version: 1.6.0

## Install

```bash
openclaw plugins install ./openclaw-wps-xiezuo-1.6.0.tgz
```
