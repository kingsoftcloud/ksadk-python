---
name: wps-calendar
description: |
  WPS365 日程与日历事件。用户要创建、列举主日历日程或「日程实例」（重复规则展开）时须走开放平台用户日历 API。
  必须调用 wps_calendar_create / wps_calendar_list_events / wps_calendar_get_event / wps_calendar_list_event_attendees / wps_calendar_respond_invitation / wps_calendar_list_calendar_event_instances / wps_calendar_list_event_instances，禁止生成本地 .ics / 脚本替代。安装本插件后随 skills 目录一并加载。
---

# WPS365 日程：创建与查询主日历事件

## 执行前必读

- **`wps_calendar_create`**：在用户已完成 **用户 OAuth** 且具备 `kso.calendar_events.readwrite`（或开放平台文档所列等价 delegated 权限）时，调用 `POST /v7/calendars/primary/events/create` 在 **主日历** 创建事件。
- **`wps_calendar_list_events`**：同一 delegated token 下调用 **`GET /v7/calendars/primary/events`**（即文档中的 `GET /v7/calendars/{calendar_id}/events`，`calendar_id=primary`）。官方说明：[查询日程列表](https://365.kdocs.cn/3rd/open/documents/app-integration-dev/wps365/server/calendar/calendar-event/get-calendar-event-list)。**HTTP 鉴权与创建日程相同**（用户 `access_token` + `Authorization: Bearer`，插件内共用同一 `WpsClient` 用户态路径，不另走 KSO-1）。
- **`wps_calendar_get_event`**：开放平台「**查询日程**」—— **`GET /v7/calendars/{calendar_id}/events/{event_id}`**（默认 `primary`）。**必填 `event_id`**（通常来自 `wps_calendar_list_events` 的 `id`）。返回体中 **`data` 为单个日程对象**（含 `recurrence`、`original_start_time`、`online_meeting` 等），不是列表。可选请求头：参数 **`x_kso_id_type`** 为 `internal` / `external` 时映射为 **`X-Kso-Id-Type`**（与文档一致）。
- **`wps_calendar_list_event_attendees`**：开放平台「**获取日程参与者列表**」—— **`GET /v7/calendars/{calendar_id}/events/{event_id}/attendees`**（默认 `primary`）。**必填 `event_id`**。响应 **`data`** 通常含 **`items[]`**（参与者）与可选 **`next_page_token`**。Query：可选 **`page_size`**（默认 30，文档最大 **100**）、**`page_token`**（上一页 `data.next_page_token`）。可选 **`x_kso_id_type`** → **`X-Kso-Id-Type`**。
- **`wps_calendar_list_calendar_event_instances`**：调用 **`GET /v7/calendars/{calendar_id}/event_instances`**（默认 `calendar_id=primary`）。在时间窗内返回**主日历上多条日程**展开后的实例（日历级扫描）。Query：`start_time` / `end_time` 为 **RFC3339**、时间窗 **≤31 天**；可选 `page_size`（默认 30）、`page_token`。**鉴权与创建相同**（Bearer）。适合「这周所有会议 occurrence」等**不指定某条 event** 的场景。
- **`wps_calendar_list_event_instances`**：开放平台「**查询日程实例**」—— **`GET /v7/calendars/{calendar_id}/events/{event_id}/event_instances`**（默认 `primary`）。**必填 `event_id`**（从 `wps_calendar_list_events` 返回的 `id` 取得）。Query 仅文档所列：`start_time` / `end_time`（**RFC3339**，**≤31 天**）；无 `page_size` / `page_token`。用于**单条重复日程**在指定时间窗内的展开实例。只看逻辑事件用 `wps_calendar_list_events`。
- **`wps_calendar_respond_invitation`**：开放平台「**答复日程邀请**」—— **`POST /v7/calendars/{calendar_id}/events/{event_id}/respond`**（默认 `primary`）。**必填**：`event_id`、`mod_type`（`normal` / `one` / `all`）、`response_status`（`accepted` / `declined` / `tentative`）、`which_day_time`（日程开始时刻的 **毫秒时间戳**，与文档一致）。用于接受/拒绝/暂定会议邀请。
- **与「通讯录」工具链的关系**：找人、发消息用 `wps_user_search` / `wps_message_send`；**日程不要**为解析 `wps_user_id` 去调 `wps_user_search` —— **`wps_user_id` = 入站 `SenderId`**。
- **授权**：首次无用户 token 时，工具会 **自动发送授权卡片**；返回 `needsAuth: true` 后，提示用户点击「前往授权」，完成后再重试。
- **部署**：用户 OAuth 回调地址由插件内置；须在开放平台「用户授权回调地址」登记**同一 URL**（见 `docs/user-oauth.md`）。

## 查询接口要点（与官方一致）

| 文档要求 | 插件行为 |
|----------|----------|
| `start_time` / `end_time` 为 **RFC3339** 字符串、URL 编码 | 工具参数传 **ISO8601/RFC3339** 字符串（如 `2026-04-22T14:00:00+08:00`），由 HTTP 客户端编码 |
| 时间窗 **0～31 天** | 超出则 **截断**到 31 天 |
| `page_size` 默认 **30** | 未传时使用 30 |
| 增量：`sync_token`、`anchor_time`、`with_cancelled` | 工具支持同名可选参数；若传 **`sync_token`**，不再自动补时间窗（与文档「增量同步」一致） |

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 创建日程 / 会议 / 提醒 / 写入日历 | `wps_calendar_create` | `summary`, `start_time`（ISO） |
| 指定结束时间（可选） | 同上 | `end_time`（ISO；省略则默认 start + 1h） |
| 查看 / 列举主日历日程（逻辑事件） | `wps_calendar_list_events` | `wps_user_id` |
| **单条**日程完整详情（含重复规则 `recurrence`） | `wps_calendar_get_event` | `wps_user_id`, **`event_id`** |
| **单条**日程的参与者列表 | `wps_calendar_list_event_attendees` | `wps_user_id`, **`event_id`**（可选 `page_size`、`page_token`） |
| 主日历时间窗内**所有**日程的展开实例（日历级） | `wps_calendar_list_calendar_event_instances` | `wps_user_id` |
| **某一条**重复日程的展开实例（须已知 `event_id`） | `wps_calendar_list_event_instances` | `wps_user_id`, **`event_id`** |
| 接受 / 拒绝 / 暂定**日程邀请** | `wps_calendar_respond_invitation` | `wps_user_id`, **`event_id`**, **`mod_type`**, **`response_status`**, **`which_day_time`**（**毫秒**） |
| 指定列表时间窗（可选） | 上述列表工具 | `start_time`, `end_time`（**RFC3339**） |

## 核心约束

1. **创建**用 **`wps_calendar_create`**；**逻辑事件列表**用 **`wps_calendar_list_events`**；**单条日程详情**（官方「查询日程」）用 **`wps_calendar_get_event`**（必须 **`event_id`**）；**参与者列表**（官方「获取日程参与者列表」）用 **`wps_calendar_list_event_attendees`**（必须 **`event_id`**）；**答复邀请**用 **`wps_calendar_respond_invitation`**；**日历级实例扫描**用 **`wps_calendar_list_calendar_event_instances`**；**单条 event 的实例**（官方「查询日程实例」路径）用 **`wps_calendar_list_event_instances`**（必须 **`event_id`**）。禁止用本地文件或臆造列表冒充 API。
2. **禁止**生成 .ics、提醒脚本、txt、MEMORY.md 等替代方案。
3. **`wps_user_id`**：当前对话 **SenderId**。
4. **创建**的 `start_time` / `end_time`：事件体用 ISO。**事件列表 / 实例列表** 的 query `start_time` / `end_time`：须为 **RFC3339**。**答复邀请**的 `which_day_time` 为 **毫秒时间戳**（与文档一致）；与 **`wps_message_list` 的 Unix 秒** 不同，勿混用。
5. 若 **`needsAuth: true`**：引导用户完成授权后再试。

## 调用示例

**创建**（省略 `end_time` 时默认 +1h）：

```json
{
  "summary": "站立会",
  "start_time": "2026-04-23T10:00:00+08:00",
  "wps_user_id": "<SenderId>"
}
```

**列举**（省略时间窗时插件默认约「过去 24h～未来 14d」，且不超过 31 天）：

```json
{
  "wps_user_id": "<SenderId>"
}
```

**列举**（显式时间窗）：

```json
{
  "wps_user_id": "<SenderId>",
  "start_time": "2026-04-01T00:00:00+08:00",
  "end_time": "2026-04-07T23:59:59+08:00",
  "page_size": 30
}
```

**单条日程详情**（含 `recurrence`、会议链接等）：

```json
{
  "wps_user_id": "<SenderId>",
  "event_id": "<来自列表的 id>"
}
```

**参与者列表**（分页：`page_token` 填上一页返回的 `data.next_page_token`）：

```json
{
  "wps_user_id": "<SenderId>",
  "event_id": "<来自列表的 id>",
  "page_size": 30
}
```

**答复日程邀请**（`which_day_time` 为该日程开始时间的 **毫秒时间戳**，可从 `wps_calendar_get_event` / 列表返回的 `start_time` 换算）：

```json
{
  "wps_user_id": "<SenderId>",
  "event_id": "<来自列表的 id>",
  "mod_type": "normal",
  "response_status": "accepted",
  "which_day_time": 1714233600000
}
```

**单条重复日程的实例**（先用 `wps_calendar_list_events` 取 `id` 作为 `event_id`）：

```json
{
  "wps_user_id": "<SenderId>",
  "event_id": "<来自列表的 id>",
  "start_time": "2026-04-01T00:00:00+08:00",
  "end_time": "2026-04-07T23:59:59+08:00"
}
```

## 常见错误与排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| `needsAuth: true` | 用户未授权 | 完成 OAuth 卡片后再试 |
| 403 / 无权限 | 应用未申请日历 delegated 权限 | 在开放平台补齐 `kso.calendar_events.read` / `readwrite` 等文档要求项 |
| 列表为空 | 时间窗与日程实际时间无交集 | 扩大 `start_time`～`end_time`（≤31 天） |

## 工具覆盖

- `wps_calendar_create` — 创建（`POST .../events/create`）
- `wps_calendar_list_events` — 逻辑事件列表（`GET /v7/calendars/primary/events`）
- `wps_calendar_get_event` — 查询单条日程（`GET /v7/calendars/primary/events/{event_id}`）
- `wps_calendar_list_event_attendees` — 参与者列表（`GET /v7/calendars/primary/events/{event_id}/attendees`）
- `wps_calendar_list_calendar_event_instances` — 日历级实例列表（`GET /v7/calendars/primary/event_instances`）
- `wps_calendar_list_event_instances` — 单条日程实例（`GET /v7/calendars/primary/events/{event_id}/event_instances`）
- `wps_calendar_respond_invitation` — 答复邀请（`POST /v7/calendars/primary/events/{event_id}/respond`）

## 安装说明

- 随插件 **`skills.directory`** 安装；**`tools.allow`** 须包含上述七工具；**`mcp.toolAllowlist`** 默认已含（见 `src/core/config.ts`）。
