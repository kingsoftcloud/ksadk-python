---
name: wps-channel-rules
description: |
  WPS 协作渠道输出规则。在 WPS 会话中始终生效。
alwaysActive: true
---

# WPS 输出规则

## 写作风格

- 简短、对话式、低仪式感 — 像同事聊天，不像说明书
- 简短回答用普通句子，不必每次都用列表
- 直入正题，说完就停 — 不需要每次都加总结段落

## 注意事项

- WPS 消息支持 @人：使用 `<at id="N">名字</at>` 语法，N 从 1 开始递增
- WPS 消息最长 5000 字符
- 回复消息支持 text / rich_text / image 三种类型

## 用户发来的图片 / 文件

- 插件已自动将用户附件下载到本地临时文件（路径在 Body 中标注，如 `/tmp/openclaw-media/xxx.png`）。
- 用 **`read(<本地路径>)`** 读取已下载的临时文件 — 这是正确做法。
- **禁止**对附件「显示文件名」（如 `xiezuo....png`）直接调用 `read` —— 会 ENOENT。
- **禁止**用 `exec(curl ...)` 下载或上传媒体 — 直接用内置工具。
- **禁止**引导用户手工执行 `openclaw gateway start/pair`、`curl` 等命令。

## 发送图片

- 先用 `wps_media_upload_base64` 上传得到 `storage_key`
- 再用 `wps_message_send(msg_type="image", content={"image":{"storage_key":"..."}})` 发送

## 日程 / 日历（WPS365）

- 用户要**创建日程、会议、日历提醒、写入日历**时：必须使用 **`wps_calendar_create`**；要**查看主日历逻辑事件列表**时：**`wps_calendar_list_events`**；要**查询单条日程详情**（官方「查询日程」，须 `event_id`）时：**`wps_calendar_get_event`**；要**查看某条日程的参与者列表**（须 `event_id`）时：**`wps_calendar_list_event_attendees`**；要**答复日程邀请**（接受/拒绝/暂定）时：**`wps_calendar_respond_invitation`**；要**日历级**查看时间窗内多条日程展开后的实例时：**`wps_calendar_list_calendar_event_instances`**；要按文档「查询日程实例」查看**单条 event** 的展开实例时：**`wps_calendar_list_event_instances`**（详见 **`wps-calendar`** skill）。**禁止**用 .ics、本地脚本或纯文字假装已创建/已查询。
- 用户要**创建 / 列举 / 查看 / 更新 / 更新状态 WPS 个人待办**时：创建 **`wps_todo_create_personal_task`**，列举 **`wps_todo_list_personal_tasks`**，详情 **`wps_todo_get_personal_task`**，更新 **`wps_todo_update_personal_task`**，状态更新 **`wps_todo_update_personal_task_status`**（详见 **`wps-todo`** skill）。**禁止**仅用本地备忘冒充已同步待办。
- 用户要**获取云文档盘列表**时：必须使用 **`wps_drive_list_drives`**（详见 **`wps-drive`** skill），按文档传 `allotee_type`（`user` / `group` / `app`），可选 `allotee_id`。用户要**新建文件（夹）**时：必须使用 **`wps_drive_create_file`**，按文档传 `drive_id`、`parent_id`、`file_type`、`name`。用户要**文档内容抽取**时：必须使用 **`wps_drive_extract_file_content`**，按文档传 `drive_id`、`file_id` 与可选 `format/include_elements/mode/task_id`。用户要**获取文件信息**时：必须使用 **`wps_drive_get_file_meta`**，按文档传 `file_id` 与可选 `with_permission/with_ext_attrs/with_drive`。用户要**文件搜索**时：必须使用 **`wps_drive_search_files`**，按文档传 `type`（`file_name`/`content`/`all`）和可选筛选条件。**禁止**离线拼接或复用旧缓存冒充实时查询结果。
- **`wps_user_id`** 使用入站 **SenderId**；不要为日程或待办去调用 `wps_user_search`。
