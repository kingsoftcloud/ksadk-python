---
name: wps-drive
description: |
  WPS365 云文档（Drive）。用户要查询盘列表、新建文件（夹）、抽取文档内容、获取文件信息或搜索文件时，必须使用开放接口。
  必须调用 wps_drive_list_drives / wps_drive_create_file / wps_drive_extract_file_content / wps_drive_get_file_meta / wps_drive_search_files，禁止用本地缓存结果冒充已同步到 WPS 云文档。安装本插件后随 skills 目录一并加载。
---

# WPS365 云文档：盘列表、新建文件（夹）、内容抽取、文件信息与文件搜索

## 执行前必读

- **`wps_drive_list_drives`**：开放平台「**获取盘列表**」—— **`GET /v7/drives`**。
- **`wps_drive_create_file`**：开放平台「**新建文件（夹）**」—— **`POST /v7/drives/{drive_id}/files/{parent_id}/create`**。
- **`wps_drive_extract_file_content`**：开放平台「**文档内容抽取**」—— **`GET /v7/drives/{drive_id}/files/{file_id}/content`**。
- **`wps_drive_get_file_meta`**：开放平台「**获取文件信息**」—— **`GET /v7/files/{file_id}/meta`**。
- **`wps_drive_search_files`**：开放平台「**文件搜索**」—— **`GET /v7/files/search`**。
- **Delegated 权限**：盘列表使用 **`kso.drive.readwrite`**；新建文件（夹）使用 **`kso.file.readwrite`**；文档内容抽取与获取文件信息使用 **`kso.file.read`**；文件搜索使用 **`kso.file.search`**（或开放平台等价用户授权）。未授权时插件会发授权卡片；`wps_user_id` 使用 **SenderId**。
- **盘列表必填**：`wps_user_id`、`allotee_type`（`user` | `group` | `app`）；`allotee_id` 为可选（三种类型都可传，不传走接口默认归属）。
- **新建文件（夹）必填**：`wps_user_id`、`drive_id`、`parent_id`、`file_type`、`name`。
- **新建 file_type**：`folder` | `file` | `shortcut`；当 `file_type=shortcut` 时，`file_id` 必填。
- **内容抽取必填**：`wps_user_id`、`drive_id`、`file_id`；可选：`format`（`kdc` | `plain` | `markdown`）、`include_elements`（`para`/`table`/`component`/`textbox`/`all`）、`mode`（`sync`/`async`/`auto`）、`task_id`。
- **获取文件信息必填**：`wps_user_id`、`file_id`；可选：`with_permission`、`with_ext_attrs`、`with_drive`。
- **文件搜索必填**：`wps_user_id`、`type`（`file_name` | `content` | `all`）；`page_size` 工具默认补 50（最大 500）。支持文档中查询条件透传，如 `file_type`、`drive_ids`、`time_type`、`with_total`、`order/order_by`、`scope` 等。
- **重名策略**：`on_name_conflict` 支持 `fail` | `rename` | `overwrite` | `replace`。
- **可选请求头**：`x_kso_id_type`（`internal` | `external`），映射到 `X-Kso-Id-Type`。

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 获取用户/群组/应用盘列表 | `wps_drive_list_drives` | `wps_user_id`, `allotee_type` |
| 新建文件（夹）/快捷方式 | `wps_drive_create_file` | `wps_user_id`, `drive_id`, `parent_id`, `file_type`, `name` |
| 文档内容抽取 | `wps_drive_extract_file_content` | `wps_user_id`, `drive_id`, `file_id` |
| 获取文件信息 | `wps_drive_get_file_meta` | `wps_user_id`, `file_id` |
| 文件搜索 | `wps_drive_search_files` | `wps_user_id`, `type` |

## 核心约束

1. 必须通过 `wps_drive_*` 工具调用开放平台，不能伪造云文档结果。
2. `wps_user_id` 必须来自当前消息 `SenderId`，不要为此调用 `wps_user_search`。
3. `file_type=shortcut` 时必须传 `file_id`；盘列表使用 `allotee_type/allotee_id` 参数名；内容抽取场景按需设置 `mode` 与 `task_id`；文件信息可选开关 `with_permission/with_ext_attrs/with_drive`；文件搜索需传合法 `type`。

## 调用示例

```json
{
  "wps_user_id": "<SenderId>",
  "drive_id": "drive_xxx",
  "parent_id": "0",
  "file_type": "folder",
  "name": "项目资料",
  "on_name_conflict": "rename",
  "x_kso_id_type": "external"
}
```

## 常见错误

| 现象 | 处理 |
|------|------|
| `needsAuth: true` | 引导用户完成 OAuth 后重试 |
| `file_id is required when file_type is shortcut` | 传入快捷方式目标文件 ID |
| `allotee_type is required and must be user, group, or app` | 校验并传入合法归属类型；可选传 `allotee_id` 精确指定归属 |
| `mode must be one of: sync, async, auto` | 修正 `mode` 参数为文档枚举值 |
| `file_id is required and must be a non-empty string` | 传入有效文件 ID |
| `type must be one of: file_name, content, all` | 修正文件搜索 `type` 参数为文档枚举值 |
| 403 | 开放平台未开通云文档 delegated 权限 |

## 工具覆盖

- `wps_drive_list_drives` — 获取盘列表（`GET /v7/drives`）
- `wps_drive_create_file` — 新建文件（夹）（`POST /v7/drives/{drive_id}/files/{parent_id}/create`）
- `wps_drive_extract_file_content` — 文档内容抽取（`GET /v7/drives/{drive_id}/files/{file_id}/content`）
- `wps_drive_get_file_meta` — 获取文件信息（`GET /v7/files/{file_id}/meta`）
- `wps_drive_search_files` — 文件搜索（`GET /v7/files/search`）

## 安装说明

随插件 **`skills.directory`** 安装；**`tools.allow`** 与 **`mcp.toolAllowlist`** 须包含 `wps_drive_list_drives`、`wps_drive_create_file`、`wps_drive_extract_file_content`、`wps_drive_get_file_meta`、`wps_drive_search_files`。
