---
name: wps-im-read
description: |
  WPS IM 消息读取与检索。在需要拉会话历史、按时间窗口翻消息、根据 message_id 查看单条内容时使用。
---

# WPS IM：读取历史与单条消息

## 执行前必读

- **时间范围**：`start_time` / `end_time` 参数使用 **秒级 Unix 时间戳**，工具内部自动转换为毫秒发给 API。
- **分页**：使用返回的 **`next_page_token`** 继续拉取；**`page_size`** 一般 1–100。
- **发送方类型**：消息体里的 `sender.type` 常见为 `user`（真人）或 `sp`（应用/机器人），用于区分人与 bot。
- **消息位置**：`position` 字段严格递增，可用于增量同步。

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 分页拉某会话历史消息 | `wps_message_list` | `chat_id` |
| 按消息 ID 取单条详情 | `wps_message_get` | `chat_id`, `message_id` |

常用可选参数（list）：`page_size`, `page_token`, `start_time`, `end_time`。

## 核心约束

- **`wps_message_list`**
  - 必须已知 `chat_id`（群会话或 P2P 会话 id）
  - `start_time` / `end_time`：秒级 Unix 时间戳，用于过滤时间范围
  - 返回的 `next_page_token` 为空则表示没有下一页
- **`wps_message_get`**
  - `chat_id` + `message_id` 唯一确定一条消息
  - 用于引用上下文、审计或回复前的内容确认

## 使用场景示例

**1）拉取最近一页历史**

```json
{
  "chat_id": "CHAT_ID",
  "page_size": 50
}
```

**2）按时间窗口过滤（注意传秒级时间戳）**

```json
{
  "chat_id": "CHAT_ID",
  "start_time": 1713206400,
  "end_time": 1713292800,
  "page_size": 100
}
```

**3）翻页**

```json
{
  "chat_id": "CHAT_ID",
  "page_size": 50,
  "page_token": "TOKEN_上一页返回"
}
```

**4）获取单条消息**

```json
{
  "chat_id": "CHAT_ID",
  "message_id": "MSG_ID"
}
```

## 常见错误与排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| 时间过滤无结果 | 误把毫秒当秒传入，或起止时间反了 | 传秒级时间戳，确认 start < end |
| 404 / chat 不存在 | `chat_id` 错误或已解散 | 用 `wps_chat_get` 校验会话状态 |
| 取单条失败 | `message_id` 不属于该 `chat_id` | 核对 id 是否同一会话上下文 |
| 返回为空 | 指定时间范围内无消息 | 扩大时间范围或去掉时间过滤 |

## 工具覆盖

- `wps_message_list` — 分页拉取会话历史
- `wps_message_get` — 查询单条消息详情
