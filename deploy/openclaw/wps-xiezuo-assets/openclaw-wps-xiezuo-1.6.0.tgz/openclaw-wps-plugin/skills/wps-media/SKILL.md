---
name: wps-media
description: |
  WPS 媒体完整流转：接收图片/文件 → 处理 → 上传 → 发送。
---

# WPS 媒体处理（下载 / 上传 / 发送）

## 入站：收到图片或文件

插件已自动将附件下载到本地临时文件。入站消息 Body 中会包含如下标记：

```
[已下载图片: /tmp/openclaw-media/xxx.png | photo.png | image/png | 42.6KB]
```

- **路径是可读的本地文件**。可直接用 `read(/tmp/openclaw-media/xxx.png)` 读取图片内容。
- 如果是图片，`read` 会返回图片数据；如果当前模型支持视觉（如 qwen-vl），可直接理解图片内容。
- `RawBody.prefetchedMedia` 中有结构化元信息（storageKey、mimeType、localPath 等）。

## 场景 1：用户要求理解/分析图片

1. 从 Body 中找到 `[已下载图片: <path> | ...]`
2. 用 `read(<path>)` 读取图片
3. 根据图片内容回答用户问题

## 场景 2：用户要求把图片发回 / 转发

1. 用 `read(<path>)` 读取本地临时文件 → 得到 base64
2. 调用 `wps_media_upload_base64(file_name, file_type, base64)` → 得到 `storage_key`
3. 调用 `wps_message_send(chat_id, msg_type="image", content={"image":{"storage_key":"..."}})` 发送

## 场景 3：AI 生成了新图片需要发送

1. 将生成的图片转为 base64
2. 调用 `wps_media_upload_base64(file_name, file_type, base64)` → 得到 `storage_key`
3. 调用 `wps_message_send(chat_id, msg_type="image", content={"image":{"storage_key":"..."}})` 发送

## 场景 4：需要额外下载（非入站预取的附件）

如果需要手动下载某个 storage_key 对应的资源：

1. 调用 `wps_media_fetch_base64(chat_id, message_id, storage_key)` → 得到 base64 + mime_type
2. 或调用 `wps_media_download(chat_id, message_id, storage_key)` → 得到预签名 URL

## 常见错误

| 错误 | 原因 |
|------|------|
| `read` + `xiezuo....png` → ENOENT | 把 WPS 显示名当成了 workspace 本地路径，正确做法是读 Body 中的 `/tmp/openclaw-media/...` 路径 |
| 只传 `storage_key` 不传 chat/message | API 需要三者唯一定位资源 |
| `exec(curl ...)` 被拦截 | 运行时禁用 elevated 命令，直接用内置工具 |
| upload 只拿到 URL 不上传 | 用 `wps_media_upload_base64` 替代旧的 `wps_media_upload`，前者自动完成全部上传 |

## 禁止操作

- 不要对附件「显示文件名」直接调用 `read`
- 不要用 `exec(curl)` 下载或上传
- 不要引导用户手动执行命令
- 不要把大段 base64 直接放在回复消息中
