---
name: wps-todo
description: |
  WPS365 个人待办（Todo）。用户要在 WPS 待办中创建个人任务时使用开放接口；须用户 OAuth（待办 delegated 权限）。
  必须调用 wps_todo_create_personal_task / wps_todo_list_personal_tasks / wps_todo_get_personal_task / wps_todo_update_personal_task / wps_todo_update_personal_task_status，禁止仅用本地备忘录冒充已同步到 WPS。安装本插件后随 skills 目录一并加载。
---

# WPS365 个人待办：创建、列表、详情与更新

## 执行前必读

- **`wps_todo_create_personal_task`**：开放平台「**创建个人待办**」—— **`POST /v7/todo/personal_tasks`**。
- **`wps_todo_list_personal_tasks`**：开放平台「**获取个人待办列表**」—— **`POST /v7/todo/personal_tasks/batch_get`**。筛选与分页均为可选；**`page_size`** 默认 20、最大 50；**`page_token`** 用于翻页（上一页 `data` 中分页字段，以实际返回名为准，如 `next_offset` 等）。**`keyword`** 最多 50 字；**`created_time_*` / `due_time_*`** 为**毫秒**时间戳范围。
- **`wps_todo_get_personal_task`**：开放平台「**获取个人待办详情**」—— **`GET /v7/todo/personal_tasks/{task_id}`**。必填 **`task_id`**（通常来自列表 **`tasks[].id`** 或创建返回的 **`task_id`**）。
- **`wps_todo_update_personal_task`**：开放平台「**更新个人待办**」—— **`POST /v7/todo/personal_tasks/{task_id}/update`**。文档要求 **`kso.task.readwrite`**。请求体字段均可选，但**至少改一项**：**`title_subject` / `title_prefix`**、**`description`**、**`due_time_ms`**、**`ext_attrs`**、**`notify_config_json`**（JSON 字符串）。响应多为 **`code` / `msg`**。
- **`wps_todo_update_personal_task_status`**：开放平台「**更新个人待办状态**」—— **`POST /v7/todo/personal_tasks/{task_id}/update_status`**。请求体字段 **`action`** 仅文档枚举：`finish`、`unfinish`、`finish_all`、`unfinish_all`。**推荐**：传 **`completion`**（`complete` | `incomplete`）及创建者二次确认后的 **`mark_scope`**（`self` | `all`）；插件会先 **GET 详情** 比对 **`wps_user_id`** 与创建者。**非创建者**仅能等价于 `finish` / `unfinish`。**创建者**未传 `mark_scope` 时工具返回 `needsUserConfirmation`，须追问用户「仅自己」还是「全部」后再带 `mark_scope` 重试。亦可显式传 **`action`**（与 `completion` 二选一）。
- **Delegated 权限**：文档为 **`kso.task.readwrite`** / **`kso.task.read`**（或开放平台所列等价用户授权）。未授权时插件会发授权卡片；`wps_user_id` 使用 **SenderId**，不要为待办去调 `wps_user_search`。
- **请求体**：必填只有 **`title`**（对象）。插件参数 **`title_subject`** → `title.subject`，可选 **`title_prefix`** → `title.prefix`。可选 **`description`**、**`due_time_ms`**（截止时间 **毫秒** Unix 时间戳）、**`status`**（`todo` | `finish`）、**`executors`**（执行人用户 ID，最多 100）。
- **响应**：成功时 **`data.task_id`** 为新待办 ID。
- **HTTP**：与日程类工具相同，使用用户 **`access_token`** + **`Authorization: Bearer`**（插件内 `UserAuthProvider`）。可选 **`x_kso_id_type`**（`internal` | `external`）映射 **`X-Kso-Id-Type`**。

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 创建个人待办 / 任务 | `wps_todo_create_personal_task` | `wps_user_id`, **`title_subject`** |
| 列举个人待办 | `wps_todo_list_personal_tasks` | **`wps_user_id`** |
| **单条**待办详情 | `wps_todo_get_personal_task` | **`wps_user_id`**, **`task_id`** |
| **更新**待办（局部字段） | `wps_todo_update_personal_task` | **`wps_user_id`**, **`task_id`** + 至少一项变更字段 |
| **更新待办状态** | `wps_todo_update_personal_task_status` | **`wps_user_id`**, **`task_id`** + **`completion`** 或 **`action`**（二选一） |

## 核心约束

1. **创建 / 列表 / 详情 / 更新 / 更新状态**分别使用上表工具，禁止假装已在 WPS 同步。
2. **`wps_user_id`**：当前对话 **SenderId**。
3. **`due_time_ms`** 为 **毫秒**；与日程答复里的 `which_day_time` 同为毫秒，勿与 Unix **秒**混淆。

## 调用示例

```json
{
  "wps_user_id": "<SenderId>",
  "title_subject": "提交周报",
  "due_time_ms": 1714377600000
}
```

## 常见错误

| 现象 | 处理 |
|------|------|
| `needsAuth: true` | 引导用户完成 OAuth 后再试 |
| 403 | 开放平台未开通待办 delegated 权限 |

## 工具覆盖

- `wps_todo_create_personal_task` — 创建（`POST /v7/todo/personal_tasks`）
- `wps_todo_list_personal_tasks` — 列表（`POST /v7/todo/personal_tasks/batch_get`）
- `wps_todo_get_personal_task` — 详情（`GET /v7/todo/personal_tasks/{task_id}`）
- `wps_todo_update_personal_task` — 更新（`POST /v7/todo/personal_tasks/{task_id}/update`）
- `wps_todo_update_personal_task_status` — 状态更新（`POST /v7/todo/personal_tasks/{task_id}/update_status`）

## 安装说明

随插件 **`skills.directory`** 安装；**`tools.allow`** 须包含上述工具；**`mcp.toolAllowlist`** 默认已含（见 `src/core/config.ts`）。
