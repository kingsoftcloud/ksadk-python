---
name: wps-user
description: |
  WPS 企业用户查询。在需要确认当前身份、按关键字找人、按邮箱/手机精确定位用户时使用。
---

# WPS 用户：查询与搜索

## 执行前必读

- **`wps_user_get`**：获取当前 access_token 对应的应用/用户身份信息（调用 `GET /v7/users/current`），返回 `id`、`user_name`、`avatar`、`company_id`。
- **`wps_user_search`**：按关键字搜索企业内活跃用户，搜索范围固定为 `user_name`、`email`、`phone`，状态限定 `active`。
- **标识统一**：接口返回的 `user.id` 是后续所有 IM / 日历等 API 的主键，发消息的 `receiver_id`、群成员的 `member_ids`、mentions 里的用户 ID 均使用此值。

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 查看当前应用/用户身份 | `wps_user_get` | 无 |
| 关键字找人（姓名/邮箱/手机） | `wps_user_search` | `keyword` |

## 核心约束

- **`wps_user_get`**
  - 无参数，返回当前 token 持有者的基本信息
  - 适用于确认 bot 身份、获取 company_id
- **`wps_user_search`**
  - `keyword`：搜索关键词（姓名片段、邮箱、手机号等）
  - 搜索字段固定：`user_name`、`email`、`phone`
  - 状态固定：仅搜索 `active` 用户
  - 搜索范围固定：`company_user`（本企业用户）
  - `page_size`：**必传**，默认 50，最大 100
  - 支持 `page_token` 翻页

## 用户搜索交互规则（必须遵守）

### 收到"给 XX 发消息"时的执行链路

1. **先调 `wps_user_search`** 查找目标用户，`keyword` 使用用户提供的姓名/邮箱/手机
2. 如果返回 **1 个结果**：直接使用该 `user_id` 调用 `wps_message_send`
3. 如果返回 **多个结果**：展示候选列表（姓名 + 部门），让用户选择
4. 如果返回 **0 个结果**：
   - 告知用户"未找到匹配的企业用户"
   - 建议：换一个关键词重试（如全名、邮箱、手机号）
   - 建议：如果对方不在本企业通讯录，需要提供其 WPS 用户 ID
   - **禁止**编造用户 ID 或猜测

### 禁止行为

- **禁止**不调用 `wps_user_search` 就声称"找不到用户"或"工具不可用"
- **禁止**跳过搜索步骤直接要求用户提供 user_id
- **禁止**使用 `sessions_send` 替代 `wps_message_send` 给 WPS 用户发消息

## 使用场景示例

**1）查看当前身份**

```json
{}
```

**2）按姓名关键字搜用户**

```json
{
  "keyword": "张三"
}
```

**3）按邮箱精确搜**

```json
{
  "keyword": "zhangsan@example.com"
}
```

**4）翻页**

```json
{
  "keyword": "张",
  "page_size": 50,
  "page_token": "TOKEN_上一页返回"
}
```

## 常见错误与排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| 搜不到人 | 关键词太短或用户不在本企业 | 换关键词；确认搜索范围 |
| 返回用户不可发消息 | 账号已禁用或离职 | 搜索默认只返回 active 用户，如仍无法发送检查权限 |
| 分页漏数据 | `page_token` 未正确传递 | 严格使用上一页响应的 `next_page_token` |
| 权限不足 | 应用未授权 `kso.contact.read` | 在 WPS 开放平台补齐权限 |

## 工具覆盖

- `wps_user_get` — 获取当前身份
- `wps_user_search` — 按关键字搜索企业用户

## 与日程（wps-calendar）的分工

- **找人 / 身份**：用本 skill 的 `wps_user_get`、`wps_user_search`。
- **创建日历事件**：用 **`wps_calendar`** skill 的 **`wps_calendar_create`**；**列举逻辑事件**：**`wps_calendar_list_events`**；**单条日程详情**：**`wps_calendar_get_event`**；**参与者列表**：**`wps_calendar_list_event_attendees`**；**答复日程邀请**：**`wps_calendar_respond_invitation`**；**日历级实例列表**：**`wps_calendar_list_calendar_event_instances`**；**单条日程的实例**（须 `event_id`）：**`wps_calendar_list_event_instances`**。**创建 / 列举 / 查看 / 更新 / 状态更新个人待办**：用 **`wps-todo`** skill 的 **`wps_todo_create_personal_task`**、**`wps_todo_list_personal_tasks`**、**`wps_todo_get_personal_task`**、**`wps_todo_update_personal_task`**、**`wps_todo_update_personal_task_status`**。**获取云文档盘列表 / 新建文件（夹）/ 文档内容抽取 / 获取文件信息 / 文件搜索**：用 **`wps-drive`** skill 的 **`wps_drive_list_drives`**、**`wps_drive_create_file`**、**`wps_drive_extract_file_content`**、**`wps_drive_get_file_meta`**、**`wps_drive_search_files`**。其中 **`wps_user_id` 直接用 SenderId**，不要为日程/待办/云文档再调 `wps_user_search`。
