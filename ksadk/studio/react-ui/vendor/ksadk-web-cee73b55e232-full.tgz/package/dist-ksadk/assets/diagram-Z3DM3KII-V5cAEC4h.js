import{n as e}from"./mermaid-parser.core-DDSRbr1P.js";import{t}from"./chunk-JWPE2WC7-kVIHmmjS.js";import{Ir as n,Lt as r,Nr as i,Sr as a,ar as o,bn as s,br as c,cr as l,er as u,or as d,rr as f,sr as p,ur as m,yr as h}from"./MermaidBlock-DctuZnSH.js";var g=o.packet,_=class{constructor(){this.packet=[],this.setAccTitle=c,this.getAccTitle=p,this.setDiagramTitle=a,this.getDiagramTitle=m,this.getAccDescription=d,this.setAccDescription=h}static{n(this,`PacketDB`)}getConfig(){let e=r({...g,...l().packet});return e.showBits&&(e.paddingY+=10),e}getPacket(){return this.packet}pushWord(e){e.length>0&&this.packet.push(e)}clear(){u(),this.packet=[]}},v=1e4,y=n((e,n)=>{t(e,n);let r=-1,a=[],o=1,{bitsPerRow:s}=n.getConfig();for(let{start:t,end:c,bits:l,label:u}of e.blocks){if(t!==void 0&&c!==void 0&&c<t)throw Error(`Packet block ${t} - ${c} is invalid. End must be greater than start.`);if(t??=r+1,t!==r+1)throw Error(`Packet block ${t} - ${c??t} is not contiguous. It should start from ${r+1}.`);if(l===0)throw Error(`Packet block ${t} is invalid. Cannot have a zero bit field.`);for(c??=t+(l??1)-1,l??=c-t+1,r=c,i.debug(`Packet block ${t} - ${r} with label ${u}`);a.length<=s+1&&n.getPacket().length<v;){let[e,r]=b({start:t,end:c,bits:l,label:u},o,s);if(a.push(e),e.end+1===o*s&&(n.pushWord(a),a=[],o++),!r)break;({start:t,end:c,bits:l,label:u}=r)}}n.pushWord(a)},`populate`),b=n((e,t,n)=>{if(e.start===void 0)throw Error(`start should have been set during first phase`);if(e.end===void 0)throw Error(`end should have been set during first phase`);if(e.start>e.end)throw Error(`Block start ${e.start} is greater than block end ${e.end}.`);if(e.end+1<=t*n)return[e,void 0];let r=t*n-1,i=t*n;return[{start:e.start,end:r,label:e.label,bits:r-e.start},{start:i,end:e.end,label:e.label,bits:e.end-i}]},`getNextFittingBlock`),x={parser:{yy:void 0},parse:n(async t=>{let n=await e(`packet`,t),r=x.parser?.yy;if(!(r instanceof _))throw Error(`parser.parser?.yy was not a PacketDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.`);i.debug(n),y(n,r)},`parse`)},S=n((e,t,n,r)=>{let i=r.db,a=i.getConfig(),{rowHeight:o,paddingY:c,bitWidth:l,bitsPerRow:u}=a,d=i.getPacket(),p=i.getDiagramTitle(),m=o+c,h=m*(d.length+1)-(p?0:o),g=l*u+2,_=s(t);_.attr(`viewBox`,`0 0 ${g} ${h}`),f(_,h,g,a.useMaxWidth);for(let[e,t]of d.entries())C(_,t,e,a);_.append(`text`).text(p).attr(`x`,g/2).attr(`y`,h-m/2).attr(`dominant-baseline`,`middle`).attr(`text-anchor`,`middle`).attr(`class`,`packetTitle`)},`draw`),C=n((e,t,n,{rowHeight:r,paddingX:i,paddingY:a,bitWidth:o,bitsPerRow:s,showBits:c})=>{let l=e.append(`g`),u=n*(r+a)+a;for(let e of t){let t=e.start%s*o+1,n=(e.end-e.start+1)*o-i;if(l.append(`rect`).attr(`x`,t).attr(`y`,u).attr(`width`,n).attr(`height`,r).attr(`class`,`packetBlock`),l.append(`text`).attr(`x`,t+n/2).attr(`y`,u+r/2).attr(`class`,`packetLabel`).attr(`dominant-baseline`,`middle`).attr(`text-anchor`,`middle`).text(e.label),!c)continue;let a=e.end===e.start,d=u-2;l.append(`text`).attr(`x`,t+(a?n/2:0)).attr(`y`,d).attr(`class`,`packetByte start`).attr(`dominant-baseline`,`auto`).attr(`text-anchor`,a?`middle`:`start`).text(e.start),a||l.append(`text`).attr(`x`,t+n).attr(`y`,d).attr(`class`,`packetByte end`).attr(`dominant-baseline`,`auto`).attr(`text-anchor`,`end`).text(e.end)}},`drawWord`),w={draw:S},T={byteFontSize:`10px`,startByteColor:`black`,endByteColor:`black`,labelColor:`black`,labelFontSize:`12px`,titleColor:`black`,titleFontSize:`14px`,blockStrokeColor:`black`,blockStrokeWidth:`1`,blockFillColor:`#efefef`},E={parser:x,get db(){return new _},renderer:w,styles:n(({packet:e}={})=>{let t=r(T,e);return`
	.packetByte {
		font-size: ${t.byteFontSize};
	}
	.packetByte.start {
		fill: ${t.startByteColor};
	}
	.packetByte.end {
		fill: ${t.endByteColor};
	}
	.packetLabel {
		fill: ${t.labelColor};
		font-size: ${t.labelFontSize};
	}
	.packetTitle {
		fill: ${t.titleColor};
		font-size: ${t.titleFontSize};
	}
	.packetBlock {
		stroke: ${t.blockStrokeColor};
		stroke-width: ${t.blockStrokeWidth};
		fill: ${t.blockFillColor};
	}
	`},`styles`)};export{E as diagram};