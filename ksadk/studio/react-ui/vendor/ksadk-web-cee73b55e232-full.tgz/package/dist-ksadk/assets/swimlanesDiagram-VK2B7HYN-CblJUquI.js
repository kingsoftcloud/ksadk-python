import"./chunk-F27PBJKO-CoydycK6.js";import"./chunk-XXDRQBXY-sN7UhNxn.js";import"./chunk-POPQ4Y6H-Ga62wO2d.js";import{r as e,t}from"./chunk-RHFEMEQ7-XkIpeiAV.js";import{Ir as n}from"./MermaidBlock-DctuZnSH.js";var r=t({defaultLayout:`swimlane`,styles:n(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};