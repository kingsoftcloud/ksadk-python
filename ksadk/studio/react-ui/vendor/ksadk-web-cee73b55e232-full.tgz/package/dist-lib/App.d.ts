import React from 'react';
export type AgentWorkbenchFeatureFlags = Record<string, boolean>;
export type AgentWorkbenchInitialSurface = 'chat' | 'tui' | 'workspace';
export type AgentWorkbenchProps = {
    /** Opaque cache scope from the authenticated host; changing it reloads the page. */
    authorizationScopeKey?: string;
    apiAdapter?: import('./core/api/types.js').ApiFacade;
    featureFlags?: AgentWorkbenchFeatureFlags;
    initialSurface?: AgentWorkbenchInitialSurface;
    routeShell?: React.ComponentType<{
        children: React.ReactNode;
    }>;
};
export declare function AgentWorkbench(props?: AgentWorkbenchProps): import("react/jsx-runtime").JSX.Element;
export default function App(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=App.d.ts.map