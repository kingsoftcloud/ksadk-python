import { t as e } from "./utils-CX-Pz5p6.js";
import { n as t, t as n } from "./sandbox-BTRIKAO6.js";
import { t as r } from "./artifact-BfFsPe5A.js";
import { useRef as i } from "react";
import { Download as a, X as o } from "lucide-react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/artifacts/ArtifactsPanel.tsx
function l() {
	let l = r((e) => e.visible), u = r((e) => e.content), d = r((e) => e.type), f = r((e) => e.hide), p = i(null);
	if (t(p), !l || !u) return null;
	let m = n(u);
	return /* @__PURE__ */ c("aside", {
		className: e("flex h-full flex-shrink-0 flex-col border-l border-slate-200/30 bg-white dark:border-slate-800/40 dark:bg-slate-950", "w-[min(42rem,50vw)]"),
		children: [/* @__PURE__ */ c("div", {
			className: "flex h-14 flex-shrink-0 items-center justify-between border-b border-slate-200/30 px-4 dark:border-slate-800/40",
			children: [/* @__PURE__ */ c("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ s("span", {
					className: "text-sm font-semibold text-slate-900 dark:text-slate-100",
					children: "Artifact"
				}), /* @__PURE__ */ s("span", {
					className: "rounded-md bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] text-slate-500 dark:bg-slate-900 dark:text-slate-400",
					children: d
				})]
			}), /* @__PURE__ */ c("div", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => {
						let e = new Blob([u], { type: "text/html;charset=utf-8" }), t = URL.createObjectURL(e), n = document.createElement("a");
						n.href = t, n.download = `artifact.${d === "svg" ? "svg" : "html"}`, document.body.appendChild(n), n.click(), document.body.removeChild(n), URL.revokeObjectURL(t);
					},
					className: "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-900",
					title: "Download",
					children: [/* @__PURE__ */ s(a, { className: "h-3.5 w-3.5" }), "Download"]
				}), /* @__PURE__ */ s("button", {
					type: "button",
					onClick: f,
					className: "rounded-lg p-1.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100",
					"aria-label": "Close Artifact",
					title: "Close",
					children: /* @__PURE__ */ s(o, { className: "h-4 w-4" })
				})]
			})]
		}), /* @__PURE__ */ s("div", {
			className: "min-h-0 flex-1",
			children: /* @__PURE__ */ s("iframe", {
				ref: p,
				srcDoc: m,
				sandbox: "allow-scripts allow-downloads",
				title: "Artifact Preview",
				className: "h-full w-full border-0 bg-white"
			})
		})]
	});
}
//#endregion
export { l as ArtifactsPanel };
