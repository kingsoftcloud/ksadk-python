import { a as e, l as t, n, r } from "./a2ui-B1x5yNaJ.js";
import { t as i } from "./utils-CX-Pz5p6.js";
import { r as a, t as o } from "./InteractionSchemaForm-ChYkHPop.js";
import * as s from "react";
import { useEffect as c, useState as l } from "react";
import { ArrowRight as u, ChevronLeft as d, ChevronRight as f, MessageCircleQuestion as p, Pencil as m, X as h } from "lucide-react";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { A2UIProvider as y, A2UIRenderer as b, useA2UI as x } from "@copilotkit/a2ui-renderer";
import * as S from "@radix-ui/react-dialog";
//#region src/components/chat/A2UIActivityMessage.tsx
function C({ surfaceId: e, serializedMessages: t }) {
	let { processMessages: n } = x();
	return c(() => {
		n(JSON.parse(t));
	}, [t, n]), /* @__PURE__ */ _(b, {
		surfaceId: e,
		className: "w-full",
		fallback: /* @__PURE__ */ _("div", {
			className: "text-sm text-slate-500 dark:text-slate-400",
			children: "界面内容暂不可用"
		}),
		loadingFallback: /* @__PURE__ */ _("div", {
			className: "text-sm text-slate-500 dark:text-slate-400",
			children: "正在加载界面"
		})
	});
}
function w({ surfaceId: e, messages: t, onAction: i }) {
	let a = e.startsWith("input-") ? r(t) : null;
	if (a) return /* @__PURE__ */ v("details", {
		className: "mx-auto mb-3 w-full max-w-3xl px-6 text-sm text-muted-foreground",
		"data-testid": "legacy-question-history",
		children: [/* @__PURE__ */ v("summary", {
			className: "cursor-pointer",
			children: [
				"历史提问 · ",
				a.length,
				" 个问题"
			]
		}), /* @__PURE__ */ _("ul", {
			className: "mt-2 list-disc space-y-1 pl-5",
			children: a.map((e, t) => /* @__PURE__ */ _("li", { children: e }, t))
		})]
	});
	let o = JSON.stringify(t);
	return /* @__PURE__ */ _("div", {
		className: "mb-3 w-full overflow-hidden rounded-lg border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-slate-900",
		children: /* @__PURE__ */ _(y, {
			catalog: n,
			onAction: i,
			children: /* @__PURE__ */ _(C, {
				surfaceId: e,
				serializedMessages: o
			})
		}, `${e}:${o}`)
	});
}
//#endregion
//#region src/components/chat/InteractionA2uiSurface.tsx
function T({ a2ui: e, disabled: t, onSubmit: n, onCancel: r }) {
	return /* @__PURE__ */ v("div", {
		className: "mt-3",
		"data-testid": "interaction-a2ui-surface",
		children: [/* @__PURE__ */ _(w, {
			surfaceId: `interaction-${e.wireVersion}`,
			messages: e.messages,
			onAction: t ? void 0 : (e) => {
				let t = e.userAction?.context || {};
				n(typeof t.payload == "object" && t.payload !== null ? t.payload : { ...t });
			}
		}), t ? null : /* @__PURE__ */ _("button", {
			type: "button",
			"data-testid": "interaction-a2ui-cancel",
			onClick: r,
			className: "mt-1 inline-flex min-h-8 items-center rounded-md px-3 py-1.5 text-xs font-medium text-slate-500 underline-offset-2 hover:underline dark:text-slate-400",
			children: "取消本次确认"
		})]
	});
}
//#endregion
//#region src/components/chat/InteractionTray.tsx
function E(e) {
	for (let t of e?.messages || []) {
		let e = t.inputSchema ?? t.input_schema ?? t.schema;
		if (typeof e == "object" && e) return e;
	}
	return null;
}
function D(e) {
	if (!e.expiresAt) return !1;
	let t = Date.parse(e.expiresAt);
	return Number.isFinite(t) && t <= Date.now();
}
function O(e) {
	let t = e.extensions.submit_error;
	return typeof t == "object" && t && "code" in t && "message" in t ? {
		code: String(t.code),
		message: String(t.message),
		retryable: !!("retryable" in t && t.retryable)
	} : null;
}
function k(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function A(e) {
	let t = k(e);
	if (t) return t;
	if (typeof e != "string") return null;
	try {
		return k(JSON.parse(e));
	} catch {
		return null;
	}
}
function j(e) {
	return Array.isArray(e) ? e.map(String).join(" ") : typeof e == "string" ? e : "";
}
function M(e) {
	let t = A(e.extensions.detail), n = A(e.extensions.arguments), r = t || n || {}, i = e.title.replace(/^审批[：:]\s*/, "").trim();
	return {
		operation: {
			command_execution: "命令执行",
			file_change: "文件修改",
			mcp_tool_call: "MCP 工具调用"
		}[i] || i,
		command: j(r.command ?? r.cmd),
		reason: j(r.reason ?? r.justification),
		cwd: j(r.cwd ?? r.workdir)
	};
}
var N = {
	approved: "已同意",
	rejected: "已拒绝",
	submitted: "已提交",
	cancelled: "已取消",
	expired: "已过期"
};
function P({ interactions: n, activeIndex: r, onSelectIndex: s, onRespond: c, localCatalog: y, className: b }) {
	let [x, S] = l(""), [C, w] = l({}), k = a(), A = n[Math.min(r, Math.max(n.length - 1, 0))];
	if (!A) return null;
	let j = D(A), P = O(A), F = M(A), I = j || A.status === "resolving", L = t(A.presentation?.a2ui, y), R = A.requestSchema ?? E(A.presentation?.a2ui) ?? null, z = A.kind === "approval" ? "basic-controls" : L === "a2ui" ? "a2ui" : L === "json-schema-form" && R || A.requestSchema && !A.presentation ? "json-schema-form" : "basic-controls", B = z === "json-schema-form" && R || A.requestSchema, V = (t, n) => {
		I || Promise.resolve(c({
			interactionId: A.interactionId,
			expectedRevision: A.revision,
			action: t,
			response: n,
			idempotencyKey: e(A.interactionId, A.revision)
		})).catch(() => {});
	};
	return /* @__PURE__ */ _("div", {
		"data-testid": "interaction-tray",
		"data-slot": "interaction-tray",
		"data-ui": "interaction-tray",
		"data-interaction-status": A.status,
		"data-interaction-count": n.length,
		className: i("mx-auto mb-2 w-full max-w-[64rem] px-3 sm:px-4", b),
		children: /* @__PURE__ */ v("div", {
			"data-slot": "interaction-card",
			className: "rounded-2xl border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-background)] px-3 py-3 text-[var(--ksadk-interaction-foreground)] shadow-sm",
			children: [
				/* @__PURE__ */ v("div", {
					className: "flex items-center justify-between gap-2 text-xs text-[var(--ksadk-interaction-muted)]",
					children: [/* @__PURE__ */ v("div", {
						className: "flex min-w-0 items-center gap-1.5",
						children: [
							/* @__PURE__ */ _(p, {
								className: "h-3.5 w-3.5 shrink-0",
								strokeWidth: 1.7,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ _("span", {
								"data-testid": "interaction-tray-title",
								children: A.title
							}),
							F.operation ? /* @__PURE__ */ _("span", {
								className: "truncate text-[11px] text-[var(--ksadk-interaction-muted)]",
								children: F.operation
							}) : null
						]
					}), /* @__PURE__ */ v("div", {
						className: "flex items-center gap-1",
						children: [n.length > 1 ? /* @__PURE__ */ v(g, { children: [
							/* @__PURE__ */ _("button", {
								type: "button",
								"data-testid": "interaction-tray-prev",
								disabled: r <= 0,
								onClick: () => s(Math.max(r - 1, 0)),
								className: "rounded p-1 transition hover:bg-[var(--ksadk-interaction-muted-background)] disabled:opacity-30",
								"aria-label": "上一条待确认",
								children: /* @__PURE__ */ _(d, {
									className: "h-3.5 w-3.5",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ v("span", {
								"data-testid": "interaction-tray-count",
								className: "min-w-10 text-center",
								children: [
									r + 1,
									" of ",
									n.length
								]
							}),
							/* @__PURE__ */ _("button", {
								type: "button",
								"data-testid": "interaction-tray-next",
								disabled: r >= n.length - 1,
								onClick: () => s(Math.min(r + 1, n.length - 1)),
								className: "rounded p-1 transition hover:bg-[var(--ksadk-interaction-muted-background)] disabled:opacity-30",
								"aria-label": "下一条待确认",
								children: /* @__PURE__ */ _(f, {
									className: "h-3.5 w-3.5",
									"aria-hidden": "true"
								})
							})
						] }) : null, /* @__PURE__ */ _("button", {
							type: "button",
							"data-testid": "interaction-cancel",
							disabled: I,
							onClick: () => V("cancel", {}),
							className: "rounded p-1 transition hover:bg-[var(--ksadk-interaction-muted-background)] hover:text-[var(--ksadk-interaction-foreground)] disabled:opacity-30",
							"aria-label": "取消本次确认",
							children: /* @__PURE__ */ _(h, {
								className: "h-3.5 w-3.5",
								"aria-hidden": "true"
							})
						})]
					})]
				}),
				A.message === F.command ? null : /* @__PURE__ */ _("p", {
					className: "mt-2 whitespace-pre-wrap break-words text-sm font-medium leading-5 text-[var(--ksadk-interaction-foreground)]",
					"data-testid": "interaction-tray-message",
					children: A.message
				}),
				F.command || F.reason || F.cwd ? /* @__PURE__ */ v("div", {
					"data-slot": "interaction-summary",
					className: "mt-1.5 space-y-1 rounded-xl bg-[var(--ksadk-interaction-muted-background)] px-2.5 py-2 text-xs leading-5",
					children: [
						F.command ? /* @__PURE__ */ _("code", {
							className: "block max-h-12 overflow-auto whitespace-pre-wrap break-all font-mono text-[var(--ksadk-interaction-foreground)]",
							children: F.command
						}) : null,
						F.reason ? /* @__PURE__ */ _("p", {
							className: "text-[var(--ksadk-interaction-muted)]",
							children: F.reason
						}) : null,
						F.cwd ? /* @__PURE__ */ _("p", {
							className: "truncate font-mono text-[11px] text-[var(--ksadk-interaction-muted)]",
							title: F.cwd,
							children: F.cwd
						}) : null
					]
				}) : null,
				j ? /* @__PURE__ */ v("p", {
					className: "mt-2 text-xs font-medium text-rose-600 dark:text-rose-400",
					"data-testid": "interaction-tray-expired",
					children: [
						"该确认已过期（",
						N.expired,
						"），等待运行时继续处理。"
					]
				}) : null,
				P ? /* @__PURE__ */ v("p", {
					className: "mt-2 text-xs font-medium text-rose-600 dark:text-rose-400",
					"data-testid": "interaction-tray-error",
					children: [
						"提交失败（",
						P.code,
						"）：",
						P.message,
						P.retryable ? "，可重试。" : ""
					]
				}) : null,
				z === "a2ui" && A.presentation?.a2ui ? /* @__PURE__ */ _(T, {
					a2ui: A.presentation.a2ui,
					disabled: I,
					onSubmit: (e) => V("submit", e),
					onCancel: () => V("cancel", {})
				}) : z === "json-schema-form" && B ? /* @__PURE__ */ _(o, {
					schema: B,
					values: C,
					onChange: w,
					disabled: I,
					onSubmit: () => V("submit", C),
					onCancel: () => V("cancel", {})
				}) : A.kind === "approval" ? /* @__PURE__ */ v("div", {
					className: "mt-2 flex flex-col gap-1",
					"data-testid": "interaction-tray-basic",
					children: [
						/* @__PURE__ */ v("button", {
							type: "button",
							"data-testid": "interaction-approve",
							disabled: I,
							onClick: () => V("approve", { decision: "approve" }),
							className: "group flex min-h-9 w-full items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-left text-sm font-medium text-[var(--ksadk-interaction-foreground)] transition hover:bg-[var(--ksadk-interaction-muted-background)] disabled:cursor-not-allowed disabled:opacity-55",
							children: [
								/* @__PURE__ */ _("span", {
									className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--ksadk-interaction-muted-background)] text-xs text-[var(--ksadk-interaction-muted)]",
									children: "1"
								}),
								/* @__PURE__ */ _("span", {
									className: "min-w-0 flex-1",
									children: "批准并继续"
								}),
								/* @__PURE__ */ _(u, {
									className: "h-3.5 w-3.5 text-[var(--ksadk-interaction-muted)] opacity-0 transition group-hover:opacity-100",
									"aria-hidden": "true"
								})
							]
						}),
						/* @__PURE__ */ v("button", {
							type: "button",
							"data-testid": "interaction-reject",
							disabled: I,
							onClick: () => V("reject", { decision: "reject" }),
							className: "group flex min-h-9 w-full items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-left text-sm font-medium text-[var(--ksadk-interaction-foreground)] transition hover:bg-[var(--ksadk-interaction-muted-background)] disabled:cursor-not-allowed disabled:opacity-55",
							children: [
								/* @__PURE__ */ _("span", {
									className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--ksadk-interaction-muted-background)] text-xs text-[var(--ksadk-interaction-muted)]",
									children: "2"
								}),
								/* @__PURE__ */ _("span", {
									className: "min-w-0 flex-1",
									children: "拒绝"
								}),
								/* @__PURE__ */ _(u, {
									className: "h-3.5 w-3.5 text-[var(--ksadk-interaction-muted)] opacity-0 transition group-hover:opacity-100",
									"aria-hidden": "true"
								})
							]
						}),
						/* @__PURE__ */ v("label", {
							className: "mt-0.5 flex min-w-0 items-center gap-2.5 rounded-xl bg-[var(--ksadk-interaction-muted-background)]/60 px-2.5 py-1.5",
							children: [
								/* @__PURE__ */ _("span", {
									className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-control-background)] text-[var(--ksadk-interaction-muted)]",
									children: /* @__PURE__ */ _(m, {
										className: "h-3.5 w-3.5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ _("input", {
									type: "text",
									value: x,
									onChange: (e) => S(e.target.value),
									onKeyDown: (e) => {
										e.key !== "Enter" || k(e) || !x.trim() || (e.preventDefault(), V("cancel", { feedback: x.trim() }));
									},
									placeholder: "告诉 Agent 要如何修改",
									disabled: I,
									"data-testid": "interaction-tray-comment",
									className: "h-8 min-w-0 flex-1 border-0 bg-transparent px-0 text-sm font-medium text-[var(--ksadk-interaction-foreground)] outline-none placeholder:text-[var(--ksadk-interaction-muted)] disabled:cursor-not-allowed disabled:opacity-55"
								}),
								/* @__PURE__ */ _("button", {
									type: "button",
									"data-testid": "interaction-feedback-submit",
									"aria-label": "提交修改意见",
									disabled: I || !x.trim(),
									onClick: () => V("cancel", { feedback: x.trim() }),
									className: "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[var(--ksadk-interaction-muted)] transition hover:bg-[var(--ksadk-interaction-control-background)] hover:text-[var(--ksadk-interaction-foreground)] disabled:opacity-30",
									children: /* @__PURE__ */ _(u, {
										className: "h-3.5 w-3.5",
										"aria-hidden": "true"
									})
								})
							]
						})
					]
				}) : /* @__PURE__ */ v("div", {
					className: "mt-2.5",
					"data-testid": "interaction-tray-basic",
					children: [/* @__PURE__ */ _("input", {
						type: "text",
						value: x,
						onChange: (e) => S(e.target.value),
						onKeyDown: (e) => {
							e.key !== "Enter" || k(e) || !x.trim() || (e.preventDefault(), V("submit", { value: x.trim() }));
						},
						placeholder: "输入回复",
						disabled: I,
						"data-testid": "interaction-tray-comment",
						className: "mb-2 h-8 w-full rounded-lg border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-control-background)] px-2.5 text-sm text-[var(--ksadk-interaction-foreground)] outline-none placeholder:text-[var(--ksadk-interaction-muted)] focus:ring-1 focus:ring-[var(--ksadk-interaction-focus-ring)]"
					}), /* @__PURE__ */ _("div", {
						className: "flex justify-end gap-2",
						children: /* @__PURE__ */ _("button", {
							type: "button",
							"data-testid": "interaction-submit",
							disabled: I,
							onClick: () => V("submit", { value: x }),
							className: "inline-flex h-8 items-center gap-1.5 rounded-lg bg-[var(--ksadk-interaction-primary-background)] px-3 text-xs font-medium text-[var(--ksadk-interaction-primary-foreground)] shadow-sm transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-55",
							children: "提交"
						})
					})]
				}),
				A.status === "resolving" ? /* @__PURE__ */ _("p", {
					className: "mt-2 text-xs text-[var(--ksadk-interaction-muted)]",
					children: "正在提交，请稍候…"
				}) : null
			]
		})
	});
}
function F({ outcome: e }) {
	return /* @__PURE__ */ _("span", {
		className: i("rounded border px-1.5 py-0.5 text-xs font-medium", e === "approved" ? "border-emerald-300 text-emerald-700 dark:border-emerald-900 dark:text-emerald-300" : e === "rejected" ? "border-rose-300 text-rose-700 dark:border-rose-900 dark:text-rose-300" : "border-slate-300 text-slate-600 dark:border-slate-700 dark:text-slate-300"),
		children: N[e] || e
	});
}
//#endregion
//#region src/utils/context.js
function I(e) {
	if (typeof e == "number" && Number.isFinite(e) && e > 0) return e;
	if (typeof e == "string" && e.trim()) {
		let t = Number(e);
		if (Number.isFinite(t) && t > 0) return t;
	}
	return null;
}
function L(e) {
	return e ? I(e.context_window_tokens) ?? I(e?.limits?.context_window_tokens) : null;
}
function R(e) {
	return e ? I(e.auto_compact_threshold_percentage) ?? 84 : 84;
}
function z({ selectedModel: e, contextUsage: t }) {
	let n = t && (!t.model || t.model === e?.id) ? t : null, r = I(n?.used_tokens), i = I(n?.context_window_tokens), a = i ?? L(e), o = {
		contextWindowTokens: a ?? void 0,
		contextWindowSource: a ? i ? "runtime" : "model" : void 0
	}, s = n?.source === "last_request" ? "上次请求输入" : "上下文占用";
	if (!r) return {
		label: "上下文用量暂不可用",
		phase: "default",
		...o
	};
	let c = a ? Math.round(r / a * 100) : void 0;
	return {
		label: s,
		phase: c !== void 0 && c >= R(e) ? "warning" : "normal",
		percent: c,
		usedTokens: r,
		...o
	};
}
//#endregion
//#region src/components/ui/dialog.tsx
var B = S.Root, V = S.Portal, H = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ _(S.Overlay, {
	ref: n,
	className: i("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", e),
	...t
}));
H.displayName = S.Overlay.displayName;
var U = s.forwardRef(({ className: e, children: t, ...n }, r) => /* @__PURE__ */ v(V, { children: [/* @__PURE__ */ _(H, {}), /* @__PURE__ */ v(S.Content, {
	ref: r,
	className: i("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", e),
	...n,
	children: [t, /* @__PURE__ */ v(S.Close, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ _(h, { className: "h-4 w-4" }), /* @__PURE__ */ _("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
U.displayName = S.Content.displayName;
var W = ({ className: e, ...t }) => /* @__PURE__ */ _("div", {
	className: i("flex flex-col space-y-1.5 text-center sm:text-left", e),
	...t
});
W.displayName = "DialogHeader";
var G = ({ className: e, ...t }) => /* @__PURE__ */ _("div", {
	className: i("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", e),
	...t
});
G.displayName = "DialogFooter";
var K = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ _(S.Title, {
	ref: n,
	className: i("text-lg font-semibold leading-none tracking-tight", e),
	...t
}));
K.displayName = S.Title.displayName;
var q = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ _(S.Description, {
	ref: n,
	className: i("text-sm text-muted-foreground", e),
	...t
}));
q.displayName = S.Description.displayName;
//#endregion
//#region src/components/chat/AttachmentPreview.tsx
function J(e, t) {
	if (!(!t || e)) return {
		width: `min(${t.width}px, calc(100vw - 5rem))`,
		height: `min(${t.height}px, calc(100vh - 9rem))`
	};
}
function Y(e, t) {
	if (!(!t || e)) return { width: `min(${t.width + 32}px, calc(100vw - 3rem))` };
}
function X({ attachment: e, isMobile: t, previewImageSize: n, onClose: r, onImageLoad: a }) {
	return /* @__PURE__ */ _(B, {
		open: !!e?.url,
		onOpenChange: (e) => !e && r(),
		children: /* @__PURE__ */ v(U, {
			className: i("gap-0 overflow-hidden border-slate-700 bg-slate-950 p-0 text-slate-100 shadow-2xl [&>button]:right-3 [&>button]:top-3 [&>button]:rounded-md [&>button]:border [&>button]:border-slate-700 [&>button]:bg-slate-900/70 [&>button]:p-1.5 [&>button]:text-slate-200 [&>button]:opacity-100", t ? "left-0 top-0 h-[var(--app-height)] max-h-[var(--app-height)] w-screen max-w-none translate-x-0 translate-y-0 rounded-none border-0" : "max-h-[calc(100vh-2rem)] max-w-[calc(100vw-2rem)] rounded-2xl"),
			style: Y(t, n),
			children: [/* @__PURE__ */ _("div", {
				className: "flex items-center gap-3 border-b border-slate-800 px-4 py-3 pr-16",
				children: /* @__PURE__ */ _(K, {
					className: "truncate text-sm font-medium",
					children: e?.name || "附件预览"
				})
			}), /* @__PURE__ */ _("div", {
				className: i("flex items-center justify-center overflow-auto bg-slate-950", t ? "h-full p-4 pb-[calc(var(--safe-area-bottom)+1rem)]" : "max-h-[calc(100vh-7rem)] p-4"),
				children: e ? e.type.startsWith("image/") ? /* @__PURE__ */ _("img", {
					src: e.url,
					alt: e.name,
					className: i("object-contain", t ? "h-auto max-h-full w-full max-w-full" : "h-auto w-auto max-h-[calc(100vh-9rem)] max-w-[calc(100vw-5rem)]"),
					style: J(t, n),
					onLoad: (e) => {
						let t = e.currentTarget;
						a({
							width: t.naturalWidth,
							height: t.naturalHeight
						});
					}
				}) : /* @__PURE__ */ _("iframe", {
					src: e.url,
					title: e.name,
					className: "h-full min-h-[24rem] w-full rounded-xl border border-slate-800 bg-white"
				}) : null
			})]
		})
	});
}
//#endregion
export { w as a, P as i, z as n, F as r, X as t };
