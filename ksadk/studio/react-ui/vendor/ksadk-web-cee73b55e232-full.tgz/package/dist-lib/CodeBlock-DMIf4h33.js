import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { t } from "./utils-CX-Pz5p6.js";
import { t as n } from "./clipboard-MB6Ru6h6.js";
import { n as r, t as i } from "./sandbox-BTRIKAO6.js";
import { useEffect as a, useRef as o, useState as s } from "react";
import { Check as c, ChevronDown as l, Copy as u, Download as d, Eye as f, TextWrap as p, X as m } from "lucide-react";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
import { Prism as _ } from "react-syntax-highlighter";
import { vscDarkPlus as v } from "react-syntax-highlighter/dist/esm/styles/prism";
//#region src/components/markdown/CodeBlock.tsx
var y = /* @__PURE__ */ e({ CodeBlock: () => k }), b = new Set(["html", "svg"]), x = new Set(["markdown", "md"]), S = 80, C = 500, w = 100, T = /* @__PURE__ */ new Map(), E = (e) => `len:${e.length}|head:${e.slice(0, 64)}`;
function D(e, t) {
	let n = [], r = "", i = !1;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		o === "\"" ? i && e[a + 1] === "\"" ? (r += "\"", a += 1) : i = !i : o === t && !i ? (n.push(r), r = "") : r += o;
	}
	return n.push(r), n;
}
function O({ value: e, delimiter: t }) {
	let n = e.replace(/\r$/, "").split("\n").filter((e) => e.length > 0).map((e) => D(e, t)), r = n.slice(0, 101), i = r[0] || [], a = r.slice(1, 101);
	return /* @__PURE__ */ g("div", {
		className: "custom-scrollbar max-w-full overflow-auto bg-[#1e1e1e] p-3",
		children: [/* @__PURE__ */ g("table", {
			className: "min-w-max border-collapse text-xs text-slate-200",
			children: [/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ h("tr", { children: i.map((e, t) => /* @__PURE__ */ h("th", {
				className: "border-b border-slate-600 px-3 py-2 text-left font-semibold",
				children: e
			}, `h-${t}`)) }) }), /* @__PURE__ */ h("tbody", { children: a.map((e, t) => /* @__PURE__ */ h("tr", {
				className: "even:bg-white/[0.03]",
				children: e.map((e, n) => /* @__PURE__ */ h("td", {
					className: "border-b border-slate-700/60 px-3 py-1.5 align-top",
					children: e
				}, `c-${t}-${n}`))
			}, `r-${t}`)) })]
		}), n.length > 101 ? /* @__PURE__ */ g("div", {
			className: "mt-2 text-xs text-slate-400",
			children: [
				"已显示前 ",
				w,
				" 行数据，原文件共 ",
				n.length - 1,
				" 行。"
			]
		}) : null]
	});
}
var k = ({ language: e, value: y }) => {
	let [w, D] = s("idle"), [k, A] = s(!1), [j, M] = s("preview"), [N, P] = s(!1), F = E(y), [I, L] = s(() => T.get(F) ?? !1), R = o(null);
	r(R), a(() => {
		if (w === "idle") return;
		let e = window.setTimeout(() => D("idle"), 2e3);
		return () => window.clearTimeout(e);
	}, [w]);
	let z = x.has(e.toLowerCase()), B = () => {
		L((e) => {
			let t = !e;
			return T.set(F, t), t;
		});
	}, V = async () => {
		D(await n(y) ? "copied" : "failed");
	}, H = () => {
		let t = e.toLowerCase(), n = t === "svg" ? "svg" : t === "csv" ? "csv" : t === "tsv" ? "tsv" : "html", r = new Blob([y], { type: n === "svg" ? "image/svg+xml" : n === "html" ? "text/html" : "text/plain" }), i = URL.createObjectURL(r), a = document.createElement("a");
		a.href = i, a.download = `code-block.${n}`, a.click(), URL.revokeObjectURL(i);
	}, U = b.has(e.toLowerCase()), W = ["csv", "tsv"].includes(e.toLowerCase()), G = String(y).replace(/\n$/, "").split("\n"), K = G.length > S, q = N ? G.slice(0, C) : G.slice(0, Math.min(S, C)), J = !W && q.length < G.length, Y = G.length > C, X = q.join("\n"), Z = e.toLowerCase() === "diff", Q = U ? i(y) : "";
	return /* @__PURE__ */ g("div", {
		className: "my-4 rounded-lg overflow-hidden bg-[#1e1e1e] border border-slate-700/50 shadow-sm",
		children: [
			/* @__PURE__ */ g("div", {
				className: "flex items-center justify-between px-4 py-1.5 bg-[#2d2d2d] text-slate-300 text-xs font-mono",
				children: [/* @__PURE__ */ h("span", {
					className: "uppercase",
					children: e || "text"
				}), /* @__PURE__ */ g("div", {
					className: "flex items-center gap-3",
					children: [
						z && /* @__PURE__ */ h("button", {
							type: "button",
							onClick: B,
							title: I ? "取消自动换行" : "自动换行",
							className: t("flex items-center gap-1.5 transition-colors py-1", I ? "text-primary" : "hover:text-white"),
							children: /* @__PURE__ */ h(p, { className: "w-3.5 h-3.5" })
						}),
						K && /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => P((e) => !e),
							title: N ? "折叠代码" : "展开代码",
							"aria-expanded": N,
							className: "flex items-center gap-1.5 py-1 transition-colors hover:text-white",
							children: [/* @__PURE__ */ h(l, { className: t("h-3.5 w-3.5 transition-transform", N && "rotate-180") }), /* @__PURE__ */ h("span", { children: N ? "折叠" : "展开" })]
						}),
						U && /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => {
								M("preview"), A(!0);
							},
							className: "flex items-center gap-1.5 hover:text-white transition-colors py-1",
							children: [/* @__PURE__ */ h(f, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ h("span", { children: "Preview" })]
						}),
						(U || W) && /* @__PURE__ */ g("button", {
							type: "button",
							onClick: H,
							className: "flex items-center gap-1.5 hover:text-white transition-colors py-1",
							title: "下载源文件",
							children: [/* @__PURE__ */ h(d, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ h("span", { children: "Download" })]
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => {
								V();
							},
							className: "flex items-center gap-1.5 hover:text-white transition-colors py-1",
							children: [w === "copied" ? /* @__PURE__ */ h(c, { className: "w-3.5 h-3.5 text-emerald-500" }) : /* @__PURE__ */ h(u, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ h("span", { children: w === "copied" ? "Copied!" : w === "failed" ? "Copy failed" : "Copy" })]
						})
					]
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: t("text-[13.5px]", I ? "whitespace-pre-wrap break-words" : "overflow-x-auto"),
				children: [W ? /* @__PURE__ */ h(O, {
					value: y,
					delimiter: e.toLowerCase() === "tsv" ? "	" : ","
				}) : /* @__PURE__ */ h(_, {
					language: e,
					style: v,
					showLineNumbers: !0,
					wrapLines: Z,
					lineProps: Z ? (e) => {
						let t = q[e - 1] || "";
						return t.startsWith("+") && !t.startsWith("+++") ? { style: {
							backgroundColor: "rgba(34, 197, 94, 0.12)",
							display: "block"
						} } : t.startsWith("-") && !t.startsWith("---") ? { style: {
							backgroundColor: "rgba(244, 63, 94, 0.12)",
							display: "block"
						} } : { style: { display: "block" } };
					} : void 0,
					lineNumberStyle: {
						color: "#64748b",
						minWidth: "2.5em",
						paddingRight: "1em",
						userSelect: "none"
					},
					customStyle: {
						margin: 0,
						padding: "1rem",
						background: "transparent",
						whiteSpace: I ? "pre-wrap" : "pre"
					},
					PreTag: "div",
					children: X
				}), J && /* @__PURE__ */ h("div", {
					className: "border-t border-slate-700/60 px-4 py-2 text-xs text-slate-400",
					children: Y ? `已显示前 ${q.length} 行，文件共 ${G.length} 行，超过单块 ${C} 行上限。` : `已折叠剩余 ${G.length - q.length} 行；点击“展开”查看完整内容。`
				})]
			}),
			k && /* @__PURE__ */ g("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center",
				children: [/* @__PURE__ */ h("div", {
					className: "fixed inset-0 bg-black/80 animate-in fade-in-0",
					onClick: () => A(!1)
				}), /* @__PURE__ */ g("div", {
					className: "relative z-50 flex w-full max-w-4xl flex-col rounded-lg border border-slate-700 bg-white shadow-lg duration-200 animate-in zoom-in-95 dark:bg-slate-900 sm:mx-4",
					children: [/* @__PURE__ */ g("div", {
						className: "flex items-center justify-between border-b border-slate-200 px-4 py-3 dark:border-slate-800",
						children: [/* @__PURE__ */ g("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ g("span", {
								className: "text-sm font-semibold text-slate-900 dark:text-slate-100",
								children: [e.toUpperCase(), " Preview"]
							}), /* @__PURE__ */ g("div", {
								className: "flex rounded-md bg-slate-100 p-0.5 text-xs dark:bg-slate-800",
								children: [/* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => M("preview"),
									className: t("rounded px-2 py-1", j === "preview" && "bg-white shadow-sm dark:bg-slate-700"),
									children: "预览"
								}), /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => M("source"),
									className: t("rounded px-2 py-1", j === "source" && "bg-white shadow-sm dark:bg-slate-700"),
									children: "源码"
								})]
							})]
						}), /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => A(!1),
							className: "rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
							children: [/* @__PURE__ */ h(m, { className: "h-4 w-4 text-slate-500" }), /* @__PURE__ */ h("span", {
								className: "sr-only",
								children: "Close"
							})]
						})]
					}), /* @__PURE__ */ h("div", {
						className: "h-[70vh] min-h-[20rem]",
						children: j === "source" ? /* @__PURE__ */ h("pre", {
							className: "custom-scrollbar h-full overflow-auto bg-[#1e1e1e] p-4 text-xs leading-5 text-slate-200",
							children: /* @__PURE__ */ h("code", { children: y })
						}) : /* @__PURE__ */ h("iframe", {
							ref: R,
							srcDoc: Q,
							sandbox: "allow-scripts allow-downloads",
							title: "HTML Preview",
							className: "h-full w-full border-0 bg-white"
						})
					})]
				})]
			})
		]
	});
};
//#endregion
export { y as n, k as t };
