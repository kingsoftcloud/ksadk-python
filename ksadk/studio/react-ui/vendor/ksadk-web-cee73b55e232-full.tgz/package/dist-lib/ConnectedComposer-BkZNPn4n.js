import { d as e, g as t, h as n, m as r } from "./a2ui-B1x5yNaJ.js";
import { t as i } from "./utils-CX-Pz5p6.js";
import { r as a } from "./InteractionSchemaForm-ChYkHPop.js";
import { n as o } from "./permission-BWNFYYw-.js";
import { i as s, n as c } from "./AttachmentPreview-DxmVrUYz.js";
import { n as l } from "./studio-controller-Bz1aNDRN.js";
import { useCallback as u, useEffect as d, useLayoutEffect as f, useMemo as p, useRef as m, useState as h } from "react";
import { ArrowUp as g, Check as _, ChevronDown as v, FileText as y, Hand as b, ListTodo as x, Paperclip as S, Plus as C, ShieldAlert as w, ShieldCheck as T, Square as E, Target as D, Upload as O } from "lucide-react";
import { Fragment as k, jsx as A, jsxs as j } from "react/jsx-runtime";
//#region src/components/chat/ContextUsageIndicator.tsx
function M({ indicator: e, onCompact: t, disabled: n }) {
	let r = m(null), [a, o] = h(!1), s = m(!1);
	d(() => {
		if (!a) return;
		let e = (e) => {
			e.target instanceof Node && !r.current?.contains(e.target) && (s.current = !1, o(!1));
		}, t = (e) => {
			e.key === "Escape" && (s.current = !1, o(!1), r.current?.querySelector("button")?.focus());
		};
		return document.addEventListener("pointerdown", e, !0), document.addEventListener("keydown", t), () => {
			document.removeEventListener("pointerdown", e, !0), document.removeEventListener("keydown", t);
		};
	}, [a]);
	let [c, l] = h(!1), [u, f] = h(""), p = typeof e.usedTokens == "number" && Number.isFinite(e.usedTokens) && e.usedTokens >= 0, g = p && typeof e.percent == "number" && Number.isFinite(e.percent) ? Math.max(0, Math.min(100, e.percent)) : void 0, _ = async () => {
		if (!(!t || c || n)) {
			l(!0), f("");
			try {
				await t(), f("上下文已压缩");
			} catch (e) {
				f(e instanceof Error ? e.message : "压缩失败，请重试");
			} finally {
				l(!1);
			}
		}
	};
	return /* @__PURE__ */ j("div", {
		ref: r,
		className: "relative flex h-8 w-8 items-center justify-center",
		onPointerEnter: (e) => {
			e.pointerType !== "touch" && o(!0);
		},
		onPointerLeave: () => {
			s.current || o(!1);
		},
		children: [/* @__PURE__ */ A("button", {
			type: "button",
			"aria-label": "上下文用量与压缩",
			"aria-expanded": a,
			onClick: () => {
				s.current = !s.current, o(s.current), f("");
			},
			className: i("flex h-8 w-8 items-center justify-center rounded-full", e.phase === "warning" ? "text-text-primary" : "text-text-muted"),
			children: /* @__PURE__ */ j("svg", {
				width: "16",
				height: "16",
				viewBox: "0 0 16 16",
				"aria-hidden": "true",
				className: c ? "animate-pulse" : void 0,
				style: {
					display: "block",
					flexShrink: 0
				},
				children: [/* @__PURE__ */ A("circle", {
					cx: "8",
					cy: "8",
					r: "6",
					fill: "none",
					stroke: "var(--ksadk-menu-border, #b8bcb5)",
					strokeWidth: "2"
				}), g !== void 0 && /* @__PURE__ */ A("circle", {
					cx: "8",
					cy: "8",
					r: "6",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					pathLength: "100",
					strokeDasharray: `${g} 100`,
					transform: "rotate(-90 8 8)"
				})]
			})
		}), /* @__PURE__ */ j("div", {
			style: {
				background: "var(--ksadk-menu-background, hsl(var(--popover)))",
				borderColor: "var(--ksadk-menu-border, hsl(var(--border)))",
				boxShadow: "var(--ksadk-menu-shadow, 0 18px 44px rgba(15, 23, 42, 0.16))"
			},
			role: a ? "dialog" : void 0,
			"aria-label": a ? "上下文" : void 0,
			className: i("absolute bottom-full right-0 z-30 w-60 rounded-xl border border-border bg-background p-4 text-sm text-foreground shadow-lg", a ? "block" : "hidden"),
			children: [
				/* @__PURE__ */ A("p", {
					className: i("font-medium", c && "waiting-thinking-text"),
					children: c ? "正在压缩上下文…" : p ? e.label : "上下文用量暂不可用"
				}),
				p && /* @__PURE__ */ j("p", {
					className: "mt-1 text-text-secondary",
					children: [`${N(e.usedTokens)} tokens`, e.contextWindowTokens ? ` / ${N(e.contextWindowTokens)}` : ""]
				}),
				e.contextWindowTokens && /* @__PURE__ */ j("p", {
					className: "mt-1 text-text-muted",
					children: [
						"模型窗口：",
						N(e.contextWindowTokens),
						" tokens"
					]
				}),
				p && !e.contextWindowTokens && /* @__PURE__ */ A("p", {
					className: "mt-1 text-text-muted",
					children: "模型窗口大小未报告"
				}),
				g !== void 0 && /* @__PURE__ */ j("p", {
					className: "text-text-muted",
					children: [g, "% 已使用"]
				}),
				a && /* @__PURE__ */ j(k, { children: [
					/* @__PURE__ */ A("button", {
						type: "button",
						onClick: () => void _(),
						disabled: !t || c || n,
						className: "mt-3 w-full rounded-lg border border-border bg-muted px-3 py-2 disabled:opacity-50",
						children: c ? "正在压缩…" : "压缩上下文"
					}),
					/* @__PURE__ */ A("p", {
						className: "mt-2 text-xs text-text-muted",
						children: n ? "请等待当前运行结束" : t ? "压缩模型上下文，保留聊天记录" : "当前会话尚不支持手动压缩"
					}),
					u && /* @__PURE__ */ A("p", {
						role: "status",
						className: "mt-2 text-xs",
						children: u
					})
				] })
			]
		})]
	});
}
function N(e) {
	return new Intl.NumberFormat("zh-CN").format(e);
}
//#endregion
//#region src/components/chat/ExecutionModeMenu.tsx
var P = [{
	value: "plan",
	label: "计划模式",
	description: "先分析并形成可执行计划",
	icon: x
}, {
	value: "goal",
	label: "设定目标",
	description: "朝可验证的停止条件持续推进",
	icon: D
}], F = {
	plan: "计划模式",
	goal: "目标"
};
function I({ attachmentsEnabled: e, mode: t, support: n, onSelectMode: r, onUpload: a }) {
	let [o, s] = h(!1), c = m(null), l = P.filter((e) => n[e.value]);
	return d(() => {
		if (!o) return;
		let e = (e) => {
			c.current && !c.current.contains(e.target) && s(!1);
		}, t = (e) => {
			e.key === "Escape" && s(!1);
		};
		return document.addEventListener("mousedown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("mousedown", e), document.removeEventListener("keydown", t);
		};
	}, [o]), !e && l.length === 0 ? null : /* @__PURE__ */ j("div", {
		ref: c,
		className: "relative flex min-w-0 items-center gap-1",
		children: [
			/* @__PURE__ */ A("button", {
				type: "button",
				onClick: () => s((e) => !e),
				className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-text-secondary transition hover:bg-muted hover:text-text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/25",
				"aria-expanded": o,
				"aria-haspopup": "menu",
				"aria-label": "添加附件或选择执行模式",
				title: "添加附件或选择执行模式",
				children: /* @__PURE__ */ A(C, { className: "h-[19px] w-[19px]" })
			}),
			t ? /* @__PURE__ */ j("button", {
				type: "button",
				onClick: () => s((e) => !e),
				className: i("flex h-8 max-w-[8.5rem] items-center gap-1 rounded-xl px-2 text-[12px] transition", t === "goal" ? "bg-neutral-50 text-neutral-700 hover:bg-neutral-100 dark:bg-neutral-950/40 dark:text-neutral-300" : "text-text-secondary hover:bg-muted hover:text-text-primary"),
				"aria-label": `当前执行模式：${F[t]}`,
				children: [/* @__PURE__ */ A("span", {
					className: "truncate",
					children: F[t]
				}), /* @__PURE__ */ A(v, { className: "h-3.5 w-3.5 shrink-0" })]
			}) : null,
			o ? /* @__PURE__ */ j("div", {
				role: "menu",
				"aria-label": "附件与执行模式",
				className: "absolute bottom-[calc(100%+0.6rem)] left-0 z-40 w-[min(18rem,calc(100vw-2rem))] rounded-xl border border-border/80 bg-popover p-1 shadow-[0_10px_24px_rgba(15,23,42,0.12)]",
				style: {
					backgroundColor: "var(--ksadk-popover, #fff)",
					borderColor: "var(--ksadk-border, rgba(15, 23, 42, 0.12))"
				},
				children: [e ? /* @__PURE__ */ j("button", {
					type: "button",
					role: "menuitem",
					onClick: () => {
						a(), s(!1);
					},
					className: "flex h-10 w-full items-center gap-2 rounded-lg px-2.5 text-left transition hover:bg-muted/70",
					children: [
						/* @__PURE__ */ A(O, { className: "h-4 w-4 shrink-0 text-text-muted" }),
						/* @__PURE__ */ A("span", {
							className: "shrink-0 text-[13px] font-medium text-text-primary",
							children: "上传附件"
						}),
						/* @__PURE__ */ A("span", {
							className: "ml-auto truncate text-[11px] text-text-muted",
							children: "添加文件或图片"
						})
					]
				}) : null, l.map((e) => {
					let n = e.icon, a = t === e.value;
					return /* @__PURE__ */ j("button", {
						type: "button",
						role: "menuitemradio",
						"aria-checked": a,
						onClick: () => {
							r(e.value), s(!1);
						},
						className: i("flex h-10 w-full items-center gap-2 rounded-lg px-2.5 text-left transition", a ? "bg-muted" : "hover:bg-muted/70"),
						children: [
							/* @__PURE__ */ A(n, { className: "h-4 w-4 shrink-0 text-text-muted" }),
							/* @__PURE__ */ A("span", {
								className: "shrink-0 text-[13px] font-medium text-text-primary",
								children: e.label
							}),
							/* @__PURE__ */ A("span", {
								className: "ml-auto truncate text-[11px] text-text-muted",
								children: e.description
							}),
							a ? /* @__PURE__ */ A(_, { className: "h-4 w-4 shrink-0 text-text-primary" }) : null
						]
					}, e.value);
				})]
			}) : null
		]
	});
}
//#endregion
//#region src/components/chat/ModelSettingsMenu.tsx
var L = [
	{
		value: "auto",
		label: "自动"
	},
	{
		value: "enabled",
		label: "开启"
	},
	{
		value: "disabled",
		label: "关闭"
	}
], R = {
	auto: "自动",
	enabled: "开启",
	disabled: "关闭"
};
function z({ availableModels: e, selectedModel: t, thinkingEnabled: n, thinkingMode: r, onSelectModel: a, onSelectThinkingMode: o }) {
	let [s, c] = h(!1), l = m(null), u = e.find((e) => e.id === t)?.display_name || t || "选择模型";
	return d(() => {
		if (!s) return;
		let e = (e) => {
			l.current && !l.current.contains(e.target) && c(!1);
		}, t = (e) => {
			e.key === "Escape" && c(!1);
		};
		return document.addEventListener("mousedown", e), document.addEventListener("keydown", t), () => {
			document.removeEventListener("mousedown", e), document.removeEventListener("keydown", t);
		};
	}, [s]), /* @__PURE__ */ j("div", {
		ref: l,
		className: "relative",
		children: [/* @__PURE__ */ j("button", {
			type: "button",
			onClick: () => c((e) => !e),
			className: "flex h-8 max-w-[15rem] items-center gap-1.5 rounded-xl px-3 text-[13px] text-text-primary transition hover:brightness-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/25",
			style: { background: "var(--ksadk-menu-trigger-background, hsl(var(--muted)))" },
			"aria-expanded": s,
			"aria-haspopup": "menu",
			"aria-label": n ? `模型 ${u}，推理 ${R[r]}` : `模型 ${u}`,
			title: n ? "选择模型与推理设置" : "选择模型",
			children: [
				/* @__PURE__ */ A("span", {
					className: "min-w-0 truncate",
					children: u
				}),
				n ? /* @__PURE__ */ A("span", {
					className: "shrink-0 text-text-muted",
					children: R[r]
				}) : null,
				/* @__PURE__ */ A(v, { className: i("h-3.5 w-3.5 shrink-0 text-text-muted transition-transform", s && "rotate-180") })
			]
		}), s ? /* @__PURE__ */ j("div", {
			role: "menu",
			"aria-label": "选择模型",
			className: "absolute bottom-[calc(100%+0.65rem)] right-0 z-40 w-[min(17rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border p-1.5",
			style: {
				background: "var(--ksadk-menu-background, hsl(var(--popover)))",
				borderColor: "var(--ksadk-menu-border, hsl(var(--border)))",
				boxShadow: "var(--ksadk-menu-shadow, 0 18px 44px rgba(15, 23, 42, 0.16))"
			},
			children: [
				/* @__PURE__ */ A("div", {
					className: "px-2.5 pb-1.5 pt-1 text-[11px] font-medium text-text-muted",
					children: "模型"
				}),
				/* @__PURE__ */ A("div", {
					className: "max-h-[min(45vh,18rem)] overflow-y-auto",
					children: e.map((e) => {
						let n = e.id === t;
						return /* @__PURE__ */ j("button", {
							type: "button",
							role: "menuitemradio",
							"aria-checked": n,
							onClick: () => {
								a(e.id), c(!1);
							},
							className: i("flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-left text-[13px] transition-colors", n ? "bg-muted text-text-primary" : "text-text-secondary hover:bg-muted hover:text-text-primary"),
							children: [/* @__PURE__ */ A("span", {
								className: "min-w-0 flex-1 truncate",
								children: e.display_name || e.id
							}), n ? /* @__PURE__ */ A(_, {
								className: "h-4 w-4 shrink-0",
								"aria-hidden": "true"
							}) : null]
						}, e.id);
					})
				}),
				n ? /* @__PURE__ */ A("div", {
					className: "mt-1 border-t border-border px-1 pt-1.5",
					children: /* @__PURE__ */ j("div", {
						className: "flex items-center justify-between gap-2 px-1.5 pb-1",
						children: [/* @__PURE__ */ A("span", {
							className: "text-[11px] font-medium text-text-muted",
							children: "推理"
						}), /* @__PURE__ */ A("div", {
							className: "flex rounded-lg bg-muted p-0.5",
							children: L.map((e) => /* @__PURE__ */ A("button", {
								type: "button",
								onClick: () => o(e.value),
								className: i("rounded-md px-2 py-1 text-[11px] transition-colors", e.value === r ? "bg-card text-text-primary shadow-sm" : "text-text-muted hover:text-text-primary"),
								children: e.label
							}, e.value))
						})]
					})
				}) : null
			]
		}) : null]
	});
}
//#endregion
//#region src/components/chat/PermissionMenu.tsx
var B = [
	{
		value: "ask",
		label: "请求批准",
		description: "Agent 请求授权时确认",
		icon: b
	},
	{
		value: "risk",
		label: "风险操作需确认",
		description: "仅副作用操作",
		icon: T
	},
	{
		value: "full",
		label: "完全访问",
		description: "不再确认",
		icon: w
	}
], V = {
	ask: "请求批准",
	risk: "风险确认",
	full: "完全访问"
};
function H({ approvalPolicy: e }) {
	let [t, n] = h(!1), r = m(null), a = o((e) => e.permissionMode), s = o((e) => e.setPermissionMode), c = a === "ask" ? b : a === "full" ? w : T, l = p(() => B.filter((t) => !e || e.Modes.includes(t.value)), [e]);
	return d(() => {
		l.some((e) => e.value === a) || s(e?.DefaultMode || l[0]?.value || "risk");
	}, [
		e?.DefaultMode,
		a,
		s,
		l
	]), d(() => {
		if (!t) return;
		let e = (e) => {
			r.current && !r.current.contains(e.target) && n(!1);
		}, i = (e) => {
			e.key === "Escape" && n(!1);
		};
		return document.addEventListener("mousedown", e), document.addEventListener("keydown", i), () => {
			document.removeEventListener("mousedown", e), document.removeEventListener("keydown", i);
		};
	}, [t]), /* @__PURE__ */ j("div", {
		ref: r,
		className: "relative",
		children: [/* @__PURE__ */ j("button", {
			type: "button",
			onClick: () => n((e) => !e),
			className: i("flex h-8 items-center gap-1.5 rounded-xl px-2.5 text-[13px] transition hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/25", a === "full" ? "text-amber-600 dark:text-amber-400" : "text-text-secondary hover:text-text-primary"),
			"aria-expanded": t,
			"aria-haspopup": "menu",
			title: "设置本次会话的工具审批规则",
			children: [
				/* @__PURE__ */ A(c, { className: "h-3.5 w-3.5" }),
				/* @__PURE__ */ A("span", { children: V[a] }),
				/* @__PURE__ */ A(v, { className: i("h-3.5 w-3.5 transition-transform", t && "rotate-180") })
			]
		}), t ? /* @__PURE__ */ A("div", {
			role: "menu",
			"aria-label": "工具权限",
			className: "absolute bottom-[calc(100%+0.6rem)] left-0 z-30 w-[18rem] rounded-xl border border-border/80 bg-popover p-1 shadow-[0_10px_24px_rgba(15,23,42,0.12)]",
			style: {
				backgroundColor: "var(--ksadk-popover, #fff)",
				borderColor: "var(--ksadk-border, rgba(15, 23, 42, 0.12))"
			},
			children: l.map((e) => {
				let t = e.icon, r = e.value === a;
				return /* @__PURE__ */ j("button", {
					type: "button",
					role: "menuitemradio",
					"aria-checked": r,
					onClick: () => {
						s(e.value), n(!1);
					},
					className: i("flex h-10 w-full items-center gap-2 rounded-lg px-2.5 text-left transition-colors", r ? "bg-primary/[0.08]" : "hover:bg-muted/75"),
					children: [
						/* @__PURE__ */ A(t, { className: i("h-4 w-4 shrink-0", r ? "text-primary" : "text-text-muted") }),
						/* @__PURE__ */ A("span", {
							className: i("shrink-0 text-[13px] font-medium", r ? "text-text-primary" : "text-text-secondary"),
							children: e.label
						}),
						/* @__PURE__ */ A("span", {
							className: "ml-auto truncate text-[11px] text-text-muted",
							children: e.description
						}),
						r ? /* @__PURE__ */ A(_, {
							className: "h-4 w-4 shrink-0 text-primary",
							"aria-hidden": "true"
						}) : null
					]
				}, e.value);
			})
		}) : null]
	});
}
//#endregion
//#region src/components/chat/ChatComposer.tsx
function U({ headerSlot: e, onCompactContext: t, attachments: n, composerContextIndicator: o, composerMaxHeight: s, fileInputRef: c, input: l, isMobile: u, isStreaming: d, attachmentsEnabled: f = !0, approvalEnabled: p = !1, approvalPolicy: m, thinkingEnabled: _ = !1, executionMode: v, executionModeSupport: b, queuedDrafts: x, onAppendAttachments: C, onInputChange: w, onSelectExecutionMode: T, onPaste: D, onRemoveAttachment: O, onStopGeneration: k, onCancelRemote: N, onSubmit: P, textareaRef: F, className: L }) {
	let [R, B] = h(!1), V = a(), U = t ? async () => {
		B(!0);
		try {
			await t();
		} finally {
			B(!1);
		}
	} : void 0, W = v === "goal" ? "描述需要持续完成的目标…" : v === "plan" ? "描述需要先规划的任务…" : u ? "发送消息..." : "发送消息…", G = N ? "保留恢复点并结束本次执行" : "停止生成", K = v === "goal" ? !!l.trim() : !!(l.trim() || n.length > 0), q = r((e) => e.availableModels), J = r((e) => e.selectedModel), Y = r((e) => e.thinkingMode), X = r((e) => e.setSelectedModel), ee = r((e) => e.setThinkingMode), Z = (e) => e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1024 / 1024).toFixed(1)} MB`;
	return /* @__PURE__ */ A("div", {
		className: i("relative z-10 flex-shrink-0 bg-background/95 px-3 py-3 backdrop-blur sm:px-4 sm:py-3", L),
		"data-slot": "composer",
		children: /* @__PURE__ */ j("div", {
			className: "mx-auto w-full max-w-[64rem]",
			children: [
				R && /* @__PURE__ */ j("div", {
					role: "status",
					className: "mb-3 flex items-center gap-2 px-2 text-sm text-text-muted",
					children: [/* @__PURE__ */ A(y, {
						size: 16,
						"aria-hidden": "true"
					}), /* @__PURE__ */ A("span", {
						className: "waiting-thinking-text",
						children: "正在压缩上下文"
					})]
				}),
				x.length > 0 ? /* @__PURE__ */ j("div", {
					className: "mb-2 rounded-2xl border border-neutral-200/80 bg-neutral-50/80 px-3 py-2 text-xs text-neutral-900 shadow-sm dark:border-neutral-900/60 dark:bg-neutral-950/30 dark:text-neutral-100",
					children: [/* @__PURE__ */ j("div", {
						className: "mb-1.5 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ j("span", {
							className: "font-semibold",
							children: ["发送队列 · ", x.length]
						}), /* @__PURE__ */ A("span", {
							className: "text-neutral-700/75 dark:text-neutral-200/75",
							children: "当前回复完成后依次发送"
						})]
					}), /* @__PURE__ */ j("div", {
						className: "flex flex-col gap-1",
						children: [x.slice(0, 3).map((e, t) => {
							let n = e.text.trim() || (e.attachments.length > 0 ? "仅附件消息" : "空消息");
							return /* @__PURE__ */ j("div", {
								className: "flex items-center gap-2 rounded-xl bg-background/70 px-2 py-1.5",
								children: [
									/* @__PURE__ */ A("span", {
										className: "flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-neutral-100 font-mono text-[10px] text-neutral-700 dark:bg-neutral-900/50 dark:text-neutral-100",
										children: t + 1
									}),
									/* @__PURE__ */ A("span", {
										className: "min-w-0 flex-1 truncate text-text-secondary",
										children: n
									}),
									e.attachments.length > 0 ? /* @__PURE__ */ j("span", {
										className: "flex-shrink-0 rounded-full bg-neutral-100 px-2 py-0.5 text-[10px] text-neutral-700 dark:bg-neutral-900/50 dark:text-neutral-100",
										children: [e.attachments.length, " 附件"]
									}) : null
								]
							}, `${t}-${n}-${e.attachments.length}`);
						}), x.length > 3 ? /* @__PURE__ */ j("div", {
							className: "px-2 pt-0.5 text-[11px] text-neutral-700/80 dark:text-neutral-200/80",
							children: [
								"还有 ",
								x.length - 3,
								" 条等待发送"
							]
						}) : null]
					})]
				}) : null,
				/* @__PURE__ */ A("div", {
					"data-slot": "composer-surface",
					className: "relative rounded-[var(--chat-composer-radius,28px)] bg-surface shadow-[0_0_0_0.5px_rgba(15,23,42,0.08),0_5px_18px_rgba(15,23,42,0.07)] dark:shadow-[0_0_0_0.5px_rgba(255,255,255,0.06),0_8px_24px_rgba(0,0,0,0.24)]",
					children: /* @__PURE__ */ A("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ j("form", {
							"data-slot": "composer-form",
							onSubmit: (e) => {
								if (e.preventDefault(), R) return;
								if (d) {
									N ? N() : k();
									return;
								}
								let t = l.trim();
								K && P(t, n);
							},
							onDragOver: (e) => {
								e.preventDefault(), e.stopPropagation();
							},
							onDrop: (e) => {
								e.preventDefault(), e.stopPropagation(), f && e.dataTransfer.files && e.dataTransfer.files.length > 0 && C(Array.from(e.dataTransfer.files));
							},
							className: "relative flex min-h-[116px] min-w-0 flex-1 flex-col rounded-[var(--chat-composer-radius,28px)] border border-border/55 bg-background px-4 pb-3 pt-3 transition-all focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/15 sm:px-5",
							children: [
								e == null ? null : /* @__PURE__ */ A("div", {
									"data-slot": "composer-header",
									className: "mb-2 min-w-0",
									children: e
								}),
								n.length > 0 ? /* @__PURE__ */ A("div", {
									className: "mb-1.5 flex flex-wrap gap-2",
									children: n.map((e, t) => /* @__PURE__ */ j("div", {
										className: i("group relative flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-xs", u ? "max-w-full" : "max-w-[14rem]"),
										children: [
											/* @__PURE__ */ A("span", {
												className: "flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-muted text-text-muted",
												children: /* @__PURE__ */ A(S, { className: "h-3.5 w-3.5" })
											}),
											/* @__PURE__ */ j("span", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ A("span", {
													className: "block truncate font-medium text-text-primary",
													children: e.name
												}), /* @__PURE__ */ A("span", {
													className: "block text-[10px] text-text-muted",
													children: Z(e.size)
												})]
											}),
											/* @__PURE__ */ A("button", {
												type: "button",
												onClick: () => O(t),
												className: "absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full border border-border bg-background text-text-muted shadow-sm transition hover:text-rose-500",
												"aria-label": `移除附件 ${e.name}`,
												children: /* @__PURE__ */ A("span", {
													className: "text-[11px] leading-none",
													children: "×"
												})
											})
										]
									}, `${e.name}-${e.size}-${t}`))
								}) : null,
								/* @__PURE__ */ A("textarea", {
									"data-slot": "composer-input",
									ref: F,
									rows: 1,
									value: l,
									onChange: w,
									onKeyDown: (e) => {
										if (e.key === "Enter" && !e.shiftKey) {
											if (V(e)) return;
											if (e.preventDefault(), d) {
												!R && K && P(l.trim(), n);
												return;
											}
											e.currentTarget.form?.requestSubmit();
										}
									},
									onPaste: D,
									placeholder: W,
									className: i("custom-scrollbar max-h-[176px] min-h-[62px] w-full resize-none overflow-y-auto border-0 bg-transparent px-0 pb-1 pt-1 text-[15px] leading-6 text-text-primary outline-none placeholder:text-text-muted/60", u ? "text-[16px]" : "text-[14px]"),
									style: {
										maxHeight: `${s}px`,
										overflowY: "auto"
									}
								}),
								/* @__PURE__ */ j("div", {
									"data-slot": "composer-toolbar",
									className: "mt-auto flex min-h-8 items-center justify-between gap-2 pt-1.5",
									children: [/* @__PURE__ */ j("div", {
										"data-slot": "composer-toolbar-start",
										className: "flex min-w-0 items-center gap-1.5",
										children: [
											/* @__PURE__ */ A("input", {
												ref: c,
												type: "file",
												multiple: !0,
												className: "hidden",
												onChange: (e) => {
													e.target.files && e.target.files.length > 0 && (C(Array.from(e.target.files)), e.target.value = "");
												}
											}),
											/* @__PURE__ */ A(I, {
												attachmentsEnabled: f,
												mode: v,
												support: b,
												onSelectMode: T,
												onUpload: () => c.current?.click()
											}),
											p ? /* @__PURE__ */ A(H, { approvalPolicy: m }) : null
										]
									}), /* @__PURE__ */ j("div", {
										"data-slot": "composer-toolbar-end",
										className: "flex min-w-0 items-center gap-1.5",
										children: [
											o ? /* @__PURE__ */ A(M, {
												indicator: o,
												onCompact: U,
												disabled: d
											}) : null,
											q.length > 0 ? /* @__PURE__ */ A(z, {
												availableModels: q,
												selectedModel: J,
												thinkingEnabled: _,
												thinkingMode: Y,
												onSelectModel: X,
												onSelectThinkingMode: ee
											}) : null,
											/* @__PURE__ */ A("button", {
												type: "submit",
												disabled: R || !d && !K,
												className: i("flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30", d || K ? "bg-[#1f1f1f] text-white hover:opacity-80" : "bg-muted text-text-muted/45"),
												title: d ? G : "发送消息",
												children: d ? /* @__PURE__ */ A(E, { className: "h-3.5 w-3.5 fill-current" }) : /* @__PURE__ */ A(g, { className: "h-[18px] w-[18px]" })
											})
										]
									})]
								})
							]
						})
					})
				})
			]
		})
	});
}
//#endregion
//#region src/utils/attachment.ts
function W(e) {
	return [
		e.name,
		e.size,
		e.lastModified,
		e.type
	].join(":");
}
function G(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(W(t), t);
	for (let e of t) n.set(W(e), e);
	return Array.from(n.values());
}
function K(e) {
	return Array.from(e.clipboardData.items || []).filter((e) => e.kind === "file").map((e) => e.getAsFile()).filter((e) => !!e);
}
//#endregion
//#region src/components/chat/ConnectedComposer.tsx
function q({ draftKey: i, draftStore: a, headerSlot: o, onCompactContext: g, composerMaxHeight: _, submitDraft: v, stopGeneration: y, cancelRemote: b, isMobile: x, attachmentsEnabled: S = !0, approvalEnabled: C = !1, approvalPolicy: w, thinkingEnabled: T = !1, runtimeCapabilityMatrix: E, pendingInteractions: D, onRespondInteraction: O, localCatalog: k, className: M }) {
	let [N, P] = h(0), [F, I] = h(), L = t((e) => e.input), R = t((e) => e.attachments), z = e((e) => e.currentSessionId), B = n((e) => e.isSessionStreaming(z || i)), V = t((e) => e.queuedDrafts), H = e((e) => e.sessions.find((e) => e.SessionId === z)?.ContextUsage), W = r((e) => e.availableModels), q = r((e) => e.selectedModel), J = r((e) => e.setThinkingMode), Y = m(null), X = m(null), [ee] = h(() => new l()), Z = a || ee, te = m(void 0);
	f(() => {
		if (!i) return;
		let e = te.current !== i;
		te.current = i;
		let n = Z.get(i), r = t.getState().input;
		if (!(!e && r.trim())) return t.setState({
			input: n.text,
			attachments: n.attachments
		}), t.subscribe((e, t) => {
			(e.input !== t.input || e.attachments !== t.attachments) && Z.set(i, e.input, e.attachments);
		});
	}, [i, Z]), d(() => !i || !a ? void 0 : Z.subscribe(() => {
		if (Z.getConflict(i)) return;
		let e = Z.get(i), n = t.getState(), r = e.attachments.length === n.attachments.length && e.attachments.every((e, t) => e === n.attachments[t]);
		(e.text !== n.input || !r) && t.setState({
			input: e.text,
			attachments: e.attachments
		});
	}), [
		i,
		a,
		Z
	]);
	let ne = p(() => W.find((e) => e.id === q) || null, [W, q]), re = p(() => c({
		selectedModel: ne,
		contextUsage: H
	}), [ne, H]), ie = p(() => ({
		plan: !!E?.plan?.supported,
		goal: !!E?.goal?.supported
	}), [E]), Q = F && ie[F] ? F : void 0, ae = u((e, n) => {
		!e && n.length === 0 || (t.getState().setInput(""), t.getState().setAttachments([]), v(e, n, void 0, void 0, Q), Q === "goal" && I(void 0));
	}, [Q, v]);
	d(() => {
		X.current && (X.current.style.height = "auto", X.current.style.height = `${Math.min(X.current.scrollHeight, _)}px`);
	}, [L, _]);
	let oe = (e) => {
		t.getState().setInput(e.target.value), e.target.style.height = "auto", e.target.style.height = `${Math.min(e.target.scrollHeight, _)}px`;
	}, se = (e) => {
		!S || !e.length || t.getState().setAttachments((t) => G(t, e));
	}, ce = (e) => {
		if (!S) return;
		let t = K(e);
		t.length && (e.preventDefault(), e.stopPropagation(), se(t));
	}, $ = D || [], le = Math.min(N, Math.max($.length - 1, 0));
	return d(() => {
		T || J("auto");
	}, [J, T]), /* @__PURE__ */ j("div", {
		className: "flex w-full flex-col justify-center",
		children: [$.length > 0 && O ? /* @__PURE__ */ A(s, {
			interactions: $,
			activeIndex: le,
			onSelectIndex: P,
			onRespond: O,
			localCatalog: k
		}) : null, /* @__PURE__ */ A(U, {
			headerSlot: o,
			onCompactContext: z ? g : void 0,
			attachments: R,
			composerContextIndicator: re,
			composerMaxHeight: _,
			fileInputRef: Y,
			input: L,
			isMobile: x,
			isStreaming: B,
			attachmentsEnabled: S,
			approvalEnabled: C,
			approvalPolicy: w,
			thinkingEnabled: T,
			executionMode: Q,
			executionModeSupport: ie,
			queuedDrafts: V,
			onAppendAttachments: se,
			onInputChange: oe,
			onSelectExecutionMode: I,
			onPaste: ce,
			onRemoveAttachment: (e) => t.getState().setAttachments((t) => t.filter((t, n) => n !== e)),
			onStopGeneration: y,
			onCancelRemote: b,
			onSubmit: ae,
			textareaRef: X,
			className: M
		})]
	});
}
//#endregion
export { I as a, z as i, U as n, M as o, H as r, q as t };
