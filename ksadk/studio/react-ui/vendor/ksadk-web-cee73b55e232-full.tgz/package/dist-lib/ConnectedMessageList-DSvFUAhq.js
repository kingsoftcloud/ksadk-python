import { d as e, g as t, h as n, m as r } from "./a2ui-B1x5yNaJ.js";
import { t as i } from "./utils-CX-Pz5p6.js";
import { a, n as o, r as s, t as c } from "./AttachmentPreview-DxmVrUYz.js";
import { c as l, l as u, u as d } from "./feedback-CuC5jRi_.js";
import { a as f, r as p, t as m } from "./MessageMarkdown-Lj01l-_B.js";
import { t as h } from "./tool-display-C9BgteMa.js";
import { t as g } from "./clipboard-MB6Ru6h6.js";
import { useCallback as _, useEffect as v, useLayoutEffect as y, useMemo as b, useRef as x, useState as S } from "react";
import { Bot as C, Check as w, ChevronDown as T, CircleAlert as ee, Copy as E, FileDiff as D, Globe2 as O, LoaderCircle as k, Paperclip as A, RefreshCcw as j, RefreshCw as M, ShieldCheck as N, Sparkles as P, StopCircle as F, ThumbsDown as I, ThumbsUp as L, Trash2 as R, WifiOff as te, Wrench as z, XCircle as B, ZapOff as V } from "lucide-react";
import { Fragment as H, jsx as U, jsxs as W } from "react/jsx-runtime";
//#region src/utils/tool-label.ts
var G = {
	read_workspace_file: "读取文件",
	list_workspace_files: "查看工作区",
	search_workspace: "搜索工作区",
	search_workspace_files: "搜索工作区",
	edit_workspace_file: "编辑文件",
	write_workspace_file: "保存文件",
	run_command: "运行命令",
	browser: "操作浏览器",
	browser_check: "检查页面",
	web_search: "搜索资料",
	web_fetch: "读取网页"
};
function K(e) {
	return Object.hasOwn(G, e) ? G[e] : e;
}
//#endregion
//#region src/utils/parse-unified-diff.ts
var q = /^diff --git "?a\/(.+?)"? "?b\/(.+?)"?$/;
function J(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = null;
	for (let i of e.split("\n")) {
		let e = i.match(q);
		if (e) {
			let a = e[2], o = n.get(a);
			if (o) {
				o.lines.push(i), r = o;
				continue;
			}
			r = {
				oldPath: e[1],
				path: a,
				lines: [i]
			}, n.set(a, r), t.push(r);
			continue;
		}
		r?.lines.push(i);
	}
	return t;
}
function Y(e) {
	let t = 0, n = 0;
	for (let r of e.lines) r.startsWith("+") && !r.startsWith("+++") ? t += 1 : r.startsWith("-") && !r.startsWith("---") && (n += 1);
	return {
		added: t,
		removed: n
	};
}
function X(e) {
	return /^diff --git /m.test(e);
}
//#endregion
//#region src/components/chat/InteractionHistoryAnchor.tsx
function Z(e) {
	if (!e) return "";
	let t = Date.parse(e);
	return Number.isFinite(t) ? new Date(t).toLocaleString() : e;
}
function Q(e) {
	let t = e?.properties;
	return typeof t != "object" || !t ? [] : Object.keys(t);
}
function $({ interaction: e }) {
	if (e.outcome === "cancelled" || e.status === "cancelled") return null;
	let t = e.status === "resolved" || e.status === "expired", n = Q(e.requestSchema);
	return /* @__PURE__ */ W("div", {
		"data-testid": "interaction-history-anchor",
		"data-interaction-id": e.interactionId,
		"data-interaction-status": e.status,
		className: "mt-2 rounded-lg border border-border bg-muted/55 px-3 py-2 text-xs text-text-secondary",
		children: [/* @__PURE__ */ W("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ U("span", {
				className: "font-medium text-text-primary",
				children: e.title
			}), /* @__PURE__ */ U(s, { outcome: e.outcome || e.status })]
		}), t ? /* @__PURE__ */ W(H, { children: [/* @__PURE__ */ W("div", {
			className: "mt-1 leading-relaxed",
			children: [
				e.actor ? /* @__PURE__ */ W("span", { children: [
					"操作人：",
					e.actor,
					" · "
				] }) : null,
				e.resolvedAt ? /* @__PURE__ */ W("span", { children: [
					"决定时间：",
					Z(e.resolvedAt),
					" · "
				] }) : null,
				/* @__PURE__ */ U("span", {
					"data-testid": "interaction-history-response-summary",
					children: e.responseSummary || "响应内容已脱敏"
				})
			]
		}), /* @__PURE__ */ W("details", {
			"data-testid": "interaction-history-detail",
			className: "mt-1",
			children: [/* @__PURE__ */ U("summary", {
				className: "cursor-pointer select-none text-text-muted hover:text-text-primary",
				children: "查看确认快照"
			}), /* @__PURE__ */ W("div", {
				"data-testid": "interaction-history-snapshot",
				className: "mt-1 rounded border border-border bg-card px-2 py-1.5 leading-relaxed text-card-foreground",
				children: [
					/* @__PURE__ */ W("div", { children: ["操作者：", /* @__PURE__ */ U("span", {
						"data-testid": "interaction-history-actor-ref",
						children: e.actor || "—"
					})] }),
					/* @__PURE__ */ W("div", { children: ["决定时间：", Z(e.resolvedAt) || "—"] }),
					/* @__PURE__ */ W("div", { children: ["关键参数：", n.length > 0 ? /* @__PURE__ */ U("span", {
						"data-testid": "interaction-history-schema-keys",
						children: n.join("、")
					}) : /* @__PURE__ */ U("span", { children: "无结构化参数" })] })
				]
			})]
		})] }) : /* @__PURE__ */ W("div", {
			className: "mt-1",
			children: ["状态：", e.status === "pending" ? "待处理（见输入区确认面板）" : "处理中…"]
		})]
	});
}
//#endregion
//#region src/components/chat/ProcessingBlocksView.tsx
function ne({ summary: e, children: t, defaultOpen: n = !1, streaming: r = !1 }) {
	let [a, o] = S(n);
	return /* @__PURE__ */ W("div", {
		className: "mb-1.5",
		children: [/* @__PURE__ */ W("button", {
			type: "button",
			onClick: () => o((e) => !e),
			className: "flex w-full items-center gap-1.5 rounded px-1 py-1 text-left text-[13px] text-slate-500 transition-colors hover:bg-slate-100/70 dark:text-slate-400 dark:hover:bg-slate-800/40",
			children: [r ? /* @__PURE__ */ U(k, { className: "h-3.5 w-3.5 animate-spin text-slate-400" }) : /* @__PURE__ */ U(T, { className: i("h-3.5 w-3.5 text-slate-400 transition-transform", a && "rotate-90") }), /* @__PURE__ */ U("span", {
				className: "min-w-0 flex-1 truncate",
				children: e
			})]
		}), a && /* @__PURE__ */ U("div", {
			className: "mt-1.5 border-l border-slate-200 pl-3.5 dark:border-slate-700/60",
			children: t
		})]
	});
}
function re({ block: e }) {
	let [t, n] = S(!1), r = e.status === "streaming", a = e.content.length, o = `${e.id}-thinking-detail`;
	return /* @__PURE__ */ W("div", {
		className: "mb-1.5 min-w-0",
		children: [/* @__PURE__ */ W("button", {
			type: "button",
			"aria-expanded": t,
			"aria-controls": o,
			onClick: () => n((e) => !e),
			className: "inline-flex max-w-full items-center gap-1.5 rounded px-1 py-1 text-left text-[13px] leading-5 text-slate-400 transition-colors hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300",
			children: [
				!r && /* @__PURE__ */ U(P, { className: "h-3.5 w-3.5 shrink-0" }),
				/* @__PURE__ */ U("span", {
					className: i("min-w-0 truncate", r && "waiting-thinking-text"),
					"data-testid": r ? "thinking-indicator" : void 0,
					role: r ? "status" : void 0,
					children: r ? "正在思考…" : "已思考"
				}),
				!r && /* @__PURE__ */ W(H, { children: [/* @__PURE__ */ U("span", {
					className: "text-slate-300 dark:text-slate-600",
					children: "·"
				}), /* @__PURE__ */ W("span", {
					className: "font-mono text-xs text-slate-400 dark:text-slate-500",
					children: [a, " 字"]
				})] }),
				/* @__PURE__ */ U(T, { className: i("h-3.5 w-3.5 shrink-0 transition-transform", t && "rotate-180") })
			]
		}), t && e.content && /* @__PURE__ */ U("div", {
			id: o,
			className: "custom-scrollbar mt-1.5 max-h-[min(46vh,28rem)] overflow-y-auto border-l border-slate-200/80 pl-3.5 text-[12px] leading-5 text-slate-500 dark:border-slate-700/60 dark:text-slate-400 [&_h1]:!mb-2 [&_h1]:!mt-3 [&_h1]:!text-[13px] [&_h2]:!mb-1.5 [&_h2]:!mt-3 [&_h2]:!text-[12px] [&_h3]:!mb-1 [&_h3]:!mt-2.5 [&_h3]:!text-[12px] [&_li]:!text-[12px] [&_li]:!leading-5 [&_p]:!my-1.5 [&_p]:!text-[12px] [&_p]:!leading-5 [&_p]:!text-slate-500 dark:[&_p]:!text-slate-400 [&_pre]:!my-1.5",
			children: /* @__PURE__ */ U(m, { content: e.content })
		})]
	});
}
function ie({ block: e, tool: t, isStreaming: n, interactionRecord: r, onRespondToApproval: a, onRespondToAguiApproval: o }) {
	let s = t?.status ?? e.status, c = t?.args ?? e.args, l = t?.output ?? e.output, u = e.extra || {}, d = (r?.outcome === "cancelled" || r?.outcome === "expired" || r?.status === "cancelled" || r?.status === "expired" ? "cancelled" : r?.outcome === "rejected" ? "rejected" : r?.outcome === "approved" ? "approved" : void 0) || u.approvalStatus || t?.approvalStatus, f = u.approvalRequestId || t?.approvalRequestId, p = u.approvalMessage || t?.approvalMessage, m = u.approvalProtocol || t?.approvalProtocol, h = u.previousResponseId || t?.previousResponseId, g = s === "running", _ = String(u.summary ?? t?.summary ?? "").trim(), v = Number(u.durationMs ?? t?.durationMs), y = d === "cancelled" || d === "rejected", b = s === "error" && !y, x = s === "paused", S = s === "unknown" ? "状态未知" : b ? "执行失败" : d === "pending" ? "等待确认" : d === "rejected" ? "已拒绝" : d === "cancelled" ? "已取消" : g ? d === "approved" ? "已授权 · 执行中" : "正在运行" : d === "approved" ? "已授权" : x ? "已暂停" : "已完成", C = b ? "text-rose-500 dark:text-rose-400" : x ? "text-amber-500 dark:text-amber-400" : g ? "text-slate-500 dark:text-slate-400" : "text-slate-400 dark:text-slate-500";
	return /* @__PURE__ */ U(ne, {
		streaming: g && !c,
		defaultOpen: d === "pending" || x,
		summary: /* @__PURE__ */ W("span", {
			className: "flex items-center gap-1.5",
			children: [
				/* @__PURE__ */ U(z, { className: i("h-3.5 w-3.5 shrink-0", C) }),
				/* @__PURE__ */ U("span", {
					className: C,
					children: S
				}),
				/* @__PURE__ */ U("span", {
					title: e.toolName,
					className: "truncate font-medium text-slate-600 dark:text-slate-300",
					children: K(e.toolName)
				}),
				_ ? /* @__PURE__ */ W("span", {
					className: "truncate text-slate-400 dark:text-slate-500",
					children: ["· ", _]
				}) : null,
				Number.isFinite(v) && v >= 0 ? /* @__PURE__ */ W("span", {
					className: "shrink-0 font-mono text-[11px] text-slate-400 dark:text-slate-500",
					children: ["· ", ue(v)]
				}) : null,
				g && c && /* @__PURE__ */ U("span", {
					className: "ml-0.5 animate-pulse text-slate-400",
					children: "…"
				})
			]
		}),
		children: /* @__PURE__ */ W("div", {
			className: "flex flex-col gap-2.5 py-1 text-[13px]",
			children: [
				f && d === "pending" && !r && /* @__PURE__ */ W("section", {
					"data-slot": "tool-approval-card",
					className: "flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border border-[var(--ksadk-approval-border)] bg-[var(--ksadk-approval-background)] px-2.5 py-2 font-sans text-[12px] text-[var(--ksadk-approval-foreground)] shadow-[0_1px_2px_rgba(15,23,42,0.03)]",
					children: [/* @__PURE__ */ W("div", {
						className: "flex min-w-0 flex-1 items-center gap-2",
						children: [
							/* @__PURE__ */ U("span", {
								className: "h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--ksadk-approval-foreground)]",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ U("span", {
								className: "shrink-0 font-medium",
								children: "需要确认"
							}),
							/* @__PURE__ */ U("span", {
								className: "min-w-0 truncate opacity-75",
								children: p || "允许后将执行此工具调用。"
							})
						]
					}), /* @__PURE__ */ W("div", {
						className: "flex shrink-0 items-center gap-1.5",
						children: [/* @__PURE__ */ U("button", {
							type: "button",
							disabled: n,
							onClick: () => m === "ag-ui" ? o?.({
								interruptId: f || "",
								approve: !0
							}) : a?.({
								approvalRequestId: f || "",
								approve: !0,
								previousResponseId: h
							}),
							className: "inline-flex h-7 items-center rounded-md bg-primary px-2.5 text-[12px] font-medium text-primary-foreground transition hover:bg-primary/90 disabled:opacity-55",
							children: "允许执行"
						}), /* @__PURE__ */ U("button", {
							type: "button",
							disabled: n,
							onClick: () => m === "ag-ui" ? o?.({
								interruptId: f || "",
								approve: !1
							}) : a?.({
								approvalRequestId: f || "",
								approve: !1,
								previousResponseId: h
							}),
							className: "inline-flex h-7 items-center rounded-md px-2 text-[12px] font-medium text-slate-500 transition hover:bg-slate-100 hover:text-rose-600 disabled:opacity-55 dark:text-slate-400 dark:hover:bg-slate-800",
							children: "拒绝"
						})]
					})]
				}),
				f && d === "pending" && r ? /* @__PURE__ */ W("div", {
					className: "flex items-center gap-1.5 font-sans text-xs text-slate-500 dark:text-slate-400",
					children: [/* @__PURE__ */ U("span", {
						className: "h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400",
						"aria-hidden": "true"
					}), "请在输入区确认面板中操作。"]
				}) : null,
				f && d && d !== "pending" && /* @__PURE__ */ W("div", {
					className: "flex items-center gap-1.5 font-sans text-xs text-slate-500 dark:text-slate-400",
					children: [
						/* @__PURE__ */ U("span", { children: d === "approved" ? "已授权" : d === "cancelled" ? "已取消" : "已拒绝" }),
						d === "approved" && g ? /* @__PURE__ */ U("span", { children: "· 工具执行中" }) : null,
						d === "approved" && b ? /* @__PURE__ */ U("span", { children: "· 工具执行失败" }) : null
					]
				}),
				c ? /* @__PURE__ */ U(de, {
					label: "入参",
					value: c,
					tone: "input"
				}) : null,
				l && !y ? ae(e.toolName, l, b) : null
			]
		})
	});
}
function ae(e, t, n) {
	if (X(t)) return /* @__PURE__ */ U(oe, { output: t });
	let r = e.toLowerCase();
	if (r.includes("web_search") || r.includes("search")) {
		let e = se(t);
		if (e.length > 0) return /* @__PURE__ */ U(ce, { sources: e });
	}
	return /* @__PURE__ */ U(de, {
		label: "输出",
		value: t,
		tone: n ? "error" : "output"
	});
}
function oe({ output: e }) {
	let t = J(e), [n, r] = S(!1), i = n ? t : t.slice(0, 3);
	return /* @__PURE__ */ W("div", {
		className: "my-2 overflow-hidden rounded-xl border border-border bg-background",
		children: [
			/* @__PURE__ */ W("div", {
				className: "flex items-center gap-1.5 border-b border-border px-3 py-2 text-xs font-medium text-text-secondary",
				children: [/* @__PURE__ */ U(D, { className: "h-3.5 w-3.5 text-primary" }), /* @__PURE__ */ W("span", { children: [
					"改动 ",
					t.length,
					" 个文件"
				] })]
			}),
			/* @__PURE__ */ U("div", {
				className: "flex flex-col",
				children: i.map((e) => {
					let { added: t, removed: n } = Y(e);
					return /* @__PURE__ */ W("div", {
						className: "group/file-change-row flex min-w-0 items-center gap-2 px-3 py-2 text-sm transition-colors hover:bg-muted",
						children: [/* @__PURE__ */ U("span", {
							className: "min-w-0 flex-1 truncate font-mono text-[13px] text-text-primary",
							children: e.path
						}), /* @__PURE__ */ W("span", {
							className: "flex-shrink-0 text-[11px] font-mono",
							children: [
								/* @__PURE__ */ W("span", {
									className: "text-emerald-600",
									children: ["+", t]
								}),
								" ",
								/* @__PURE__ */ W("span", {
									className: "text-rose-500",
									children: ["−", n]
								})
							]
						})]
					}, e.path);
				})
			}),
			t.length > 3 ? /* @__PURE__ */ U("button", {
				type: "button",
				onClick: () => r((e) => !e),
				className: "flex w-full items-center justify-center gap-1 border-t border-border py-1.5 text-xs text-text-muted transition hover:bg-muted hover:text-text-primary",
				children: n ? "收起" : `展开剩余 ${t.length - 3} 个文件`
			}) : null
		]
	});
}
function se(e) {
	try {
		let t = JSON.parse(e), n = Array.isArray(t) ? t : t?.results ?? t?.sources ?? [];
		return Array.isArray(n) ? n.map((e) => {
			let t = e, n = String(t?.url ?? t?.link ?? t?.href ?? ""), r = "";
			try {
				let e = new URL(n, typeof window > "u" ? "http://localhost/" : window.location.href).protocol.toLowerCase();
				["http:", "https:"].includes(e) && (r = n);
			} catch {
				r = "";
			}
			let i = String(t?.title ?? t?.name ?? r);
			return r ? {
				url: r,
				title: i
			} : null;
		}).filter((e) => e !== null) : [];
	} catch {
		return [];
	}
}
function ce({ sources: e }) {
	return /* @__PURE__ */ U("div", {
		className: "mt-2 flex min-w-0",
		children: /* @__PURE__ */ W("span", {
			className: "group/web-search-sources relative inline-flex min-w-0",
			children: [/* @__PURE__ */ W("button", {
				type: "button",
				className: "inline-flex h-7 min-w-0 items-center gap-1.5 rounded-md border border-border bg-surface px-2 text-xs text-text-secondary transition-colors hover:bg-muted hover:text-text-primary",
				children: [/* @__PURE__ */ U(O, {
					className: "h-3.5 w-3.5 shrink-0",
					strokeWidth: 1.7
				}), /* @__PURE__ */ W("span", { children: ["来源 · ", e.length] })]
			}), /* @__PURE__ */ U("span", {
				className: "absolute bottom-full left-0 z-30 hidden max-w-[calc(100vw-3rem)] pb-1 group-hover/web-search-sources:block",
				children: /* @__PURE__ */ U("span", {
					className: "block w-[min(26rem,calc(100vw-3rem))] rounded-xl border border-border bg-popover p-2 text-left text-text-primary shadow-2xl",
					children: /* @__PURE__ */ U("span", {
						className: "flex min-w-0 flex-col gap-1",
						children: e.map((e, t) => /* @__PURE__ */ W("a", {
							href: e.url,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "flex min-w-0 items-center gap-2 rounded-lg px-2 py-1.5 text-sm leading-5 text-text-secondary transition-colors hover:bg-muted hover:text-text-primary",
							children: [/* @__PURE__ */ U(O, {
								className: "h-3.5 w-3.5 shrink-0",
								strokeWidth: 1.7
							}), /* @__PURE__ */ U("span", {
								className: "min-w-0 flex-1 truncate",
								children: e.title
							})]
						}, `${e.url}-${t}`))
					})
				})
			})]
		})
	});
}
var le = 12e3;
function ue(e) {
	return e < 1e3 ? `${Math.round(e)}ms` : `${(e / 1e3).toFixed(1)}s`;
}
function de({ label: e, tone: t, value: n }) {
	let [r, a] = S(!1), o = n.length > le, s = o && !r ? n.slice(0, le) : n;
	return /* @__PURE__ */ W("div", { children: [
		/* @__PURE__ */ U("div", {
			className: "mb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400",
			children: e
		}),
		/* @__PURE__ */ U("pre", {
			className: i("custom-scrollbar max-h-60 overflow-auto rounded-lg px-3 py-2 text-[12.5px] leading-relaxed whitespace-pre-wrap break-all", t === "error" ? "bg-rose-50/60 text-rose-700 dark:bg-rose-950/20 dark:text-rose-200" : t === "output" ? "bg-emerald-50/40 text-emerald-800 dark:bg-emerald-950/20 dark:text-emerald-200" : "bg-slate-50 text-slate-700 dark:bg-slate-900/40 dark:text-slate-200"),
			children: f(s).map((e, t) => e.type === "text" ? /* @__PURE__ */ U("span", { children: e.value }, t) : /* @__PURE__ */ U("a", {
				href: "#",
				style: {
					textDecoration: "underline",
					textUnderlineOffset: 2,
					textDecorationColor: "rgba(0,0,0,0.35)"
				},
				title: `预览 ${e.value}`,
				onClick: (t) => {
					t.preventDefault(), p(e.value);
				},
				children: e.value
			}, t))
		}),
		o ? /* @__PURE__ */ U("button", {
			type: "button",
			onClick: () => a((e) => !e),
			className: "mt-1 text-xs text-primary hover:underline",
			"aria-expanded": r,
			children: r ? "收起完整日志" : `查看完整日志（已显示前 ${le.toLocaleString()} 字符）`
		}) : null
	] });
}
function fe({ block: e }) {
	return e.content ? /* @__PURE__ */ U("div", {
		className: "w-full break-words py-0.5 text-[14px] leading-[1.65]",
		children: /* @__PURE__ */ U(m, { content: e.content })
	}) : null;
}
function pe({ message: e, isStreaming: t, onRespondToApproval: n, onRespondToAguiApproval: r, interactionRecords: a, renderProcessingBlock: o, className: s }) {
	let c = e.blocks ?? [];
	return /* @__PURE__ */ U("div", {
		className: i("mb-3 min-w-0", s),
		"data-slot": "processing-blocks",
		children: c.map((i) => {
			let s = o?.(i, e);
			if (s !== void 0) return /* @__PURE__ */ U("div", { children: s }, i.id);
			if (i.type === "thinking") return /* @__PURE__ */ U(re, { block: i }, i.id);
			if (i.type === "tool") {
				let o = i.extra || {}, s = String(o.callId || o.call_id || ""), c = e.tools?.[s || i.toolName], l = String(o.approvalRequestId || c?.approvalRequestId || ""), u = l ? a?.find((e) => e.interactionId === l) : s ? a?.find((e) => String(e.extensions.call_id || "") === s) : void 0;
				return /* @__PURE__ */ W("div", { children: [/* @__PURE__ */ U(ie, {
					block: i,
					tool: c,
					isStreaming: t,
					interactionRecord: u,
					onRespondToApproval: n,
					onRespondToAguiApproval: r
				}), u ? /* @__PURE__ */ U($, { interaction: u }) : null] }, i.id);
			}
			return /* @__PURE__ */ U(fe, { block: i }, i.id);
		})
	});
}
//#endregion
//#region src/components/chat/AgentBlockView.tsx
var me = {
	submitted: "已提交",
	working: "正在处理",
	input_required: "等待输入",
	completed: "已完成",
	failed: "执行失败",
	cancelled: "已取消"
};
function he(e, t) {
	if (typeof e != "number" || typeof t != "number" || !Number.isFinite(e) || !Number.isFinite(t) || e < 0 || t < e) return;
	let n = Math.floor(t - e);
	if (n < 60) return `${n} 秒`;
	let r = Math.floor(n / 60);
	return r < 60 ? `${r} 分 ${n % 60} 秒` : `${Math.floor(r / 60)} 小时 ${r % 60} 分`;
}
function ge({ block: e, actions: t }) {
	let [n, r] = S(!1), [i, a] = S("none"), o = x(!1), s = e.item.payload, c = s.agent, l = s.cancel, u = String(s.status || "submitted"), d = [
		"submitted",
		"working",
		"input_required"
	].includes(u), [f, p] = S(() => Date.now());
	v(() => {
		if (!d || typeof s.started_at != "number" || !Number.isFinite(s.started_at)) return;
		let e = setInterval(() => p(Date.now()), 1e3);
		return () => clearInterval(e);
	}, [d, s.started_at]);
	let h = he(s.started_at, d ? f / 1e3 : s.ended_at), g = {
		sessionId: e.item.sessionId,
		runId: e.item.runId,
		scopeId: String(s.scope_id),
		parentItemId: e.item.parentItemId || ""
	}, _ = l?.request_state && l.request_state !== "none" ? l.request_state : i === "none" ? t?.getCancelRequestState?.(g) || "none" : i, y = {
		processing: "取消请求处理中",
		cancel_requested: "取消请求处理中",
		confirmed: "远程取消已确认",
		local_confirmed: "已取消",
		unknown: "取消结果未知",
		unsupported: "不支持远程取消"
	}, b = async () => {
		if (!o.current) {
			o.current = !0, a("processing");
			try {
				a(await t?.cancel?.(g) || "processing");
			} catch {
				a("unknown");
			} finally {
				o.current = !1;
			}
		}
	};
	return /* @__PURE__ */ W("section", {
		"data-testid": "agent-block",
		className: "mb-3 rounded border border-slate-200 p-3 dark:border-slate-700",
		children: [
			/* @__PURE__ */ W("button", {
				type: "button",
				"aria-expanded": n,
				"aria-label": c?.name || "远程智能体",
				onClick: () => r(!n),
				className: "flex w-full items-center justify-between text-sm",
				children: [/* @__PURE__ */ U("span", { children: c?.name || "远程智能体" }), /* @__PURE__ */ W("span", {
					className: "flex items-center gap-2",
					children: [h && /* @__PURE__ */ U("span", {
						"data-testid": "agent-block-elapsed",
						className: "text-xs text-slate-500",
						"aria-label": `耗时 ${h}`,
						children: h
					}), /* @__PURE__ */ U("span", {
						role: "status",
						children: me[u] || "状态未知"
					})]
				})]
			}),
			e.summary && /* @__PURE__ */ U("p", {
				"data-testid": "agent-block-summary",
				className: "mt-1 line-clamp-2 text-xs text-slate-500",
				children: e.summary
			}),
			y[_] && /* @__PURE__ */ U("p", {
				role: "status",
				"data-testid": "agent-block-cancel-state",
				className: "mt-1 text-xs text-slate-500",
				children: y[_]
			}),
			n && /* @__PURE__ */ W("div", {
				className: "mt-3 space-y-2",
				"data-testid": "agent-block-detail",
				children: [e.messages.map((e) => /* @__PURE__ */ W("div", { children: [e.blocks?.length ? /* @__PURE__ */ U(pe, {
					message: e,
					isStreaming: d
				}) : /* @__PURE__ */ U(m, { content: e.content }), e.attachments?.map((e) => /* @__PURE__ */ U("a", {
					href: e.url,
					rel: "noreferrer",
					target: "_blank",
					children: e.name
				}, e.url))] }, e.id)), d && t?.cancel && l?.capability === "supported" && ["none", "unknown"].includes(_) && /* @__PURE__ */ U("button", {
					type: "button",
					onClick: () => void b(),
					children: "取消远程智能体"
				})]
			})
		]
	});
}
//#endregion
//#region src/components/chat/UserInputBody.tsx
var _e = 120;
function ve({ content: e, messageId: t, revealRequest: n }) {
	let r = x(null), [i, a] = S(!1), [o, s] = S({
		content: e,
		messageId: t,
		revealRequest: n,
		expanded: n !== void 0
	}), c = o.content === e && o.messageId === t && o.revealRequest === n ? o.expanded : n !== void 0, l = `user-input-${t}`;
	return y(() => {
		let e = r.current;
		if (!e) return;
		let t = () => a(e.scrollHeight > 121);
		t();
		let n = typeof ResizeObserver > "u" ? null : new ResizeObserver(t);
		return n?.observe(e), window.addEventListener("resize", t), () => {
			n?.disconnect(), window.removeEventListener("resize", t);
		};
	}, [e, t]), /* @__PURE__ */ W("div", {
		className: "relative min-w-0",
		children: [/* @__PURE__ */ U("div", {
			id: l,
			ref: r,
			"data-slot": "user-input-body",
			className: "whitespace-pre-wrap break-words",
			style: {
				maxHeight: c ? void 0 : _e,
				overflow: c ? void 0 : "hidden",
				maskImage: i && !c ? "linear-gradient(black 70%, transparent)" : void 0
			},
			children: e
		}), i && /* @__PURE__ */ U("div", {
			className: "flex justify-center pt-1",
			children: /* @__PURE__ */ W("button", {
				type: "button",
				"aria-expanded": c,
				"aria-controls": l,
				"aria-label": c ? "收起完整需求" : "展开完整需求",
				onClick: () => s({
					content: e,
					messageId: t,
					revealRequest: n,
					expanded: !c
				}),
				className: "inline-flex items-center gap-1 rounded-full border border-border bg-background px-2 py-1 text-xs text-muted-foreground hover:text-foreground",
				children: [c ? "收起" : "展开完整需求", /* @__PURE__ */ U(T, {
					"aria-hidden": "true",
					className: `h-3 w-3${c ? " rotate-180" : ""}`
				})]
			})
		})]
	});
}
//#endregion
//#region src/components/chat/StatusBanner.tsx
function ye({ onRetry: t }) {
	let r = n((e) => e.banner), a = e((e) => e.currentSessionId);
	if (!r || r.sessionId && r.sessionId !== a) return null;
	let o = r.kind === "rate_limited" ? /* @__PURE__ */ U(be, {
		message: r.message,
		retryAfterSec: r.retryAfterSec
	}, r.createdAt || `${r.sessionId || ""}:${r.retryAfterSec || 0}`) : null, s = {
		rate_limited: {
			icon: /* @__PURE__ */ U(V, { className: "h-4 w-4 text-neutral-500" }),
			bg: "border-neutral-200/70 bg-neutral-50/70 dark:border-neutral-900/40 dark:bg-neutral-950/20",
			text: "text-neutral-700 dark:text-neutral-200",
			label: o
		},
		network: {
			icon: /* @__PURE__ */ U(k, { className: "h-4 w-4 animate-spin text-text-secondary" }),
			bg: "border-border/70 bg-muted/60",
			text: "text-text-secondary",
			label: r.message || "网络异常，正在重连…"
		},
		error: {
			icon: /* @__PURE__ */ U(te, { className: "h-4 w-4 text-rose-500" }),
			bg: "border-rose-200/70 bg-rose-50/70 dark:border-rose-900/40 dark:bg-rose-950/20",
			text: "text-rose-600 dark:text-rose-300",
			label: r.message || "运行失败，请重试"
		}
	}[r.kind];
	return /* @__PURE__ */ W("div", {
		className: i("mx-auto mb-3 flex w-full max-w-3xl items-center gap-2.5 rounded-xl border px-3.5 py-2.5 text-sm shadow-sm", s.bg, s.text),
		role: "status",
		children: [
			s.icon,
			/* @__PURE__ */ U("span", {
				className: "min-w-0 flex-1 truncate",
				children: s.label
			}),
			r.kind === "error" && t ? /* @__PURE__ */ W("button", {
				type: "button",
				onClick: t,
				className: "flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium text-rose-600 transition hover:bg-rose-100 dark:text-rose-300 dark:hover:bg-rose-950/40",
				children: [/* @__PURE__ */ U(M, { className: "h-3 w-3" }), "重试"]
			}) : null
		]
	});
}
function be({ message: e, retryAfterSec: t }) {
	let [n, r] = S(t || 0);
	return v(() => {
		if (!t) return;
		let e = setInterval(() => {
			r((e) => e > 0 ? e - 1 : 0);
		}, 1e3);
		return () => clearInterval(e);
	}, [t]), n > 0 ? `${e}（${n}s 后可重试）` : e;
}
//#endregion
//#region src/utils/session-helpers.ts
function xe(e) {
	return String(e.Title || "").trim() || String(e.FirstPrompt || "").trim() || String(e.LastPrompt || "").trim() || String(e.Summary || "").trim() || "新对话";
}
//#endregion
//#region src/utils/message-virtualization.js
function Se(e, t, n) {
	return Math.max(t, Math.min(n, e));
}
function Ce({ items: e = [], scrollTop: t = 0, viewportHeight: n = 0, overscan: r = 4, defaultItemHeight: i = 120, measuredHeights: a = /* @__PURE__ */ new Map(), getItemKey: o = (e, t) => e?.id || String(t) } = {}) {
	let s = Math.max(0, Number(n) || 0), c = Math.max(0, Number(t) || 0), l = Math.max(0, Number(r) || 0), u = Math.max(1, Number(i) || 120);
	if (!e.length) return {
		startIndex: 0,
		endIndex: 0,
		offsetTop: 0,
		totalHeight: 0,
		visibleItems: []
	};
	let d = e.map((e, t) => {
		let n = o(e, t), r = Number(a.get(n));
		return Number.isFinite(r) && r > 0 ? r : u;
	}), f = Array(e.length), p = 0;
	for (let t = 0; t < e.length; t += 1) f[t] = p, p += d[t];
	let m = p, h = c + s, g = 0;
	for (; g < e.length && f[g] + d[g] <= c;) g += 1;
	let _ = g;
	for (; _ < e.length && f[_] < h;) _ += 1;
	return g = Se(g - l, 0, e.length), _ = Se(Math.max(g + 1, _ + l), 0, e.length), {
		startIndex: g,
		endIndex: _,
		offsetTop: f[g] || 0,
		totalHeight: m,
		visibleItems: e.slice(g, _).map((e, t) => {
			let n = g + t;
			return {
				index: n,
				item: e,
				top: f[n] || 0,
				height: d[n] || u
			};
		})
	};
}
function we({ scrollHeight: e, scrollTop: t, clientHeight: n }) {
	return Math.max(0, e - t - n);
}
function Te(e) {
	return e.scrollHeight > e.clientHeight + 1 && we(e) > 96;
}
//#endregion
//#region src/utils/chat-message-grouping.ts
function Ee(e) {
	return String(e?.runId || e?.invocationId || "").trim();
}
function De(e, t) {
	if (e?.role !== "model" || t.role !== "model") return !1;
	let n = Ee(e);
	return !!(n && n === Ee(t));
}
//#endregion
//#region src/components/chat/ChatMessageList.tsx
var Oe = 140, ke = 4;
function Ae(e) {
	let t = String(e || "").trim().toLowerCase();
	return t === "elevated" ? "高风险" : t === "always" ? "始终确认" : t === "confirm" ? "需确认" : e || "";
}
function je(e) {
	return String(e || "").trim().toLowerCase() === "elevated" ? "border-[var(--ksadk-approval-elevated-border)] bg-[var(--ksadk-approval-elevated-background)] text-[var(--ksadk-approval-elevated-foreground)]" : "border-[var(--ksadk-approval-border)] bg-[var(--ksadk-approval-background)] text-[var(--ksadk-approval-foreground)]";
}
function Me({ messageId: e, top: t, onMeasure: n, children: r, highlighted: i }) {
	let a = x(null);
	return y(() => {
		let r = a.current;
		if (!r) return;
		let i = () => n(e, r.offsetHeight, t);
		if (i(), typeof ResizeObserver > "u") return;
		let o = new ResizeObserver(i);
		return o.observe(r), () => o.disconnect();
	}, [
		e,
		n,
		t
	]), /* @__PURE__ */ U("div", {
		ref: a,
		"data-message-id": e,
		"data-search-target": i || void 0,
		tabIndex: -1,
		style: {
			position: "absolute",
			top: t,
			left: 0,
			right: 0
		},
		children: r
	});
}
function Ne({ agentName: e }) {
	return /* @__PURE__ */ W("div", {
		className: "flex flex-col items-center justify-center min-h-[50vh] px-4",
		children: [
			/* @__PURE__ */ U("div", {
				className: "mb-6 h-16 w-16 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600\n        flex items-center justify-center shadow-lg shadow-blue-500/20",
				children: /* @__PURE__ */ U(C, { className: "h-8 w-8 text-white" })
			}),
			/* @__PURE__ */ U("h2", {
				className: "text-xl font-semibold text-slate-900 dark:text-slate-50",
				children: "有什么我可以帮您的吗？"
			}),
			/* @__PURE__ */ W("p", {
				className: "mt-2 text-sm text-slate-500",
				children: [
					"我是 ",
					e,
					"，由 Ksyun AgentEngine 驱动"
				]
			})
		]
	});
}
function Pe() {
	return /* @__PURE__ */ W("div", {
		className: "mx-auto flex w-full max-w-[44rem] flex-col gap-5 px-2 py-8",
		"aria-label": "正在加载会话历史",
		children: [
			/* @__PURE__ */ U("div", { className: "h-4 w-28 animate-pulse rounded bg-slate-200/80 dark:bg-slate-800" }),
			/* @__PURE__ */ U("div", { className: "h-20 w-4/5 animate-pulse rounded-lg bg-slate-100 dark:bg-slate-900" }),
			/* @__PURE__ */ U("div", { className: "ml-auto h-12 w-3/5 animate-pulse rounded-lg bg-slate-100 dark:bg-slate-900" }),
			/* @__PURE__ */ U("div", { className: "h-16 w-11/12 animate-pulse rounded-lg bg-slate-100 dark:bg-slate-900" })
		]
	});
}
function Fe({ attachments: e, isMobile: t, onOpenAttachmentPreview: n }) {
	let r = (e) => typeof e != "number" || !Number.isFinite(e) || e < 0 ? "" : e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / (1024 * 1024)).toFixed(1)} MB`, a = (e) => {
		let t = e.status === "pending" ? "生成中" : e.status === "failed" ? "生成失败" : "";
		return [
			e.type,
			r(e.sizeBytes),
			t,
			e.runId && `run ${e.runId.slice(0, 12)}`
		].filter(Boolean).join(" · ");
	}, o = (e) => !!(e.artifactId || e.itemId || e.runId || e.sizeBytes != null);
	return /* @__PURE__ */ U("div", {
		className: "mb-3 flex flex-wrap gap-3",
		children: e.map((e, r) => e.type.startsWith("image/") ? e.url ? /* @__PURE__ */ W("div", {
			className: "flex flex-col gap-1",
			children: [/* @__PURE__ */ U("button", {
				type: "button",
				onClick: () => n(e),
				className: i("group relative overflow-hidden rounded-xl border border-slate-200 shadow-sm dark:border-slate-700", t ? "w-full max-w-full" : "max-w-[200px]"),
				children: /* @__PURE__ */ U("img", {
					src: e.url,
					alt: e.name,
					className: i("object-cover transition group-hover:scale-[1.02]", t ? "max-h-[16rem] w-full max-w-full" : "max-h-[200px] max-w-[200px]")
				})
			}), o(e) && /* @__PURE__ */ U("span", {
				className: "max-w-[200px] truncate text-[11px] text-slate-500 dark:text-slate-400",
				title: `来源 item ${e.itemId || "未知"} · run ${e.runId || "未知"}`,
				children: a(e)
			})]
		}, `${e.name}-${r}`) : /* @__PURE__ */ U("div", {
			className: i("flex items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-900/40 dark:text-slate-400", t ? "h-28 w-full" : "h-[120px] w-[200px]"),
			children: e.name
		}, `${e.name}-${r}`) : /* @__PURE__ */ W("div", {
			className: i("flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-100 px-3 py-2 shadow-sm dark:border-slate-700 dark:bg-slate-800", t ? "w-full max-w-full" : "w-max max-w-full"),
			children: [
				/* @__PURE__ */ U(A, { className: "h-4 w-4 flex-shrink-0 text-blue-500" }),
				e.url ? /* @__PURE__ */ U("a", {
					href: e.url,
					target: "_blank",
					rel: "noreferrer",
					className: "truncate text-sm text-slate-700 hover:underline dark:text-slate-300",
					title: e.name,
					children: e.name
				}) : /* @__PURE__ */ U("span", {
					className: "truncate text-sm text-slate-700 dark:text-slate-300",
					title: e.name,
					children: e.name
				}),
				o(e) && /* @__PURE__ */ U("span", {
					className: "text-[11px] text-slate-500 dark:text-slate-400",
					title: `来源 item ${e.itemId || "未知"} · run ${e.runId || "未知"}`,
					children: a(e)
				})
			]
		}, `${e.name}-${r}`))
	});
}
function Ie({ message: e }) {
	return e.contextActivity ? /* @__PURE__ */ W("div", {
		className: "flex items-center gap-2 py-3 text-xs text-neutral-500",
		"data-context-status": e.contextActivity.status,
		role: e.contextActivity.status === "running" ? "status" : void 0,
		children: [
			/* @__PURE__ */ U("span", { className: "h-px flex-1 bg-neutral-200 dark:bg-neutral-800" }),
			e.contextActivity.status === "running" ? /* @__PURE__ */ U(j, { className: "h-3 w-3 animate-spin" }) : null,
			/* @__PURE__ */ U("span", { children: e.content }),
			/* @__PURE__ */ U("span", { className: "h-px flex-1 bg-neutral-200 dark:bg-neutral-800" })
		]
	}) : /* @__PURE__ */ U("div", {
		className: "w-full px-0 py-2 sm:px-4",
		children: /* @__PURE__ */ W("div", {
			className: "mx-auto max-w-3xl rounded-xl border border-neutral-200/70 bg-neutral-50/60 px-4 py-3 text-sm text-neutral-600 dark:border-neutral-800 dark:bg-neutral-900/40 dark:text-neutral-300",
			children: [
				/* @__PURE__ */ W("div", {
					className: "flex items-center gap-2 font-medium",
					children: [e.status === "running" ? /* @__PURE__ */ U(j, { className: "h-4 w-4 animate-spin text-neutral-600 dark:text-neutral-300" }) : e.status === "failed" ? /* @__PURE__ */ U(F, { className: "h-4 w-4 text-rose-600 dark:text-rose-400" }) : e.runOutcome && e.runOutcome.outcome !== "verified" ? /* @__PURE__ */ U(ee, { className: "h-4 w-4 text-amber-600 dark:text-amber-400" }) : /* @__PURE__ */ U(w, { className: "h-4 w-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ U("span", { children: e.content })]
				}),
				e.compactedUntilSeqId ? /* @__PURE__ */ W("div", {
					className: "mt-1 text-xs text-neutral-700/80 dark:text-neutral-200/80",
					children: ["已折叠到会话事件 #", e.compactedUntilSeqId]
				}) : null,
				e.summary ? /* @__PURE__ */ W("details", {
					className: "mt-3 rounded-xl border border-neutral-200/80 bg-white/70 px-3 py-2 dark:border-neutral-900/60 dark:bg-slate-950/40",
					children: [/* @__PURE__ */ U("summary", {
						className: "cursor-pointer select-none text-xs font-medium text-neutral-800 dark:text-neutral-200",
						children: "查看压缩摘要"
					}), /* @__PURE__ */ U("div", {
						className: "mt-2 text-[13px] leading-relaxed text-slate-700 dark:text-slate-200",
						children: /* @__PURE__ */ U(m, { content: e.summary })
					})]
				}) : null
			]
		})
	});
}
function Le({ label: e, tone: t, value: n }) {
	let [r, a] = S("idle"), o = h(n);
	v(() => {
		if (r === "idle") return;
		let e = window.setTimeout(() => a("idle"), 1600);
		return () => window.clearTimeout(e);
	}, [r]);
	let s = async () => {
		a(await g(o) ? "copied" : "failed");
	};
	return /* @__PURE__ */ W("div", { children: [/* @__PURE__ */ W("div", {
		className: "mb-1 flex items-center justify-between gap-2",
		children: [/* @__PURE__ */ U("div", {
			className: i("text-xs font-semibold uppercase", t === "input" ? "text-blue-500" : t === "error" ? "text-rose-500" : "text-emerald-500"),
			children: e
		}), /* @__PURE__ */ W("button", {
			type: "button",
			onClick: () => {
				s();
			},
			className: "inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-slate-500 transition hover:bg-white hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100",
			children: [r === "copied" ? /* @__PURE__ */ U(w, { className: "h-3.5 w-3.5 text-emerald-500" }) : /* @__PURE__ */ U(E, { className: "h-3.5 w-3.5" }), r === "copied" ? "已复制" : r === "failed" ? "复制失败" : "复制"]
		})]
	}), /* @__PURE__ */ U("div", {
		className: "custom-scrollbar max-h-[220px] overflow-y-auto whitespace-pre-wrap break-words rounded-xl border border-slate-200/30 bg-white/70 p-3 text-slate-600 shadow-sm dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-300 sm:max-h-[300px]",
		children: o
	})] });
}
function Re({ isLastMessage: e, isStreaming: t, message: n, onDeleteFeedback: r, onSubmitFeedback: a, alwaysVisible: o = !1 }) {
	let [s, c] = S(!1), [u, d] = S(n.feedback?.comment || ""), f = l(n, t, e), p = !!n.feedback?.pending, m = n.feedback?.rating, h = async () => {
		let e = n.content || "";
		e && g(e);
	};
	return f ? /* @__PURE__ */ W("div", {
		className: i("mt-2 flex flex-col gap-2 transition-opacity duration-150 focus-within:opacity-100", o ? "opacity-100" : "opacity-0 group-hover:opacity-100"),
		children: [
			/* @__PURE__ */ W("div", {
				className: "flex flex-wrap items-center gap-1.5 text-xs text-text-muted",
				children: [
					/* @__PURE__ */ U("button", {
						type: "button",
						onClick: () => {
							h();
						},
						className: "inline-flex items-center gap-1 rounded-full px-2 py-1 font-medium text-text-secondary transition hover:bg-muted hover:text-text-primary",
						title: "复制",
						children: /* @__PURE__ */ U(E, { className: "h-3.5 w-3.5" })
					}),
					/* @__PURE__ */ U("span", {
						className: "text-text-muted/60",
						children: "·"
					}),
					/* @__PURE__ */ U("span", {
						className: "font-medium",
						children: "本次回复有帮助吗？"
					}),
					/* @__PURE__ */ W("button", {
						type: "button",
						disabled: p,
						onClick: () => a({
							message: n,
							rating: "up",
							comment: ""
						}),
						className: i("inline-flex items-center gap-1 rounded-full border px-2.5 py-1 font-medium transition disabled:cursor-not-allowed disabled:opacity-60", m === "up" ? "border-primary/30 bg-primary/10 text-primary" : "border-border bg-background text-text-secondary hover:border-primary/30 hover:text-primary"),
						children: [/* @__PURE__ */ U(L, { className: "h-3.5 w-3.5" }), "有帮助"]
					}),
					/* @__PURE__ */ W("button", {
						type: "button",
						disabled: p,
						onClick: () => {
							d(n.feedback?.comment || ""), c((e) => !e);
						},
						className: i("inline-flex items-center gap-1 rounded-full border px-2.5 py-1 font-medium transition disabled:cursor-not-allowed disabled:opacity-60", m === "down" ? "border-rose-300 bg-rose-50 text-rose-600 dark:border-rose-900/70 dark:bg-rose-950/30 dark:text-rose-300" : "border-border bg-background text-text-secondary hover:border-rose-300 hover:text-rose-600"),
						children: [/* @__PURE__ */ U(I, { className: "h-3.5 w-3.5" }), "需改进"]
					}),
					n.feedback ? /* @__PURE__ */ W("button", {
						type: "button",
						disabled: p,
						onClick: () => r(n),
						className: "inline-flex items-center gap-1 rounded-full border border-transparent px-2 py-1 font-medium text-slate-400 transition hover:border-slate-200 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-60 dark:hover:border-slate-800 dark:hover:text-slate-200",
						children: [/* @__PURE__ */ U(R, { className: "h-3.5 w-3.5" }), "删除反馈"]
					}) : null,
					p ? /* @__PURE__ */ U("span", {
						className: "text-slate-400",
						children: "提交中…"
					}) : null
				]
			}),
			s ? /* @__PURE__ */ W("div", {
				className: "max-w-xl rounded-2xl border border-rose-100 bg-rose-50/60 p-3 shadow-sm dark:border-rose-900/60 dark:bg-rose-950/20",
				children: [/* @__PURE__ */ U("textarea", {
					value: u,
					onChange: (e) => d(e.target.value),
					placeholder: "可以补充哪里不准确、缺失或不符合预期。",
					className: "min-h-[84px] w-full resize-y rounded-xl border border-rose-100 bg-white px-3 py-2 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-rose-300 focus:ring-2 focus:ring-rose-100 dark:border-rose-900/70 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-rose-700 dark:focus:ring-rose-950"
				}), /* @__PURE__ */ W("div", {
					className: "mt-2 flex flex-wrap justify-end gap-2",
					children: [/* @__PURE__ */ U("button", {
						type: "button",
						onClick: () => c(!1),
						className: "rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-500 transition hover:bg-white hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-950 dark:hover:text-slate-100",
						children: "取消"
					}), /* @__PURE__ */ U("button", {
						type: "button",
						disabled: p,
						onClick: () => {
							a({
								message: n,
								rating: "down",
								comment: u
							}), c(!1);
						},
						className: "rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-rose-500 disabled:cursor-not-allowed disabled:opacity-60",
						children: "提交点踩"
					})]
				})]
			}) : m === "down" && n.feedback?.comment ? /* @__PURE__ */ W("div", {
				className: "max-w-xl rounded-xl border border-rose-100 bg-rose-50/50 px-3 py-2 text-xs text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/20 dark:text-rose-200",
				children: ["反馈：", n.feedback.comment]
			}) : null,
			n.feedback?.error ? /* @__PURE__ */ U("div", {
				className: "text-xs text-rose-600 dark:text-rose-300",
				children: n.feedback.error
			}) : null
		]
	}) : null;
}
function ze({ agentName: e, isMobile: t, isStreaming: n, isLastMessage: r, suppressWaitingIndicator: o = !1, showAgentHeader: s, message: c, revealRequest: l, onDeleteFeedback: u, onOpenAttachmentPreview: d, onRespondToApproval: f, onRespondToAguiApproval: p, onSubmitFeedback: h, onSubmitAguiAction: g, interactionRecords: _, agentBlockActions: v, renderProcessingBlock: y }) {
	if (c.role === "user") return /* @__PURE__ */ U("div", {
		className: "mb-3 flex justify-end",
		children: /* @__PURE__ */ W("div", {
			"data-slot": "user-message",
			className: "max-w-[80%] rounded-2xl bg-muted px-3 py-2 text-[14px] leading-relaxed text-foreground",
			children: [c.attachments?.length ? /* @__PURE__ */ U(Fe, {
				attachments: c.attachments,
				isMobile: t,
				onOpenAttachmentPreview: d
			}) : null, /* @__PURE__ */ U(ve, {
				content: c.content || "",
				messageId: c.id,
				revealRequest: l
			})]
		})
	});
	if (c.role === "a2ui" && c.aguiActivity) return /* @__PURE__ */ U(a, {
		surfaceId: c.aguiActivity.surfaceId,
		messages: c.aguiActivity.messages,
		onAction: g
	});
	let b = n && r && !c.content;
	return /* @__PURE__ */ W("div", {
		"data-slot": "assistant-message",
		className: "group mx-auto mb-3 w-full max-w-[60rem] px-2 sm:px-4",
		children: [
			s ? /* @__PURE__ */ W("div", {
				className: "mb-1.5 flex items-center gap-2 text-xs text-text-muted",
				children: [/* @__PURE__ */ U(C, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ U("span", { children: e })]
			}) : null,
			c.attachments?.length ? /* @__PURE__ */ U(Fe, {
				attachments: c.attachments,
				isMobile: t,
				onOpenAttachmentPreview: d
			}) : null,
			c.agentBlock ? /* @__PURE__ */ U(ge, {
				block: c.agentBlock,
				actions: v
			}, c.agentBlock.item.itemId) : c.blocks?.length ? /* @__PURE__ */ U(pe, {
				message: c,
				isStreaming: n,
				onRespondToApproval: f,
				interactionRecords: _,
				onRespondToAguiApproval: p,
				renderProcessingBlock: y
			}) : /* @__PURE__ */ W(H, { children: [
				c.reasoning ? /* @__PURE__ */ W("details", {
					className: "group/details mb-3 overflow-hidden rounded-md border border-slate-200/80 bg-slate-50/60 text-sm text-slate-600 transition-colors open:bg-white dark:border-slate-700/80 dark:bg-slate-900/40 dark:text-slate-300 dark:open:bg-slate-950/30",
					children: [/* @__PURE__ */ W("summary", {
						className: "flex cursor-pointer list-none items-center justify-between gap-3 px-3 py-2 font-medium outline-none marker:hidden",
						children: [/* @__PURE__ */ W("div", {
							className: "flex min-w-0 items-center gap-2",
							children: [
								b ? null : /* @__PURE__ */ U(w, { className: "h-4 w-4 text-slate-400" }),
								/* @__PURE__ */ U("span", {
									className: i("truncate", b && "waiting-thinking-text"),
									"data-testid": b ? "legacy-thinking-indicator" : void 0,
									role: b ? "status" : void 0,
									children: b ? "正在思考…" : "思考过程"
								}),
								b ? null : /* @__PURE__ */ U("span", {
									className: "rounded-full bg-slate-200/70 px-2 py-0.5 text-[11px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300",
									children: "已完成"
								})
							]
						}), /* @__PURE__ */ U(T, { className: "h-4 w-4 flex-shrink-0 text-slate-400 transition-transform group-open/details:rotate-180" })]
					}), /* @__PURE__ */ U("div", {
						className: "border-t border-slate-200/70 bg-white/70 dark:border-slate-800 dark:bg-slate-950/20",
						children: /* @__PURE__ */ U("div", {
							className: "custom-scrollbar max-h-[min(46vh,28rem)] overflow-y-auto px-4 py-3 text-[14px] leading-7 text-slate-600 dark:text-slate-300 [&_p]:my-2 [&_pre]:my-2",
							children: /* @__PURE__ */ U(m, { content: c.reasoning })
						})
					})]
				}) : null,
				c.tools ? Object.values(c.tools).map((e, t) => /* @__PURE__ */ W("details", {
					open: e.approvalStatus === "pending" || e.status === "paused" ? !0 : void 0,
					className: i("group/details mb-2 overflow-hidden rounded-md border text-sm transition-colors", e.status === "paused" ? "border-neutral-200/80 bg-neutral-50/25 text-slate-700 dark:border-neutral-900/60 dark:bg-neutral-950/10 dark:text-slate-200" : e.status === "error" ? "border-rose-200/80 bg-rose-50/25 text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/10 dark:text-rose-200" : "border-slate-200/80 bg-slate-50/40 text-slate-600 dark:border-slate-700/80 dark:bg-slate-900/30 dark:text-slate-300"),
					children: [/* @__PURE__ */ U("summary", {
						className: "flex cursor-pointer list-none items-center justify-between gap-2 px-3 py-2 font-medium",
						children: /* @__PURE__ */ W("div", {
							className: "flex items-center gap-2",
							children: [e.status === "running" ? /* @__PURE__ */ U(j, { className: "h-4 w-4 animate-spin text-slate-500" }) : e.status === "paused" ? /* @__PURE__ */ U(N, { className: "h-4 w-4 text-neutral-500" }) : e.status === "error" ? /* @__PURE__ */ U(B, { className: "h-4 w-4 text-rose-500" }) : /* @__PURE__ */ U(w, { className: "h-4 w-4 text-slate-400" }), /* @__PURE__ */ W("span", { children: [e.approvalStatus === "pending" ? "等待审批：" : e.approvalStatus === "approved" ? "已批准：" : e.approvalStatus === "rejected" ? "已拒绝：" : e.approvalStatus === "cancelled" ? "已取消：" : e.status === "error" ? "工具调用失败：" : "工具调用：", e.name] })]
						})
					}), /* @__PURE__ */ W("div", {
						className: i("flex flex-col gap-3 border-t px-3 py-3 font-mono text-[13px] leading-relaxed", e.status === "paused" ? "border-neutral-200/70 dark:border-neutral-900/60" : e.status === "error" ? "border-rose-200/70 dark:border-rose-900/60" : "border-slate-200/70 dark:border-slate-800"),
						children: [
							e.approvalRequestId ? /* @__PURE__ */ W("div", {
								className: "font-sans text-sm text-slate-700 dark:text-slate-200",
								children: [
									/* @__PURE__ */ U("div", {
										className: "font-medium",
										children: e.approvalStatus === "approved" ? "已批准该工具调用。" : e.approvalStatus === "rejected" ? "已拒绝该工具调用。" : e.approvalStatus === "cancelled" ? "已取消该工具调用。" : e.approvalMessage || "该工具调用需要人工确认后继续。"
									}),
									e.approvalLevel ? /* @__PURE__ */ W("div", {
										className: i("mt-2 inline-flex items-center rounded border px-1.5 py-0.5 text-xs font-medium", je(e.approvalLevel)),
										children: ["审批级别：", Ae(e.approvalLevel)]
									}) : null,
									e.serverLabel ? /* @__PURE__ */ W("div", {
										className: "mt-1 text-xs text-neutral-700/80 dark:text-neutral-200/80",
										children: ["MCP Server: ", e.serverLabel]
									}) : null,
									e.approvalStatus === "pending" ? /* @__PURE__ */ W("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: [/* @__PURE__ */ W("button", {
											type: "button",
											disabled: n || e.approvalStatus !== "pending",
											onClick: () => e.approvalProtocol === "ag-ui" ? p?.({
												interruptId: e.approvalRequestId || "",
												approve: !0
											}) : f({
												approvalRequestId: e.approvalRequestId || "",
												approve: !0,
												previousResponseId: e.previousResponseId
											}),
											className: "inline-flex min-h-8 items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-55",
											children: [/* @__PURE__ */ U(w, { className: "h-3.5 w-3.5" }), "批准并继续"]
										}), /* @__PURE__ */ W("button", {
											type: "button",
											disabled: n || e.approvalStatus !== "pending",
											onClick: () => e.approvalProtocol === "ag-ui" ? p?.({
												interruptId: e.approvalRequestId || "",
												approve: !1
											}) : f({
												approvalRequestId: e.approvalRequestId || "",
												approve: !1,
												previousResponseId: e.previousResponseId
											}),
											className: "inline-flex min-h-8 items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 disabled:cursor-not-allowed disabled:opacity-55 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300 dark:hover:border-rose-800 dark:hover:bg-rose-950/30 dark:hover:text-rose-300",
											children: [/* @__PURE__ */ U(B, { className: "h-3.5 w-3.5" }), "拒绝"]
										})]
									}) : /* @__PURE__ */ W("div", {
										className: "mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400",
										children: [e.approvalStatus === "approved" ? /* @__PURE__ */ U(w, { className: "h-3.5 w-3.5 text-emerald-500" }) : /* @__PURE__ */ U(B, { className: "h-3.5 w-3.5 text-rose-500" }), e.approvalStatus === "approved" ? "已批准" : e.approvalStatus === "cancelled" ? "已取消" : "已拒绝"]
									})
								]
							}) : null,
							e.args ? /* @__PURE__ */ U(Le, {
								label: "入参 (Args)",
								tone: "input",
								value: e.args
							}) : null,
							e.output ? /* @__PURE__ */ U(Le, {
								label: "输出 (Output)",
								tone: e.status === "error" ? "error" : "output",
								value: e.output
							}) : null
						]
					})]
				}, `${e.name}-${t}`)) : null,
				c.tools ? Object.values(c.tools).filter((e) => _?.some((t) => t.interactionId === e.approvalRequestId)).map((e) => /* @__PURE__ */ U($, { interaction: _.find((t) => t.interactionId === e.approvalRequestId) }, `anchor-${e.approvalRequestId}`)) : null,
				/* @__PURE__ */ U("div", {
					"data-slot": "assistant-content",
					className: "w-full break-words",
					children: c.content ? /* @__PURE__ */ U(m, { content: c.content }) : !o && (n && r && !c.reasoning && !c.tools || c.eventType === "optimistic_assistant_placeholder") ? /* @__PURE__ */ U("span", {
						className: "relative mt-1 inline-flex h-4 w-4 items-center justify-center",
						role: "status",
						"aria-label": "正在生成",
						children: /* @__PURE__ */ U("span", { className: "waiting-generation-breathe h-2.5 w-2.5 rounded-full" })
					}) : null
				})
			] }),
			c.aguiActivities?.map((e) => /* @__PURE__ */ U(a, {
				surfaceId: e.surfaceId,
				messages: e.messages,
				onAction: g
			}, e.surfaceId)),
			/* @__PURE__ */ U(Re, {
				isLastMessage: r,
				isStreaming: n,
				message: c,
				onDeleteFeedback: u,
				onSubmitFeedback: h
			})
		]
	});
}
function Be({ agentName: e, showAgentHeader: t = !0, emptyState: n, isMobile: r, isStreaming: a, activity: o, contextIndicator: s, messages: c, showWaitingIndicator: l = !1, isLoadingInitialHistory: u = !1, onDeleteFeedback: d, onOpenAttachmentPreview: f, onRespondToApproval: p, onRespondToAguiApproval: m, onSubmitFeedback: h, onSubmitAguiAction: g, onStopGeneration: C, onCancelRemote: w, agentBlockActions: ee, onScrollToBottom: E, checkpoints: D = [], onResumeCheckpoint: O, interactionRecords: k, scrollRef: A, className: j, revealMessage: M, expandUserInput: N, renderProcessingBlock: P }) {
	let [F, I] = S(0), [L, R] = S(0), [te, z] = S(0), [B, V] = S(/* @__PURE__ */ new Map()), G = x(B);
	y(() => {
		let e = A.current;
		if (!e) return;
		let t = () => {
			I(e.scrollTop), R(e.clientHeight), z(e.scrollHeight);
		};
		if (t(), typeof ResizeObserver > "u") return;
		let n = new ResizeObserver(() => t());
		return n.observe(e), e.firstElementChild instanceof HTMLElement && n.observe(e.firstElementChild), () => n.disconnect();
	}, [A]);
	let K = b(() => Ce({
		items: c,
		scrollTop: F,
		viewportHeight: L,
		overscan: ke,
		defaultItemHeight: Oe,
		measuredHeights: B,
		getItemKey: (e, t) => e?.id || String(t)
	}), [
		B,
		c,
		F,
		L
	]), q = K.visibleItems;
	v(() => {
		if (!M) return;
		let e = A.current, t = c.findIndex((e) => e.id === M.id);
		if (!e || t < 0) return;
		let n = e.style.scrollBehavior;
		e.style.scrollBehavior = "auto";
		let r = 0, i = 0, a = 0, o = -1, s = () => {
			let l = c.slice(0, t).reduce((e, t) => e + (G.current.get(t.id) || Oe), 0);
			e.scrollTop = Math.max(0, l - 24), I(e.scrollTop), R(e.clientHeight);
			let u = Array.from(e.querySelectorAll("[data-message-id]")).find((e) => e.dataset.messageId === M.id);
			if (a = u && Math.abs(o - l) < 1 ? a + 1 : 0, o = l, u && (a >= 3 || i >= 30)) {
				e.scrollTop += u.getBoundingClientRect().top - e.getBoundingClientRect().top - 24, u.focus({ preventScroll: !0 }), e.dispatchEvent(new Event("scroll")), e.style.scrollBehavior = n;
				return;
			}
			++i < 30 ? r = requestAnimationFrame(s) : e.style.scrollBehavior = n;
		};
		return r = requestAnimationFrame(s), () => {
			cancelAnimationFrame(r), e.style.scrollBehavior = n;
		};
	}, [M, A]);
	let J = _((e, t, n) => {
		if (!e || !Number.isFinite(t) || t <= 0) return;
		let r = G.current, i = r.get(e) ?? Oe;
		if (i === t) return;
		let a = new Map(r);
		a.set(e, t), G.current = a, V(a);
		let o = A.current;
		o && n < o.scrollTop && (o.scrollTop += t - i, I(o.scrollTop), z(o.scrollHeight));
	}, [A]), Y = we({
		scrollHeight: te,
		scrollTop: F,
		clientHeight: L
	}), X = Te({
		scrollHeight: te,
		scrollTop: F,
		clientHeight: L
	});
	return /* @__PURE__ */ W("div", {
		ref: A,
		onScroll: (e) => {
			I(e.currentTarget.scrollTop), R(e.currentTarget.clientHeight), z(e.currentTarget.scrollHeight);
		},
		className: i("custom-scrollbar relative min-h-0 flex-1 overflow-y-auto scroll-smooth", r ? "px-3 py-3" : "px-4 py-5", j),
		"data-slot": "message-list",
		style: { overflowAnchor: "none" },
		children: [
			/* @__PURE__ */ U("div", {
				"data-slot": "message-list-content",
				className: "mx-auto flex w-full max-w-[64rem] flex-col pb-6 sm:pb-8",
				children: c.length === 0 && u ? /* @__PURE__ */ U(Pe, {}) : c.length === 0 && !l ? n === void 0 ? /* @__PURE__ */ U(Ne, { agentName: e }) : n : /* @__PURE__ */ W(H, { children: [c.length > 0 && /* @__PURE__ */ U("div", {
					style: { height: K.totalHeight },
					className: "relative",
					children: q.map((n) => /* @__PURE__ */ U(Me, {
						messageId: n.item.id || String(n.index),
						highlighted: n.item.id === M?.id,
						top: n.top,
						onMeasure: J,
						children: n.item.role === "system" ? /* @__PURE__ */ U(Ie, { message: n.item }) : /* @__PURE__ */ U(ze, {
							agentName: e,
							isMobile: r,
							isStreaming: a,
							suppressWaitingIndicator: l,
							isLastMessage: n.index === c.length - 1,
							showAgentHeader: t && !De(c[n.index - 1], n.item),
							message: n.item,
							agentBlockActions: ee,
							renderProcessingBlock: P,
							revealRequest: n.item.id === (N || M)?.id ? (N || M)?.request : void 0,
							onDeleteFeedback: d,
							onOpenAttachmentPreview: f,
							onRespondToApproval: p,
							interactionRecords: k,
							onRespondToAguiApproval: m,
							onSubmitFeedback: h,
							onSubmitAguiAction: g
						})
					}, n.item.id || n.index))
				}), l && /* @__PURE__ */ U("div", {
					className: "mx-auto w-full max-w-[60rem] px-2 sm:px-4",
					role: "status",
					"data-testid": "waiting-first-token",
					children: /* @__PURE__ */ U("span", {
						className: "waiting-thinking-text",
						children: "正在思考…"
					})
				})] })
			}),
			/* @__PURE__ */ U(ye, {}),
			X ? /* @__PURE__ */ U("button", {
				type: "button",
				"aria-label": "回到底部",
				"data-distance-from-bottom": Math.round(Y),
				onClick: () => {
					if (E) {
						E();
						return;
					}
					let e = A.current;
					e && e.scrollTo({
						top: e.scrollHeight,
						behavior: "auto"
					});
				},
				className: "sticky bottom-4 left-1/2 z-20 mx-auto flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full border border-border bg-surface text-text-secondary shadow-[0_8px_24px_rgba(15,23,42,0.12)] transition hover:text-text-primary",
				title: "回到底部",
				children: a ? /* @__PURE__ */ U("span", {
					"aria-hidden": "true",
					className: "flex items-center gap-0.5",
					"data-scroll-indicator": "streaming",
					children: [
						0,
						1,
						2
					].map((e) => /* @__PURE__ */ U("span", {
						className: "h-1 w-1 animate-bounce rounded-full bg-current motion-reduce:animate-none",
						style: { animationDelay: `${e * 120}ms` }
					}, e))
				}) : /* @__PURE__ */ U(T, {
					"aria-hidden": "true",
					className: "h-5 w-5",
					"data-scroll-indicator": "idle"
				})
			}) : null
		]
	});
}
//#endregion
//#region src/utils/session-message-history.ts
function Ve(e) {
	return e.requestedSessionId === e.activeSessionId && e.requestToken === e.activeRequestToken;
}
//#endregion
//#region src/components/chat/ConnectedMessageList.tsx
function He({ agentName: i, emptyState: a, isMobile: s, onDeleteFeedback: l, onSubmitFeedback: f, onRespondToApproval: p, onRespondToAguiApproval: m, onSubmitAguiAction: h, onStopGeneration: g, onCancelRemote: y, agentBlockActions: S, checkpointResumeEnabled: C = !1, onResumeCheckpoint: w, onLoadOlderSessionMessages: T, interactionRecords: ee, className: E, revealMessage: D }) {
	let O = d((e) => e.messages), k = e((e) => e.currentSessionId), A = e((e) => e.isLoadingSessions), j = n((e) => e.isSessionStreaming(k)), M = n((e) => e.getSessionActivity(k)), N = u((e) => e.getSessionCheckpoints(k)), P = e((e) => k ? e.messageHistory[k] : null), F = A || !!P?.isLoadingInitial, I = e((e) => e.sessions.find((e) => e.SessionId === k)?.ContextUsage), L = r((e) => e.availableModels), R = r((e) => e.selectedModel), te = t((e) => e.previewAttachment), z = t((e) => e.previewImageSize), B = x(null), V = x(!0), G = x(!1), K = x(0), q = x(j), J = x(!1), Y = x(null), X = x(!0), Z = x(""), Q = x(D);
	v(() => {
		Q.current = D;
	});
	let $ = b(() => L.find((e) => e.id === R) || null, [L, R]), ne = b(() => o({
		selectedModel: $,
		contextUsage: I
	}), [$, I]), re = O.reduce((e, t, n) => t.role === "user" ? n : e, -1), ie = j && !O.slice(re + 1).some((e) => !!(e.role === "model" && (e.content || e.reasoning || e.blocks?.some((e) => e.type === "text" || e.type === "thinking" ? e.content : !0) || e.attachments?.length || e.a2ui || e.aguiActivity || e.aguiActivities?.length || Object.keys(e.tools || {}).length))), ae = _(() => {
		let e = B.current;
		if (!e) return;
		V.current = !0, G.current = !1;
		let t = e.style.scrollBehavior;
		e.style.scrollBehavior = "auto";
		let n = 0, r = 0, i = -1, a = () => {
			if (B.current === e) {
				if (e.scrollTop = e.scrollHeight, K.current = e.scrollTop, e.dispatchEvent(new Event("scroll")), r = e.scrollHeight === i ? r + 1 : 0, i = e.scrollHeight, n += 1, r >= 3 || n >= 12) {
					e.style.scrollBehavior = t;
					return;
				}
				requestAnimationFrame(a);
			}
		};
		a();
	}, []);
	return v(() => {
		q.current = j;
	}, [j]), v(() => {
		X.current = !0, V.current = !0, G.current = !1, K.current = 0, J.current = !1, Y.current = null, Z.current = "";
	}, [k]), v(() => {
		D && (V.current = !1, G.current = !0, X.current = !1);
	}, [D]), v(() => {
		let e = O.at(-1), t = Z.current;
		Z.current = String(e?.id || ""), e?.role === "user" && e.id !== t && !X.current && ae();
	}, [O, ae]), v(() => {
		let t = B.current;
		if (!t) return;
		let n = () => {
			let n = t.scrollHeight - t.scrollTop - t.clientHeight, r = t.scrollTop < K.current - 2;
			if (K.current = t.scrollTop, !X.current && r && t.scrollTop < 200 && k && P?.hasMore && !P.isLoadingOlder && !J.current && T) {
				let n = t.scrollHeight, r = k, i = Symbol(r);
				J.current = !0, Y.current = i, T(r).then(() => {
					Ve({
						requestedSessionId: r,
						activeSessionId: e.getState().currentSessionId,
						requestToken: i,
						activeRequestToken: Y.current
					}) && requestAnimationFrame(() => {
						if (!Ve({
							requestedSessionId: r,
							activeSessionId: e.getState().currentSessionId,
							requestToken: i,
							activeRequestToken: Y.current
						})) return;
						let t = B.current;
						if (!t) return;
						let a = t.scrollHeight - n;
						t.scrollTop += a, K.current = t.scrollTop;
					});
				}).finally(() => {
					Y.current === i && (Y.current = null, J.current = !1);
				});
			}
			if (q.current && r) {
				G.current = !0, V.current = !1;
				return;
			}
			if (G.current) {
				let e = n <= 12;
				G.current = !e, V.current = e;
				return;
			}
			V.current = n < 96;
		};
		return n(), t.addEventListener("scroll", n, { passive: !0 }), () => t.removeEventListener("scroll", n);
	}, [
		P,
		k,
		T
	]), v(() => {
		let e = B.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver(() => {
			!X.current && !V.current || (e.scrollTop = e.scrollHeight, K.current = e.scrollTop, e.dispatchEvent(new Event("scroll")));
		});
		return t.observe(e), e.firstElementChild instanceof HTMLElement && t.observe(e.firstElementChild), () => t.disconnect();
	}, [k]), v(() => {
		let t = B.current;
		if (t) {
			if (O.length > 0 && X.current) {
				let t = Q.current, n = e.getState().currentSessionId, r = B.current, i = r ? r.style.scrollBehavior : "";
				r && (r.style.scrollBehavior = "auto", r.scrollTop = r.scrollHeight, K.current = r.scrollTop);
				let a = 0, o = r?.scrollHeight ?? -1, s = !1, c = 0, l = () => {
					let e = B.current;
					e && (e.scrollTop = e.scrollHeight, K.current = e.scrollTop, e.dispatchEvent(new Event("scroll")));
				}, u = () => {
					if (!s) {
						if (s = !0, Q.current !== t) {
							r && (r.style.scrollBehavior = i);
							return;
						}
						l(), r && (r.style.scrollBehavior = i), V.current = !0, G.current = !1, X.current = !1;
					}
				}, d = () => {
					if (s) return;
					if (Q.current !== t) {
						u();
						return;
					}
					if (e.getState().currentSessionId !== n) {
						s = !0;
						return;
					}
					let r = B.current;
					if (r) {
						if (r.scrollHeight !== o) o = r.scrollHeight, l(), a = 0;
						else if (a += 1, a >= 3) {
							u();
							return;
						}
						c = requestAnimationFrame(d);
					}
				}, f = window.setTimeout(u, 2e3);
				return c = requestAnimationFrame(d), () => {
					if (cancelAnimationFrame(c), window.clearTimeout(f), e.getState().currentSessionId !== n) {
						u();
						return;
					}
					r && (r.style.scrollBehavior = i);
				};
			}
			V.current && (t.scrollTop = t.scrollHeight, K.current = t.scrollTop);
		}
	}, [
		O,
		j,
		D
	]), /* @__PURE__ */ W(H, { children: [/* @__PURE__ */ U(Be, {
		revealMessage: D,
		emptyState: a,
		agentName: i,
		isMobile: s,
		isStreaming: j,
		activity: M,
		contextIndicator: ne,
		messages: O,
		showWaitingIndicator: ie,
		isLoadingInitialHistory: F,
		onDeleteFeedback: l,
		onOpenAttachmentPreview: (e) => {
			t.getState().setPreviewAttachment(e), t.getState().setPreviewImageSize(null);
		},
		onRespondToApproval: p,
		onRespondToAguiApproval: m,
		interactionRecords: ee,
		onScrollToBottom: ae,
		onSubmitFeedback: f,
		onSubmitAguiAction: h,
		onStopGeneration: g,
		onCancelRemote: y,
		agentBlockActions: S,
		checkpoints: C ? N : [],
		onResumeCheckpoint: w,
		scrollRef: B,
		className: E
	}), /* @__PURE__ */ U(c, {
		attachment: te,
		isMobile: s,
		previewImageSize: z,
		onClose: () => {
			t.getState().setPreviewAttachment(null), t.getState().setPreviewImageSize(null);
		},
		onImageLoad: (e) => t.getState().setPreviewImageSize(e)
	})] });
}
//#endregion
export { ge as a, ye as i, Be as n, pe as o, xe as r, $ as s, He as t };
