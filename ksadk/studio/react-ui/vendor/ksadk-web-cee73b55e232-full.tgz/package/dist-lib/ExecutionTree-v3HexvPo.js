import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { a as t, o as n, t as r } from "./presentation-yYw7xK60.js";
import { memo as i, useMemo as a, useState as o } from "react";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/components/teams/ExecutionTree.tsx
var u = /* @__PURE__ */ e({
	ExecutionTree: () => m,
	InvocationTree: () => g,
	MemberTimeline: () => h
}), d = 228, f = 104, p = 72, m = i(function({ tasks: e, members: i, selectedTaskId: u, onSelect: m, execution: _, executionLoading: v, executionError: y, onRetryExecution: b, onSelectNode: x }) {
	let [S, C] = o("graph"), [w, T] = o(200), E = a(() => {
		let { levels: n, invalidIds: r } = t(e);
		return {
			nodes: n.flatMap((e, t) => e.map((e, n) => ({
				task: e,
				x: 32 + t * 300,
				y: 32 + n * 132
			}))),
			invalidIds: r,
			width: Math.max(640, n.length * 300),
			height: Math.max(260, Math.max(0, ...n.map((e) => e.length)) * 132 + 64)
		};
	}, [e]), D = E.nodes.slice(0, w), O = new Map(D.map((e) => [e.task.taskId, e]));
	return /* @__PURE__ */ l("div", {
		className: "team-execution",
		children: [
			/* @__PURE__ */ l("nav", {
				className: "team-view-switch",
				"aria-label": "执行视图",
				children: [
					/* @__PURE__ */ c("button", {
						type: "button",
						"aria-pressed": S === "graph",
						onClick: () => C("graph"),
						children: "任务依赖"
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						"aria-pressed": S === "list",
						onClick: () => C("list"),
						children: "任务列表"
					}),
					/* @__PURE__ */ c("button", {
						type: "button",
						"aria-pressed": S === "timeline",
						onClick: () => C("timeline"),
						children: "成员时间线"
					}),
					(_ || v || y || b) && /* @__PURE__ */ c("button", {
						type: "button",
						"aria-pressed": S === "invocations",
						onClick: () => C("invocations"),
						children: "执行调用"
					})
				]
			}),
			S === "invocations" ? /* @__PURE__ */ c(g, {
				execution: _,
				loading: v,
				error: y,
				onRetry: b,
				onSelect: x
			}) : e.length ? S === "list" ? /* @__PURE__ */ c("div", {
				className: "team-execution-list",
				children: e.slice(0, w).map((e) => /* @__PURE__ */ l("button", {
					type: "button",
					onClick: () => m(e),
					"aria-pressed": u === e.taskId,
					children: [
						/* @__PURE__ */ c("strong", { children: e.title }),
						/* @__PURE__ */ c("span", { children: i.find((t) => t.memberId === e.ownerMemberId)?.name || "待分派" }),
						/* @__PURE__ */ c("span", {
							className: "team-status",
							"data-status": e.status,
							children: r[e.status]
						}),
						/* @__PURE__ */ c("small", { children: n(e) })
					]
				}, e.taskId))
			}) : S === "timeline" ? /* @__PURE__ */ c(h, {
				tasks: e,
				members: i,
				onSelect: m
			}) : /* @__PURE__ */ l(s, { children: [
				/* @__PURE__ */ c("p", {
					className: "team-graph-caption",
					children: "任务依赖决定等待顺序。选择任务查看执行与交付证据。"
				}),
				!!E.invalidIds.length && /* @__PURE__ */ c("p", {
					className: "team-inline-error",
					role: "alert",
					children: "部分任务依赖缺失或存在循环，请通过任务列表检查。"
				}),
				/* @__PURE__ */ c("div", {
					className: "team-graph-scroll",
					tabIndex: 0,
					"aria-label": "任务依赖图，可滚动查看",
					children: /* @__PURE__ */ l("svg", {
						width: E.width,
						height: E.height,
						role: "group",
						"aria-label": "真实任务依赖关系",
						children: [D.flatMap((e) => e.task.dependencies.map((t) => {
							let n = O.get(t);
							if (!n) return null;
							let r = n.x + d, i = n.y + f / 2, a = e.y + f / 2;
							return /* @__PURE__ */ c("path", {
								d: `M ${r} ${i} C ${r + p / 2} ${i}, ${e.x - p / 2} ${a}, ${e.x} ${a}`,
								className: "team-graph-edge",
								"aria-label": `${n.task.title} 完成后可开始 ${e.task.title}`
							}, `${t}:${e.task.taskId}`);
						})), D.map((e) => /* @__PURE__ */ c("foreignObject", {
							x: e.x,
							y: e.y,
							width: d,
							height: f,
							children: /* @__PURE__ */ l("button", {
								type: "button",
								className: "team-graph-node",
								"data-status": e.task.status,
								"aria-pressed": u === e.task.taskId,
								onClick: () => m(e.task),
								children: [
									/* @__PURE__ */ c("span", {
										className: "team-status",
										"data-status": e.task.status,
										children: r[e.task.status]
									}),
									/* @__PURE__ */ c("strong", { children: e.task.title }),
									/* @__PURE__ */ l("small", { children: [i.find((t) => t.memberId === e.task.ownerMemberId)?.name || "待分派", n(e.task) ? ` · ${n(e.task)}` : ""] })
								]
							})
						}, e.task.taskId))]
					})
				})
			] }) : /* @__PURE__ */ l("div", {
				className: "team-empty",
				children: [/* @__PURE__ */ c("h3", { children: "尚无执行数据" }), /* @__PURE__ */ c("p", { children: "团队建立任务后，真实依赖与执行状态会显示在这里。" })]
			}),
			e.length > w && S !== "timeline" && /* @__PURE__ */ l("button", {
				className: "team-button team-history-more",
				type: "button",
				onClick: () => {
					C("list"), T((e) => e + 200);
				},
				children: [
					"已展示 ",
					Math.min(w, e.length),
					" / ",
					e.length,
					" 项，继续查看列表"
				]
			})
		]
	});
});
function h({ tasks: e, members: t, onSelect: i }) {
	return /* @__PURE__ */ c("div", {
		className: "team-member-timeline",
		children: t.map((t) => {
			let a = e.filter((e) => e.ownerMemberId === t.memberId);
			return /* @__PURE__ */ l("section", { children: [/* @__PURE__ */ l("h3", { children: [t.name, /* @__PURE__ */ c("span", { children: t.role === "leader" ? "Leader" : "成员" })] }), a.length ? a.map((e) => {
				let t = e.attempts.at(-1), a = t?.startedAt ? new Date(t.startedAt) : null, o = t?.endedAt ? new Date(t.endedAt) : null, s = a && o && Number.isFinite(a.getTime()) && Number.isFinite(o.getTime()) && o >= a ? Math.round((o.getTime() - a.getTime()) / 1e3) : null;
				return /* @__PURE__ */ l("button", {
					type: "button",
					className: "team-timeline-task",
					onClick: () => i(e),
					children: [
						/* @__PURE__ */ c("span", {
							className: "team-status",
							"data-status": e.status,
							children: r[e.status]
						}),
						/* @__PURE__ */ c("strong", { children: e.title }),
						/* @__PURE__ */ l("span", { children: [a ? a.toLocaleTimeString() : "尚未开始", o ? ` → ${o.toLocaleTimeString()}` : a ? " → 尚无结束事件" : ""] }),
						s !== null && /* @__PURE__ */ l("small", { children: [s, " 秒"] }),
						n(e) && /* @__PURE__ */ c("p", { children: n(e) })
					]
				}, e.taskId);
			}) : /* @__PURE__ */ c("p", {
				className: "team-muted",
				children: "当前未分派任务"
			})] }, t.memberId);
		})
	});
}
function g({ execution: e, loading: t, error: i, onRetry: a, onSelect: s }) {
	let [u, d] = o(200), f = e?.nodes ?? [], p = [], m = /* @__PURE__ */ new Set(), h = (e, t) => {
		m.has(e.nodeId) || p.length >= u || (m.add(e.nodeId), p.push({
			node: e,
			depth: t
		}), t < 30 && f.filter((t) => t.parentNodeId === e.nodeId).forEach((e) => h(e, t + 1)));
	};
	f.filter((e) => !e.parentNodeId || !f.some((t) => t.nodeId === e.parentNodeId)).forEach((e) => h(e, 0)), f.filter((e) => !m.has(e.nodeId)).forEach((e) => h(e, 0));
	let g = {
		task: "任务",
		run: "成员执行",
		child_invocation: "子执行"
	}, _ = {
		running: "进行中",
		waiting: "等待中",
		awaiting_approval: "待审批",
		queued: "排队中",
		idle: "空闲",
		succeeded: "已完成",
		failed: "失败",
		cancelled: "已取消",
		interrupted: "已中断",
		unavailable: "不可用"
	};
	return /* @__PURE__ */ l("section", {
		className: "team-invocations",
		"aria-label": "真实执行调用链",
		children: [
			/* @__PURE__ */ c("p", {
				className: "team-graph-caption",
				children: "执行与子调用来自运行记录；没有执行来源的任务仍是计划。"
			}),
			t && /* @__PURE__ */ c("p", {
				role: "status",
				className: "team-muted",
				children: "正在读取执行记录…"
			}),
			i && /* @__PURE__ */ l("p", {
				role: "alert",
				className: "team-inline-error",
				children: [
					i,
					" ",
					a && /* @__PURE__ */ c("button", {
						className: "team-text-button",
						onClick: a,
						children: "重试"
					})
				]
			}),
			!f.length && !t && !i && /* @__PURE__ */ c("p", {
				className: "team-muted",
				children: "尚无已登记的执行调用。"
			}),
			/* @__PURE__ */ c("ol", {
				className: "team-invocation-list",
				children: p.map(({ node: e, depth: t }) => /* @__PURE__ */ c("li", {
					style: { paddingInlineStart: Math.min(t, 10) * 14 },
					children: /* @__PURE__ */ l("button", {
						type: "button",
						className: "team-invocation-node",
						"data-kind": e.kind,
						"data-planned": e.kind === "task" && !e.source,
						onClick: () => s?.(e),
						disabled: !s || !e.taskId && !e.source,
						children: [
							/* @__PURE__ */ l("span", {
								className: "team-eyebrow",
								children: [g[e.kind], e.kind === "task" && !e.source ? " · 尚未执行" : ""]
							}),
							/* @__PURE__ */ c("strong", { children: e.title }),
							/* @__PURE__ */ c("span", {
								className: "team-status",
								"data-status": e.status,
								children: (e.kind === "task" ? r[e.status] : _[e.status]) || e.status
							}),
							(e.kind === "task" ? n(e) : e.reason) && /* @__PURE__ */ c("small", { children: e.kind === "task" ? n(e) : e.reason })
						]
					})
				}, e.nodeId))
			}),
			f.length > u && /* @__PURE__ */ c("button", {
				className: "team-button",
				onClick: () => d((e) => e + 200),
				children: "继续查看执行记录"
			})
		]
	});
}
//#endregion
export { h as i, u as n, g as r, m as t };
