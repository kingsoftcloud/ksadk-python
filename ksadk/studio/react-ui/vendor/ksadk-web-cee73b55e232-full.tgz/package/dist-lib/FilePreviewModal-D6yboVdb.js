import { n as e, t } from "./MessageMarkdown-Lj01l-_B.js";
import { useEffect as n, useState as r } from "react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/components/workspace/FilePreviewModal.tsx
var o = (e) => fetch(`/api/v1/workspace/file?path=${encodeURIComponent(e)}`, { headers: { Accept: "application/json" } });
async function s(e, t) {
	let n = await fetch(`/api/v1/workspace/file?path=${encodeURIComponent(e)}&download=true`);
	if (!n.ok) throw Error(`下载失败（${n.status}）`);
	let r = await n.blob(), i = URL.createObjectURL(r), a = document.createElement("a");
	a.href = i, a.download = t, a.click(), URL.revokeObjectURL(i);
}
function c({ path: e, fetchFile: o }) {
	let [s, c] = r({
		payload: null,
		error: "",
		busy: !0
	});
	n(() => {
		let t = new AbortController(), n = !0;
		return o(e).then(async (e) => {
			let t = await e.json().catch(() => null);
			if (!e.ok) throw Error(t?.error?.message || t?.detail || `预览失败（${e.status}）`);
			return t;
		}).then((e) => {
			n && c({
				payload: e,
				error: "",
				busy: !1
			});
		}).catch((e) => {
			n && !t.signal.aborted && c({
				payload: null,
				error: e instanceof Error ? e.message : "预览失败。",
				busy: !1
			});
		}), () => {
			n = !1, t.abort();
		};
	}, [e, o]);
	let l = s.payload;
	return /* @__PURE__ */ a("div", {
		style: {
			minHeight: 0,
			flex: "1 1 auto",
			overflow: "auto",
			padding: "16px 20px",
			fontSize: 14,
			lineHeight: 1.65,
			color: "#1f2937"
		},
		children: [
			s.busy && /* @__PURE__ */ a("p", {
				role: "status",
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8,
					color: "#6b7280",
					fontSize: 13
				},
				children: [
					/* @__PURE__ */ i("span", {
						"aria-hidden": !0,
						style: {
							width: 15,
							height: 15,
							borderRadius: "50%",
							border: "2px solid #d1d5db",
							borderTopColor: "#0091ea",
							display: "inline-block",
							animation: "ksadk-fp-spin 0.8s linear infinite"
						}
					}),
					"正在加载文件…",
					/* @__PURE__ */ i("style", { children: "@keyframes ksadk-fp-spin { to { transform: rotate(360deg); } }" })
				]
			}),
			!s.busy && s.error && /* @__PURE__ */ i("p", {
				role: "alert",
				style: {
					margin: 0,
					color: "#b91c1c",
					fontSize: 13
				},
				children: s.error
			}),
			!s.busy && !s.error && l?.mediaCategory === "markdown" && /* @__PURE__ */ i(t, { content: l.content || "" }),
			!s.busy && !s.error && l?.mediaCategory === "image" && /* @__PURE__ */ i("img", {
				src: `data:${l.contentType};base64,${l.dataBase64}`,
				alt: l.name,
				style: {
					display: "block",
					maxWidth: "100%",
					margin: "0 auto",
					borderRadius: 8
				}
			}),
			!s.busy && !s.error && l?.mediaCategory === "text" && /* @__PURE__ */ i("pre", {
				style: {
					overflowX: "auto",
					whiteSpace: "pre-wrap",
					wordBreak: "break-word",
					background: "#f6f8fa",
					padding: 12,
					borderRadius: 8,
					margin: 0,
					fontSize: 13,
					lineHeight: 1.6,
					color: "#1f2937"
				},
				children: l.content
			})
		]
	});
}
var l = {
	width: 30,
	height: 30,
	display: "inline-flex",
	alignItems: "center",
	justifyContent: "center",
	borderRadius: 8,
	border: "1px solid #e5e7eb",
	background: "#fff",
	cursor: "pointer",
	padding: 0,
	color: "#374151",
	flex: "0 0 auto"
};
function u({ path: e, onClose: t, fetchFile: r = o }) {
	if (n(() => {
		if (!e) return;
		let n = (e) => {
			e.key === "Escape" && t();
		};
		return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
	}, [e, t]), !e) return null;
	let u = e.split("/").pop() || e;
	return /* @__PURE__ */ i("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": `文件预览 ${u}`,
		onClick: t,
		style: {
			position: "fixed",
			inset: 0,
			zIndex: 2147483e3,
			display: "flex",
			alignItems: "center",
			justifyContent: "center",
			background: "rgba(15, 23, 42, 0.5)",
			padding: 24,
			fontFamily: "-apple-system, system-ui, \"SF Pro SC\", \"PingFang SC\", \"Microsoft YaHei\", sans-serif"
		},
		children: /* @__PURE__ */ a("div", {
			onClick: (e) => e.stopPropagation(),
			style: {
				display: "flex",
				flexDirection: "column",
				width: "100%",
				maxWidth: 760,
				maxHeight: "100%",
				overflow: "hidden",
				background: "#ffffff",
				color: "#1f2937",
				border: "1px solid #e5e7eb",
				borderRadius: 12,
				boxShadow: "0 20px 50px rgba(15, 23, 42, 0.25)"
			},
			children: [/* @__PURE__ */ a("header", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 12,
					padding: "12px 16px",
					borderBottom: "1px solid #e5e7eb",
					flex: "0 0 auto"
				},
				children: [
					/* @__PURE__ */ a("div", {
						style: {
							minWidth: 0,
							flex: "1 1 auto"
						},
						children: [/* @__PURE__ */ i("h2", {
							style: {
								margin: 0,
								fontSize: 14,
								fontWeight: 500,
								color: "#111827",
								whiteSpace: "nowrap",
								overflow: "hidden",
								textOverflow: "ellipsis"
							},
							children: u
						}), /* @__PURE__ */ i("p", {
							style: {
								margin: "2px 0 0",
								fontSize: 12,
								color: "#6b7280",
								whiteSpace: "nowrap",
								overflow: "hidden",
								textOverflow: "ellipsis"
							},
							children: e
						})]
					}),
					/* @__PURE__ */ i("button", {
						type: "button",
						"aria-label": "下载文件",
						style: l,
						onClick: () => void s(e, u),
						children: /* @__PURE__ */ a("svg", {
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							"aria-hidden": !0,
							children: [
								/* @__PURE__ */ i("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
								/* @__PURE__ */ i("polyline", { points: "7 10 12 15 17 10" }),
								/* @__PURE__ */ i("line", {
									x1: "12",
									y1: "15",
									x2: "12",
									y2: "3"
								})
							]
						})
					}),
					/* @__PURE__ */ i("button", {
						type: "button",
						"aria-label": "关闭预览",
						style: l,
						onClick: t,
						children: /* @__PURE__ */ a("svg", {
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ i("path", { d: "M18 6 6 18" }), /* @__PURE__ */ i("path", { d: "m6 6 12 12" })]
						})
					})
				]
			}), /* @__PURE__ */ i(c, {
				path: e,
				fetchFile: r
			})]
		})
	});
}
function d({ fetchFile: t }) {
	let [a, o] = r(null);
	return n(() => e(o), []), /* @__PURE__ */ i(u, {
		path: a,
		onClose: () => o(null),
		fetchFile: t
	});
}
//#endregion
export { u as n, d as t };
