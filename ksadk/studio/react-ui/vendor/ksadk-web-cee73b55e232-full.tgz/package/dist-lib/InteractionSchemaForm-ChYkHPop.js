import { useEffect as e, useRef as t, useState as n } from "react";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/hooks/useImeComposition.ts
function a() {
	let n = t(!1);
	return e(() => {
		let e = () => {
			n.current = !0;
		}, t = () => {
			n.current = !1;
		};
		return document.addEventListener("compositionstart", e), document.addEventListener("compositionend", t), () => {
			document.removeEventListener("compositionstart", e), document.removeEventListener("compositionend", t);
		};
	}, []), function(e) {
		return n.current || e.nativeEvent.isComposing === !0 || e.nativeEvent.keyCode === 229;
	};
}
//#endregion
//#region src/components/chat/schema-fields.ts
function o(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function s(e) {
	let t = o(e.properties) || {}, n = Array.isArray(e.required) ? new Set(e.required.map(String)) : /* @__PURE__ */ new Set(), r = [];
	for (let [e, i] of Object.entries(t)) {
		let t = o(i), a = String(t?.type || "").toLowerCase(), s = a === "string" || a === "number" || a === "boolean" || a === "array" ? a : "unknown", c = o(t?.items), l = Array.isArray(t?.["x-codex-options"]) ? t["x-codex-options"].map(o).map((e) => e?.label).filter((e) => typeof e == "string") : [], u = l.length ? l : void 0;
		r.push({
			name: e,
			title: typeof t?.title == "string" ? t.title : void 0,
			description: typeof t?.description == "string" ? t.description : void 0,
			allowOther: t?.["x-codex-is-other"] === !0,
			secret: t?.["x-codex-is-secret"] === !0,
			type: s,
			required: n.has(e),
			enumValues: Array.isArray(t?.enum) ? t.enum : Array.isArray(c?.enum) ? c.enum : u
		});
	}
	return r;
}
//#endregion
//#region src/components/chat/InteractionSchemaForm.tsx
function c({ schema: e, values: t, onChange: o, disabled: c, onSubmit: l, onCancel: u }) {
	let d = s(e), [f, p] = n(""), m = a();
	return /* @__PURE__ */ i("form", {
		className: "mt-3",
		"data-testid": "interaction-schema-form",
		onKeyDown: (e) => {
			e.key === "Enter" && m(e) && e.preventDefault();
		},
		onSubmit: (e) => {
			if (e.preventDefault(), !c) {
				if (!d.every((e) => {
					let n = t[e.name];
					return !e.required || (Array.isArray(n) ? n.length > 0 : String(n ?? "").trim().length > 0);
				})) {
					p("请回答必填问题后再提交。");
					return;
				}
				p(""), l();
			}
		},
		children: [
			d.map((e) => /* @__PURE__ */ i("div", {
				className: "mb-2 block text-xs text-[var(--ksadk-interaction-muted)]",
				children: [/* @__PURE__ */ i("span", {
					className: "mb-1 block font-medium",
					children: [e.description || e.title || e.name, e.required ? /* @__PURE__ */ r("span", {
						className: "ml-0.5 text-rose-500",
						children: "*"
					}) : null]
				}), e.enumValues && e.enumValues.length > 0 ? /* @__PURE__ */ i("div", {
					className: "space-y-1",
					"data-testid": `interaction-field-${e.name}`,
					children: [e.enumValues.map((n, a) => {
						let s = e.type === "array" ? Array.isArray(t[e.name]) && t[e.name].includes(n) : t[e.name] === n;
						return /* @__PURE__ */ i("label", {
							className: "flex min-h-10 cursor-pointer items-center gap-2 rounded-xl px-2 text-sm text-[var(--ksadk-interaction-foreground)] hover:bg-[var(--ksadk-interaction-muted-background)]",
							children: [
								/* @__PURE__ */ r("span", {
									className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--ksadk-interaction-muted-background)] text-xs text-[var(--ksadk-interaction-muted)]",
									children: a + 1
								}),
								/* @__PURE__ */ r("input", {
									type: e.type === "array" ? "checkbox" : "radio",
									name: e.name,
									disabled: c,
									checked: !!s,
									onChange: (r) => {
										let i = Array.isArray(t[e.name]) ? t[e.name] : [], a = e.type === "array" ? r.target.checked ? [...i, n] : i.filter((e) => e !== n) : n;
										o({
											...t,
											[e.name]: a
										});
									},
									className: "h-4 w-4 accent-current"
								}),
								/* @__PURE__ */ r("span", { children: String(n) })
							]
						}, String(n));
					}), e.allowOther ? /* @__PURE__ */ r("input", {
						"aria-label": `${e.title || e.name}：自定义回答`,
						placeholder: "或填写自己的回答",
						type: e.secret ? "password" : "text",
						disabled: c,
						value: e.type === "array" ? (Array.isArray(t[e.name]) ? t[e.name] : []).filter((t) => !e.enumValues.includes(t)).join("\n") : e.enumValues.includes(t[e.name]) ? "" : String(t[e.name] ?? ""),
						onChange: (n) => {
							let r = n.target.value, i = (Array.isArray(t[e.name]) ? t[e.name] : []).filter((t) => e.enumValues.includes(t));
							o({
								...t,
								[e.name]: e.type === "array" ? [...i, ...r.trim() ? [r] : []] : r
							});
						},
						className: "w-full rounded-lg border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-control-background)] px-3 py-2 text-sm text-[var(--ksadk-interaction-foreground)]"
					}) : null]
				}) : e.type === "boolean" ? /* @__PURE__ */ r("input", {
					type: "checkbox",
					"data-testid": `interaction-field-${e.name}`,
					disabled: c,
					checked: !!t[e.name],
					onChange: (n) => o({
						...t,
						[e.name]: n.target.checked
					}),
					className: "h-4 w-4"
				}) : e.type === "number" ? /* @__PURE__ */ r("input", {
					type: "number",
					"data-testid": `interaction-field-${e.name}`,
					disabled: c,
					value: t[e.name] === void 0 ? "" : String(t[e.name]),
					onChange: (n) => o({
						...t,
						[e.name]: n.target.value === "" ? void 0 : Number(n.target.value)
					}),
					className: "w-full rounded-md border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-control-background)] px-2 py-1.5 text-sm text-foreground"
				}) : /* @__PURE__ */ r("input", {
					type: e.secret ? "password" : "text",
					"data-testid": `interaction-field-${e.name}`,
					disabled: c,
					value: String(t[e.name] ?? ""),
					onChange: (n) => o({
						...t,
						[e.name]: n.target.value
					}),
					className: "w-full rounded-md border border-[var(--ksadk-interaction-border)] bg-[var(--ksadk-interaction-control-background)] px-2 py-1.5 text-sm text-foreground"
				})]
			}, e.name)),
			f ? /* @__PURE__ */ r("p", {
				role: "alert",
				className: "mt-2 text-xs text-rose-600",
				children: f
			}) : null,
			/* @__PURE__ */ i("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ r("button", {
					type: "submit",
					"data-testid": "interaction-submit",
					disabled: c,
					className: "inline-flex min-h-8 items-center rounded-md bg-[var(--ksadk-interaction-primary-background)] px-3 py-1.5 text-xs font-semibold text-[var(--ksadk-interaction-primary-foreground)] disabled:cursor-not-allowed disabled:opacity-55",
					children: "提交"
				}), /* @__PURE__ */ r("button", {
					type: "button",
					"data-testid": "interaction-form-cancel",
					disabled: c,
					onClick: u,
					className: "inline-flex min-h-8 items-center rounded-md px-3 py-1.5 text-xs font-medium text-slate-500 underline-offset-2 hover:underline disabled:cursor-not-allowed disabled:opacity-55 dark:text-slate-400",
					children: "取消本次确认"
				})]
			})
		]
	});
}
//#endregion
export { s as n, a as r, c as t };
