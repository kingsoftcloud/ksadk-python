import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { i as t, o as n } from "./MessageMarkdown-Lj01l-_B.js";
import { t as r } from "./CodeBlock-DMIf4h33.js";
import { t as i } from "./MermaidBlock-H_0qzQDf.js";
import a from "react";
import { jsx as o } from "react/jsx-runtime";
import s from "react-markdown";
import c from "remark-gfm";
import l from "remark-breaks";
import u from "remark-math";
import d from "rehype-katex";
import "katex/dist/katex.min.css";
//#region src/components/markdown/MathMessageMarkdown.tsx
var f = /* @__PURE__ */ e({ MathMessageMarkdown: () => m }), p = {
	code({ className: e, children: t, ...n }) {
		let a = /language-(\w+)/.exec(e || ""), s = String(t ?? "");
		if (!a && !s.includes("\n")) return /* @__PURE__ */ o("code", {
			className: "break-all font-mono text-[0.92em] text-slate-800 dark:text-slate-200 before:content-none after:content-none",
			...n,
			children: t
		});
		let c = a ? a[1] : "";
		return c === "mermaid" ? /* @__PURE__ */ o(i, { chart: s }) : /* @__PURE__ */ o(r, {
			language: c,
			value: s
		});
	},
	table({ children: e, ...t }) {
		return /* @__PURE__ */ o("div", {
			className: "my-4 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700",
			children: /* @__PURE__ */ o("table", {
				className: "my-0 w-full min-w-[36rem] table-auto text-left text-sm",
				...t,
				children: e
			})
		});
	},
	th({ children: e, ...t }) {
		return /* @__PURE__ */ o("th", {
			className: "break-words border-b border-slate-200 bg-slate-50 px-3 py-2 text-left align-top font-semibold dark:border-slate-700 dark:bg-slate-800/50",
			...t,
			children: e
		});
	},
	td({ children: e, ...t }) {
		return /* @__PURE__ */ o("td", {
			className: "break-words border-b border-slate-100 px-3 py-2 align-top dark:border-slate-800 last:border-0",
			...t,
			children: e
		});
	},
	a({ children: e, href: t, ...n }) {
		return /* @__PURE__ */ o("a", {
			href: t,
			className: "text-blue-600 dark:text-blue-400 hover:underline",
			target: "_blank",
			rel: "noopener noreferrer",
			...n,
			children: e
		});
	}
}, m = a.memo(({ content: e }) => {
	let r = n(e);
	return /* @__PURE__ */ o("div", {
		className: "prose prose-slate dark:prose-invert max-w-none break-words text-[15px] leading-7 prose-headings:mb-3 prose-headings:mt-6 prose-headings:font-semibold prose-headings:text-slate-900 dark:prose-headings:text-slate-50 prose-h1:text-[1.95rem] prose-h1:leading-tight prose-h1:tracking-[-0.02em] prose-h2:text-[1.55rem] prose-h2:leading-tight prose-h2:tracking-[-0.015em] prose-h3:text-[1.2rem] prose-h3:leading-snug prose-p:my-3 prose-p:leading-7 prose-strong:text-slate-900 dark:prose-strong:text-slate-100 prose-ol:my-3 prose-ul:my-3 prose-li:my-1.5 prose-li:leading-7 prose-hr:my-5 prose-hr:border-slate-200 dark:prose-hr:border-slate-700 prose-pre:m-0 prose-pre:bg-transparent prose-pre:p-0 [&>*:first-child]:mt-0 [&>*:last-child]:mb-0",
		children: /* @__PURE__ */ o(s, {
			remarkPlugins: [
				c,
				u,
				l
			],
			rehypePlugins: [t, d],
			components: p,
			children: r
		})
	});
});
//#endregion
export { f as n, m as t };
