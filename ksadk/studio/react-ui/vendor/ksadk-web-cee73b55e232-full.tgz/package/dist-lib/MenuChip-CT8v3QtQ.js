import { t as e } from "./utils-CX-Pz5p6.js";
import { useEffect as t, useRef as n, useState as r } from "react";
import { ChevronDown as i } from "lucide-react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/components/chat/MenuChip.tsx
function s({ label: s, options: c, value: l, onChange: u, title: d }) {
	let [f, p] = r(!1), m = n(null);
	return t(() => {
		if (!f) return;
		let e = (e) => {
			m.current && !m.current.contains(e.target) && p(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [f]), /* @__PURE__ */ o("div", {
		ref: m,
		className: "relative",
		children: [/* @__PURE__ */ o("button", {
			type: "button",
			onClick: () => p((e) => !e),
			title: d,
			className: "flex h-8 max-w-[12rem] items-center gap-1 overflow-hidden rounded-full px-2 text-sm font-normal leading-[18px] text-text-primary hover:bg-muted",
			children: [/* @__PURE__ */ a("span", {
				className: "min-w-0 flex-1 truncate text-center",
				children: s
			}), /* @__PURE__ */ a(i, { className: e("h-4 w-4 shrink-0 text-text-secondary transition-transform", f && "rotate-180") })]
		}), f ? /* @__PURE__ */ a("div", {
			className: "absolute bottom-[calc(100%+0.5rem)] left-0 z-30 max-h-[min(50vh,20rem)] min-w-[10rem] max-w-[16rem] overflow-y-auto rounded-xl border border-border bg-popover p-1.5 text-sm shadow-[0_10px_28px_rgba(0,0,0,0.18)]",
			children: c.map((t) => /* @__PURE__ */ a("button", {
				type: "button",
				onClick: () => {
					u(t.value), p(!1);
				},
				className: e("flex w-full items-center rounded-lg px-2.5 py-1.5 text-left leading-5 transition-colors", t.value === l ? "bg-muted text-text-primary" : "text-text-secondary hover:bg-muted hover:text-text-primary"),
				children: /* @__PURE__ */ a("span", {
					className: "min-w-0 flex-1 truncate",
					children: t.label
				})
			}, t.value))
		}) : null]
	});
}
//#endregion
export { s as t };
