import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { useEffect as t, useId as n, useState as r } from "react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import o from "mermaid";
//#region src/components/markdown/MermaidBlock.tsx
var s = /* @__PURE__ */ e({ MermaidBlock: () => c });
o.initialize({
	startOnLoad: !1,
	theme: "default",
	securityLevel: "strict"
});
var c = ({ chart: e }) => {
	let [s, c] = r(""), [l, u] = r(!1), d = n().replace(/:/g, "-");
	return t(() => {
		let t = !1;
		return (async () => {
			try {
				let { svg: n } = await o.render(d, e);
				t || (c(n), u(!1));
			} catch {
				t || u(!0);
			}
		})(), () => {
			t = !0;
		};
	}, [e, d]), l ? /* @__PURE__ */ a("div", {
		className: "my-4 overflow-hidden rounded-lg border border-red-200 bg-slate-100 dark:border-red-800 dark:bg-slate-800",
		children: [/* @__PURE__ */ i("div", {
			role: "alert",
			className: "border-b border-red-200 px-4 py-2 text-xs text-red-600 dark:border-red-800 dark:text-red-300",
			children: "Mermaid 渲染失败，已显示源码。"
		}), /* @__PURE__ */ i("pre", {
			className: "overflow-x-auto p-4 text-sm text-slate-700 dark:text-slate-200",
			children: e
		})]
	}) : /* @__PURE__ */ i("div", {
		className: "my-4 flex justify-center bg-white dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 overflow-x-auto",
		dangerouslySetInnerHTML: { __html: s }
	});
};
//#endregion
export { s as n, c as t };
