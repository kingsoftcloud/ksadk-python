import e, { Suspense as t, useState as n } from "react";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import a from "react-markdown";
import o from "remark-gfm";
import s from "remark-breaks";
//#region src/utils/markdown.js
function c(e) {
	return e.replace(/<think>([\s\S]*?)(?:<\/think>|$)/gi, (e, t) => `\n> 💭 **思考过程**\n>\n${String(t || "").trim().split("\n").filter(Boolean).map((e) => `> ${e}`).join("\n")}\n\n`);
}
function l(e) {
	return /^\s*\|(?:\s*[:\-]+\s*\|){2,}\s*$/.test(e);
}
function u(e) {
	let t = e.trim();
	return t.startsWith("|") ? t.split("|").length >= 4 : !1;
}
function d(e) {
	let t = e.trim();
	return t.startsWith("|") ? t.replace(/^\|/, "").replace(/\|\s*$/, "").split("|").map((e) => e.trim()) : [];
}
function f(e, t = "") {
	return `${t}| ${e.join(" | ")} |`;
}
function p(e) {
	let t = e.split("\n"), n = [], r = 0;
	for (; r < t.length;) {
		let e = t[r];
		if (u(e) && r + 1 < t.length && l(t[r + 1])) {
			let i = e.match(/^(\s*)/)?.[1] || "", a = d(e), o = d(t[r + 1]), s = [], c = r + 2, l = Math.max(a.length, o.length);
			for (; c < t.length && u(t[c]);) {
				let e = d(t[c]);
				l = Math.max(l, e.length), s.push(e), c += 1;
			}
			let p = (e) => {
				let t = [...e];
				for (; t.length < l;) t.push("");
				return t;
			};
			n.push(f(p(a), i)), n.push(f(((e) => {
				let t = [...e];
				for (; t.length < l;) t.push("---");
				return t;
			})(o), i));
			for (let e of s) n.push(f(p(e), i));
			r = c;
		} else n.push(e), r += 1;
	}
	return n.join("\n");
}
function m(e) {
	return l(e) || /\|\|/.test(e) || /\|(?:\s*[:\-]+\s*\|){2,}/.test(e) && /\|(?:[^|\n]*\|){2,}/.test(e);
}
function h(e) {
	return m(e) ? e.replace(/\|\s*\|/g, "|\n|").split("\n").map((e) => e.trimEnd()).filter((e) => e.trim().length > 0) : [e];
}
function g(e) {
	return u(e) ? e.replace(/\|\s*(?:\*{1,2}|_{1,2})\s*$/u, "|") : e;
}
function _(e) {
	let t = e.trim();
	return u(t) ? t.split("|").slice(1, -1).length : 0;
}
function v(e) {
	let t = e.match(/^(\s*)/)?.[1] || "", n = _(e);
	return n < 2 ? "" : `${t}| ${Array.from({ length: n }, () => "---").join(" | ")} |`;
}
function y(e) {
	let t = [];
	for (let n of e.split("\n")) {
		if (/^\s*\|\s*$/.test(n)) continue;
		let e = n.match(/^(\s*)\|\s*([^|]+)$/);
		if (e) {
			t.push(`${e[1]}${e[2].trim()}`);
			continue;
		}
		t.push(...h(n).map(g));
	}
	let n = [];
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		r.trim().length === 0 && u(n[n.length - 1] || "") && l(t[e + 1] || "") || n.push(r);
	}
	let r = [];
	for (let e = 0; e < n.length; e += 1) {
		let t = n[e], i = n[e + 1] || "";
		if (r.push(t), u(t) && u(i) && !l(i) && _(t) === _(i)) {
			let i = u(n[e - 1] || ""), a = t.match(/^(\s*)/)?.[1] || "";
			if (!i && a.length === 0) {
				let e = v(t);
				e && r.push(e);
			}
		}
	}
	let i = [];
	for (let e = 0; e < r.length; e += 1) {
		let t = r[e], n = r[e + 1] || "", a = i[i.length - 1] || "", o = u(t) && (a.trim().length === 0 || !u(a)), s = u(t) && (n.trim().length === 0 || !u(n)), c = t.match(/^(\s*)/)?.[1] || "";
		o && c.length === 0 && a.trim().length > 0 && i.push(""), i.push(t), s && c.length === 0 && n.trim().length > 0 && i.push("");
	}
	return i.join("\n");
}
function b(e) {
	let t = e.replace(/^[\u200B-\u200D\uFEFF]+/u, ""), n = t.match(/^([ \t\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]*)([＃#]{1,6})([ \t\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]*)(\S.*)?$/u);
	if (!n) return t;
	let [, r, i, , a = ""] = n, o = r.replace(/[^\t ]/gu, " "), s = i.replace(/＃/gu, "#");
	return a ? `${o}${s} ${a}` : `${o}${s}`;
}
function x(e) {
	let t = e;
	return t = t.split("\n").map((e) => b(e)).join("\n"), t = t.replace(/^[ \t]+(#{1,6}\s*)/gm, "$1"), t = t.replace(/([^\n#])\s*(#{1,6}\s*[^\s|])/g, "$1\n\n$2"), t = t.replace(/^(#{1,6}\s*[^\n]+)\n(?!\n)/gm, "$1\n\n"), t = t.replace(/^(#{1,6}[^\n|]+?)\s*(\|)/gm, "$1\n$2"), t = t.replace(/([。；;：:])\s*(\d+\.\s*)/g, "$1\n$2"), t = t.replace(/([。；;：:\.])\s*-(?!-)\s*/g, "$1\n- "), t = t.replace(/([^\n\s-])-\s+/g, "$1\n- "), t = t.replace(/^-(?!-)(\S)/gm, "- $1"), t = y(t), t = t.replace(/\n{3,}/g, "\n\n"), t.trim();
}
function S(e) {
	return e.map((t, n) => {
		if (n % 2 == 1) return t;
		let r = x(t), i = n > 0, a = n < e.length - 1;
		return r ? (i && !r.startsWith("\n") && (r = `\n${r}`), a && !r.endsWith("\n") && (r = `${r}\n`), r) : i && a ? "\n\n" : i || a ? "\n" : r;
	});
}
function C(e) {
	if (!e) return e;
	let t = String(e).replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
	return t = c(t), t = p(t), (t.match(/```/g) || []).length % 2 == 1 && (t = `${t}\n\`\`\``), S(t.split("```")).join("```").trim();
}
//#endregion
//#region src/utils/workspace-file-paths.ts
var w = new RegExp(["/(?:[^\\s`'\"()\\[\\]{}<>，。；！？、：·…]+/)+[^\\s`'\"()\\[\\]{}<>，。；！？、：·…]+\\.(?:md|markdown|txt|json|csv|tsv|log|py|js|ts|tsx|jsx|html|css|yaml|yml|toml|xml|sh|sql|go|rs|java|c|cpp|h|diff|ini|png|jpg|jpeg|gif|webp|svg|bmp|ico)", "\\.{1,2}/[^\\s`'\"()\\[\\]{}<>，。；！？、：·…]+\\.(?:md|markdown|txt|json|csv|tsv|log|py|js|ts|tsx|jsx|html|css|yaml|yml|toml|xml|sh|sql|png|jpg|jpeg|gif|webp|svg)"].join("|"), "g"), T = new Set([
	"a",
	"script",
	"style",
	"head"
]);
function E(e) {
	let t = [], n = 0;
	w.lastIndex = 0;
	let r;
	for (; r = w.exec(e);) r.index > n && t.push({
		type: "text",
		value: e.slice(n, r.index)
	}), t.push({
		type: "element",
		tagName: "a",
		properties: {
			href: "#",
			dataWorkspaceFile: r[0]
		},
		children: [{
			type: "text",
			value: r[0]
		}]
	}), n = r.index + r[0].length;
	return n < e.length && t.push({
		type: "text",
		value: e.slice(n)
	}), t.length ? t : [{
		type: "text",
		value: e
	}];
}
function D() {
	return (e) => {
		let t = (e, n) => {
			if (!e.children) return;
			let r = n || T.has(e.tagName || ""), i = [];
			for (let n of e.children) {
				if (!r && n.type === "text" && typeof n.value == "string" && (w.lastIndex = 0, w.test(n.value))) {
					i.push(...E(n.value));
					continue;
				}
				t(n, r), i.push(n);
			}
			e.children = i;
		};
		t(e, !1);
	};
}
function O(e) {
	let t = [], n = 0;
	w.lastIndex = 0;
	let r;
	for (; r = w.exec(e);) r.index > n && t.push({
		type: "text",
		value: e.slice(n, r.index)
	}), t.push({
		type: "file",
		value: r[0]
	}), n = r.index + r[0].length;
	return n === 0 ? [{
		type: "text",
		value: e
	}] : (n < e.length && t.push({
		type: "text",
		value: e.slice(n)
	}), t);
}
//#endregion
//#region src/utils/workspace-file-preview-bus.ts
var k = "ksadk-workspace-file-preview";
function A(e) {
	typeof window > "u" || window.dispatchEvent(new CustomEvent(k, { detail: { path: e } }));
}
function j(e) {
	if (typeof window > "u") return () => {};
	let t = (t) => {
		let n = t.detail;
		e(n?.path ? n.path : null);
	};
	return window.addEventListener(k, t), () => window.removeEventListener(k, t);
}
//#endregion
//#region src/components/MessageMarkdown.tsx
var M = e.lazy(() => import("./CodeBlock-DMIf4h33.js").then((e) => e.n).then((e) => ({ default: e.CodeBlock }))), N = e.lazy(() => import("./MermaidBlock-H_0qzQDf.js").then((e) => e.n).then((e) => ({ default: e.MermaidBlock }))), P = e.lazy(() => import("./MathMessageMarkdown-BY98Kkdm.js").then((e) => e.n).then((e) => ({ default: e.MathMessageMarkdown })));
function F(e) {
	return /\$[^$]+\$|\$\$[^$]+\$\$/.test(e);
}
function I(e) {
	if (e) try {
		let t = new URL(e, typeof window > "u" ? "http://localhost/" : window.location.href).protocol.toLowerCase();
		return [
			"http:",
			"https:",
			"mailto:"
		].includes(t) ? e : void 0;
	} catch {
		return;
	}
}
function L(e) {
	if (e) try {
		let t = new URL(e, typeof window > "u" ? "http://localhost/" : window.location.href).protocol.toLowerCase();
		return ["http:", "https:"].includes(t) ? e : void 0;
	} catch {
		return;
	}
}
function R({ src: e, alt: t, ...a }) {
	let o = L(e), [s, c] = n(o ? "loading" : "error"), [l, u] = n(null);
	return !o || s === "error" ? /* @__PURE__ */ r("span", {
		role: "img",
		"aria-label": t || "图片无法加载",
		className: "my-2 inline-flex rounded-md border border-border bg-muted px-3 py-2 text-xs text-text-secondary",
		children: t || "图片无法加载"
	}) : /* @__PURE__ */ i("figure", {
		className: "my-3 max-w-full",
		children: [/* @__PURE__ */ r("a", {
			href: o,
			target: "_blank",
			rel: "noopener noreferrer",
			title: "查看原图",
			children: /* @__PURE__ */ r("img", {
				...a,
				src: o,
				alt: t || "图片",
				loading: "lazy",
				decoding: "async",
				onLoad: (e) => {
					c("loaded"), u({
						width: e.currentTarget.naturalWidth,
						height: e.currentTarget.naturalHeight
					});
				},
				onError: () => c("error"),
				className: "max-h-[28rem] max-w-full cursor-zoom-in rounded-lg border border-border object-contain shadow-sm"
			})
		}), /* @__PURE__ */ i("figcaption", {
			className: "mt-1 flex items-center gap-2 text-xs text-text-secondary",
			children: [
				/* @__PURE__ */ r("span", { children: s === "loading" ? "图片加载中…" : "点击查看原图" }),
				l ? /* @__PURE__ */ i("span", {
					"aria-label": "图片尺寸",
					children: [
						"· ",
						l.width,
						" × ",
						l.height
					]
				}) : null,
				/* @__PURE__ */ r("a", {
					href: o,
					download: !0,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "text-primary hover:underline",
					children: "下载"
				})
			]
		})]
	});
}
var z = {
	h1({ children: e }) {
		return /* @__PURE__ */ r("h1", {
			className: "mb-3.5 mt-5 text-[17px] font-semibold text-foreground",
			children: e
		});
	},
	h2({ children: e }) {
		return /* @__PURE__ */ r("h2", {
			className: "mb-2.5 mt-4.5 text-[15px] font-semibold text-foreground",
			children: e
		});
	},
	h3({ children: e }) {
		return /* @__PURE__ */ r("h3", {
			className: "mb-2 mt-3.5 text-[14px] font-semibold text-foreground",
			children: e
		});
	},
	p({ children: e }) {
		return /* @__PURE__ */ r("p", {
			className: "mb-2.5 min-w-0 break-words leading-[1.65] text-foreground",
			children: e
		});
	},
	ul({ children: e }) {
		return /* @__PURE__ */ r("ul", {
			className: "mb-3 list-disc space-y-1.5 pl-5 text-foreground",
			children: e
		});
	},
	ol({ children: e }) {
		return /* @__PURE__ */ r("ol", {
			className: "mb-3 list-decimal space-y-1.5 pl-8 text-foreground",
			children: e
		});
	},
	li({ children: e }) {
		return /* @__PURE__ */ r("li", {
			className: "min-w-0 break-words pl-1 leading-6 text-foreground",
			children: e
		});
	},
	strong({ children: e }) {
		return /* @__PURE__ */ r("strong", {
			className: "font-semibold text-foreground",
			children: e
		});
	},
	blockquote({ children: e }) {
		return /* @__PURE__ */ r("blockquote", {
			className: "mb-3 border-l-2 border-border pl-4 text-text-secondary",
			children: e
		});
	},
	code({ className: e, children: n, ...i }) {
		let a = /language-(\w+)/.exec(e || ""), o = String(n ?? "");
		if (!a && !o.includes("\n")) return /* @__PURE__ */ r("code", {
			className: "break-all font-mono text-[0.92em] text-text-primary before:content-none after:content-none",
			...i,
			children: n
		});
		let s = a ? a[1] : "";
		return s === "mermaid" ? /* @__PURE__ */ r(t, {
			fallback: /* @__PURE__ */ r("div", { className: "h-32 animate-pulse rounded bg-muted" }),
			children: /* @__PURE__ */ r(N, { chart: o })
		}) : /* @__PURE__ */ r(t, {
			fallback: /* @__PURE__ */ r("pre", {
				className: "p-4 text-sm",
				children: o
			}),
			children: /* @__PURE__ */ r(M, {
				language: s,
				value: o
			})
		});
	},
	table({ children: e, ...t }) {
		return /* @__PURE__ */ r("div", {
			className: "mb-3 max-w-full overflow-x-auto rounded-lg border border-border",
			children: /* @__PURE__ */ r("table", {
				className: "w-full min-w-[36rem] table-auto border-collapse text-sm text-foreground",
				...t,
				children: e
			})
		});
	},
	th({ children: e, ...t }) {
		return /* @__PURE__ */ r("th", {
			className: "break-words border-b border-border bg-muted/40 px-3 py-2 text-left align-top font-semibold text-foreground",
			...t,
			children: e
		});
	},
	td({ children: e, ...t }) {
		return /* @__PURE__ */ r("td", {
			className: "break-words border-b border-border px-3 py-2 align-top text-text-secondary",
			...t,
			children: e
		});
	},
	a({ children: e, href: t, ...n }) {
		let i = n["data-workspace-file"];
		if (typeof i == "string" && i) return /* @__PURE__ */ r("a", {
			href: "#",
			className: "text-primary underline decoration-primary/40 underline-offset-2 hover:decoration-primary",
			title: `预览 ${i}`,
			onClick: (e) => {
				e.preventDefault(), A(i);
			},
			...n,
			children: e
		});
		let a = I(t);
		return a ? /* @__PURE__ */ r("a", {
			href: a,
			className: "text-primary hover:underline",
			target: "_blank",
			rel: "noopener noreferrer",
			...n,
			children: e
		}) : /* @__PURE__ */ r("span", {
			className: "text-text-secondary",
			children: e
		});
	},
	img({ src: e, alt: t, ...n }) {
		return /* @__PURE__ */ r(R, {
			src: e,
			alt: t,
			...n
		});
	}
}, B = e.memo(({ content: e }) => {
	let t = C(e);
	return /* @__PURE__ */ r("div", {
		className: "max-w-none break-words text-[14px] leading-[1.65] [&>*:first-child]:mt-0 [&>*:last-child]:mb-0",
		children: /* @__PURE__ */ r(a, {
			remarkPlugins: [o, s],
			rehypePlugins: [D],
			components: z,
			children: t
		})
	});
}), V = e.memo(({ content: e }) => F(e) ? /* @__PURE__ */ r(t, {
	fallback: /* @__PURE__ */ r(B, { content: e }),
	children: /* @__PURE__ */ r(P, { content: e })
}) : /* @__PURE__ */ r(B, { content: e }));
//#endregion
export { O as a, D as i, j as n, C as o, A as r, V as t };
