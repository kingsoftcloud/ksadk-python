import { t as e } from "./rolldown-runtime-Dy4uBu1J.js";
import { t } from "./utils-CX-Pz5p6.js";
import { useCallback as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { CheckCircle2 as s, PlugZap as c, Plus as l, RefreshCw as u, TerminalSquare as d, Trash2 as f, X as p } from "lucide-react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
import "@xterm/xterm/css/xterm.css";
//#region src/utils/terminal-session.js
var g = "/_ksadk/terminal/sessions", _ = /\x1b\](?:10|11|12);(?:rgb:)?[0-9a-fA-F]{1,4}\/[0-9a-fA-F]{1,4}\/[0-9a-fA-F]{1,4}(?:\x07|\x1b\\)/g, v = /\]1[012];(?:rgb:)?[0-9a-fA-F]{1,4}\/[0-9a-fA-F]{1,4}\/[0-9a-fA-F]{1,4}/g;
function y(e, t) {
	let n = Number(e);
	return Number.isFinite(n) && n > 0 ? Math.floor(n) : t;
}
function b(e) {
	let t = Date.parse(String(e?.updated_at || e?.UpdatedAt || ""));
	return Number.isNaN(t) ? 0 : t;
}
function x(e = {}) {
	let t = {
		mode: String(e.mode || "tui").trim() || "tui",
		cols: y(e.cols, 80),
		rows: y(e.rows, 24)
	}, n = String(e.sessionId || e.session_id || "").trim();
	n && (t.session_id = n);
	let r = String(e.cwd || "").trim();
	return r && (t.cwd = r), e.options && typeof e.options == "object" && (t.options = e.options), (e.forceNew === !0 || e.force_new === !0) && (t.force_new = !0), t;
}
function S(e = {}, t) {
	let n = t || (typeof window < "u" ? window.location : { href: "http://localhost/" }), r = new URL(g, n.href || "http://localhost/"), i = String(e.sessionId || e.session_id || "").trim();
	i && r.searchParams.set("session_id", i);
	let a = String(e.mode || "").trim();
	return a && r.searchParams.set("mode", a), r.pathname + r.search;
}
function C(e) {
	return (Array.isArray(e?.sessions) ? e.sessions : Array.isArray(e?.Sessions) ? e.Sessions : []).map((e) => ({
		terminal_session_id: String(e?.terminal_session_id || e?.TerminalSessionId || "").trim(),
		mode: String(e?.mode || e?.Mode || "tui").trim() || "tui",
		status: String(e?.status || e?.Status || "closed").trim() || "closed",
		cols: y(e?.cols ?? e?.Cols, 80),
		rows: y(e?.rows ?? e?.Rows, 24),
		session_id: String(e?.session_id || e?.SessionId || "").trim(),
		cwd: String(e?.cwd || e?.Cwd || "").trim(),
		created_at: e?.created_at || e?.CreatedAt || "",
		updated_at: e?.updated_at || e?.UpdatedAt || "",
		exit_code: e?.exit_code ?? e?.ExitCode ?? null
	})).filter((e) => e.terminal_session_id).filter((e) => e.status !== "closed" && e.status !== "deleted").sort((e, t) => {
		let n = +(e.status === "running"), r = +(t.status === "running");
		return n === r ? b(t) - b(e) : r - n;
	});
}
function w(e = "/_ksadk/terminal/ws", t, n) {
	let r = n || (typeof window < "u" ? window.location : {
		href: "http://localhost/",
		protocol: "http:"
	}), i = new URL(e || "/_ksadk/terminal/ws", r.href || "http://localhost/");
	i.protocol = i.protocol === "https:" ? "wss:" : "ws:";
	let a = String(t || "").trim();
	return a && i.searchParams.set("terminal_session_id", a), i.toString();
}
function T(e) {
	return String(e || "").replace(_, "").replace(v, "");
}
//#endregion
//#region src/components/native/NativeTerminalPanel.tsx
var E = /* @__PURE__ */ e({ NativeTerminalPanel: () => A }), D = 2e4;
function O(e) {
	return typeof e == "string" ? Promise.resolve(e) : e instanceof Blob ? e.text() : Promise.resolve(new TextDecoder().decode(e));
}
async function k(e) {
	let t = await e.text();
	if (!t) return {};
	try {
		return JSON.parse(t);
	} catch {
		return {};
	}
}
function A({ capability: e, open: _, onClose: v, sessionId: y, autoCreateWhenEmpty: b = !0 }) {
	let [E, A] = o("idle"), [j, M] = o([]), [N, P] = o(null), [F, I] = o(!1), L = a(null), R = a(null), z = a(null), B = a(null), V = a([]), H = a(null), U = a(!1), W = i(() => j.find((e) => e.terminal_session_id === N) || null, [N, j]), G = n(async ({ forceNew: t = !1 } = {}) => {
		U.current = !0, A("connecting");
		let n = await fetch(g, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(x({
				mode: e.Mode || "tui",
				sessionId: y,
				forceNew: t
			}))
		});
		if (!n.ok) {
			A("error");
			return;
		}
		let r = (await k(n))?.session;
		if (!r?.terminal_session_id) {
			A("error");
			return;
		}
		await H.current?.(), P(r.terminal_session_id);
	}, [e.Mode, y]), K = n(async () => {
		I(!0);
		try {
			let t = await fetch(S({
				sessionId: y,
				mode: e.Mode || "tui"
			}));
			if (!t.ok) throw Error(`HTTP ${t.status}`);
			let n = C(await k(t));
			M(n), P((e) => e && n.some((t) => t.terminal_session_id === e) ? e : n[0]?.terminal_session_id || null), _ && e.Enabled && b && n.length === 0 && !U.current && (U.current = !0, await G());
		} catch {
			A("error");
		} finally {
			I(!1);
		}
	}, [
		b,
		e.Enabled,
		e.Mode,
		G,
		_,
		y
	]);
	r(() => {
		V.current = j;
	}, [j]), r(() => {
		H.current = K;
	}, [K]), r(() => {
		(!_ || !e.Enabled) && (U.current = !1);
	}, [e.Enabled, _]);
	let q = a(void 0);
	r(() => {
		if (q.current !== void 0 && q.current !== y) {
			let e = V.current;
			M([]), P(null), Promise.all(e.map((e) => fetch(`${g}/${e.terminal_session_id}`, { method: "DELETE" }).catch(() => {})));
		}
		q.current = y;
	}, [y]);
	let J = n(async (t) => {
		if (!L.current) return () => {};
		A("connecting");
		let n = !1, r = null, i = null, a = null, o = null, s = null, c = null, l = null, u = null;
		return R.current?.close(1e3, "switch terminal session"), R.current = null, z.current?.dispose(), z.current = null, B.current = null, L.current.innerHTML = "", Promise.all([import("@xterm/xterm"), import("@xterm/addon-fit")]).then(([d, f]) => {
			if (n || !L.current) return;
			let { Terminal: p } = d, { FitAddon: m } = f;
			r = new p({
				cursorBlink: !0,
				convertEol: !0,
				fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", monospace",
				fontSize: 14,
				lineHeight: 1.2,
				scrollback: 6e3,
				allowProposedApi: !0,
				theme: {
					background: "#020617",
					foreground: "#e5edf5",
					cursor: "#34d399",
					cursorAccent: "#020617",
					selectionBackground: "#1e40af66",
					black: "#020617",
					red: "#fb7185",
					green: "#34d399",
					yellow: "#fbbf24",
					blue: "#60a5fa",
					magenta: "#c084fc",
					cyan: "#22d3ee",
					white: "#e5edf5",
					brightBlack: "#64748b",
					brightRed: "#fda4af",
					brightGreen: "#86efac",
					brightYellow: "#fde68a",
					brightBlue: "#93c5fd",
					brightMagenta: "#d8b4fe",
					brightCyan: "#67e8f9",
					brightWhite: "#ffffff"
				}
			}), i = new m(), r.loadAddon(i), r.open(L.current), z.current = r, B.current = i;
			let h = () => {
				try {
					i?.fit();
				} catch {}
			}, g = () => {
				s?.readyState !== WebSocket.OPEN || !r || s.send(JSON.stringify({
					type: "resize",
					cols: r.cols || t.cols || 80,
					rows: r.rows || t.rows || 24
				}));
			}, _ = () => {
				h(), g();
			}, v = () => {
				window.requestAnimationFrame(() => {
					n || (_(), window.requestAnimationFrame(() => {
						n || _();
					}));
				});
			};
			window.setTimeout(v, 0), s = new WebSocket(w(e.Path || "/_ksadk/terminal/ws", t.terminal_session_id), e.Protocol || "ks-terminal.v1"), R.current = s, s.addEventListener("open", () => {
				h(), s?.send(JSON.stringify({
					type: "attach",
					terminal_session_id: t.terminal_session_id,
					cols: r?.cols || t.cols || 80,
					rows: r?.rows || t.rows || 24
				})), v(), A("connected"), r?.focus();
			}), s.addEventListener("message", (e) => {
				if (typeof e.data == "string") try {
					let t = JSON.parse(e.data);
					if (t?.type === "ready") {
						A("connected");
						return;
					}
					if (t?.type === "pong") return;
					if (t?.type === "exit") {
						A("closed");
						return;
					}
					if (t?.type === "error") {
						A("error"), r?.writeln(`\r\n${t.message || "Terminal error"}`);
						return;
					}
				} catch {}
				O(e.data).then((e) => {
					e && r?.write(e);
				});
			}), s.addEventListener("close", () => {
				A((e) => e === "error" ? e : "closed"), R.current = null;
			}), s.addEventListener("error", () => {
				A("error");
			});
			let y = (e) => {
				let t = T(e);
				t && s?.readyState === WebSocket.OPEN && s.send(new TextEncoder().encode(t));
			};
			a = r.onData((e) => {
				y(e);
			}), o = r.onBinary((e) => {
				y(e);
			}), u = window.setInterval(() => {
				s?.readyState === WebSocket.OPEN && s.send(JSON.stringify({ type: "ping" }));
			}, D), c = () => {
				_();
			}, window.addEventListener("resize", c), l = new ResizeObserver(() => {
				v();
			}), l.observe(L.current);
		}), () => {
			n = !0, a?.dispose(), o?.dispose(), c && window.removeEventListener("resize", c), u !== null && window.clearInterval(u), l?.disconnect(), s && (s.readyState === WebSocket.OPEN || s.readyState === WebSocket.CONNECTING) && s.close(1e3, "panel closed"), R.current === s && (R.current = null), r?.dispose(), z.current = null, B.current = null;
		};
	}, [e.Path, e.Protocol]);
	r(() => {
		!_ || !e.Enabled || K();
	}, [
		e.Enabled,
		_,
		K
	]), r(() => {
		let e = V.current.find((e) => e.terminal_session_id === N) || null;
		if (!_ || !e) return;
		let t = () => {}, n = !1;
		return J(e).then((e) => {
			t = e, n && t();
		}), () => {
			n = !0, t();
		};
	}, [
		N,
		J,
		_
	]);
	let Y = async (e) => {
		let t = j.filter((t) => t.terminal_session_id !== e);
		M(t), N === e && (P(t[0]?.terminal_session_id || null), t.length === 0 && A("idle"), R.current?.close(1e3, "terminal session deleted"), R.current = null, z.current?.dispose(), z.current = null, B.current = null, L.current && (L.current.innerHTML = ""));
		let n = await fetch(`${g}/${e}`, { method: "DELETE" });
		!n.ok && n.status !== 404 && A("error"), await K();
	};
	return _ ? /* @__PURE__ */ h("div", {
		className: "fixed inset-0 z-50 overflow-hidden border border-slate-800 bg-slate-950 text-slate-100 shadow-2xl shadow-slate-950/40 sm:inset-3 sm:rounded-3xl",
		children: [/* @__PURE__ */ h("div", {
			className: "flex items-center justify-between border-b border-slate-800 bg-slate-900 px-4 py-3",
			children: [/* @__PURE__ */ h("div", {
				className: "flex min-w-0 items-center gap-3",
				children: [/* @__PURE__ */ m("div", {
					className: "flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-300",
					children: /* @__PURE__ */ m(d, { className: "h-4 w-4" })
				}), /* @__PURE__ */ h("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ m("div", {
						className: "truncate text-sm font-semibold",
						children: "Native TUI"
					}), /* @__PURE__ */ h("div", {
						className: "flex items-center gap-1.5 text-xs text-slate-400",
						children: [/* @__PURE__ */ m(c, { className: "h-3 w-3" }), E]
					})]
				})]
			}), /* @__PURE__ */ h("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => void K(),
						className: "rounded-xl p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100",
						"aria-label": "刷新会话列表",
						children: /* @__PURE__ */ m(u, { className: t("h-4 w-4", F && "animate-spin") })
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => void G({ forceNew: !0 }),
						className: "rounded-xl p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100",
						"aria-label": "新建终端会话",
						children: /* @__PURE__ */ m(l, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: v,
						className: "rounded-xl p-2 text-slate-400 transition hover:bg-slate-800 hover:text-slate-100",
						"aria-label": "关闭 TUI",
						children: /* @__PURE__ */ m(p, { className: "h-4 w-4" })
					})
				]
			})]
		}), /* @__PURE__ */ h("div", {
			className: "grid h-[calc(100%-4rem)] min-h-0 grid-cols-[18rem_minmax(0,1fr)] bg-slate-950",
			children: [/* @__PURE__ */ h("aside", {
				className: "flex min-h-0 flex-col border-r border-slate-800 bg-slate-950",
				children: [/* @__PURE__ */ m("div", {
					className: "border-b border-slate-800 px-4 py-3 text-xs font-medium uppercase tracking-[0.12em] text-slate-500",
					children: "会话"
				}), /* @__PURE__ */ h("div", {
					className: "min-h-0 flex-1 overflow-y-auto p-2",
					children: [j.length === 0 ? /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => void G({ forceNew: !0 }),
						className: "flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-700 px-3 py-5 text-sm text-slate-400 transition hover:bg-slate-900",
						children: [/* @__PURE__ */ m(l, { className: "h-4 w-4" }), "新建终端会话"]
					}) : null, j.map((e) => /* @__PURE__ */ h("div", {
						role: "button",
						tabIndex: 0,
						onClick: () => P(e.terminal_session_id),
						onKeyDown: (t) => {
							(t.key === "Enter" || t.key === " ") && (t.preventDefault(), P(e.terminal_session_id));
						},
						className: t("group mb-2 rounded-2xl border px-3 py-3 text-left transition", N === e.terminal_session_id ? "border-emerald-400/50 bg-emerald-500/10" : "border-slate-800 bg-slate-900/60 hover:bg-slate-900"),
						children: [/* @__PURE__ */ h("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ h("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ m("div", {
									className: "truncate text-sm font-medium text-slate-100",
									children: e.terminal_session_id
								}), /* @__PURE__ */ m("div", {
									className: "mt-1 text-[11px] text-slate-400",
									children: e.session_id || "未绑定会话"
								})]
							}), /* @__PURE__ */ h("div", {
								className: "flex items-center gap-1",
								children: [e.status === "running" ? /* @__PURE__ */ m(s, { className: "h-3.5 w-3.5 text-emerald-400" }) : null, /* @__PURE__ */ m("button", {
									type: "button",
									onClick: (t) => {
										t.stopPropagation(), Y(e.terminal_session_id);
									},
									className: "rounded-lg p-1.5 text-slate-500 opacity-0 transition hover:bg-slate-800 hover:text-rose-300 group-hover:opacity-100",
									title: "关闭会话",
									children: /* @__PURE__ */ m(f, { className: "h-3.5 w-3.5" })
								})]
							})]
						}), /* @__PURE__ */ h("div", {
							className: "mt-3 flex items-center gap-2 text-[11px] text-slate-500",
							children: [
								/* @__PURE__ */ m("span", {
									className: "rounded-full border border-slate-700 px-2 py-0.5",
									children: e.mode
								}),
								/* @__PURE__ */ h("span", {
									className: "rounded-full border border-slate-700 px-2 py-0.5",
									children: [
										e.cols,
										"x",
										e.rows
									]
								}),
								/* @__PURE__ */ m("span", {
									className: "rounded-full border border-slate-700 px-2 py-0.5",
									children: e.status
								})
							]
						})]
					}, e.terminal_session_id))]
				})]
			}), /* @__PURE__ */ m("section", {
				className: "min-h-0 bg-slate-950 p-2",
				children: /* @__PURE__ */ h("div", {
					className: "flex h-full min-h-0 flex-col overflow-hidden rounded-2xl border border-slate-800 bg-slate-950",
					children: [/* @__PURE__ */ h("div", {
						className: "flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-4 py-2 text-xs text-slate-400",
						children: [/* @__PURE__ */ h("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ m("span", {
								className: "rounded-full border border-slate-700 px-2 py-0.5",
								children: W?.terminal_session_id || "no session"
							}), /* @__PURE__ */ m("span", { children: W?.status || "idle" })]
						}), /* @__PURE__ */ m("div", {
							className: "text-slate-500",
							children: W?.cwd || W?.session_id || "attach to a terminal session"
						})]
					}), /* @__PURE__ */ h("div", {
						className: "relative min-h-0 flex-1",
						children: [E === "connecting" ? /* @__PURE__ */ m("div", {
							className: "absolute left-5 top-5 z-10 rounded-full bg-slate-900/90 px-3 py-1 text-xs text-slate-400",
							children: "正在连接原生 TUI..."
						}) : null, /* @__PURE__ */ m("div", {
							ref: L,
							className: "h-full w-full overflow-hidden bg-slate-950"
						})]
					})]
				})
			})]
		})]
	}) : null;
}
//#endregion
export { E as n, A as t };
