import { d as e, g as t, p as n, u as r } from "./a2ui-B1x5yNaJ.js";
import { t as i } from "./utils-CX-Pz5p6.js";
import { n as a, t as o } from "./permission-BWNFYYw-.js";
import { t as s } from "./MessageMarkdown-Lj01l-_B.js";
import { n as c, t as l } from "./sandbox-BTRIKAO6.js";
import * as u from "react";
import { Suspense as d, lazy as f, useCallback as p, useEffect as m, useId as h, useLayoutEffect as g, useMemo as _, useRef as v, useState as y } from "react";
import { ArrowUp as b, Code as x, Download as S, ExternalLink as C, Eye as w, FileCode2 as T, FileText as ee, FolderOpen as E, Image as te, Loader2 as ne, LoaderCircle as D, Maximize2 as re, MessageSquarePlus as ie, MessageSquareText as ae, Minimize2 as oe, MoreHorizontal as se, Package as ce, PanelLeft as O, PanelLeftClose as le, Pin as k, PinOff as A, RefreshCw as ue, Save as de, Search as fe, ShieldCheck as j, TerminalSquare as M, Trash2 as pe, Upload as me, X as he } from "lucide-react";
import { Fragment as N, jsx as P, jsxs as F } from "react/jsx-runtime";
import * as I from "@radix-ui/react-dialog";
import { cva as ge } from "class-variance-authority";
import { EditorView as L, crosshairCursor as R, drawSelection as z, dropCursor as B, highlightActiveLine as V, highlightActiveLineGutter as H, keymap as U, lineNumbers as W, rectangularSelection as _e } from "@codemirror/view";
import { Compartment as G, EditorState as K } from "@codemirror/state";
import { defaultKeymap as ve, history as q, historyKeymap as J, indentWithTab as ye } from "@codemirror/commands";
import { LanguageDescription as be, bracketMatching as xe, defaultHighlightStyle as Se, foldGutter as Y, foldKeymap as Ce, indentOnInput as we, syntaxHighlighting as Te } from "@codemirror/language";
import { oneDark as Ee } from "@codemirror/theme-one-dark";
import { highlightSelectionMatches as De, searchKeymap as Oe } from "@codemirror/search";
import { autocompletion as ke, closeBrackets as Ae, closeBracketsKeymap as je, completionKeymap as Me } from "@codemirror/autocomplete";
import { languages as Ne } from "@codemirror/language-data";
//#region src/components/AgentAuthorizationBoundary.tsx
function Pe() {
	return /* @__PURE__ */ P("div", {
		className: "ksadk-web",
		children: /* @__PURE__ */ P("div", {
			role: "status",
			className: "fixed inset-0 flex items-center justify-center bg-background text-sm text-text-muted",
			children: "正在初始化会话身份…"
		})
	});
}
function Fe({ authorizationScopeKey: t, children: i }) {
	let [s, c] = y(!1);
	return g(() => {
		if (n.enter(t) === "reload") {
			window.location.reload();
			return;
		}
		e.setState({ pinnedSessionIds: r() }), a.setState({ permissionMode: o() }), c(!0);
	}, [t]), !s || !n.matches(t) ? /* @__PURE__ */ P(Pe, {}) : i;
}
//#endregion
//#region src/components/ui/sheet.tsx
var Ie = I.Root, Le = I.Portal, Re = u.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ P(I.Overlay, {
	className: i("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", e),
	...t,
	ref: n
}));
Re.displayName = I.Overlay.displayName;
var ze = ge("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left",
		right: "inset-y-0 right-0 h-full border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right"
	} },
	defaultVariants: { side: "right" }
}), Be = u.forwardRef(({ side: e = "right", className: t, children: n, showOverlay: r = !0, showCloseButton: a = !0, ...o }, s) => /* @__PURE__ */ F(Le, { children: [r ? /* @__PURE__ */ P(Re, {}) : null, /* @__PURE__ */ F(I.Content, {
	ref: s,
	className: i(ze({ side: e }), t),
	...o,
	children: [n, a ? /* @__PURE__ */ F(I.Close, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ P(he, { className: "h-4 w-4" }), /* @__PURE__ */ P("span", {
			className: "sr-only",
			children: "Close"
		})]
	}) : null]
})] }));
Be.displayName = I.Content.displayName;
var Ve = ({ className: e, ...t }) => /* @__PURE__ */ P("div", {
	className: i("flex flex-col space-y-2 text-center sm:text-left", e),
	...t
});
Ve.displayName = "SheetHeader";
var He = ({ className: e, ...t }) => /* @__PURE__ */ P("div", {
	className: i("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", e),
	...t
});
He.displayName = "SheetFooter";
var Ue = u.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ P(I.Title, {
	ref: n,
	className: i("text-lg font-semibold text-foreground", e),
	...t
}));
Ue.displayName = I.Title.displayName;
var We = u.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ P(I.Description, {
	ref: n,
	className: i("text-sm text-muted-foreground", e),
	...t
}));
We.displayName = I.Description.displayName;
//#endregion
//#region src/components/chat/ChatHeader.tsx
var Ge = f(() => import("./NativeTerminalPanel-beSt6mii.js").then((e) => e.n).then((e) => ({ default: e.NativeTerminalPanel })));
function Ke({ availableModels: e, selectedModel: t, onSelectModel: n, selectedModelLabel: r, modelCatalogLoaded: a, modelSource: o, thinkingEnabled: s, thinkingMode: c, onSelectThinkingMode: l, compact: u = !1 }) {
	let d = i("rounded-full border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none transition-colors focus:ring-1 focus:ring-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300", u ? "w-full" : "max-w-[13rem]"), f = e.length > 1 ? /* @__PURE__ */ P("select", {
		value: t,
		onChange: (e) => n(e.target.value),
		className: d,
		children: e.map((e) => /* @__PURE__ */ P("option", {
			value: e.id,
			children: e.display_name || e.id
		}, e.id))
	}) : r ? /* @__PURE__ */ P("span", {
		className: i(d, "inline-flex max-w-full items-center", u ? "justify-start" : ""),
		title: o || r,
		children: /* @__PURE__ */ P("span", {
			className: "truncate",
			children: r
		})
	}) : /* @__PURE__ */ P("span", {
		className: "text-sm text-slate-400",
		children: a ? "未配置模型" : "Loading models..."
	}), p = s ? /* @__PURE__ */ F("select", {
		value: c,
		onChange: (e) => l(e.target.value),
		className: i(d, u ? "" : "max-w-[9rem]"),
		title: "控制模型 thinking/reasoning 参数",
		children: [
			/* @__PURE__ */ P("option", {
				value: "auto",
				children: "思考自动"
			}),
			/* @__PURE__ */ P("option", {
				value: "enabled",
				children: "开启思考"
			}),
			/* @__PURE__ */ P("option", {
				value: "disabled",
				children: "关闭思考"
			})
		]
	}) : null;
	return /* @__PURE__ */ F("div", {
		className: i("flex min-w-0 gap-2", u ? "w-full flex-col" : "items-center"),
		children: [f, p]
	});
}
function qe({ agentName: e, currentSessionId: t, isMobile: n, sidebarOpen: r, mobileSidebarOpen: a, onToggleSidebar: o, availableModels: s, selectedModel: c, onSelectModel: l, selectedModelLabel: u, modelCatalogLoaded: f, modelSource: p, thinkingEnabled: m, thinkingMode: h, onSelectThinkingMode: g, mobileActionsOpen: _, onMobileActionsOpenChange: v, workspaceEnabled: b, onOpenWorkspace: x, nativeManagementLink: S, nativeTerminal: w, nativeLauncherMode: T = !1 }) {
	let [ee, te] = y(!1), ne = !!w?.Enabled, D = P(n ? a ? le : O : r ? le : O, { className: "h-5 w-5" });
	return /* @__PURE__ */ F(N, { children: [
		/* @__PURE__ */ F("header", {
			className: i("flex flex-shrink-0 items-center justify-between border-b border-black/[0.06] bg-background/95 px-3 py-2 backdrop-blur dark:border-white/[0.08] dark:bg-background/95 sm:px-4", n ? "pt-[calc(var(--safe-area-top)+0.5rem)]" : "h-12"),
			children: [/* @__PURE__ */ F("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [T ? null : /* @__PURE__ */ P("button", {
					type: "button",
					onClick: o,
					className: "rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-slate-800",
					"aria-label": n ? "打开历史记录" : "切换侧边栏",
					children: D
				}), /* @__PURE__ */ F("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ P("div", {
						className: "truncate text-sm font-semibold text-slate-900 dark:text-slate-100 sm:text-base",
						children: e
					}), /* @__PURE__ */ P("div", {
						className: "text-[11px] text-slate-400 dark:text-slate-500",
						children: T ? "原生运行时入口" : "智能体"
					})]
				})]
			}), n ? /* @__PURE__ */ P("button", {
				type: "button",
				onClick: () => v(!0),
				className: "rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-slate-800",
				"aria-label": "打开会话操作",
				children: /* @__PURE__ */ P(se, { className: "h-5 w-5" })
			}) : /* @__PURE__ */ F("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [
					S ? /* @__PURE__ */ F("a", {
						href: S.href,
						target: "_blank",
						rel: "noreferrer",
						title: S.title,
						className: "inline-flex flex-shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium leading-none text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700",
						children: [/* @__PURE__ */ P(C, { className: "h-4 w-4" }), /* @__PURE__ */ P("span", { children: S.label })]
					}) : null,
					b ? /* @__PURE__ */ F("button", {
						type: "button",
						onClick: x,
						className: "inline-flex flex-shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium leading-none text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700",
						children: [/* @__PURE__ */ P(E, { className: "h-4 w-4" }), /* @__PURE__ */ P("span", { children: "Workspace" })]
					}) : null,
					ne ? /* @__PURE__ */ F("button", {
						type: "button",
						onClick: () => te(!0),
						className: "inline-flex flex-shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium leading-none text-emerald-800 transition hover:bg-emerald-100 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-200",
						children: [/* @__PURE__ */ P(M, { className: "h-4 w-4" }), /* @__PURE__ */ P("span", { children: "TUI" })]
					}) : null,
					!T && n ? /* @__PURE__ */ P(Ke, {
						availableModels: s,
						selectedModel: c,
						onSelectModel: l,
						selectedModelLabel: u,
						modelCatalogLoaded: f,
						modelSource: p,
						thinkingEnabled: m,
						thinkingMode: h,
						onSelectThinkingMode: g,
						compact: !0
					}) : null,
					!T && t ? /* @__PURE__ */ F("span", {
						className: "rounded bg-slate-50 px-2 py-1 text-xs font-mono text-slate-400 dark:bg-slate-800",
						children: ["ID: ", t.slice(0, 8)]
					}) : null
				]
			})]
		}),
		n ? /* @__PURE__ */ P(Ie, {
			open: _,
			onOpenChange: v,
			children: /* @__PURE__ */ F(Be, {
				side: "bottom",
				className: "rounded-t-[1.75rem] border-slate-200 bg-white px-4 pb-[calc(var(--safe-area-bottom)+1rem)] pt-6 dark:border-slate-800 dark:bg-slate-900",
				children: [/* @__PURE__ */ F(Ve, {
					className: "text-left",
					children: [/* @__PURE__ */ P(Ue, { children: "会话设置" }), /* @__PURE__ */ P(We, {
						className: "sr-only",
						children: "调整当前会话的模型和 Workspace 操作。"
					})]
				}), /* @__PURE__ */ F("div", {
					className: "mt-6 flex flex-col gap-4",
					children: [
						b ? /* @__PURE__ */ F("button", {
							type: "button",
							onClick: () => {
								v(!1), x();
							},
							className: "inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-medium text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700",
							children: [/* @__PURE__ */ P(E, { className: "h-4 w-4" }), "工作区文件"]
						}) : null,
						ne ? /* @__PURE__ */ F("button", {
							type: "button",
							onClick: () => {
								v(!1), te(!0);
							},
							className: "inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-3 text-sm font-medium text-emerald-800 transition hover:bg-emerald-100 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-200",
							children: [/* @__PURE__ */ P(M, { className: "h-4 w-4" }), "原生 TUI"]
						}) : null,
						S ? /* @__PURE__ */ F("a", {
							href: S.href,
							target: "_blank",
							rel: "noreferrer",
							title: S.title,
							onClick: () => v(!1),
							className: "inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-medium text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700",
							children: [/* @__PURE__ */ P(C, { className: "h-4 w-4" }), S.label]
						}) : null,
						T ? /* @__PURE__ */ P("div", {
							className: "rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm leading-6 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300",
							children: "当前运行时对话在原生管理台中进行；这里保留管理入口和 Workspace 文件操作。"
						}) : /* @__PURE__ */ F(N, { children: [/* @__PURE__ */ F("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ P("div", {
								className: "text-xs font-medium uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500",
								children: "模型"
							}), /* @__PURE__ */ P(Ke, {
								availableModels: s,
								selectedModel: c,
								onSelectModel: l,
								selectedModelLabel: u,
								modelCatalogLoaded: f,
								modelSource: p,
								thinkingEnabled: m,
								thinkingMode: h,
								onSelectThinkingMode: g,
								compact: !0
							})]
						}), /* @__PURE__ */ F("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ P("div", {
								className: "text-xs font-medium uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500",
								children: "当前会话"
							}), /* @__PURE__ */ P("div", {
								className: "rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300",
								children: t ? /* @__PURE__ */ P("span", {
									className: "break-all font-mono",
									children: t
								}) : "新对话尚未创建会话 ID"
							})]
						})] })
					]
				})]
			})
		}) : null,
		w && ee ? /* @__PURE__ */ P(d, {
			fallback: null,
			children: /* @__PURE__ */ P(Ge, {
				capability: w,
				open: ee,
				sessionId: t,
				onClose: () => te(!1)
			})
		}) : null
	] });
}
//#endregion
//#region src/utils/session-list.js
var Je = new Set([
	"in_progress",
	"running",
	"resuming",
	"starting",
	"streaming",
	"queued",
	"pending",
	"accepted"
]), Ye = new Set([
	"failed",
	"error",
	"resume_failed",
	"interrupted",
	"cancelled",
	"canceled",
	"aborted",
	"expired"
]), Xe = 300 * 1e3;
function Ze(e) {
	let t = e?.UpdatedAt ?? e?.updated_at;
	if (typeof t == "string") {
		let e = Date.parse(t);
		return Number.isNaN(e) ? 0 : e;
	}
	return typeof t == "number" && Number.isFinite(t) ? t > 1e11 ? t : t * 1e3 : 0;
}
function Qe(e) {
	return String(e || "").trim().toLowerCase();
}
function $e(e) {
	if (!e) return "";
	let t = typeof e == "number" ? new Date(e > 1e11 ? e : e * 1e3) : new Date(e);
	return Number.isNaN(t.getTime()) ? "" : t.toLocaleString("zh-CN", {
		timeZone: "Asia/Shanghai",
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		hour12: !1
	});
}
function et(e) {
	return [
		e?.Title,
		e?.Summary,
		e?.FirstPrompt,
		e?.LastPrompt,
		e?.SessionId,
		e?.Model?.display_name,
		e?.Model?.id
	].map(Qe).join(" ");
}
function tt(e, t = {}) {
	if (!Je.has(Qe(e?.ActiveRunStatus))) return !1;
	let n = Ze(e);
	if (!n) return !0;
	let r = Number.isFinite(Number(t.now)) ? Number(t.now) : Date.now(), i = Number.isFinite(Number(t.activeStaleAfterMs)) ? Number(t.activeStaleAfterMs) : Xe;
	return r - n <= i;
}
function nt(e = [], t = "", n = {}) {
	let r = Qe(t), i = new Set(Array.isArray(n.pinnedSessionIds) ? n.pinnedSessionIds : []);
	return (Array.isArray(e) ? e : []).filter((e) => e?.SessionId).filter((e) => !r || et(e).includes(r)).slice().sort((e, t) => {
		let r = +!!i.has(e.SessionId), a = +!!i.has(t.SessionId);
		if (r !== a) return a - r;
		let o = +!!tt(e, n), s = +!!tt(t, n);
		return o === s ? Ze(t) - Ze(e) : s - o;
	});
}
function rt(e, t = {}) {
	let n = tt(e, t), r = Ye.has(Qe(e?.ActiveRunStatus));
	return {
		running: n,
		failed: r,
		label: n || r ? "" : $e(e?.UpdatedAt ?? e?.updated_at)
	};
}
//#endregion
//#region src/components/chat/ChatSidebar.tsx
function it({ sessions: e, currentSessionId: t, onCreateNewSession: n, onSelectSession: r, onDeleteSession: a, onTogglePinSession: o, onLoadMoreSessions: s, sessionTitle: c, pinnedSessionIds: l = [], hasMoreSessions: u = !1, isLoadingSessions: d = !1, className: f }) {
	let [p, m] = y(""), h = _(() => nt(e, p, { pinnedSessionIds: l }), [
		e,
		l,
		p
	]), g = _(() => new Set(l), [l]);
	return /* @__PURE__ */ F("div", {
		className: i("flex h-full min-h-0 flex-col bg-sidebar", f),
		children: [
			/* @__PURE__ */ F("div", {
				className: "flex flex-shrink-0 flex-col gap-2 border-b border-black/[0.06] px-3 py-3 dark:border-white/[0.08]",
				children: [/* @__PURE__ */ F("button", {
					type: "button",
					onClick: n,
					className: "flex h-[34px] w-full items-center justify-between rounded-[10px] px-2.5 text-sm font-medium text-sidebar-text-secondary transition-colors hover:bg-sidebar-hover hover:text-sidebar-text",
					children: [/* @__PURE__ */ F("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ P(ie, { className: "h-4 w-4" }), /* @__PURE__ */ P("span", { children: "新对话" })]
					}), /* @__PURE__ */ P("span", {
						className: "rounded border border-black/[0.08] px-1.5 py-0.5 text-[11px] text-sidebar-text-muted dark:border-white/[0.1]",
						children: "⌘ N"
					})]
				}), /* @__PURE__ */ F("label", {
					className: "flex h-9 items-center gap-2 rounded-[10px] border border-black/[0.06] bg-background px-2.5 text-xs text-sidebar-text-muted focus-within:border-primary/40 dark:border-white/[0.08]",
					children: [/* @__PURE__ */ P(fe, { className: "h-3.5 w-3.5 flex-shrink-0" }), /* @__PURE__ */ P("input", {
						value: p,
						onChange: (e) => m(e.target.value),
						className: "min-w-0 flex-1 bg-transparent text-sm text-sidebar-text outline-none placeholder:text-sidebar-text-muted",
						placeholder: "搜索会话、模型或摘要"
					})]
				})]
			}),
			/* @__PURE__ */ F("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-2 pb-4 pt-2 custom-scrollbar",
				onScroll: (e) => {
					if (!s || d || !u || p.trim()) return;
					let t = e.currentTarget;
					t.scrollHeight - t.scrollTop - t.clientHeight < 200 && s();
				},
				children: [/* @__PURE__ */ F("div", {
					className: "px-2.5 py-2 text-xs font-medium text-sidebar-text-muted opacity-75",
					children: ["历史记录", p.trim() ? ` · ${h.length}` : ""]
				}), /* @__PURE__ */ F("div", {
					className: "flex flex-col gap-0.5",
					children: [h.length > 0 ? h.map((e) => {
						let n = rt(e), s = g.has(e.SessionId), l = t === e.SessionId;
						return /* @__PURE__ */ F("div", {
							className: i("group relative flex h-[30px] items-center gap-1 rounded-[10px] border-l-2 border-transparent px-2 text-sm leading-5 transition-colors", l ? "border-l-2 border-primary bg-primary/10 font-medium text-sidebar-text" : n.running ? "cursor-pointer bg-primary/[0.035] text-sidebar-text" : "cursor-pointer text-sidebar-text-secondary hover:bg-sidebar-hover hover:text-sidebar-text"),
							children: [/* @__PURE__ */ F("button", {
								type: "button",
								"aria-current": l ? "page" : void 0,
								className: "flex min-w-0 flex-1 items-center gap-1 text-left outline-none focus-visible:ring-2 focus-visible:ring-primary/60",
								onClick: () => r(e.SessionId),
								children: [/* @__PURE__ */ P("span", {
									className: "min-w-0 flex-1 truncate text-[13px]",
									children: c(e)
								}), n.running ? /* @__PURE__ */ P("span", {
									"aria-label": "运行中",
									className: "h-1.5 w-1.5 flex-shrink-0 animate-spin rounded-full border border-primary border-t-transparent"
								}) : n.failed ? /* @__PURE__ */ P("span", {
									"aria-label": "运行失败",
									title: "运行失败",
									className: "h-1.5 w-1.5 flex-shrink-0 rounded-full bg-rose-500/75"
								}) : n.label ? /* @__PURE__ */ P("span", {
									className: "flex-shrink-0 text-[11px] leading-none text-sidebar-text-muted group-hover:hidden",
									children: n.label
								}) : null]
							}), /* @__PURE__ */ F("div", {
								className: "absolute right-1 top-1/2 flex -translate-y-1/2 items-center justify-end gap-0.5 opacity-0 transition-opacity group-focus-within:opacity-100 group-hover:opacity-100",
								children: [/* @__PURE__ */ P("button", {
									type: "button",
									onClick: (t) => o(e.SessionId, t),
									className: i("flex h-6 w-6 items-center justify-center rounded-md text-sidebar-text-muted hover:bg-sidebar-active hover:text-sidebar-text", s && "text-primary opacity-100"),
									title: s ? "取消置顶" : "置顶会话",
									"aria-label": s ? "取消置顶会话" : "置顶会话",
									children: P(s ? A : k, { className: "h-3.5 w-3.5" })
								}), /* @__PURE__ */ P("button", {
									type: "button",
									onClick: (t) => a(e.SessionId, t),
									className: "flex h-6 w-6 items-center justify-center rounded-md text-sidebar-text-muted hover:bg-sidebar-active hover:text-rose-500",
									title: "删除会话",
									children: /* @__PURE__ */ P(pe, { className: "h-3.5 w-3.5" })
								})]
							})]
						}, e.SessionId);
					}) : /* @__PURE__ */ P("div", {
						className: "rounded-xl border border-dashed border-black/[0.08] px-3 py-8 text-center text-xs text-sidebar-text-muted dark:border-white/[0.1]",
						children: "没有匹配的会话"
					}), d ? /* @__PURE__ */ F("div", {
						className: "flex items-center justify-center gap-2 px-3 py-3 text-xs text-sidebar-text-muted",
						children: [/* @__PURE__ */ P(D, { className: "h-3.5 w-3.5 animate-spin" }), /* @__PURE__ */ P("span", { children: "加载中" })]
					}) : null]
				})]
			}),
			/* @__PURE__ */ F("div", {
				className: "border-t border-black/[0.06] px-4 py-3 text-center dark:border-white/[0.08]",
				children: [
					/* @__PURE__ */ P("div", {
						className: "text-[10px] font-medium tracking-[0.14em] text-sidebar-text-muted",
						children: "POWERED BY"
					}),
					/* @__PURE__ */ P("div", {
						className: "mt-1 bg-gradient-to-r from-blue-600 to-indigo-500 bg-clip-text text-xs font-bold text-transparent dark:from-blue-400 dark:to-indigo-300",
						children: "Ksyun AgentEngine"
					}),
					/* @__PURE__ */ P("div", {
						className: "mx-auto mt-2 max-w-[13rem] text-[10px] leading-4 text-sidebar-text-muted",
						children: "Agent 可能产生不准确的信息，请独立验证。"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/native/NativeRuntimeLauncher.tsx
var at = f(() => import("./NativeTerminalPanel-beSt6mii.js").then((e) => e.n).then((e) => ({ default: e.NativeTerminalPanel })));
function ot({ productLabel: e = "原生运行时", nativeManagementLink: t, nativeTerminal: n, workspaceEnabled: r, onOpenWorkspace: i }) {
	let a = !!n?.Enabled, [o, s] = y(!1);
	return /* @__PURE__ */ F("section", {
		className: "flex min-h-0 flex-1 overflow-y-auto bg-[radial-gradient(circle_at_top_left,rgba(14,165,233,0.12),transparent_34%),linear-gradient(135deg,#f8fafc_0%,#ffffff_48%,#f1f5f9_100%)] px-4 py-8 dark:bg-[radial-gradient(circle_at_top_left,rgba(14,165,233,0.16),transparent_34%),linear-gradient(135deg,#020617_0%,#0f172a_52%,#111827_100%)] sm:px-8",
		children: [/* @__PURE__ */ P("div", {
			className: "mx-auto flex w-full max-w-5xl flex-col justify-center",
			children: /* @__PURE__ */ F("div", {
				className: "overflow-hidden rounded-[2rem] border border-slate-200/80 bg-white/90 shadow-xl shadow-slate-200/60 backdrop-blur dark:border-slate-800 dark:bg-slate-900/85 dark:shadow-black/30",
				children: [/* @__PURE__ */ F("div", {
					className: "border-b border-slate-200/80 bg-slate-50/80 px-6 py-5 dark:border-slate-800 dark:bg-slate-950/40 sm:px-8",
					children: [
						/* @__PURE__ */ F("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-sky-200 bg-sky-50 px-3 py-1 text-xs font-medium text-sky-700 dark:border-sky-900/60 dark:bg-sky-950/50 dark:text-sky-300",
							children: [
								/* @__PURE__ */ P(j, { className: "h-3.5 w-3.5" }),
								e,
								" native runtime"
							]
						}),
						/* @__PURE__ */ P("h1", {
							className: "mt-5 text-2xl font-semibold tracking-tight text-slate-950 dark:text-slate-50 sm:text-3xl",
							children: "对话请使用原生管理台"
						}),
						/* @__PURE__ */ P("p", {
							className: "mt-3 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-300 sm:text-base",
							children: "当前运行时的对话状态由原生管理台承载。AgentEngine Hosted UI 在这里保留统一入口和 Workspace 文件管理，不重复实现运行时内部已有的复杂对话状态机。"
						})
					]
				}), /* @__PURE__ */ F("div", {
					className: "grid gap-4 p-6 md:grid-cols-3 sm:p-8",
					children: [
						/* @__PURE__ */ F("div", {
							className: "rounded-3xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900",
							children: [
								/* @__PURE__ */ P("div", {
									className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white dark:bg-slate-100 dark:text-slate-950",
									children: /* @__PURE__ */ P(ae, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ P("h2", {
									className: "mt-4 text-base font-semibold text-slate-950 dark:text-slate-50",
									children: "原生管理台"
								}),
								/* @__PURE__ */ P("p", {
									className: "mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300",
									children: "使用原生管理台处理对话、工具卡片、思考流、审批、中断和运行时历史，避免跨状态机不一致。"
								}),
								t ? /* @__PURE__ */ F("a", {
									href: t.href,
									target: "_blank",
									rel: "noreferrer",
									title: t.title,
									className: "mt-5 inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white",
									children: [
										/* @__PURE__ */ P(C, { className: "h-4 w-4" }),
										"打开",
										t.label
									]
								}) : /* @__PURE__ */ P("div", {
									className: "mt-5 rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-sm leading-6 text-neutral-800 dark:border-neutral-900/60 dark:bg-neutral-950/30 dark:text-neutral-200",
									children: "当前访问模式不开放原生管理入口。需要完整对话体验时，请使用 owner/private 链接或 CLI。"
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "rounded-3xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900",
							children: [
								/* @__PURE__ */ P("div", {
									className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300",
									children: /* @__PURE__ */ P(E, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ P("h2", {
									className: "mt-4 text-base font-semibold text-slate-950 dark:text-slate-50",
									children: "Workspace 文件管理"
								}),
								/* @__PURE__ */ P("p", {
									className: "mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300",
									children: "文件浏览、上传、预览仍由 Hosted UI 提供，和原生管理台组合使用覆盖对话与工作区。"
								}),
								r ? /* @__PURE__ */ F("button", {
									type: "button",
									onClick: i,
									className: "mt-5 inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-800 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700",
									children: [/* @__PURE__ */ P(E, { className: "h-4 w-4" }), "打开 Workspace"]
								}) : /* @__PURE__ */ P("div", {
									className: "mt-5 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-6 text-slate-500 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-400",
									children: "当前链接未开放 Workspace 文件管理。Owner 或 private 链接可使用该能力。"
								})
							]
						}),
						/* @__PURE__ */ F("div", {
							className: "rounded-3xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900",
							children: [
								/* @__PURE__ */ P("div", {
									className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
									children: /* @__PURE__ */ P(M, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ P("h2", {
									className: "mt-4 text-base font-semibold text-slate-950 dark:text-slate-50",
									children: "原生 TUI"
								}),
								/* @__PURE__ */ P("p", {
									className: "mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300",
									children: "如果运行时暴露安全的 ks-terminal.v1 通道，可以在这里进入原生终端 UI；share 链接不会开放该入口。"
								}),
								a ? /* @__PURE__ */ F("button", {
									type: "button",
									onClick: () => s(!0),
									className: "mt-5 inline-flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-sm font-medium text-emerald-800 transition hover:bg-emerald-100 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-200",
									children: [/* @__PURE__ */ P(M, { className: "h-4 w-4" }), "打开 TUI"]
								}) : /* @__PURE__ */ P("div", {
									className: "mt-5 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-6 text-slate-500 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-400",
									children: "当前运行时未声明可用的浏览器 TUI 能力。"
								})
							]
						})
					]
				})]
			})
		}), n && o ? /* @__PURE__ */ P(d, {
			fallback: null,
			children: /* @__PURE__ */ P(at, {
				capability: n,
				open: o,
				onClose: () => s(!1)
			})
		}) : null]
	});
}
//#endregion
//#region src/components/workspace/FileEditor.tsx
function st(e) {
	let t = String(e || "").split("/").pop() || "", n = t.lastIndexOf(".");
	return n >= 0 ? t.slice(n) : "";
}
function ct(e) {
	return be.matchFilename(Ne, `file${e}`);
}
function X({ content: e, path: t, readOnly: n = !1, onSave: r, onDirtyChange: i, onContentChange: a, getContentRef: o }) {
	let s = v(null), c = v(null), l = v(new G()), u = v(new G()), d = v(new G()), f = v(!1), h = v(r), g = v(i), _ = v(a);
	m(() => {
		h.current = r, g.current = i, _.current = a;
	}, [
		r,
		i,
		a
	]);
	let y = p((e) => {
		f.current !== e && (f.current = e, g.current?.(e));
	}, []);
	return m(() => {
		if (!s.current) return;
		let r = document.documentElement.classList.contains("dark"), i = U.of([{
			key: "Mod-s",
			run: (e) => {
				let t = e.state.doc.toString();
				return h.current?.(t), y(!1), !0;
			},
			preventDefault: !0
		}]), a = new L({
			state: K.create({
				doc: e,
				extensions: [
					W(),
					H(),
					q(),
					Y(),
					z(),
					B(),
					K.allowMultipleSelections.of(!0),
					we(),
					Te(Se, { fallback: !0 }),
					xe(),
					Ae(),
					ke(),
					_e(),
					R(),
					V(),
					De(),
					U.of([
						...je,
						...ve,
						...Oe,
						...J,
						...Ce,
						...Me,
						ye
					]),
					i,
					L.updateListener.of((e) => {
						e.docChanged && (y(!0), _.current?.(e.state.doc.toString()));
					}),
					d.current.of(K.readOnly.of(n)),
					l.current.of([]),
					u.current.of(r ? Ee : []),
					L.theme({
						"&": { height: "100%" },
						".cm-scroller": { overflow: "auto" }
					})
				]
			}),
			parent: s.current
		});
		c.current = a, o && (o.current = () => a.state.doc.toString());
		let f = ct(st(t));
		return f && f.load().then((e) => {
			c.current && c.current.dispatch({ effects: l.current.reconfigure(e) });
		}).catch(() => {}), () => {
			a.destroy(), c.current = null, o && (o.current = null);
		};
	}, []), m(() => {
		let t = c.current;
		if (!t) return;
		let n = t.state.doc.toString();
		n !== e && (t.dispatch({ changes: {
			from: 0,
			to: n.length,
			insert: e
		} }), y(!1));
	}, [e, y]), m(() => {
		let e = c.current;
		if (!e) return;
		let n = ct(st(t));
		n ? n.load().then((e) => {
			c.current && c.current.dispatch({ effects: l.current.reconfigure(e) });
		}).catch(() => {}) : e.dispatch({ effects: l.current.reconfigure([]) });
	}, [t]), m(() => {
		let e = c.current;
		e && e.dispatch({ effects: d.current.reconfigure(K.readOnly.of(n)) });
	}, [n]), m(() => {
		let e = new MutationObserver(() => {
			let e = c.current;
			if (!e) return;
			let t = document.documentElement.classList.contains("dark");
			e.dispatch({ effects: u.current.reconfigure(t ? Ee : []) });
		});
		return e.observe(document.documentElement, {
			attributes: !0,
			attributeFilter: ["class"]
		}), () => e.disconnect();
	}, []), /* @__PURE__ */ P("div", {
		ref: s,
		className: "h-full w-full overflow-hidden [&_.cm-editor]:h-full [&_.cm-scroller]:auto"
	});
}
//#endregion
//#region src/components/workspace/FilePreview.tsx
function lt({ content: e, objectUrl: t, kind: n, filename: r, path: i }) {
	return n === "markdown" ? /* @__PURE__ */ P(s, { content: e || "" }) : n === "image" && t ? /* @__PURE__ */ P("div", {
		className: "flex items-center justify-center p-4",
		children: /* @__PURE__ */ P("img", {
			src: t,
			alt: r,
			className: "max-h-[70vh] max-w-full rounded object-contain"
		})
	}) : n === "pdf" && t ? /* @__PURE__ */ P("iframe", {
		src: t,
		title: r,
		className: "h-full w-full border-0"
	}) : (n === "text" || n === "code") && e !== null ? /* @__PURE__ */ P(X, {
		content: e,
		path: i || r,
		readOnly: !0,
		onSave: () => {},
		onDirtyChange: () => {},
		getContentRef: { current: () => e || "" }
	}) : /* @__PURE__ */ P("div", {
		className: "flex h-full items-center justify-center px-6 text-center",
		children: /* @__PURE__ */ P("div", {
			className: "w-full max-w-md rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-5 py-5 text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400",
			children: "该文件类型暂不支持在线预览，请直接下载查看。"
		})
	});
}
var Z = "/_ksadk/workspace/v1/files", ut = new Set([
	".md",
	".markdown",
	".mdx"
]), dt = new Set([".pdf"]), ft = new Set([
	".png",
	".jpg",
	".jpeg",
	".gif",
	".webp",
	".svg",
	".bmp",
	".ico"
]), pt = new Set(/* @__PURE__ */ ".txt,.log,.json,.yaml,.yml,.xml,.html,.css,.js,.jsx,.ts,.tsx,.py,.sh,.sql,.csv,.tsv,.toml,.ini,.env,.lock,.conf,.c,.cc,.cpp,.go,.java,.rs".split(",")), mt = new Set([
	"application/json",
	"application/ld+json",
	"application/xml",
	"application/javascript",
	"application/x-javascript",
	"application/typescript",
	"application/x-sh",
	"application/x-yaml",
	"application/yaml",
	"text/csv",
	"text/tab-separated-values"
]);
function Q(e) {
	let t = String(e || "").trim().replace(/\\/g, "/");
	if (!t || t === "/") return ".";
	let n = [];
	for (let e of t.split("/")) {
		let t = e.trim();
		if (!(!t || t === ".")) {
			if (t === "..") {
				n.length > 0 && n.pop();
				continue;
			}
			n.push(t);
		}
	}
	return n.length > 0 ? n.join("/") : ".";
}
function ht(e) {
	let t = Q(e);
	return t === "." ? "" : t.split("/").filter(Boolean).map((e) => encodeURIComponent(e)).join("/");
}
function gt(e) {
	let t = ht(e);
	return t ? `${Z}/${t}` : Z;
}
function _t(e) {
	let t = Q(e);
	if (t === "." || !t.includes("/")) return `${Z}/`;
	let n = ht(t.substring(0, t.lastIndexOf("/")));
	return n ? `${Z}/${n}/` : `${Z}/`;
}
function vt(e) {
	return Q(e) === ".";
}
function yt(e) {
	let t = Q(e);
	return t === "." ? "/" : `/${t}`;
}
function bt(e) {
	let t = String(e || "").split("/").pop() || "", n = t.lastIndexOf(".");
	return n >= 0 ? t.slice(n).toLowerCase() : "";
}
function xt(e) {
	return String(e || "").split(";")[0].trim().toLowerCase();
}
var St = new Set([".html", ".htm"]);
function $({ path: e, mimeType: t }) {
	let n = bt(e), r = xt(t);
	return r === "text/html" || St.has(n) ? "html" : r === "text/markdown" || ut.has(n) ? "markdown" : r === "application/pdf" || dt.has(n) ? "pdf" : r.startsWith("image/") || ft.has(n) ? "image" : r.startsWith("text/") || mt.has(r) || pt.has(n) ? "text" : "unsupported";
}
var Ct = new Set([
	".txt",
	".log",
	".csv",
	".tsv",
	".env",
	".ini",
	".conf",
	".lock"
]);
function wt({ path: e, mimeType: t }) {
	let n = bt(e), r = xt(t);
	return St.has(n) || r === "text/html" ? "html" : r === "text/markdown" || ut.has(n) ? "markdown" : r === "application/pdf" || dt.has(n) || r.startsWith("image/") || ft.has(n) ? null : Ct.has(n) || r === "text/plain" ? "text" : r.startsWith("text/") || mt.has(r) || pt.has(n) ? "code" : null;
}
function Tt({ isMobile: e }) {
	return e ? {
		renderMode: "sheet",
		modal: !0,
		showOverlay: !0,
		preventOutsideClose: !1,
		side: "bottom"
	} : {
		renderMode: "inline",
		modal: !1,
		showOverlay: !1,
		preventOutsideClose: !0,
		side: "right"
	};
}
function Et() {
	let e = 0;
	return {
		next(t) {
			return e += 1, {
				path: t,
				version: e
			};
		},
		invalidate() {
			e += 1;
		},
		isCurrent(t) {
			return !!t && t.version === e;
		}
	};
}
function Dt({ workspaceFiles: e, accessMode: t }) {
	if (!e?.Enabled) return !1;
	let n = String(t || "").trim().toLowerCase();
	return n === "owner" || n === "private";
}
//#endregion
//#region src/components/workspace/HtmlPreview.tsx
function Ot({ content: e, path: t, onSave: n, onDirtyChange: r, getContentRef: a, isMobile: o }) {
	let s = v(null), u = h(), [d, f] = y("preview"), g = _t(t), _ = gt(t), b = p(() => l(e, {
		basePath: g,
		channelId: u
	}), [
		e,
		g,
		u
	]), [S, T] = y(b());
	m(() => {
		let e = setTimeout(() => {
			T(b());
		}, 300);
		return () => clearTimeout(e);
	}, [b]), c(s, u);
	let ee = p(() => {
		let e = new Blob([S], { type: "text/html;charset=utf-8" }), t = URL.createObjectURL(e), n = window.open(t, "_blank", "noopener,noreferrer");
		window.setTimeout(() => URL.revokeObjectURL(t), 3e4), n || window.open(_, "_blank", "noopener,noreferrer");
	}, [_, S]);
	return o ? /* @__PURE__ */ F("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ F("div", {
			className: "flex items-center gap-1 border-b border-slate-200 px-2 py-1.5 dark:border-slate-700",
			children: [/* @__PURE__ */ F("button", {
				onClick: () => f("editor"),
				className: i("flex items-center gap-1.5 rounded-md px-3 py-1 text-xs font-medium transition-colors", d === "editor" ? "bg-slate-100 text-slate-900 dark:bg-slate-700 dark:text-slate-100" : "text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"),
				children: [/* @__PURE__ */ P(x, { className: "h-3.5 w-3.5" }), "编辑"]
			}), /* @__PURE__ */ F("button", {
				onClick: () => f("preview"),
				className: i("flex items-center gap-1.5 rounded-md px-3 py-1 text-xs font-medium transition-colors", d === "preview" ? "bg-slate-100 text-slate-900 dark:bg-slate-700 dark:text-slate-100" : "text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"),
				children: [/* @__PURE__ */ P(w, { className: "h-3.5 w-3.5" }), "预览"]
			})]
		}), d === "editor" ? /* @__PURE__ */ P(X, {
			content: e,
			path: t,
			onSave: n,
			onDirtyChange: r,
			getContentRef: a
		}) : /* @__PURE__ */ P("iframe", {
			ref: s,
			srcDoc: S,
			sandbox: "allow-scripts allow-downloads allow-same-origin",
			title: "HTML 预览",
			className: "h-full w-full border-0 bg-white"
		})]
	}) : d === "editor" ? /* @__PURE__ */ F("div", {
		className: "relative flex h-full flex-col",
		children: [/* @__PURE__ */ P(X, {
			content: e,
			path: t,
			onSave: n,
			onDirtyChange: r,
			getContentRef: a
		}), /* @__PURE__ */ F("button", {
			onClick: () => f("preview"),
			className: "absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/90 dark:text-slate-300 dark:hover:bg-slate-700",
			children: [/* @__PURE__ */ P(w, { className: "h-3.5 w-3.5" }), "预览"]
		})]
	}) : /* @__PURE__ */ F("div", {
		className: "relative flex h-full flex-col",
		children: [/* @__PURE__ */ P("iframe", {
			ref: s,
			srcDoc: S,
			sandbox: "allow-scripts allow-downloads allow-same-origin",
			title: "HTML 预览",
			className: "h-full w-full border-0 bg-white"
		}), /* @__PURE__ */ F("div", {
			className: "absolute right-3 top-3 z-10 flex gap-1.5",
			children: [/* @__PURE__ */ F("button", {
				onClick: ee,
				className: "inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/90 dark:text-slate-300 dark:hover:bg-slate-700",
				title: "在新窗口中打开当前预览",
				children: [/* @__PURE__ */ P(C, { className: "h-3.5 w-3.5" }), "新窗口"]
			}), /* @__PURE__ */ F("button", {
				onClick: () => f("editor"),
				className: "inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/90 dark:text-slate-300 dark:hover:bg-slate-700",
				children: [/* @__PURE__ */ P(x, { className: "h-3.5 w-3.5" }), "编辑"]
			})]
		})]
	});
}
//#endregion
//#region src/components/workspace/MarkdownPreview.tsx
function kt(e) {
	e.current && clearTimeout(e.current);
}
function At({ content: e, path: t, onSave: n, onDirtyChange: r, getContentRef: a, isMobile: o }) {
	let [c, l] = y("editor"), [u, d] = y(e), f = v(null);
	return m(() => (kt(f), f.current = setTimeout(() => d(e), 300), () => kt(f)), [e]), o ? /* @__PURE__ */ F("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ F("div", {
			className: "flex items-center gap-1 border-b border-slate-200/30 px-2 py-1.5 dark:border-slate-700/30",
			children: [/* @__PURE__ */ F("button", {
				onClick: () => l("editor"),
				className: i("flex items-center gap-1.5 rounded-md px-3 py-1 text-xs font-medium transition-colors", c === "editor" ? "bg-slate-100 text-slate-900 dark:bg-slate-700 dark:text-slate-100" : "text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"),
				children: [/* @__PURE__ */ P(x, { className: "h-3.5 w-3.5" }), "编辑"]
			}), /* @__PURE__ */ F("button", {
				onClick: () => l("preview"),
				className: i("flex items-center gap-1.5 rounded-md px-3 py-1 text-xs font-medium transition-colors", c === "preview" ? "bg-slate-100 text-slate-900 dark:bg-slate-700 dark:text-slate-100" : "text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"),
				children: [/* @__PURE__ */ P(w, { className: "h-3.5 w-3.5" }), "预览"]
			})]
		}), c === "editor" ? /* @__PURE__ */ P(X, {
			content: e,
			path: t,
			onSave: n,
			onDirtyChange: r,
			getContentRef: a
		}) : /* @__PURE__ */ P("div", {
			className: "flex-1 overflow-auto p-4",
			children: /* @__PURE__ */ P(s, { content: u })
		})]
	}) : c === "editor" ? /* @__PURE__ */ F("div", {
		className: "relative flex h-full flex-col",
		children: [/* @__PURE__ */ P(X, {
			content: e,
			path: t,
			onSave: n,
			onDirtyChange: r,
			getContentRef: a
		}), /* @__PURE__ */ F("button", {
			onClick: () => l("preview"),
			className: "absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-lg border border-slate-200/30 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/90 dark:text-slate-300 dark:hover:bg-slate-700",
			children: [/* @__PURE__ */ P(w, { className: "h-3.5 w-3.5" }), "预览"]
		})]
	}) : /* @__PURE__ */ F("div", {
		className: "relative flex h-full flex-col",
		children: [/* @__PURE__ */ P("div", {
			className: "flex-1 overflow-auto p-4",
			children: /* @__PURE__ */ P(s, { content: u })
		}), /* @__PURE__ */ F("button", {
			onClick: () => l("editor"),
			className: "absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-lg border border-slate-200/30 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/90 dark:text-slate-300 dark:hover:bg-slate-700",
			children: [/* @__PURE__ */ P(x, { className: "h-3.5 w-3.5" }), "编辑"]
		})]
	});
}
//#endregion
//#region src/components/workspace/WorkspacePanel.tsx
var jt = "/agentengine/api/v1/GetWorkspaceFileContent", Mt = 4e3;
function Nt(e) {
	let t = Q(e);
	if (!t || t === ".") return ".";
	let n = t.split("/").filter(Boolean);
	return n.length <= 1 ? "." : n.slice(0, -1).join("/");
}
function Pt(e) {
	if (!e) return "";
	let t = Date.parse(e);
	return Number.isNaN(t) ? e : new Date(t).toLocaleString();
}
function Ft(e) {
	let t = Number(e);
	return !Number.isFinite(t) || t <= 0 ? "0 B" : t < 1024 ? `${t} B` : t < 1024 * 1024 ? `${(t / 1024).toFixed(1)} KB` : t < 1024 * 1024 * 1024 ? `${(t / (1024 * 1024)).toFixed(1)} MB` : `${(t / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}
var It = [
	{
		label: "Markdown",
		detail: ".md .markdown .mdx"
	},
	{
		label: "代码/文本",
		detail: ".py .js .ts .tsx .json .yaml .log .txt"
	},
	{
		label: "图片",
		detail: "PNG JPG GIF WebP SVG"
	},
	{
		label: "PDF",
		detail: ".pdf"
	},
	{
		label: "表格文本",
		detail: "CSV TSV"
	}
];
function Lt(e) {
	return gt(e);
}
function Rt({ label: e, showSupportedTypes: t = !1 }) {
	return /* @__PURE__ */ P("div", {
		className: "flex h-full min-h-[16rem] flex-col items-center justify-center px-6 text-center",
		children: /* @__PURE__ */ F("div", {
			className: "w-full max-w-md rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-5 py-5 text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400",
			children: [/* @__PURE__ */ P("div", { children: e }), t ? /* @__PURE__ */ F("div", {
				className: "mt-4 text-left",
				children: [
					/* @__PURE__ */ P("div", {
						className: "text-xs font-semibold uppercase tracking-[0.12em] text-slate-400",
						children: "支持在线预览"
					}),
					/* @__PURE__ */ P("div", {
						className: "mt-2 grid gap-2",
						children: It.map((e) => /* @__PURE__ */ F("div", {
							className: "rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-800 dark:bg-slate-950",
							children: [/* @__PURE__ */ P("div", {
								className: "text-sm font-medium text-slate-700 dark:text-slate-200",
								children: e.label
							}), /* @__PURE__ */ P("div", {
								className: "mt-0.5 font-mono text-[11px] text-slate-400",
								children: e.detail
							})]
						}, e.label))
					}),
					/* @__PURE__ */ P("div", {
						className: "mt-3 text-xs leading-5 text-slate-400",
						children: "Word、Excel、PPT 当前不支持在线预览，可下载后查看。"
					})
				]
			}) : null]
		})
	});
}
function zt({ agentId: e, capability: t, open: n, onClose: r, isFullscreen: a = !1, onToggleFullscreen: o, isMobile: s = !1, api: c }) {
	let l = v(null), u = v(null), [d, f] = y(!1), [h, g] = y("."), [x, C] = y([]), [w, D] = y(!1), [ie, ae] = y(!1), [se, O] = y(!1), [le, k] = y(""), [A, fe] = y(null), [j, M] = y(null), [N, I] = y(!1), [ge, L] = y(!1), R = v(null), z = v(null), B = v("selection"), V = v(Et()), H = _(() => x.find((e) => e.Path === A) ?? null, [x, A]), U = _(() => H ? wt({
		path: H.Path,
		mimeType: H.MimeType
	}) : null, [H]), W = p(() => N ? window.confirm("当前文件有未保存的更改，确定要离开吗？") : !0, [N]), _e = t.ContentPath || jt, G = t.RootLabel || "Workspace", K = G ? `${G.charAt(0).toUpperCase()}${G.slice(1)}` : "Workspace", ve = yt(h), q = p(() => {
		u.current &&= (URL.revokeObjectURL(u.current), null);
	}, []);
	m(() => () => q(), [q]);
	let J = p(async (t, n = {}) => {
		let r = !!n.background;
		r ? ae(!0) : D(!0), r || k("");
		try {
			let n = await c.listWorkspaceFiles(e, t, !1), i = Q(String(n?.Path || t || ".")), a = Array.isArray(n?.Entries) ? n.Entries : [];
			g(i), C(a), B.current = r ? "background-refresh" : "selection", fe((e) => {
				if (e) {
					let t = a.find((t) => t.Path === e);
					if (t && t.Type === "file") return e;
				}
				return a.find((e) => e.Type === "file")?.Path ?? null;
			});
		} catch (e) {
			console.error("Failed to load workspace entries:", e), r || k(e instanceof Error ? e.message : String(e));
		} finally {
			r ? ae(!1) : D(!1);
		}
	}, [e, c]);
	m(() => {
		!n || d || (f(!0), J("."));
	}, [
		d,
		J,
		n
	]), m(() => {
		if (!n || N || !d) return;
		let e = window.setInterval(() => {
			J(h, { background: !0 });
		}, Mt);
		return () => window.clearInterval(e);
	}, [
		h,
		N,
		d,
		J,
		n
	]);
	let ye = p(async (t) => {
		let n = V.current.next(t.Path), r = $({
			path: t.Path,
			mimeType: t.MimeType
		});
		if (z.current = t.Path, r === "unsupported") {
			q(), M({
				path: t.Path,
				kind: r,
				status: "ready",
				mimeType: t.MimeType ?? void 0
			});
			return;
		}
		q(), M({
			path: t.Path,
			kind: r,
			status: "loading",
			mimeType: t.MimeType ?? void 0
		});
		try {
			let r = await c.getWorkspaceFileContent(e, t.Path, { asText: !1 });
			if (!V.current.isCurrent(n)) return;
			if (r instanceof Blob) {
				let e = t.MimeType || "", i = $({
					path: t.Path,
					mimeType: e
				});
				if (i === "image" || i === "pdf") {
					let n = URL.createObjectURL(r);
					u.current = n, M({
						path: t.Path,
						kind: i,
						status: "ready",
						mimeType: e,
						objectUrl: n
					});
					return;
				}
				let a = await r.text();
				if (!V.current.isCurrent(n)) return;
				let o = $({
					path: t.Path,
					mimeType: e
				});
				M({
					path: t.Path,
					kind: o,
					status: "ready",
					mimeType: e,
					content: a
				});
			} else {
				let e = t.MimeType || "", n = $({
					path: t.Path,
					mimeType: e
				});
				M({
					path: t.Path,
					kind: n,
					status: "ready",
					mimeType: e,
					content: r
				});
			}
		} catch (e) {
			if (!V.current.isCurrent(n)) return;
			console.error("Failed to preview workspace file:", e), M({
				path: t.Path,
				kind: r,
				status: "error",
				mimeType: t.MimeType ?? void 0,
				error: e instanceof Error ? e.message : String(e)
			});
		}
	}, [
		e,
		c,
		q
	]);
	m(() => {
		if (!H || H.Type !== "file") {
			q(), M(null), I(!1), z.current = null;
			return;
		}
		if (B.current === "background-refresh" && z.current === H.Path) {
			B.current = "selection";
			return;
		}
		B.current = "selection", ye(H);
	}, [
		q,
		ye,
		H
	]);
	let be = async (n) => {
		if (!(!n || n.length === 0)) {
			O(!0), k("");
			try {
				for (let r of Array.from(n)) {
					if (r.size > t.MaxUploadBytes) throw Error(`文件 ${r.name} 超过上传上限`);
					let n = vt(h) ? r.name : `${h}/${r.name}`, i = new FormData();
					i.append("file", r), i.append("AgentId", e), i.append("Path", n), await c.addWorkspaceFile(i);
				}
				await J(h);
			} catch (e) {
				console.error("Failed to upload workspace files:", e), k(e instanceof Error ? e.message : String(e));
			} finally {
				l.current && (l.current.value = ""), O(!1);
			}
		}
	}, xe = async (n) => {
		if (!t.SupportsDelete) return;
		let r = Q(n.Path);
		if (window.confirm(`删除 ${r} ?`)) {
			k("");
			try {
				await c.deleteWorkspaceFile(e, r), A && Q(A) === r && (fe(null), I(!1)), await J(n.Type === "directory" && (Q(h) === r || Q(h).startsWith(`${r}/`)) ? Nt(r) : h);
			} catch (e) {
				console.error("Failed to delete workspace file:", e), k(e instanceof Error ? e.message : String(e));
			}
		}
	}, Se = () => !H || H.Type !== "file" ? /* @__PURE__ */ P(Rt, {
		label: "从左侧选择文件后在这里查看内容预览。",
		showSupportedTypes: !0
	}) : !j || j.path !== H.Path || j.status === "loading" ? /* @__PURE__ */ P("div", {
		className: "flex h-full min-h-[16rem] items-center justify-center",
		children: /* @__PURE__ */ F("div", {
			className: "inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-500 shadow-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400",
			children: [/* @__PURE__ */ P(ne, { className: "h-4 w-4 animate-spin" }), "正在加载预览..."]
		})
	}) : j.status === "error" ? /* @__PURE__ */ P(Rt, { label: j.error || "文件预览加载失败。" }) : j.kind === "markdown" ? /* @__PURE__ */ P(At, {
		content: j.content || "",
		path: H.Path,
		onSave: Y,
		onDirtyChange: I,
		getContentRef: R,
		isMobile: s
	}) : j.kind === "image" && j.objectUrl ? /* @__PURE__ */ P(lt, {
		content: null,
		objectUrl: j.objectUrl,
		kind: "image",
		filename: H.Name,
		mimeType: j.mimeType || ""
	}) : j.kind === "pdf" && j.objectUrl ? /* @__PURE__ */ P(lt, {
		content: null,
		objectUrl: j.objectUrl,
		kind: "pdf",
		filename: H.Name,
		mimeType: j.mimeType || ""
	}) : j.kind === "html" ? /* @__PURE__ */ P(Ot, {
		content: j.content || "",
		path: H.Path,
		onSave: Y,
		onDirtyChange: I,
		getContentRef: R,
		isMobile: s,
		agentId: e,
		contentPath: _e
	}) : j.kind === "text" || j.kind === "code" ? /* @__PURE__ */ P(X, {
		content: j.content || "",
		path: H.Path,
		onSave: Y,
		onDirtyChange: I,
		getContentRef: R
	}) : /* @__PURE__ */ P(lt, {
		content: null,
		kind: "unsupported",
		filename: H.Name,
		mimeType: j.mimeType || ""
	}), Y = async (t) => {
		if (H) {
			L(!0), k("");
			try {
				let n = new Blob([t], { type: H.MimeType || "text/plain" }), r = new FormData();
				r.append("file", n, H.Name), r.append("AgentId", e), r.append("Path", H.Path), await c.addWorkspaceFile(r), V.current.invalidate(), I(!1), M((e) => e && e.path === H.Path ? {
					...e,
					content: t
				} : e), z.current = H.Path, await J(h, { background: !0 });
			} catch (e) {
				console.error("Failed to save workspace file:", e), k(e instanceof Error ? e.message : String(e));
			} finally {
				L(!1);
			}
		}
	}, Ce = H?.Type === "file" && j?.path === H.Path && j.status === "ready" && (j.kind === "text" || j.kind === "code" || j.kind === "html" || j.kind === "markdown"), we = H?.Type === "file" && j?.path === H.Path && j.status === "ready" && j.kind === "pdf";
	return /* @__PURE__ */ F("div", {
		className: "flex h-full min-h-[22rem] w-full min-w-0 flex-col bg-white text-slate-800 dark:bg-slate-950 dark:text-slate-200",
		children: [/* @__PURE__ */ F("div", {
			className: "flex h-14 flex-shrink-0 items-center gap-3 border-b border-slate-200/30 px-4 dark:border-slate-800/40",
			children: [/* @__PURE__ */ F("div", {
				className: "flex min-w-0 flex-1 items-center gap-3",
				children: [
					/* @__PURE__ */ P("div", {
						className: "truncate text-sm font-semibold text-slate-900 dark:text-slate-100",
						children: K
					}),
					/* @__PURE__ */ P("div", { className: "hidden h-4 w-px bg-slate-200/70 dark:bg-slate-800 sm:block" }),
					/* @__PURE__ */ F("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ P("span", {
							className: "flex-shrink-0 text-xs text-slate-400",
							children: "当前目录"
						}), /* @__PURE__ */ P("div", {
							className: "custom-scrollbar max-w-[min(42vw,34rem)] overflow-x-auto whitespace-nowrap rounded-md bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-600 dark:bg-slate-900 dark:text-slate-300",
							title: `${ve}，来自 ListWorkspaceFiles 返回的 Data.Path 字段`,
							children: ve
						})]
					}),
					/* @__PURE__ */ P("div", {
						className: "hidden truncate text-[11px] text-slate-400 xl:block",
						children: "工作区内相对路径，不是宿主机绝对路径。"
					})
				]
			}), /* @__PURE__ */ F("div", {
				className: "flex flex-shrink-0 items-center gap-1.5",
				children: [
					/* @__PURE__ */ P("input", {
						ref: l,
						type: "file",
						multiple: !0,
						className: "hidden",
						onChange: (e) => void be(e.target.files)
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						onClick: () => l.current?.click(),
						disabled: se,
						className: "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50 dark:text-slate-300 dark:hover:bg-slate-900",
						title: `上传文件，上限 ${Math.floor(t.MaxUploadBytes / (1024 * 1024))}MB`,
						children: [/* @__PURE__ */ P(me, { className: "h-3.5 w-3.5" }), se ? "上传中" : "上传"]
					}),
					/* @__PURE__ */ F("button", {
						type: "button",
						onClick: () => {
							let e = new URLSearchParams({ Path: h }).toString();
							window.open(`/agentengine/api/v1/ExportWorkspaceZip?${e}`, "_blank", "noopener,noreferrer");
						},
						className: "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-900",
						title: "导出当前目录为 ZIP",
						children: [/* @__PURE__ */ P(ce, { className: "h-3.5 w-3.5" }), "导出"]
					}),
					o ? /* @__PURE__ */ P("button", {
						type: "button",
						onClick: o,
						className: "rounded-lg p-1.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100",
						"aria-label": a ? "退出全屏" : "全屏查看 Workspace",
						title: a ? "退出全屏" : "全屏查看",
						children: P(a ? oe : re, { className: "h-4 w-4" })
					}) : null,
					r ? /* @__PURE__ */ P("button", {
						type: "button",
						onClick: () => {
							W() && r?.();
						},
						className: "rounded-lg p-1.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100",
						"aria-label": "关闭 Workspace",
						title: "关闭",
						children: /* @__PURE__ */ P(he, { className: "h-4 w-4" })
					}) : null
				]
			})]
		}), /* @__PURE__ */ F("div", {
			className: "flex min-h-0 flex-1 flex-col md:flex-row",
			children: [/* @__PURE__ */ F("div", {
				className: "flex w-full flex-col border-b border-slate-200/30 dark:border-slate-800/40 md:w-[13.5rem] md:border-b-0 md:border-r",
				children: [/* @__PURE__ */ F("div", {
					className: "flex h-14 flex-shrink-0 items-center border-b border-slate-200/30 px-3 dark:border-slate-800/40",
					children: [/* @__PURE__ */ F("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ F("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ P("div", {
								className: "text-xs font-medium text-slate-900 dark:text-slate-100",
								children: "文件"
							}), /* @__PURE__ */ F("div", {
								className: "flex items-center gap-1 text-[11px] text-slate-400",
								children: [/* @__PURE__ */ F("span", { children: [x.length, " 项"] }), ie ? /* @__PURE__ */ P(ue, {
									className: "h-3 w-3 animate-spin",
									"aria-label": "正在同步 Workspace 目录"
								}) : null]
							})]
						}), /* @__PURE__ */ F("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ P("button", {
								type: "button",
								onClick: () => {
									W() && J(Nt(h));
								},
								disabled: w || vt(h),
								className: "rounded-md p-1.5 text-slate-500 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 dark:text-slate-400 dark:hover:bg-slate-900",
								title: "返回上级目录",
								children: /* @__PURE__ */ P(b, { className: "h-4 w-4" })
							}), /* @__PURE__ */ P("button", {
								type: "button",
								onClick: () => {
									W() && J(h);
								},
								disabled: w,
								className: "rounded-md p-1.5 text-slate-500 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 dark:text-slate-400 dark:hover:bg-slate-900",
								title: "刷新目录",
								children: /* @__PURE__ */ P(ue, { className: `h-4 w-4 ${w ? "animate-spin" : ""}` })
							})]
						})]
					}), le ? /* @__PURE__ */ P("div", {
						className: "mt-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-600 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300",
						children: le
					}) : null]
				}), /* @__PURE__ */ P("div", {
					className: "custom-scrollbar min-h-0 flex-1 overflow-y-auto px-2 py-2",
					children: !d && !n ? /* @__PURE__ */ P("div", {
						className: "px-3 py-4 text-sm text-slate-400",
						children: "打开面板后加载 workspace 文件。"
					}) : w ? /* @__PURE__ */ P("div", {
						className: "px-3 py-4 text-sm text-slate-400",
						children: "正在加载目录..."
					}) : x.length === 0 ? /* @__PURE__ */ P("div", {
						className: "px-3 py-4 text-sm text-slate-400",
						children: "当前目录为空。"
					}) : /* @__PURE__ */ P("div", {
						className: "space-y-0.5",
						children: x.map((e) => {
							let n = $({
								path: e.Path,
								mimeType: e.MimeType
							}), r = A === e.Path, a = e.Type === "file" ? Lt(e.Path) : "";
							return /* @__PURE__ */ F("div", {
								title: e.Path,
								className: i("group flex items-center gap-1 rounded-lg px-1.5 py-1 transition", r ? "bg-slate-100 text-slate-950 dark:bg-slate-800 dark:text-slate-50" : "text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-900"),
								children: [/* @__PURE__ */ F("button", {
									type: "button",
									onClick: () => {
										if (e.Type === "directory") {
											J(e.Path);
											return;
										}
										A !== e.Path && !W() || fe(e.Path);
									},
									className: "flex min-w-0 flex-1 items-center gap-2 text-left",
									children: [/* @__PURE__ */ P("div", {
										className: i("flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-md", r ? "text-slate-900 dark:text-slate-50" : "text-slate-400 dark:text-slate-500"),
										children: e.Type === "directory" ? /* @__PURE__ */ P(E, { className: "h-3.5 w-3.5" }) : P(n === "image" ? te : n === "markdown" || n === "text" || n === "html" ? T : ee, { className: "h-3.5 w-3.5" })
									}), /* @__PURE__ */ F("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ P("div", {
											className: "truncate text-[13px] leading-5",
											children: e.Name
										}), /* @__PURE__ */ P("div", {
											className: i("truncate text-[11px] leading-4", r ? "text-slate-500 dark:text-slate-400" : "text-slate-400"),
											children: e.Type === "directory" ? "目录" : Ft(e.SizeBytes)
										})]
									})]
								}), /* @__PURE__ */ F("div", {
									className: "flex flex-shrink-0 items-center gap-0.5 opacity-0 transition group-hover:opacity-100",
									children: [e.Type === "file" ? /* @__PURE__ */ P("a", {
										href: a,
										download: e.Name,
										className: i("rounded-md p-1.5 transition", r ? "hover:bg-white dark:hover:bg-slate-700" : "hover:bg-slate-100 dark:hover:bg-slate-800"),
										title: "下载",
										children: /* @__PURE__ */ P(S, { className: "h-3.5 w-3.5" })
									}) : null, t.SupportsDelete ? /* @__PURE__ */ P("button", {
										type: "button",
										onClick: () => void xe(e),
										className: i("rounded-md p-1.5 transition", r ? "hover:bg-white dark:hover:bg-slate-700" : "hover:bg-slate-100 dark:hover:bg-slate-800"),
										title: "删除",
										children: /* @__PURE__ */ P(pe, { className: "h-3.5 w-3.5" })
									}) : null]
								})]
							}, e.Path);
						})
					})
				})]
			}), /* @__PURE__ */ F("div", {
				className: "flex min-h-0 min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ P("div", {
					className: "flex h-14 flex-shrink-0 items-center border-b border-slate-200/30 px-4 dark:border-slate-800/40",
					children: H ? /* @__PURE__ */ F("div", {
						className: "flex w-full items-start justify-between gap-3",
						children: [/* @__PURE__ */ F("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ P("div", {
									className: "truncate text-sm font-semibold text-slate-900 dark:text-slate-100",
									children: H.Name
								}),
								/* @__PURE__ */ P("div", {
									className: "mt-0.5 break-all font-mono text-[11px] text-slate-400",
									children: H.Path
								}),
								/* @__PURE__ */ F("div", {
									className: "mt-1 text-[11px] text-slate-400",
									children: [
										Ft(H.SizeBytes),
										H.MimeType ? ` · ${H.MimeType}` : "",
										H.ModifiedAt ? ` · ${Pt(H.ModifiedAt)}` : ""
									]
								})
							]
						}), U === "text" || U === "code" || U === "html" || U === "markdown" ? /* @__PURE__ */ F("button", {
							type: "button",
							onClick: () => {
								let e = R.current;
								e && Y(e());
							},
							disabled: !N || ge,
							className: i("inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition", N && !ge ? "bg-blue-600 text-white hover:bg-blue-700" : "text-slate-400 dark:text-slate-500 cursor-not-allowed"),
							children: [/* @__PURE__ */ P(de, { className: "h-3.5 w-3.5" }), ge ? "保存中" : N ? "保存" : "已保存"]
						}) : null]
					}) : /* @__PURE__ */ F("div", {
						className: "w-full",
						children: [/* @__PURE__ */ P("div", {
							className: "text-sm font-semibold text-slate-900 dark:text-slate-100",
							children: "文件预览"
						}), /* @__PURE__ */ P("div", {
							className: "mt-0.5 text-xs text-slate-500 dark:text-slate-400",
							children: "选择左侧文件后可在此查看内容。"
						})]
					})
				}), /* @__PURE__ */ P("div", {
					className: i("custom-scrollbar min-h-0 flex-1", we || Ce ? "overflow-hidden p-0" : "overflow-y-auto px-4 py-4"),
					children: Se()
				})]
			})]
		})]
	});
}
//#endregion
//#region src/components/workspace/WorkspacePanelContainer.tsx
function Bt({ agentId: e, capability: n, workspacePanelOpen: r, workspacePanelWidth: a, workspacePanelFullscreen: o, isMobile: s, workspaceEnabled: c, workspaceFiles: l, workspacePanelPresentation: u, closeWorkspacePanel: d, handleWorkspacePanelResizeStart: f, api: p }) {
	let m = u.renderMode === "inline", h = u.renderMode === "sheet";
	return !c || !l ? null : /* @__PURE__ */ F(N, { children: [m ? /* @__PURE__ */ F(N, { children: [r && !o ? /* @__PURE__ */ P("div", {
		role: "separator",
		"aria-label": "调整 Workspace 宽度",
		"aria-orientation": "vertical",
		onPointerDown: f,
		className: "hidden h-full w-1 cursor-col-resize bg-transparent transition-colors hover:bg-blue-200/60 dark:hover:bg-blue-900/50 md:block"
	}) : null, /* @__PURE__ */ P("aside", {
		style: r && !o ? { width: `${a}px` } : void 0,
		className: i(o ? "fixed inset-0 z-40 flex h-[var(--app-height)] w-screen overflow-hidden bg-white dark:bg-slate-950" : "hidden h-full flex-shrink-0 overflow-hidden bg-white transition-[width] duration-200 ease-out dark:bg-slate-950 md:flex", r ? "border-l border-slate-200/30 dark:border-slate-800/40" : "w-0 border-l border-transparent"),
		children: r ? /* @__PURE__ */ P(zt, {
			agentId: e,
			capability: n,
			open: r,
			onClose: d,
			isFullscreen: o,
			onToggleFullscreen: () => t.getState().setWorkspacePanelFullscreen(!o),
			isMobile: s,
			api: p
		}) : null
	})] }) : null, h ? /* @__PURE__ */ P(Ie, {
		open: r,
		onOpenChange: (e) => {
			e || t.getState().setWorkspacePanelFullscreen(!1), t.getState().setWorkspacePanelOpen(e);
		},
		modal: u.modal,
		children: /* @__PURE__ */ F(Be, {
			side: u.side,
			showOverlay: u.showOverlay,
			onInteractOutside: (e) => {
				u.preventOutsideClose && e.preventDefault();
			},
			showCloseButton: !1,
			className: i("border-slate-200 bg-white p-0 dark:border-slate-800 dark:bg-slate-950", s ? "h-[70vh] rounded-t-[1.75rem]" : "h-[calc(100vh-1.5rem)] w-[min(72rem,calc(100vw-1.5rem))] max-w-[calc(100vw-1.5rem)] rounded-l-[1.5rem] border-l shadow-2xl"),
			children: [
				/* @__PURE__ */ P(Ue, {
					className: "sr-only",
					children: "Workspace 文件"
				}),
				/* @__PURE__ */ P(We, {
					className: "sr-only",
					children: "浏览、上传和预览 Workspace 文件。"
				}),
				/* @__PURE__ */ P(zt, {
					agentId: e,
					capability: n,
					open: r,
					onClose: d,
					isMobile: s,
					api: p
				})
			]
		})
	}) : null] });
}
//#endregion
export { it as a, Be as c, Fe as d, Pe as f, ot as i, We as l, Dt as n, qe as o, Tt as r, Ie as s, Bt as t, Ue as u };
