import { t as e } from "./runtime-items-VPq7711E.js";
import { create as t } from "zustand";
import { A2UI_SCHEMA_CONTEXT_DESCRIPTION as n, basicCatalog as r, buildCatalogContextValue as i } from "@copilotkit/a2ui-renderer";
//#region src/stores/ui.ts
function a(e, t) {
	return typeof t == "function" ? t(e) : t;
}
var o = t()((e) => ({
	sidebarOpen: !0,
	mobileSidebarOpen: !1,
	mobileActionsOpen: !1,
	workspacePanelOpen: !1,
	workspacePanelWidth: 820,
	workspacePanelFullscreen: !1,
	input: "",
	attachments: [],
	previewAttachment: null,
	previewImageSize: null,
	queuedDrafts: [],
	toasts: [],
	toggleSidebar: () => e((e) => ({ sidebarOpen: !e.sidebarOpen })),
	setSidebarOpen: (t) => e({ sidebarOpen: t }),
	toggleMobileSidebar: () => e((e) => ({ mobileSidebarOpen: !e.mobileSidebarOpen })),
	setMobileSidebarOpen: (t) => e({ mobileSidebarOpen: t }),
	toggleMobileActions: () => e((e) => ({ mobileActionsOpen: !e.mobileActionsOpen })),
	setMobileActionsOpen: (t) => e({ mobileActionsOpen: t }),
	setWorkspacePanelOpen: (t) => e({ workspacePanelOpen: t }),
	setWorkspacePanelWidth: (t) => e({ workspacePanelWidth: t }),
	setWorkspacePanelFullscreen: (t) => e({ workspacePanelFullscreen: t }),
	setInput: (t) => e({ input: t }),
	setAttachments: (t) => e((e) => ({ attachments: a(e.attachments, t) })),
	setPreviewAttachment: (t) => e({ previewAttachment: t }),
	setPreviewImageSize: (t) => e({ previewImageSize: t }),
	setQueuedDrafts: (t) => e((e) => ({ queuedDrafts: a(e.queuedDrafts, t) })),
	pushToast: (t, n = "info") => e((e) => ({ toasts: [...e.toasts, {
		id: String(Date.now() + Math.random()),
		message: t,
		variant: n,
		createdAt: Date.now()
	}] })),
	dismissToast: (t) => e((e) => ({ toasts: e.toasts.filter((e) => e.id !== t) }))
})), s = (e) => Object.keys(e).length > 0, c = {
	runId: null,
	status: null,
	items: []
}, l = new e(), u = (e, t) => {
	let n = { ...e };
	return delete n[t], n;
}, d = t()((t, n) => ({
	isStreaming: !1,
	currentRunId: "",
	stopRequested: !1,
	activity: null,
	sessionActivities: {},
	sessionStreaming: {},
	banner: null,
	lastSeqId: 0,
	activeInvocationId: "",
	runtimeItems: c,
	setStreaming: (e) => t({ isStreaming: e }),
	setBanner: (e) => t({ banner: e ? {
		...e,
		createdAt: Date.now()
	} : null }),
	setLastSeqId: (e) => t({ lastSeqId: e }),
	setActiveInvocationId: (e) => t({ activeInvocationId: e }),
	setSessionStreaming: (e, n) => t((t) => {
		let r = String(e || ""), i = u(t.sessionStreaming, r), a = n ? {
			...i,
			[r]: !0
		} : i;
		return {
			sessionStreaming: a,
			isStreaming: s(a)
		};
	}),
	isSessionStreaming: (e) => {
		let t = String(e || "");
		return !!n().sessionStreaming[t];
	},
	getSessionActivity: (e) => {
		let t = String(e || "");
		return t && n().sessionActivities[t] || null;
	},
	setCurrentRunId: (e) => t({ currentRunId: e }),
	requestStop: () => t({ stopRequested: !0 }),
	beginActivity: (e) => t({
		stopRequested: !1,
		activity: {
			runId: e.runId,
			source: e.source || "run",
			status: e.status || "running",
			phase: e.phase,
			detail: e.detail,
			startedAt: Date.now(),
			lastEventAt: Date.now(),
			eventCount: 0
		}
	}),
	updateActivity: (e) => t((t) => {
		let n = String(e.sessionId || ""), r = n ? t.sessionActivities[n] : t.activity, i = r ? {
			...r,
			runId: e.runId || r.runId,
			source: e.source || r.source,
			status: e.status || r.status,
			phase: e.phase || r.phase,
			detail: e.detail === void 0 ? r.detail : e.detail,
			lastEventAt: Date.now(),
			eventCount: r.eventCount + (e.countEvent === !1 ? 0 : 1)
		} : {
			runId: e.runId,
			source: e.source || "run",
			status: e.status || "running",
			phase: e.phase || "正在运行",
			detail: e.detail,
			startedAt: Date.now(),
			lastEventAt: Date.now(),
			eventCount: e.countEvent === !1 ? 0 : 1
		};
		return n ? {
			isStreaming: s(t.sessionStreaming),
			sessionActivities: {
				...t.sessionActivities,
				[n]: i
			},
			...e.visible === !1 ? {} : { activity: i }
		} : { ...e.visible === !1 ? {} : { activity: i } };
	}),
	stopActivity: (e) => t((t) => ({
		isStreaming: !1,
		stopRequested: !0,
		activity: t.activity ? {
			...t.activity,
			status: "stopped",
			phase: "已断开输出流",
			detail: e || "前端已断开本次输出流；后台运行可稍后通过会话记录继续查看。",
			lastEventAt: Date.now()
		} : null
	})),
	stopSessionActivity: (e, n, r = !0) => t((t) => {
		let i = String(e || "");
		if (!i) return {};
		let a = t.sessionActivities[i];
		if (!a) return {};
		let o = {
			...a,
			status: "stopped",
			phase: "已断开输出流",
			detail: n || "前端已断开本次输出流；后台运行可稍后通过会话记录继续查看。",
			lastEventAt: Date.now()
		}, c = {
			...t.sessionActivities,
			[i]: o
		}, l = u(t.sessionStreaming, i);
		return {
			isStreaming: s(l),
			...r ? {
				activity: o,
				stopRequested: !0
			} : {},
			sessionActivities: c,
			sessionStreaming: l
		};
	}),
	clearActivity: () => t({ activity: null }),
	clearSessionActivity: (e) => t((t) => {
		let n = String(e || "");
		if (!n) return {};
		let { [n]: r, ...i } = t.sessionActivities, a = u(t.sessionStreaming, n);
		return {
			sessionActivities: i,
			sessionStreaming: a,
			isStreaming: s(a),
			activity: t.activity === r ? null : t.activity
		};
	}),
	applyRuntimeItemOperations: (e) => {
		l.applyAll(e), t({ runtimeItems: l.snapshot() });
	},
	resetRun: () => {
		l = new e(), t({
			isStreaming: !1,
			currentRunId: "",
			stopRequested: !1,
			activity: null,
			sessionActivities: {},
			sessionStreaming: {},
			lastSeqId: 0,
			activeInvocationId: "",
			runtimeItems: c
		});
	}
}));
//#endregion
//#region src/stores/model.ts
function f(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) t?.id && n.set(t.id, t);
	for (let e of t) e?.id && n.set(e.id, {
		...n.get(e.id) || {},
		...e
	});
	return Array.from(n.values()).sort((e, t) => e.id.localeCompare(t.id));
}
var p = t()((e) => ({
	availableModels: [],
	selectedModel: "",
	modelSource: "",
	modelCatalogLoaded: !1,
	thinkingMode: "auto",
	upsertModels: (t) => e((e) => ({ availableModels: f(e.availableModels, t) })),
	setSelectedModel: (t) => e({ selectedModel: t }),
	setModelSource: (t) => e({ modelSource: t }),
	setModelCatalogLoaded: (t) => e({ modelCatalogLoaded: t }),
	setThinkingMode: (t) => e({ thinkingMode: t }),
	resetCatalog: () => e({
		availableModels: [],
		selectedModel: "",
		modelSource: "",
		modelCatalogLoaded: !1
	})
})), m = new class {
	initialized = !1;
	scope;
	blocked = !1;
	enter(e) {
		if (e !== void 0 && !e.trim()) throw Error("authorizationScopeKey must be non-empty");
		return this.blocked ? "reload" : this.initialized && this.scope !== e ? (this.blocked = !0, "reload") : (this.initialized = !0, this.scope = e, "ready");
	}
	matches(e) {
		return this.initialized && !this.blocked && this.scope === e;
	}
	key(e) {
		return this.scope === void 0 ? e : `ksadk:authorization:${encodeURIComponent(this.scope)}:${e}`;
	}
	get writable() {
		return !this.blocked;
	}
}();
//#endregion
//#region src/utils/session-pagination.js
function h(e = /* @__PURE__ */ new Set(), t = []) {
	let n = new Set(e);
	for (let e of t) {
		let t = Number(e);
		Number.isFinite(t) && t > 0 && n.add(t);
	}
	return new Set(Array.from(n).sort((e, t) => e - t));
}
function g({ sessionsLength: e = 0, total: t = 0, page: n = 0, pageSize: r = 30, loadedPages: i = /* @__PURE__ */ new Set() } = {}) {
	let a = Math.max(0, Number(t) || 0), o = Math.max(0, Number(e) || 0);
	return {
		total: a,
		page: Math.max(0, Number(n) || 0),
		pageSize: Math.max(1, Number(r) || 30),
		loadedPages: h(i),
		hasMore: o < a
	};
}
function _({ total: e = 0, pageSize: t = 30, loadedPages: n = /* @__PURE__ */ new Set() } = {}) {
	let r = Math.max(0, Number(e) || 0), i = Math.max(1, Number(t) || 30);
	if (r <= 0) return null;
	let a = Math.ceil(r / i);
	for (let e = 1; e <= a; e += 1) if (!n.has(e)) return e;
	return null;
}
//#endregion
//#region src/stores/session.ts
function v(e) {
	let t = e.UpdatedAt;
	if (typeof t == "string") {
		let e = Date.parse(t);
		return Number.isNaN(e) ? 0 : e;
	}
	return typeof t == "number" && Number.isFinite(t) ? t > 1e11 ? t : t * 1e3 : 0;
}
var y = "ksadk.pinnedSessionIds";
function b() {
	try {
		let e = globalThis.localStorage?.getItem(m.key(y)), t = e ? JSON.parse(e) : [];
		return Array.isArray(t) ? t.filter((e) => typeof e == "string") : [];
	} catch {
		return [];
	}
}
function x(e) {
	if (m.writable) try {
		globalThis.localStorage?.setItem(m.key(y), JSON.stringify(e));
	} catch {}
}
function S(e, t) {
	let n = new Set(t);
	return e.slice().sort((e, t) => {
		let r = +!!n.has(e.SessionId), i = +!!n.has(t.SessionId);
		return r === i ? v(t) - v(e) : i - r;
	});
}
function C(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let t of e) t?.SessionId && r.set(t.SessionId, t);
	for (let e of t) e?.SessionId && r.set(e.SessionId, {
		...r.get(e.SessionId) || {},
		...e
	});
	return S(Array.from(r.values()), n);
}
var w = t()((e) => ({
	sessions: [],
	currentSessionId: null,
	sessionsAgentId: "",
	sessionsGeneration: 0,
	sessionsTotal: 0,
	sessionsPage: 0,
	sessionsPageSize: 30,
	loadedPages: /* @__PURE__ */ new Set(),
	hasMoreSessions: !1,
	isLoadingSessions: !0,
	pinnedSessionIds: b(),
	messageHistory: {},
	setSessions: (t) => e((e) => ({ sessions: S(t, e.pinnedSessionIds) })),
	setCurrentSessionId: (t) => e({ currentSessionId: t }),
	upsertSessions: (t, n) => e((e) => {
		let r = C(n?.replace ? [] : e.sessions, t, e.pinnedSessionIds), i = n?.page ?? e.sessionsPage, a = n?.pageSize ?? e.sessionsPageSize, o = n?.total ?? Math.max(e.sessionsTotal, r.length), s = n?.replace ? h(/* @__PURE__ */ new Set(), [i]) : h(e.loadedPages, [i]), c = g({
			sessionsLength: r.length,
			total: o,
			page: i,
			pageSize: a,
			loadedPages: s
		});
		return {
			sessions: r,
			sessionsAgentId: n?.agentId ?? e.sessionsAgentId,
			sessionsTotal: c.total,
			sessionsPage: c.page,
			sessionsPageSize: c.pageSize,
			loadedPages: c.loadedPages,
			hasMoreSessions: c.hasMore
		};
	}),
	removeSession: (t) => e((e) => {
		let n = e.sessions.filter((e) => e.SessionId !== t), r = Math.max(0, e.sessionsTotal - 1);
		return {
			sessions: n,
			sessionsTotal: r,
			hasMoreSessions: g({
				sessionsLength: n.length,
				total: r,
				page: e.sessionsPage,
				pageSize: e.sessionsPageSize,
				loadedPages: e.loadedPages
			}).hasMore,
			pinnedSessionIds: e.pinnedSessionIds.filter((e) => e !== t)
		};
	}),
	setLoadingSessions: (t) => e({ isLoadingSessions: t }),
	resetSessionPagination: (t) => e((e) => ({
		sessionsGeneration: e.sessionsGeneration + 1,
		sessions: [],
		sessionsAgentId: t,
		sessionsTotal: 0,
		sessionsPage: 0,
		loadedPages: /* @__PURE__ */ new Set(),
		hasMoreSessions: !1,
		isLoadingSessions: !1
	})),
	togglePinnedSession: (t) => e((e) => {
		let n = new Set(e.pinnedSessionIds);
		n.has(t) ? n.delete(t) : n.add(t);
		let r = Array.from(n);
		return x(r), {
			pinnedSessionIds: r,
			sessions: S(e.sessions, r)
		};
	}),
	setSessionMessageHistory: (t, n) => e((e) => ({ messageHistory: {
		...e.messageHistory,
		[t]: {
			nextCursor: n.nextCursor,
			hasMore: n.hasMore,
			isLoadingInitial: !1,
			isLoadingOlder: n.isLoadingOlder ?? !1
		}
	} })),
	setSessionInitialMessageHistoryLoading: (t, n) => e((e) => {
		let r = e.messageHistory[t];
		return { messageHistory: {
			...e.messageHistory,
			[t]: {
				nextCursor: r?.nextCursor ?? null,
				hasMore: r?.hasMore ?? !1,
				isLoadingInitial: n,
				isLoadingOlder: r?.isLoadingOlder ?? !1
			}
		} };
	}),
	setSessionMessageHistoryLoading: (t, n) => e((e) => {
		let r = e.messageHistory[t];
		return r ? { messageHistory: {
			...e.messageHistory,
			[t]: {
				...r,
				isLoadingOlder: n
			}
		} } : {};
	}),
	clearSessionMessageHistory: (t) => e((e) => {
		if (!t) return { messageHistory: {} };
		let n = { ...e.messageHistory };
		return delete n[t], { messageHistory: n };
	})
})), T = "0.9.1";
function E(e) {
	let t = typeof e == "object" && e ? e.components : null, n = Array.isArray(t) ? t : [], r = [];
	for (let e of n) typeof e == "object" && e && typeof e.id == "string" && r.push(e.id);
	return r.sort();
}
function D(e) {
	let t = E(e).join("|"), n = 2166136261, r = 16777619;
	for (let e = 0; e < t.length; e += 1) {
		let i = t.charCodeAt(e);
		n = (n ^ i) >>> 0, n = Math.imul(n, 16777619) >>> 0, r = r + Math.imul(i + e, 2246822507) >>> 0;
	}
	return `fnv1a-${n.toString(16)}-${r.toString(16)}`;
}
function O(e, t) {
	if (!e) return k(null);
	if (e.wireVersion !== "0.9.1" || !e.messages || e.messages.length === 0) return k(e);
	if (e.catalogDigest) {
		let n = D(t);
		if (e.catalogDigest !== n) return "json-schema-form";
	}
	return "a2ui";
}
function k(e) {
	return e && A(e) ? "json-schema-form" : "basic-controls";
}
function A(e) {
	return e.messages.some((e) => {
		let t = e.inputSchema ?? e.input_schema ?? e.schema;
		return typeof t == "object" && !!t;
	});
}
//#endregion
//#region src/core/interaction/types.ts
var j = new Set([
	"resolved",
	"cancelled",
	"expired"
]);
function M(e) {
	return j.has(e);
}
function N(e, t) {
	return `interaction:${e}:revision-${t}`;
}
function P(e, t) {
	let n = t.approved;
	if (typeof n == "boolean") return n ? "已同意" : "已拒绝";
	let r = Object.keys(t);
	return r.length === 0 ? e === "approve" ? "已同意" : e === "reject" ? "已拒绝" : e === "cancel" ? "已取消" : "已提交" : `${e}(${r.slice(0, 3).map((e) => {
		let n = t[e];
		return `${e}=${typeof n == "string" ? n.length > 24 ? `${n.slice(0, 24)}…` : n : typeof n == "object" && n ? "[object]" : String(n)}`;
	}).join(", ")})`;
}
//#endregion
//#region src/core/run/a2ui.ts
var F = r, I = {
	description: n,
	value: i(F)
};
function L(e) {
	return e.map((e) => {
		let t = e.updateComponents;
		if (!t || typeof t != "object" || Array.isArray(t)) return e;
		let n = t.components;
		if (!Array.isArray(n)) return e;
		let r = n.filter((e) => !!(e && typeof e == "object" && !Array.isArray(e)));
		if (r.some((e) => e.id === "root")) return e;
		let i = r.filter((e) => typeof e.id == "string" && e.id.endsWith("-root"));
		if (i.length !== 1) return e;
		let a = i[0];
		return {
			...e,
			updateComponents: {
				...t,
				components: n.map((e) => e === a ? {
					...a,
					id: "root"
				} : e)
			}
		};
	});
}
function R(e) {
	for (let t of e) {
		let e = t.updateComponents?.components;
		if (!Array.isArray(e) || !e.some((e) => e.component === "Form" && e.id === "form")) continue;
		let n = e.filter((e) => e.component === "MultipleChoice");
		if (n.length) return n.map((e) => String(e.description || e.label || e.id));
	}
	return null;
}
//#endregion
export { N as a, T as c, w as d, _ as f, o as g, d as h, L as i, O as l, p as m, F as n, M as o, m as p, R as r, P as s, I as t, b as u };
