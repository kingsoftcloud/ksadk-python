export declare class ApiError extends Error {
    code: number;
    detail?: unknown;
    constructor(code: number, message: string, detail?: unknown);
}
export declare class StreamError extends Error {
    event: string;
    raw?: string;
    constructor(event: string, raw?: string, message?: string);
}
export declare class CancelledError extends Error {
    constructor(message?: string);
}
export type AgentEngineFetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
export type AgentEngineClientOptions = {
    fetch?: AgentEngineFetch;
    baseUrl?: string;
    /**
     * Scope every action to one agent. Embedded hosts such as Studio should set
     * this instead of selecting an agent through a process-wide cookie.
     */
    agentId?: string;
};
/** 1. JSON POST — 普通 agentengine action */
export declare class AgentEngineClient {
    private readonly fetcher;
    private readonly baseUrl;
    private readonly agentId;
    constructor(options?: AgentEngineClientOptions);
    private actionUrl;
    private scopedBody;
    postJsonAction<T>(action: string, body: Record<string, unknown>, options?: {
        signal?: AbortSignal;
    }): Promise<T>;
    /** 2. FormData POST — UploadFile、AddWorkspaceFile */
    postFormAction<T>(action: string, formData: FormData, options?: {
        signal?: AbortSignal;
    }): Promise<T>;
    /** 3. GET blob/text — GetWorkspaceFileContent、AttachmentContent */
    getResource(action: string, params: Record<string, string>, options?: {
        signal?: AbortSignal;
        asText?: boolean;
    }): Promise<Blob | string>;
    /** 4. SSE stream — RunAgent / SubscribeRunEvents */
    streamAction(action: string, body: Record<string, unknown>, options?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array>>;
    /** GET SSE stream — SubscribeRunEvents 用 query params */
    streamGetAction(action: string, params: Record<string, string>, options?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array>>;
}
export declare const postJsonAction: <T>(action: string, body: Record<string, unknown>, options?: {
    signal?: AbortSignal;
}) => Promise<T>;
export declare const postFormAction: <T>(action: string, formData: FormData, options?: {
    signal?: AbortSignal;
}) => Promise<T>;
export declare const getResource: (action: string, params: Record<string, string>, options?: {
    signal?: AbortSignal;
    asText?: boolean;
}) => Promise<Blob | string>;
export declare const streamAction: (action: string, body: Record<string, unknown>, options?: {
    signal?: AbortSignal;
}) => Promise<ReadableStream<Uint8Array>>;
export declare const streamGetAction: (action: string, params: Record<string, string>, options?: {
    signal?: AbortSignal;
}) => Promise<ReadableStream<Uint8Array>>;
//# sourceMappingURL=client.d.ts.map