import { create as e } from "zustand";
//#region src/stores/artifact.ts
var t = e()((e) => ({
	content: null,
	type: "html",
	visible: !1,
	show: (t, n = "html") => e({
		content: t,
		type: n,
		visible: !0
	}),
	hide: () => e({ visible: !1 }),
	setContent: (t, n) => e((e) => ({
		content: t,
		type: n ?? e.type
	}))
}));
//#endregion
export { t };
