//#region src/types/runtime-capability-matrix.js
var e = [
	"cancel",
	"pause",
	"resume",
	"submit_interaction",
	"attach",
	"steer",
	"inject",
	"checkpoint",
	"durable_restore"
], t = [
	"goal",
	"loop",
	"plan"
], n = new Set([
	"native",
	"emulated",
	"unavailable"
]), r = new Set([
	"supported",
	"mode",
	"reason"
]), i = new Set([
	"schema_version",
	...e,
	...t
]);
function a(e, t) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw Error(`${t} must be an object`);
	return e;
}
function o(e, t) {
	let i = a(e, t);
	if (typeof i.supported != "boolean") throw Error(`${t}.supported must be a boolean`);
	if (!n.has(i.mode)) throw Error(`${t}.mode must be native, emulated, or unavailable`);
	if (i.reason !== void 0 && i.reason !== null && (typeof i.reason != "string" || i.reason.length === 0)) throw Error(`${t}.reason must be a non-empty string or null`);
	if (!i.supported && (i.mode !== "unavailable" || !i.reason)) throw Error(`${t}: unsupported capability requires mode=unavailable and reason`);
	return {
		supported: i.supported,
		mode: i.mode,
		reason: i.reason ?? null,
		extensions: Object.fromEntries(Object.entries(i).filter(([e]) => !r.has(e)))
	};
}
function s(n) {
	let r = a(n, "RuntimeCapabilityMatrix/v1");
	if (r.schema_version !== 1) throw Error("schema_version must equal 1");
	for (let t of e) if (!(t in r)) throw Error(`${t} is required`);
	let s = {
		schema_version: 1,
		extensions: Object.fromEntries(Object.entries(r).filter(([e]) => !i.has(e)))
	};
	for (let t of e) s[t] = o(r[t], t);
	for (let e of t) r[e] !== void 0 && r[e] !== null && (s[e] = o(r[e], e));
	return s;
}
//#endregion
//#region src/utils/capabilities.js
var c = ["responses", "chat_completions"], l = new Map([["openclaw", "OpenClaw"], ["hermes", "Hermes"]]);
function u(e) {
	return String(e || "").trim().toLowerCase();
}
function d(...e) {
	for (let t of e) {
		let e = u(t);
		if (e) return e;
	}
	return "";
}
function f(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : {};
}
function p(e) {
	if (!Array.isArray(e)) return c;
	let t = e.filter((e) => e === "responses" || e === "chat_completions");
	return t.length > 0 ? t : c;
}
function m(e, t) {
	return typeof e == "boolean" ? e : t;
}
function h(e) {
	return Array.isArray(e) ? e.map((e) => f(e)).filter((e) => typeof e.name == "string" && e.name.trim()).map((e) => {
		let t = {
			...e,
			name: e.name.trim(),
			group: typeof e.group == "string" ? e.group : "",
			risk_level: typeof e.risk_level == "string" ? e.risk_level : "low",
			requires_approval: !!e.requires_approval,
			side_effects: Array.isArray(e.side_effects) ? e.side_effects.filter((e) => typeof e == "string") : [],
			enabled: m(e.enabled, !0)
		};
		return typeof e.description == "string" && (t.description = e.description), t;
	}) : [];
}
function g(e) {
	let t = f(e), n = Array.isArray(t.Modes) ? t.Modes.filter((e) => [
		"ask",
		"risk",
		"full"
	].includes(e)) : [
		"ask",
		"risk",
		"full"
	], r = n.length > 0 ? [...new Set(n)] : [
		"ask",
		"risk",
		"full"
	];
	return {
		Modes: r,
		DefaultMode: r.includes(t.DefaultMode) ? t.DefaultMode : "risk",
		RuntimeOverride: m(t.RuntimeOverride, !0)
	};
}
function _(e) {
	if (e != null) try {
		return s(e);
	} catch {
		return;
	}
}
function v(e, t) {
	if (t != null || d(f(e.Agent).Framework, e.Framework) !== "codex") return;
	let n = {
		supported: !1,
		mode: "unavailable",
		reason: "legacy_bootstrap_not_advertised",
		extensions: {}
	}, r = {
		supported: !0,
		mode: "emulated",
		extensions: {}
	};
	return {
		schema_version: 1,
		cancel: { ...n },
		pause: { ...n },
		resume: { ...n },
		submit_interaction: { ...n },
		attach: { ...n },
		steer: { ...n },
		inject: { ...n },
		checkpoint: { ...n },
		durable_restore: { ...n },
		goal: { ...r },
		plan: { ...r },
		extensions: { compatibility: "legacy-codex" }
	};
}
function y(e) {
	return Array.isArray(e) ? e.flatMap((e) => {
		let t = f(e), n = String(t.Protocol || "").trim().toLowerCase(), r = String(t.Endpoint || "").trim();
		if (!["ag-ui", "responses"].includes(n) || !r.startsWith("/")) return [];
		let i = f(t.Capabilities);
		return [{
			Protocol: n,
			Runtime: String(t.Runtime || "").trim(),
			Endpoint: r,
			Version: String(t.Version || "").trim(),
			Capabilities: {
				A2UI: !!i.A2UI,
				Interrupt: !!i.Interrupt,
				Cancel: !!i.Cancel
			}
		}];
	}) : [];
}
function b(e) {
	let t = e?.Data || e || {}, n = f(t.Capabilities), r = f(t.HostedRuntime), i = d(t.Agent?.Framework, r.Framework, r.Type), a = l.get(i) || "", o = p(t.ApiFormats || n.HostedChat?.ApiFormats), s = i !== "openclaw", c = !!a, u = !!a, b = f(n.HostedChat), x = f(n.NativeDashboard), S = f(n.NativeTerminal), C = f(n.RunLifecycle), w = f(t.HostedChat), T = y(b.Transports || w.Transports), E = String(b.PreferredTransport || w.PreferredTransport || "responses").trim().toLowerCase(), D = T.some((e) => e.Protocol === E) ? E : "responses", O = m(b.Enabled, s), k = m(x.Enabled, c), A = m(S.Enabled, u), j = m(C.Enabled, O), M = !!(n.interaction_v1?.enabled ?? n.Interaction?.V1 ?? n.InteractionV1 ?? !1), N = n.RuntimeCapabilityMatrix ?? t.RuntimeCapabilityMatrix, P = _(N) ?? v(t, N), F = n.ApprovalPolicy !== void 0 && n.ApprovalPolicy !== null;
	return {
		...n,
		Approval: m(n.Approval, F),
		RuntimeCapabilityMatrix: P,
		InteractionV1: M,
		ContextCompaction: n.ContextCompaction === !0,
		HostedChat: {
			Enabled: O,
			ApiFormats: p(b.ApiFormats || o),
			PreferredTransport: D,
			Transports: T
		},
		NativeDashboard: {
			Enabled: k,
			Href: typeof x.Href == "string" ? x.Href : k ? "/" : null,
			Label: typeof x.Label == "string" ? x.Label : k ? "管理平台" : null
		},
		NativeTerminal: {
			Enabled: A,
			Mode: typeof S.Mode == "string" ? S.Mode : A ? "tui" : null,
			Protocol: typeof S.Protocol == "string" ? S.Protocol : "ks-terminal.v1",
			Path: typeof S.Path == "string" ? S.Path : "/_ksadk/terminal/ws"
		},
		RunLifecycle: {
			Enabled: j,
			Resume: m(C.Resume, j),
			Abort: m(C.Abort, j),
			Checkpoints: m(C.Checkpoints, !1),
			CheckpointResume: m(C.CheckpointResume, !1),
			CheckpointResumePreview: m(C.CheckpointResumePreview, !1)
		},
		ApprovalPolicy: g(n.ApprovalPolicy),
		BuiltinTools: h(n.BuiltinTools)
	};
}
function x(e) {
	return b({ Data: { Capabilities: e } }).HostedChat.Enabled;
}
function S(e) {
	return b({ Data: { Capabilities: e } }).NativeDashboard.Enabled;
}
function C(e) {
	return b({ Data: { Capabilities: e } }).NativeTerminal.Enabled;
}
function w(e, t = {}) {
	let n = b({ Data: { Capabilities: e } }).HostedChat, r = n.Transports.find((e) => e.Protocol === n.PreferredTransport), i = n.Transports.find((e) => e.Protocol === "responses");
	return t.requireResumableRun && i ? i : r || i || {
		Protocol: "responses",
		Runtime: "ksadk",
		Endpoint: "/v1/responses",
		Version: "v1",
		Capabilities: {
			A2UI: !1,
			Interrupt: !1,
			Cancel: !1
		}
	};
}
//#endregion
export { w as a, b as i, S as n, s as o, C as r, x as t };
