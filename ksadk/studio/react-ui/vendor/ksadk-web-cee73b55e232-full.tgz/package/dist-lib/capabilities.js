import { i as e, n as t, r as n, t as r } from "./capabilities-CXle1R-K.js";
//#region src/core/capability/registry.ts
var i = class {
	plugins = [];
	register(e) {
		this.plugins.push(e);
	}
	getEnabled(e) {
		return this.plugins.filter((t) => t.isEnabled(e));
	}
	getForSlot(e, t, n) {
		return this.plugins.filter((e) => e.isEnabled(t)).map((t) => t.getComponent(e, n)).filter((e) => e !== null);
	}
};
//#endregion
export { i as PluginRegistry, r as isHostedChatEnabled, t as isNativeDashboardEnabled, n as isNativeTerminalEnabled, e as normalizeCapabilities };
