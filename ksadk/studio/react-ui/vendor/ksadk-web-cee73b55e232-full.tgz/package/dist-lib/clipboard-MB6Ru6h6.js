//#region src/utils/clipboard.js
async function e(e, t = globalThis) {
	let n = String(e ?? ""), r = t?.navigator;
	if (r?.clipboard?.writeText) try {
		return await r.clipboard.writeText(n), !0;
	} catch {}
	let i = t?.document, a = i?.body;
	if (!i?.createElement || !a?.appendChild || !a?.removeChild) return !1;
	let o = i.createElement("textarea");
	o.value = n, o.setAttribute?.("readonly", ""), o.style && (o.style.position = "fixed", o.style.top = "0", o.style.left = "-9999px", o.style.opacity = "0", o.style.pointerEvents = "none");
	let s = i.activeElement;
	a.appendChild(o), o.focus?.(), o.select?.(), o.setSelectionRange?.(0, n.length);
	try {
		return typeof i.execCommand == "function" ? !!i.execCommand("copy") : !1;
	} finally {
		a.removeChild(o), s?.focus?.();
	}
}
//#endregion
export { e as t };
