import { z as e } from "zod";
//#region src/core/teams/types.ts
var t = "teams.ksadk.io/v1", n = e.string().min(1).max(2048), r = e.number().int().nonnegative(), i = e.string().min(1), a = e.enum([
	"planning",
	"running",
	"waiting",
	"needs_attention",
	"awaiting_acceptance",
	"succeeded",
	"failed",
	"cancel_requested",
	"cancelled"
]), o = e.enum([
	"draft",
	"ready",
	"blocked",
	"running",
	"awaiting_acceptance",
	"succeeded",
	"failed",
	"cancel_requested",
	"cancelled"
]), s = e.object({
	authorityRef: n,
	groupId: n,
	memberId: n,
	bindingRef: n,
	providerRef: n,
	sessionId: n,
	runId: n,
	itemId: n.optional()
}).passthrough(), c = s.extend({ interactionId: n }), l = e.object({
	enqueue: e.boolean(),
	cancel: e.boolean(),
	steer: e.boolean(),
	restore: e.boolean(),
	interaction: e.boolean(),
	leader: e.boolean()
}).passthrough(), u = e.object({
	groupId: n,
	name: e.string().min(1),
	authorityRef: n,
	tenantId: n,
	ownerSubject: n,
	policy: e.object({
		taskAcceptance: e.enum([
			"leader",
			"human",
			"result"
		]),
		peerWake: e.boolean()
	}).optional(),
	leaderMemberId: n,
	revision: r,
	status: e.enum(["active", "archived"]),
	createdAt: i,
	updatedAt: i
}).passthrough(), d = e.object({
	memberId: n,
	groupId: n,
	name: e.string().min(1),
	role: e.enum(["leader", "member"]),
	responsibility: e.string().max(2e3).optional(),
	bindingRef: n,
	binding: e.object({
		bindingRef: n,
		providerRef: n,
		kind: e.enum([
			"local_build",
			"a2a",
			"cloud"
		]),
		agentId: n,
		capabilities: l
	}).passthrough(),
	sessionId: n,
	revision: r,
	status: e.enum([
		"active",
		"removed",
		"unavailable"
	]),
	executionStatus: e.enum([
		"idle",
		"queued",
		"running",
		"waiting",
		"needs_attention",
		"unavailable"
	])
}).passthrough(), f = d.extend({
	runMemberId: n,
	teamRunId: n,
	groupRevision: r
}), ee = e.discriminatedUnion("kind", [e.object({
	kind: e.literal("text"),
	text: e.string()
}), e.object({
	kind: e.literal("attachment"),
	attachmentRef: n,
	mediaType: n,
	name: e.string().optional()
})]), p = e.object({
	messageId: n,
	groupId: n,
	revision: r,
	createdAt: i,
	senderPrincipal: n,
	senderName: e.string(),
	groupRole: e.enum([
		"owner",
		"leader",
		"member",
		"system"
	]),
	parts: e.array(ee),
	mentions: e.array(n),
	intent: e.enum([
		"start_goal",
		"followup",
		"directed",
		"note",
		"result",
		"progress"
	]),
	sourceRefs: e.array(s).optional(),
	visibility: e.enum(["public", "internal"])
}).passthrough(), te = e.object({
	artifactId: n,
	name: e.string(),
	mediaType: n,
	source: s
}).passthrough(), ne = e.object({
	attemptId: n,
	attemptNumber: r,
	executionEpoch: r,
	status: o,
	source: s.optional(),
	artifacts: e.array(te)
}).passthrough(), re = e.object({
	taskId: n,
	groupId: n,
	teamRunId: n,
	revision: r,
	title: e.string().min(1),
	description: e.string(),
	ownerMemberId: n.nullable(),
	dependencies: e.array(n),
	status: o,
	acceptanceCriteria: e.string(),
	attempts: e.array(ne)
}).passthrough(), ie = e.object({
	sourcePath: e.string().min(1),
	baseRef: e.string().optional(),
	inputs: e.array(e.string()).optional(),
	mode: e.enum(["auto", "directory"]).optional()
}).passthrough(), ae = e.object({
	groupId: n,
	teamRunId: n,
	state: e.enum([
		"armed",
		"blocked",
		"active"
	]),
	primaryNodeId: n,
	primarySessionId: n,
	primaryBindingRef: n,
	standbyNodeId: n,
	standbyBindingRef: n,
	buildDigest: n,
	epoch: r,
	reason: e.string().nullable().optional(),
	automaticFailback: e.literal(!1),
	sessionId: n.optional(),
	checkpointId: n.optional()
}).passthrough(), oe = e.object({
	teamRunId: n,
	groupId: n,
	groupRevision: r,
	policy: u.shape.policy,
	revision: r,
	goalMessageId: n,
	goal: e.string(),
	result: e.string().optional(),
	resultHistory: e.array(e.object({
		result: e.string(),
		reason: e.string(),
		revision: r,
		requestedAt: i
	}).passthrough()).optional(),
	workspace: ie.nullable().optional(),
	leaderStandby: ae.nullable().optional(),
	leaderMemberId: n,
	status: a,
	dispatchSuspended: e.boolean(),
	dispatchEpoch: r,
	budget: e.object({
		maxMembers: r,
		maxConcurrent: r,
		maxStarts: r,
		startsUsed: r,
		maxHops: r
	}).passthrough(),
	createdAt: i,
	updatedAt: i
}).passthrough(), se = e.object({
	deliveryId: n,
	groupId: n,
	teamRunId: n,
	messageId: n,
	memberId: n,
	revision: r,
	status: e.enum([
		"pending",
		"accepted",
		"rejected",
		"uncertain",
		"cancelled"
	])
}).passthrough(), ce = e.object({
	ref: c,
	revision: r,
	title: e.string(),
	message: e.string(),
	kind: e.enum(["approval", "input"]),
	status: e.enum([
		"pending",
		"resolving",
		"resolved",
		"cancelled",
		"expired"
	]),
	createdAt: i
}).passthrough(), le = e.object({
	apiVersion: e.literal(t),
	group: u,
	watermark: r,
	members: e.array(d),
	runMembers: e.array(f).optional(),
	messages: e.array(p),
	tasks: e.array(re),
	teamRuns: e.array(oe),
	deliveries: e.array(se),
	interactions: e.array(ce),
	artifacts: e.array(te).optional()
}).passthrough(), ue = e.object({
	apiVersion: e.literal(t),
	eventId: n,
	groupId: n,
	groupSeq: e.number().int().positive(),
	type: n,
	createdAt: i,
	payload: e.record(e.string(), e.unknown())
}).passthrough(), de = e.object({
	nodeId: n,
	kind: e.enum([
		"task",
		"run",
		"child_invocation"
	]),
	title: e.string(),
	status: n,
	taskId: n.optional(),
	memberId: n.nullable().optional(),
	attemptId: n.optional(),
	source: s.nullable().optional(),
	parentNodeId: n.optional(),
	reason: e.string().nullable().optional()
}).passthrough(), fe = e.object({
	groupId: n,
	teamRunId: n,
	watermark: r,
	nodes: e.array(de),
	edges: e.array(e.object({
		source: n,
		target: n,
		kind: e.enum(["dependency", "invocation"])
	}).passthrough())
}).passthrough();
function pe(e) {
	let t = fe.safeParse(e);
	if (!t.success) throw new m("contract_mismatch", "执行视图格式不兼容，请刷新或更新客户端。");
	let n = t.data, r = new Set(n.nodes.map((e) => e.nodeId));
	if (r.size !== n.nodes.length || n.edges.some((e) => !r.has(e.source) || !r.has(e.target)) || n.nodes.some((e) => e.source && e.source.groupId !== n.groupId)) throw new m("scope_mismatch", "执行视图包含无效的节点引用。");
	return n;
}
var m = class extends Error {
	code;
	status;
	constructor(e, t, n) {
		super(t), this.name = "TeamsError", this.code = e, this.status = n;
	}
};
function h(e) {
	let t = le.safeParse(e);
	if (!t.success) throw new m("contract_mismatch", "群快照格式不兼容，请刷新或更新客户端。");
	let n = t.data, r = n.group.groupId;
	if ([
		n.runMembers || [],
		n.members,
		n.messages,
		n.tasks,
		n.teamRuns,
		n.deliveries
	].some((e) => e.some((e) => e.groupId !== r)) || n.interactions.some((e) => e.ref.groupId !== r || e.ref.authorityRef !== n.group.authorityRef)) throw new m("scope_mismatch", "群快照包含其他作用域的数据。");
	if ([
		...(n.artifacts || []).map((e) => e.source),
		...n.messages.flatMap((e) => e.sourceRefs || []),
		...n.tasks.flatMap((e) => e.attempts.flatMap((e) => [...e.source ? [e.source] : [], ...e.artifacts.map((e) => e.source)]))
	].some((e) => e.groupId !== r || e.authorityRef !== n.group.authorityRef)) throw new m("scope_mismatch", "群快照的产物或执行来源跨越作用域。");
	let i = (e) => new Set(e).size === e.length;
	if (!i((n.runMembers || []).map((e) => e.runMemberId)) || (n.runMembers || []).some((e) => !n.teamRuns.some((t) => t.teamRunId === e.teamRunId)) || !i((n.artifacts || []).map((e) => e.artifactId)) || !i(n.members.map((e) => e.memberId)) || !i(n.messages.map((e) => e.messageId)) || !i(n.tasks.map((e) => e.taskId)) || !i(n.teamRuns.map((e) => e.teamRunId)) || !i(n.deliveries.map((e) => e.deliveryId)) || !i(n.interactions.map((e) => JSON.stringify(e.ref)))) throw new m("contract_mismatch", "群快照存在重复身份。");
	return n;
}
function me(e) {
	let t = ue.safeParse(e);
	if (!t.success) throw new m("contract_mismatch", "群事件格式不兼容。");
	return t.data;
}
function he(e) {
	if (!e.name.trim()) throw new m("invalid_name", "请填写群组名称。");
	if (!e.members.length || e.members.length > 8) throw new m("invalid_members", "请选择 1–8 位成员。");
	if (new Set(e.members.map((e) => e.memberId)).size !== e.members.length) throw new m("duplicate_member", "成员不能重复。");
	if (!e.members.some((t) => t.memberId === e.leaderMemberId)) throw new m("invalid_leader", "Leader 必须是已选成员。");
}
//#endregion
//#region src/core/teams/reducer.ts
function ge(e) {
	return JSON.stringify([
		e.authorityRef,
		e.groupId,
		e.memberId,
		e.bindingRef,
		e.providerRef,
		e.sessionId,
		e.runId
	]);
}
function _e(e) {
	return JSON.stringify([ge(e), e.interactionId]);
}
function g(e, t, n) {
	let r = e.findIndex((e) => n(e) === n(t));
	return r >= 0 && e[r].revision >= t.revision ? e : r < 0 ? [...e, t] : e.map((e, n) => n === r ? t : e);
}
var ve = class {
	value;
	seenIds = /* @__PURE__ */ new Set();
	constructor(e) {
		this.value = h(e);
	}
	snapshot() {
		return this.value;
	}
	replace(e) {
		let t = h(e);
		if (t.group.groupId !== this.value.group.groupId || t.group.authorityRef !== this.value.group.authorityRef || t.group.tenantId !== this.value.group.tenantId) throw new m("scope_mismatch", "不能把另一个群或授权域的快照用于当前会话。");
		return t.watermark < this.value.watermark || t.group.revision < this.value.group.revision ? !1 : (this.value = t, this.seenIds.clear(), !0);
	}
	apply(e) {
		let t = me(e), n = this.value;
		if (t.groupId !== n.group.groupId) throw new m("scope_mismatch", "事件不属于当前群。");
		if (t.groupSeq <= n.watermark) return !1;
		if (t.groupSeq !== n.watermark + 1 || this.seenIds.has(t.eventId)) throw new m("reset_required", "群事件存在缺口，需要重新读取快照。");
		let r = {
			...n,
			watermark: t.groupSeq
		}, i = (e, t) => {
			let r;
			try {
				r = e.parse(t);
			} catch {
				throw new m("contract_mismatch", "群事件内容格式不兼容。");
			}
			let i = r;
			if (i.groupId && i.groupId !== n.group.groupId || i.ref && (i.ref.groupId !== n.group.groupId || i.ref.authorityRef !== n.group.authorityRef)) throw new m("scope_mismatch", "群事件引用了其他作用域。");
			if ([
				...i.source ? [i.source] : [],
				...i.sourceRefs || [],
				...(i.attempts || []).flatMap((e) => [...e.source ? [e.source] : [], ...e.artifacts.map((e) => e.source)])
			].some((e) => e.groupId !== n.group.groupId || e.authorityRef !== n.group.authorityRef)) throw new m("scope_mismatch", "群事件的产物或执行来源跨越作用域。");
			return r;
		};
		switch (t.type) {
			case "group.updated": {
				let e = i(u, t.payload.group);
				if (e.groupId !== n.group.groupId || e.authorityRef !== n.group.authorityRef || e.tenantId !== n.group.tenantId) throw new m("scope_mismatch", "群事件改变了授权域。");
				e.revision > n.group.revision && (r.group = e);
				break;
			}
			case "run_member.updated":
				r.runMembers = g(n.runMembers || [], i(f, t.payload.runMember), (e) => e.runMemberId);
				break;
			case "member.updated":
				r.members = g(n.members, i(d, t.payload.member), (e) => e.memberId);
				break;
			case "message.created":
			case "message.updated":
				r.messages = g(n.messages, i(p, t.payload.message), (e) => e.messageId);
				break;
			case "task.updated":
				r.tasks = g(n.tasks, i(re, t.payload.task), (e) => e.taskId);
				break;
			case "team_run.updated":
				r.teamRuns = g(n.teamRuns, i(oe, t.payload.teamRun), (e) => e.teamRunId);
				break;
			case "delivery.updated":
				r.deliveries = g(n.deliveries, i(se, t.payload.delivery), (e) => e.deliveryId);
				break;
			case "artifact.updated": {
				let e = i(te, t.payload.artifact);
				r.artifacts = [...new Map([...n.artifacts || [], e].map((e) => [e.artifactId, e])).values()];
				break;
			}
			case "interaction.updated":
				r.interactions = g(n.interactions, i(ce, t.payload.interaction), (e) => _e(e.ref));
				break;
			default: break;
		}
		return this.seenIds.add(t.eventId), this.seenIds.size > 2048 && this.seenIds.delete(this.seenIds.values().next().value), this.value = r, !0;
	}
};
//#endregion
//#region src/core/teams/client.ts
function _(e) {
	if (e?.aborted) throw new DOMException("Aborted", "AbortError");
}
function ye(e, t) {
	return new Promise((n, r) => {
		_(t);
		let i = () => t.removeEventListener("abort", o), a = setTimeout(() => {
			i(), n();
		}, e), o = () => {
			clearTimeout(a), i(), r(new DOMException("Aborted", "AbortError"));
		};
		t.addEventListener("abort", o, { once: !0 });
	});
}
async function be(e, t, n) {
	if (!e.body || !e.headers.get("content-type")?.includes("text/event-stream")) throw new m("contract_mismatch", "服务没有返回事件流。");
	let r = e.body.getReader(), i = new TextDecoder(), a = "", o = () => {
		r.cancel().catch(() => {});
	};
	t.addEventListener("abort", o, { once: !0 });
	let s = (e) => {
		_(t);
		let r = "message", i = [];
		for (let t of e.split(/\r?\n/)) t.startsWith("event:") && (r = t.slice(6).trim()), t.startsWith("data:") && i.push(t.slice(5).trimStart());
		if (!i.length) return;
		let a;
		try {
			a = JSON.parse(i.join("\n"));
		} catch {
			throw new m("contract_mismatch", "无法解析群事件。");
		}
		n(r, a);
	};
	try {
		for (;;) {
			_(t);
			let { done: e, value: n } = await r.read();
			if (_(t), a += e ? i.decode() : i.decode(n, { stream: !0 }), a.length > 8e6) throw new m("event_too_large", "群事件超过客户端大小限制。");
			let o = /\r?\n\r?\n/.exec(a);
			for (; o;) s(a.slice(0, o.index)), a = a.slice(o.index + o[0].length), o = /\r?\n\r?\n/.exec(a);
			if (e) {
				a.trim() && s(a);
				break;
			}
		}
	} finally {
		t.removeEventListener("abort", o), await r.cancel().catch(() => {}), r.releaseLock();
	}
}
var xe = class {
	fetcher;
	baseUrl;
	reconnects;
	retryDelay;
	constructor(e = {}) {
		if (this.fetcher = e.fetch ?? ((e, t) => globalThis.fetch(e, t)), this.baseUrl = (e.baseUrl ?? "/api/v1/groups").replace(/\/+$/, ""), this.reconnects = e.maxReconnects ?? 6, !Number.isSafeInteger(this.reconnects) || this.reconnects < 0 || this.reconnects > 32) throw new m("invalid_reconnect_limit", "重连次数必须在 0–32 之间。");
		this.retryDelay = e.retryDelayMs ?? ((e) => Math.min(500 * 2 ** e, 1e4));
	}
	path(e, t = "") {
		return `/${encodeURIComponent(e)}${t}`;
	}
	async request(e, t = {}) {
		_(t.signal ?? void 0);
		let n = await this.fetcher(`${this.baseUrl}${e}`, t);
		if (!n.ok) {
			let e = await n.json().catch(() => ({}));
			throw new m(e.error?.code ?? e.code ?? "http_error", e.error?.message ?? e.message ?? `群服务请求失败（${n.status}）`, n.status);
		}
		return n;
	}
	async json(e, t = {}) {
		let n = await this.request(e, t);
		return n.status === 204 ? void 0 : n.json();
	}
	post(e, t, n) {
		return this.json(e, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(t),
			signal: n
		});
	}
	list(e = {}) {
		let t = new URLSearchParams();
		return e.cursor && t.set("cursor", e.cursor), e.limit && t.set("limit", String(e.limit)), this.json(t.size ? `?${t}` : "", { signal: e.signal });
	}
	async snapshot(e, t) {
		let n = h(await this.json(this.path(e), { signal: t }));
		if (n.group.groupId !== e) throw new m("scope_mismatch", "服务返回了另一个群。");
		return n;
	}
	async create(e, t) {
		return he(e), h(await this.post("", e, t));
	}
	async update(e, t, n) {
		let r = h(await this.json(this.path(e), {
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(t),
			signal: n
		}));
		if (r.group.groupId !== e) throw new m("scope_mismatch", "群更新返回了另一个群。");
		return r;
	}
	send(e, t, n) {
		if (!t.parts.some((e) => e.kind !== "text" || e.text.trim())) throw new m("empty_message", "请输入消息。");
		if (t.workspace && t.intent !== "start_goal") throw new m("invalid_workspace_scope", "工作目录只能在新建任务时指定。");
		if (t.intent === "directed" && !t.mentions.length) throw new m("missing_recipient", "请选择接收成员。");
		return this.post(this.path(e, "/messages"), t, n);
	}
	start(e, t, n) {
		return this.post(this.path(e, "/team-runs"), t, n);
	}
	taskAction(e, t, n, r) {
		return this.post(this.path(e, `/tasks/${encodeURIComponent(t)}/actions`), n, r);
	}
	control(e, t, n, r) {
		return this.post(this.path(e, `/team-runs/${encodeURIComponent(t)}/control`), n, r);
	}
	acceptRun(e, t, n, r) {
		return this.post(this.path(e, `/team-runs/${encodeURIComponent(t)}/acceptance`), n, r);
	}
	async configureLeaderStandby(e, t, n, r) {
		if (!n.bindingRef.trim()) throw new m("missing_binding", "请选择云端备用节点。");
		let i = await this.post(this.path(e, `/team-runs/${encodeURIComponent(t)}/leader-standby`), n, r);
		if (i.groupId !== e || i.teamRunId !== t || i.standbyBindingRef !== n.bindingRef || ![
			"armed",
			"blocked",
			"active"
		].includes(i.state)) throw new m("scope_mismatch", "备用节点确认不属于当前任务或所选节点。");
		return i;
	}
	interaction(e, t, n) {
		if (t.ref.groupId !== e) throw new m("scope_mismatch", "审批不属于当前群。");
		return this.post(this.path(e, "/interactions"), t, n);
	}
	cancelMember(e, t, n, r) {
		if (n.ref.groupId !== e || n.ref.memberId !== t) throw new m("scope_mismatch", "停止请求不属于当前成员。");
		return this.post(this.path(e, `/members/${encodeURIComponent(t)}/cancel`), n, r);
	}
	async execution(e, t, n) {
		let r = pe(await this.json(this.path(e, `/execution${t ? `?teamRunId=${encodeURIComponent(t)}` : ""}`), { signal: n }));
		if (r.groupId !== e || t && r.teamRunId !== t) throw new m("scope_mismatch", "执行视图不属于当前协作轮次。");
		return r;
	}
	markRead(e, t, n) {
		return this.post(this.path(e, "/read"), { watermark: t }, n);
	}
	async reconciliation(e, t) {
		let n = await this.json(this.path(e, "/reconciliation"));
		if (n.groupId !== e || !Array.isArray(n.items)) throw new m("scope_mismatch", "原单核查结果不属于当前团队。");
		return n.items.filter((e) => e.teamRunId === t);
	}
	reconcile(e, t, n) {
		return this.post(this.path(e, `/reconciliation/${encodeURIComponent(t)}`), n);
	}
	async watch(e, t) {
		let { signal: n, onSnapshot: r, onConnection: i, onError: a } = t, o, s = !0, c = 0;
		i?.("connecting");
		try {
			for (; !n.aborted;) try {
				if (s) {
					let t = await this.snapshot(e, n);
					if (o) {
						if (!o.replace(t)) throw new m("reset_required", "服务返回的快照早于当前状态，正在重新核对。");
					} else o = new ve(t);
					s = !1, _(n), r(o.snapshot());
				}
				if (!o) throw new m("reset_required", "群快照尚未就绪。");
				let t = await this.request(this.path(e, `/events?after=${o.snapshot().watermark}`), { signal: n });
				throw i?.("connected"), await be(t, n, (e, t) => {
					if (e === "reset_required") throw new m("reset_required", "群事件游标已过期。");
					e === "heartbeat" || e === "ping" || o.apply(me(t)) && (c = 0, r(o.snapshot()));
				}), _(n), new m("stream_ended", "群事件连接已断开。");
			} catch (e) {
				if (n.aborted) break;
				let t = e instanceof m ? e : new m("network_error", e instanceof Error ? e.message : "无法连接群服务。");
				if (t.code === "reset_required") s = !0;
				else if (t.status === 401 || t.status === 403 || t.status === 404 || t.code === "contract_mismatch" || t.code === "scope_mismatch") throw t;
				if (c++ >= this.reconnects) throw t;
				i?.("reconnecting"), await ye(this.retryDelay(c - 1), n);
			}
		} catch (e) {
			if (!n.aborted) {
				i?.("offline");
				let t = e instanceof m ? e : new m("network_error", String(e));
				throw a?.(t), t;
			}
		} finally {
			n.aborted && i?.("closed");
		}
	}
}, Se = class extends Error {
	constructor() {
		super("invalid_teams_canonical_json"), this.name = "TeamsCanonicalJsonError";
	}
};
function Ce(e) {
	for (let t = 0; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(++t);
			if (!(n >= 56320 && n <= 57343)) return !1;
		} else if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function v(e) {
	let t = /* @__PURE__ */ new Set(), n = () => {
		throw new Se();
	}, r = (e, i) => {
		if (i > 50) return n();
		if (e === null || typeof e == "boolean") return JSON.stringify(e);
		if (typeof e == "string") return Ce(e) ? JSON.stringify(e) : n();
		if (typeof e == "number") return !Number.isFinite(e) || Number.isInteger(e) && !Number.isSafeInteger(e) ? n() : JSON.stringify(e);
		if (!e || typeof e != "object" || t.has(e) || Object.getOwnPropertySymbols(e).length || !Array.isArray(e) && Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null) return n();
		t.add(e);
		let a;
		if (Array.isArray(e)) {
			if (Object.getOwnPropertyNames(e).length !== e.length + 1) return n();
			let t = [];
			for (let a = 0; a < e.length; a++) {
				let o = Object.getOwnPropertyDescriptor(e, a);
				if (!o || !("value" in o)) return n();
				t.push(r(o.value, i + 1));
			}
			a = `[${t.join(",")}]`;
		} else {
			let t = Object.keys(e).sort();
			if (Object.getOwnPropertyNames(e).length !== t.length) return n();
			a = `{${t.map((t) => {
				if (!Ce(t)) return n();
				let a = Object.getOwnPropertyDescriptor(e, t);
				return !a || !("value" in a) ? n() : `${JSON.stringify(t)}:${r(a.value, i + 1)}`;
			}).join(",")}}`;
		}
		return t.delete(e), a;
	};
	return r(e, 0);
}
async function y(e, t = globalThis.crypto.subtle) {
	let n = await t.digest("SHA-256", new TextEncoder().encode(v(e)));
	return `sha256:${Array.from(new Uint8Array(n), (e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function we(e, t) {
	let n = Array.from(e, (e) => e.codePointAt(0)), r = Array.from(t, (e) => e.codePointAt(0));
	for (let e = 0; e < Math.min(n.length, r.length); e++) if (n[e] !== r[e]) return n[e] - r[e];
	return n.length - r.length;
}
//#endregion
//#region src/core/teams/operationOutbox.ts
var b = class extends Error {
	code;
	constructor(e) {
		super(e), this.name = "TeamsOperationOutboxError", this.code = e;
	}
}, Te = "teams_operations", Ee = [
	"scope.origin",
	"scope.ownerScopeRef",
	"scope.authorityId",
	"scope.groupId"
], De = new Set(["confirmed", "rejected"]), Oe = new Set([
	"authorization",
	"proxyauthorization",
	"cookie",
	"setcookie",
	"credentials",
	"headers",
	"password",
	"secret",
	"secretkey",
	"accesskey",
	"accesskeyid",
	"accesskeysecret",
	"apikey",
	"token",
	"tokenref",
	"accesstoken",
	"refreshtoken",
	"refreshsecret",
	"privatekey",
	"clientsecret",
	"nodecredential",
	"runtimetoken",
	"signedurl",
	"presignedurl"
]), ke = new Set([
	"requestId",
	"idempotencyKey",
	"transportTimestamp",
	"transportTime"
]);
function x(e) {
	throw new b(e);
}
function S(e, t = 200, n = !1) {
	return (typeof e != "string" || !n && !e.trim() || e.length > t || Array.from(e).some((e) => e.charCodeAt(0) < 32)) && x("invalid_operation_identity"), e;
}
function Ae(e, t, n = !0) {
	(!e || Array.isArray(e) || typeof e != "object") && x("invalid_business_payload"), n && Object.keys(e).some((e) => ke.has(e)) && x("transport_metadata_not_allowed");
	let r;
	try {
		r = v(e);
	} catch {
		x("invalid_business_payload");
	}
	new TextEncoder().encode(r).byteLength > t && x("payload_too_large");
	let i = (e) => {
		if (Array.isArray(e)) e.forEach(i);
		else if (e && typeof e == "object") for (let [t, n] of Object.entries(e)) Oe.has(t.toLowerCase().replace(/[^a-z0-9]/g, "")) && x("credentials_not_allowed"), i(n);
	};
	return i(e), {
		payload: JSON.parse(r),
		json: r
	};
}
function C(e) {
	return new Promise((t, n) => {
		e.onsuccess = () => t(e.result), e.onerror = () => n(e.error);
	});
}
function w(e) {
	return [
		e.origin,
		e.ownerScopeRef,
		e.authorityId,
		e.groupId
	];
}
function T(e, t, n) {
	return (!Number.isSafeInteger(e) || e < t || e > n) && x("invalid_outbox_limit"), e;
}
var je = class {
	scope;
	factory;
	cryptography;
	now;
	databaseName;
	maxEntries;
	maxPayloadBytes;
	database;
	closed = !1;
	constructor(e) {
		let { origin: t, ownerScopeRef: n, authorityId: r, groupId: i } = e.scope, a;
		try {
			a = new URL(t);
		} catch {
			x("invalid_operation_origin");
		}
		(a.origin !== t || !["http:", "https:"].includes(a.protocol)) && x("invalid_operation_origin"), this.scope = Object.freeze({
			origin: t,
			ownerScopeRef: S(n, 512),
			authorityId: S(r),
			groupId: S(i, 200, !0)
		}), this.factory = e.indexedDB ?? globalThis.indexedDB, this.cryptography = e.crypto ?? globalThis.crypto, (!this.factory || !this.cryptography?.subtle || !this.cryptography.randomUUID) && x("outbox_unavailable"), this.now = e.now ?? Date.now, this.databaseName = e.databaseName ?? "ksadk-teams-operations", this.maxEntries = T(e.maxEntries ?? 1e3, 1, 1e4), this.maxPayloadBytes = T(e.maxPayloadBytes ?? 1048576, 1, 2097152);
	}
	async open() {
		return this.closed && x("outbox_closed"), this.database ||= new Promise((e, t) => {
			let n = this.factory.open(this.databaseName, 1);
			n.onupgradeneeded = () => {
				let e = n.result.createObjectStore(Te, { keyPath: [...Ee, "operationId"] });
				e.createIndex("scope", Ee), e.createIndex("scope_key", [
					...Ee,
					"operation",
					"idempotencyKey"
				], { unique: !0 });
			}, n.onsuccess = () => {
				n.result.onversionchange = () => {
					n.result.close(), this.closed = !0;
				}, e(n.result);
			}, n.onerror = () => t(new b("outbox_unavailable")), n.onblocked = () => t(new b("outbox_upgrade_blocked"));
		}), this.database;
	}
	key(e) {
		return [...w(this.scope), S(e)];
	}
	async transaction(e, t) {
		let n = (await this.open()).transaction(Te, e, { durability: e === "readwrite" ? "strict" : "default" }), r = new Promise((e, t) => {
			n.oncomplete = () => e(), n.onabort = () => t(n.error ?? new b("outbox_transaction_aborted")), n.onerror = () => {};
		});
		r.catch(() => void 0);
		try {
			let e = await t(n.objectStore(Te));
			return await r, e;
		} catch (e) {
			try {
				n.abort();
			} catch {}
			throw await r.catch(() => void 0), e;
		}
	}
	async digest(e, t) {
		return y({
			operation: e,
			payload: JSON.parse(t)
		}, this.cryptography.subtle);
	}
	async enqueue(e, t = {}) {
		let n = S(e.operationId ?? this.cryptography.randomUUID()), r = S(e.operation, 512);
		(!/^[a-zA-Z0-9_.:/-]+$/.test(r) || r.includes("://")) && x("invalid_business_operation");
		let i = S(e.idempotencyKey ?? this.cryptography.randomUUID()), { payload: a, json: o } = Ae(e.payload, this.maxPayloadBytes), s = await this.digest(r, o);
		return this.transaction("readwrite", async (o) => {
			let c = await C(o.get(this.key(n)));
			if (c) return (c.payloadDigest !== s || c.operation !== r || e.idempotencyKey !== void 0 && c.idempotencyKey !== i) && x("operation_payload_conflict"), c;
			let l = await C(o.index("scope").getAll(w(this.scope))), u = t.reuseUnresolved && l.find((e) => e.operation === r && e.payloadDigest === s && !De.has(e.status));
			if (u) return u;
			await C(o.index("scope_key").get([
				...w(this.scope),
				r,
				i
			])) && x("idempotency_key_conflict");
			let d = l.filter((e) => De.has(e.status)).sort((e, t) => e.updatedAt - t.updatedAt), f = l.length;
			for (; f >= this.maxEntries && d.length;) await C(o.delete(this.key(d.shift().operationId))), f--;
			f >= this.maxEntries && x("outbox_capacity");
			let ee = this.now(), p = {
				scope: { ...this.scope },
				operationId: n,
				operation: r,
				idempotencyKey: i,
				payload: a,
				payloadDigest: s,
				createdAt: ee,
				updatedAt: ee,
				status: "queued",
				revision: 1,
				attempts: 0
			};
			return await C(o.add(p)), p;
		});
	}
	async get(e) {
		return this.transaction("readonly", async (t) => await C(t.get(this.key(e))));
	}
	async list(e = {}) {
		let t = T(e.limit ?? 100, 1, 1e4);
		return this.transaction("readonly", async (n) => (await C(n.index("scope").getAll(w(this.scope)))).filter((t) => !e.statuses || e.statuses.includes(t.status)).sort((e, t) => e.createdAt - t.createdAt || e.operationId.localeCompare(t.operationId)).slice(0, t));
	}
	async updateDraft(e, t, n) {
		let r = await this.get(e);
		r || x("operation_not_found");
		let { payload: i, json: a } = Ae(n, this.maxPayloadBytes), o = await this.digest(r.operation, a);
		return this.transaction("readwrite", async (n) => {
			let r = await C(n.get(this.key(e)));
			r || x("operation_not_found"), r.revision !== t && x("operation_revision_conflict"), (r.status !== "queued" || r.attempts !== 0) && x("operation_already_sent");
			let a = {
				...r,
				payload: i,
				payloadDigest: o,
				revision: r.revision + 1,
				updatedAt: this.now()
			};
			return await C(n.put(a)), a;
		});
	}
	async claimNext(e, t, n = /* @__PURE__ */ new Set()) {
		S(e), T(t, 100, 12e4);
		let r = this.cryptography.randomUUID();
		return this.transaction("readwrite", async (i) => {
			let a = this.now(), o = (await C(i.index("scope").getAll(w(this.scope)))).filter((e) => !De.has(e.status) && !n.has(e.operationId) && (!e.leaseExpiresAt || e.leaseExpiresAt <= a)).sort((e, t) => e.attempts - t.attempts || e.createdAt - t.createdAt || e.operationId.localeCompare(t.operationId))[0];
			if (!o) return;
			let s = {
				...o,
				status: "sending",
				leaseOwner: e,
				leaseToken: r,
				leaseExpiresAt: a + t,
				attempts: o.attempts + 1,
				revision: o.revision + 1,
				updatedAt: a
			};
			return await C(i.put(s)), s;
		});
	}
	owns(e, t) {
		return !!(e && w(t.scope).every((e, t) => e === w(this.scope)[t]) && e.status === "sending" && e.leaseOwner === t.leaseOwner && e.leaseToken === t.leaseToken && e.leaseExpiresAt > this.now());
	}
	async renew(e, t) {
		return T(t, 100, 12e4), this.transaction("readwrite", async (n) => {
			let r = await C(n.get(this.key(e.operationId)));
			return this.owns(r, e) ? (await C(n.put({
				...r,
				leaseExpiresAt: this.now() + t,
				updatedAt: this.now()
			})), !0) : !1;
		});
	}
	async settle(e, t, n) {
		[
			"confirmed",
			"rejected",
			"uncertain",
			"pending"
		].includes(t.status) || x("invalid_operation_receipt");
		let r = t.serverOperationId === void 0 ? void 0 : S(t.serverOperationId), i = "receipt" in t && t.receipt !== void 0 ? Ae(t.receipt, this.maxPayloadBytes, !1).payload : void 0, a = t.status === "rejected" ? t.code : n ?? (t.status === "pending" ? "pending" : void 0);
		return a !== void 0 && !/^[a-z][a-z0-9_]{0,99}$/.test(a) && x("invalid_operation_error_code"), this.transaction("readwrite", async (n) => {
			let o = await C(n.get(this.key(e.operationId)));
			if (!this.owns(o, e)) return !1;
			let s = {
				...o,
				status: t.status === "pending" ? "uncertain" : t.status,
				updatedAt: this.now(),
				revision: o.revision + 1
			};
			return delete s.leaseOwner, delete s.leaseToken, delete s.leaseExpiresAt, delete s.errorCode, delete s.receipt, r !== void 0 && (s.serverOperationId = r), i !== void 0 && (s.receipt = i), a !== void 0 && (s.errorCode = a), await C(n.put(s)), !0;
		});
	}
	async close() {
		this.closed = !0, this.database && (await this.database).close();
	}
}, Me = class {
	outbox;
	transport;
	tabId;
	active;
	deactivated = !1;
	constructor(e, t, n = globalThis.crypto.randomUUID()) {
		this.outbox = e, this.transport = t, this.tabId = S(n);
	}
	deactivate() {
		this.deactivated = !0, this.active?.abort();
	}
	async drain(e = {}) {
		this.deactivated && x("outbox_identity_inactive"), this.active && x("outbox_drain_in_progress");
		let t = T(e.maxOperations ?? 50, 1, 1e3), n = T(e.maxDurationMs ?? 3e4, 1, 12e4), r = T(e.requestTimeoutMs ?? 1e4, 1, 12e4), i = T(e.leaseMs ?? 15e3, 100, 12e4), a = new AbortController();
		this.active = a;
		let o = () => a.abort();
		e.signal?.addEventListener("abort", o, { once: !0 }), e.signal?.aborted && o();
		let s = setTimeout(o, n), c = {
			processed: 0,
			confirmed: 0,
			rejected: 0,
			uncertain: 0,
			aborted: !1
		}, l = /* @__PURE__ */ new Set();
		try {
			for (; !a.signal.aborted && c.processed < t;) {
				let e = await this.outbox.claimNext(this.tabId, i, l);
				if (!e) break;
				l.add(e.operationId), c.processed++;
				let t = await this.recover(e, a.signal, i, r);
				t !== void 0 && c[t]++;
			}
			return c.aborted = a.signal.aborted, c;
		} finally {
			clearTimeout(s), e.signal?.removeEventListener("abort", o), this.active = void 0;
		}
	}
	async recover(e, t, n, r) {
		let i = new AbortController(), a = () => i.abort();
		t.addEventListener("abort", a, { once: !0 }), t.aborted && a();
		let o = !1, s = setInterval(() => {
			o || i.signal.aborted || (o = !0, this.outbox.renew(e, n).then((e) => {
				e || a();
			}, a).finally(() => {
				o = !1;
			}));
		}, Math.floor(n / 3));
		try {
			let t = await this.call((t) => this.transport.lookup(structuredClone(e), t), i.signal, r);
			return t.status === "missing" && ((i.signal.aborted || !await this.outbox.renew(e, n)) && x("operation_aborted"), t = await this.call((t) => this.transport.send(structuredClone(e), t), i.signal, r)), i.signal.aborted && x("operation_aborted"), await this.outbox.settle(e, t) ? t.status === "pending" ? "uncertain" : t.status : void 0;
		} catch (n) {
			let r = t.aborted ? "aborted" : n instanceof b && n.code === "operation_timeout" ? "timeout" : "transport_uncertain";
			return await this.outbox.settle(e, { status: "uncertain" }, r) ? "uncertain" : void 0;
		} finally {
			clearInterval(s), t.removeEventListener("abort", a), i.abort();
		}
	}
	async call(e, t, n) {
		t.aborted && x("operation_aborted");
		let r = new AbortController(), i = () => void 0, a, o = new Promise((e, o) => {
			i = () => {
				r.abort(), o(new b("operation_aborted"));
			}, t.addEventListener("abort", i, { once: !0 }), a = setTimeout(() => {
				r.abort(), o(new b("operation_timeout"));
			}, n);
		});
		try {
			return await Promise.race([Promise.resolve().then(() => (r.signal.aborted && x("operation_aborted"), e(r.signal))), o]);
		} finally {
			clearTimeout(a), t.removeEventListener("abort", i), r.abort();
		}
	}
}, E = "teams-node/v1", Ne = "teams-host/v1", Pe = 20 * 1024 * 1024, Fe = 64 * 1024 * 1024, Ie = 1024 * 1024, D = e.string().refine(Ce, "Invalid Unicode scalar string"), O = (e, t) => D.refine((n) => {
	let r = Array.from(n).length;
	return r >= e && r <= t;
}, "Invalid text length"), k = O(1, 256).refine((e) => !Array.from(e).some((e) => {
	let t = e.codePointAt(0);
	return t >= 9 && t <= 13 || t === 32 || t >= 8192 && t <= 8202 || [
		133,
		160,
		5760,
		8232,
		8233,
		8239,
		8287,
		12288
	].includes(t);
}), "Identifier contains whitespace"), A = O(1, 200), j = D.length(71).regex(/^sha256:[0-9a-f]{64}$/), M = D.length(36).regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/), N = e.number().int().min(0).max(2 ** 53 - 1), P = N.min(1), F = D.refine((e) => {
	if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(e) || e.startsWith("0000")) return !1;
	let t = new Date(e);
	return Number.isFinite(t.getTime()) && t.toISOString() === e;
}, "Expected a valid UTC timestamp with millisecond precision"), Le = e.lazy(() => e.union([
	e.null(),
	e.boolean(),
	D,
	e.number().refine((e) => Number.isFinite(e) && (!Number.isInteger(e) || Number.isSafeInteger(e))),
	e.array(Le),
	e.record(D, Le)
])), I = e.record(D, Le), L = k.nullable().default(null), Re = e.discriminatedUnion("kind", [e.strictObject({
	kind: e.literal("node"),
	nodeId: k,
	nodeGeneration: P
}), e.strictObject({
	kind: e.literal("cloud_agent"),
	agentId: k,
	versionId: k,
	runtimeId: k,
	agentInstanceId: k
})]), ze = e.strictObject({
	authorityId: k,
	groupId: k,
	teamRunId: k,
	memberId: k,
	runMemberId: k,
	taskId: L,
	attemptId: k,
	deliveryId: k,
	bindingRef: k,
	providerRef: k,
	sessionId: k,
	commandId: M,
	idempotencyKey: A,
	schedulerEpoch: P,
	leaderEpoch: P,
	dispatchEpoch: P,
	attemptEpoch: P,
	target: Re,
	bundleDigest: j,
	contractDigest: j,
	capabilitiesDigest: j,
	nativeRunId: L
}), Be = e.strictObject({
	sessionId: k,
	runId: k,
	commandId: M,
	terminalSeq: N,
	terminalEventDigest: j,
	resultDigest: j.nullable().default(null)
}), Ve = new Set([
	"succeeded",
	"failed",
	"cancelled",
	"interrupted"
]), He = e.strictObject({
	status: e.enum([
		"missing",
		"accepted",
		"duplicate",
		"rejected",
		"uncertain"
	]),
	commandId: M,
	idempotencyKey: A,
	payloadDigest: j,
	storeIncarnation: k,
	runId: L,
	acceptedSeq: N.nullable().default(null),
	nativeStatus: e.enum([
		"queued",
		"running",
		"waiting",
		"awaiting_approval",
		"waiting_for_node",
		"succeeded",
		"failed",
		"cancelled",
		"interrupted"
	]).nullable().default(null),
	terminalEvidence: Be.nullable().default(null)
}).superRefine((e, t) => {
	e.status === "missing" && [
		e.runId,
		e.acceptedSeq,
		e.nativeStatus,
		e.terminalEvidence
	].some((e) => e !== null) && t.addIssue({
		code: "custom",
		message: "Missing receipt cannot contain execution evidence"
	}), e.terminalEvidence && (e.commandId !== e.terminalEvidence.commandId || e.runId !== e.terminalEvidence.runId || !Ve.has(e.nativeStatus ?? "")) && t.addIssue({
		code: "custom",
		message: "Terminal evidence must match the original command/run and terminal status"
	});
}), Ue = e.strictObject({
	eventId: k,
	sessionId: k,
	runId: k,
	seq: N,
	family: k,
	type: k,
	payload: I,
	sourceRef: e.strictObject({
		nativeRunId: L,
		parentRunId: L,
		nativeEventType: L
	})
});
function We(e, t) {
	try {
		if (new TextEncoder().encode(v(e)).byteLength <= Ie) return;
	} catch {}
	t.addIssue({
		code: "custom",
		message: "Report is not safe canonical JSON within one MiB"
	});
}
var Ge = e.strictObject({
	sessionId: k,
	storeIncarnation: k,
	afterSeq: N,
	nextSeq: N,
	snapshotUpperSeq: N,
	hasMore: e.boolean(),
	items: e.array(Ue).max(200)
}).superRefine((e, t) => {
	(!(e.afterSeq <= e.nextSeq && e.nextSeq <= e.snapshotUpperSeq) || e.hasMore !== e.nextSeq < e.snapshotUpperSeq || e.hasMore && e.nextSeq === e.afterSeq) && t.addIssue({
		code: "custom",
		message: "Invalid frozen canonical session cursor interval"
	});
	let n = e.afterSeq, r = /* @__PURE__ */ new Set();
	for (let i of e.items) (i.sessionId !== e.sessionId || !(n < i.seq && i.seq <= e.nextSeq) || r.has(i.eventId)) && t.addIssue({
		code: "custom",
		message: "Events must be unique and ordered in the declared session interval"
	}), n = i.seq, r.add(i.eventId);
	We(e, t);
}), Ke = e.strictObject({
	permitKind: e.enum(["execute", "recovery"]),
	permit: O(1, 16384),
	grantRevision: P.nullable().default(null)
}), R = {
	protocolVersion: e.literal(E).default(E),
	nodeCommandId: M,
	operationKey: A,
	ref: ze,
	commandDigest: j,
	issuedAt: F,
	claimLeaseUntil: F,
	authorization: Ke
}, qe = e.strictObject({
	contextRef: k,
	contextDigest: j,
	materialManifestRef: L
}), Je = e.object({
	schema_version: e.literal(1).optional(),
	command_id: M,
	idempotency_key: e.string(),
	tenant_id: e.string(),
	agent_instance_id: e.string(),
	session_id: e.string(),
	command_type: e.literal("enqueue"),
	source: e.object({
		kind: e.enum([
			"studio",
			"responses",
			"agui",
			"a2a",
			"parent_agent",
			"scheduler",
			"workflow",
			"channel",
			"system"
		]),
		ref: e.string()
	}).passthrough(),
	authorization_ref: e.string(),
	submitted_at: e.string(),
	causation_id: e.string().nullable().optional(),
	correlation_id: e.string().nullable().optional(),
	payload: e.object({
		content: Le,
		reply_to: e.string().nullable().optional(),
		execution_grant_id: O(1, 512),
		execution_grant_attempt_epoch: P.nullable().optional(),
		execution_policy_ref: O(1, 2 ** 53 - 1),
		teams_context_ref: O(1, 2 ** 53 - 1)
	}).passthrough()
}).passthrough(), Ye = e.strictObject({
	command: I,
	payloadDigest: j
}).superRefine((e, t) => {
	Je.safeParse(e.command).success || t.addIssue({
		code: "custom",
		message: "Teams submit requires an original governed native enqueue envelope"
	});
}), Xe = e.strictObject({
	grantId: k,
	expectedRevision: P,
	state: e.enum([
		"active",
		"suspended",
		"revoked"
	]),
	attemptEpoch: P,
	expiresAt: F,
	renewalId: A.nullable().default(null),
	controlId: A.nullable().default(null)
}).superRefine((e, t) => {
	(e.renewalId === null == (e.controlId === null) || e.renewalId !== null && e.state !== "active") && t.addIssue({
		code: "custom",
		message: "Exactly one control or active renewal identity is required"
	});
}), Ze = e.discriminatedUnion("operation", [
	e.strictObject({
		...R,
		operation: e.literal("prepare"),
		lane: e.literal("execution"),
		payload: qe
	}),
	e.strictObject({
		...R,
		operation: e.literal("submit"),
		lane: e.literal("execution"),
		payload: Ye
	}),
	e.strictObject({
		...R,
		operation: e.literal("lookup"),
		lane: e.literal("control"),
		payload: e.strictObject({
			commandId: M,
			idempotencyKey: A,
			payloadDigest: j,
			storeIncarnation: k
		})
	}),
	e.strictObject({
		...R,
		operation: e.literal("set_grant"),
		lane: e.literal("control"),
		payload: Xe
	}),
	e.strictObject({
		...R,
		operation: e.literal("set_admission"),
		lane: e.literal("control"),
		payload: e.strictObject({
			grantId: k,
			expectedAdmissionRevision: P,
			admissionAllowed: e.boolean(),
			attemptEpoch: P,
			controlId: A
		})
	}),
	e.strictObject({
		...R,
		operation: e.literal("get_grant"),
		lane: e.literal("control"),
		payload: e.strictObject({
			grantId: k,
			renewalId: A.nullable().default(null)
		})
	}),
	e.strictObject({
		...R,
		operation: e.literal("cancel"),
		lane: e.literal("control"),
		payload: e.strictObject({
			controlCommandId: M,
			controlIdempotencyKey: A,
			targetRunId: k,
			reason: O(0, 2e3)
		})
	}),
	e.strictObject({
		...R,
		operation: e.literal("respond_interaction"),
		lane: e.literal("control"),
		payload: e.strictObject({
			controlCommandId: M,
			controlIdempotencyKey: A,
			interactionId: k,
			expectedRevision: P,
			action: e.enum([
				"approve",
				"reject",
				"submit",
				"cancel"
			]),
			response: I
		})
	}),
	e.strictObject({
		...R,
		operation: e.literal("observe"),
		lane: e.literal("control"),
		payload: e.strictObject({
			sessionId: k,
			afterSeq: N,
			limit: e.number().int().min(1).max(200).default(200)
		})
	})
]).superRefine((e, t) => {
	let n = (e) => t.addIssue({
		code: "custom",
		message: e
	});
	(e.ref.target.kind !== "node" || e.nodeCommandId === e.ref.commandId || e.claimLeaseUntil <= e.issuedAt) && n("Invalid node target, operation identity or claim interval"), e.operation === "submit" && (e.payload.command.command_id !== e.ref.commandId || e.payload.command.idempotency_key !== e.ref.idempotencyKey || e.payload.command.session_id !== e.ref.sessionId) && n("Submit differs from frozen enqueue reference"), e.operation === "lookup" && (e.payload.commandId !== e.ref.commandId || e.payload.idempotencyKey !== e.ref.idempotencyKey) && n("Lookup must target the original enqueue"), (e.operation === "cancel" || e.operation === "respond_interaction") && (([e.nodeCommandId, e.ref.commandId].includes(e.payload.controlCommandId) || e.payload.controlIdempotencyKey === e.ref.idempotencyKey || e.ref.nativeRunId === null) && n("Control requires original native run and independent identity"), e.operation === "cancel" && e.payload.targetRunId !== e.ref.nativeRunId && n("Cancel must target the exact original native run")), e.operation === "observe" && e.payload.sessionId !== e.ref.sessionId && n("Observe must target the original session"), e.operation === "set_admission" && (e.payload.attemptEpoch !== e.ref.attemptEpoch || e.payload.controlId === e.ref.idempotencyKey) && n("Admission requires the original attempt and an independent control identity"), ([
		"prepare",
		"submit",
		"respond_interaction",
		"set_admission"
	].includes(e.operation) || e.operation === "set_grant" && e.payload.state !== "revoked") && e.authorization.permitKind !== "execute" && n("Recovery authorization cannot grant execution");
});
async function Qe(e) {
	let t = { ...e.ref };
	return delete t.schedulerEpoch, y({
		protocolVersion: e.protocolVersion,
		nodeCommandId: e.nodeCommandId,
		operationKey: e.operationKey,
		operation: e.operation,
		lane: e.lane,
		ref: t,
		payload: e.payload
	});
}
async function $e(e) {
	let t = Ze.parse(e);
	if (await Qe(t) !== t.commandDigest) throw Error("node_command_digest_mismatch");
	return t;
}
var et = D.refine((e) => !e || Array.from(e).length > 4096 || e.startsWith("/") || e.includes("\\") || /^[A-Za-z]:/.test(e) || Array.from(e).some((e) => e.codePointAt(0) < 32 || e.codePointAt(0) === 127) ? !1 : e.split("/").every((e) => e !== "" && e !== "." && e !== ".."), "Material path must be a normalized relative file path"), tt = e.strictObject({
	path: et,
	digest: j,
	sizeBytes: e.number().int().min(0).max(Pe),
	mediaType: O(1, 200)
}), nt = {
	kind: e.enum(["files", "git_snapshot"]),
	sourceCommit: D.refine((e) => [40, 64].includes(e.length) && /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(e)).nullable().default(null),
	entries: e.array(tt).min(1).max(4096)
};
function rt(e, t) {
	let n = (e) => t.addIssue({
		code: "custom",
		message: e
	});
	e.kind === "git_snapshot" != (e.sourceCommit !== null) && n("Only Git snapshots require a full source commit"), e.entries.reduce((e, t) => e + t.sizeBytes, 0) > Fe && n("Material exceeds 64 MiB");
	let r = new Set(e.entries.map((e) => e.path));
	r.size !== e.entries.length && n("Duplicate material path");
	for (let e of r) {
		let t = e.split("/");
		for (t.pop(); t.length;) r.has(t.join("/")) && n("A material file cannot also be a directory"), t.pop();
	}
}
var z = e.strictObject(nt).superRefine(rt), it = e.strictObject({
	...nt,
	idempotencyKey: A
}).superRefine(rt);
async function at(e) {
	let t = z.parse(e);
	return y({
		kind: t.kind,
		...t.sourceCommit === null ? {} : { sourceCommit: t.sourceCommit },
		entries: [...t.entries].sort((e, t) => we(e.path, t.path))
	});
}
var ot = e.strictObject({
	storeIncarnation: k,
	grant: e.strictObject({
		grantId: k,
		state: e.enum([
			"active",
			"suspended",
			"revoked"
		]),
		revision: P,
		attemptEpoch: P,
		expiresAt: F,
		admissionAllowed: e.boolean(),
		admissionRevision: P
	}),
	barrier: e.strictObject({
		queuedMessageIds: e.array(k).max(1e4).default([]),
		inFlightMessageIds: e.array(k).max(1e4).default([]),
		discardedMessageIds: e.array(k).max(1e4).default([]),
		settledMessageIds: e.array(k).max(1e4).default([]),
		commands: e.array(e.strictObject({
			messageId: k,
			commandId: M,
			idempotencyKey: A,
			inboxState: e.enum([
				"accepted",
				"claimed",
				"completed",
				"discarded"
			]),
			runId: L,
			runState: e.enum([
				"pending",
				"running",
				"paused",
				"waiting",
				"completed",
				"failed",
				"cancelled",
				"interrupted"
			]).nullable().default(null)
		})).max(1e4).default([])
	})
}), st = e.strictObject({
	operationId: A,
	status: e.literal("applied").default("applied"),
	snapshot: ot
}), ct = e.strictObject({
	operation: e.literal("get_grant"),
	storeIncarnation: k,
	current: ot.nullable().default(null),
	lookupOperationId: A.nullable().default(null),
	mutationReceipt: st.nullable().default(null)
}).superRefine((e, t) => {
	(e.current && e.current.storeIncarnation !== e.storeIncarnation || e.mutationReceipt && (e.mutationReceipt.operationId !== e.lookupOperationId || e.mutationReceipt.snapshot.storeIncarnation !== e.storeIncarnation)) && t.addIssue({
		code: "custom",
		message: "Grant lookup must match the original store and mutation identity"
	});
}), lt = e.discriminatedUnion("operation", [
	e.strictObject({
		operation: e.literal("prepare"),
		contextRef: k,
		contextDigest: j,
		snapshot: ot
	}),
	e.strictObject({
		operation: e.literal("set_grant"),
		mutationReceipt: st
	}),
	e.strictObject({
		operation: e.literal("set_admission"),
		mutationReceipt: st
	}),
	ct
]), ut = e.strictObject({
	protocolVersion: e.literal(E).default(E),
	nodeCommandId: M,
	operation: e.literal("describe"),
	lane: e.literal("control").default("control"),
	operationKey: A,
	authorityId: k,
	nodeId: k,
	bindingRef: k,
	localBindingRef: k,
	expectedDigests: e.strictObject({
		bundle: j,
		contract: j,
		capabilities: j
	}),
	nodeGeneration: P,
	claimLeaseUntil: F,
	authorization: e.strictObject({
		permitKind: e.literal("probe"),
		permit: O(1, 16384)
	}),
	commandDigest: j
});
async function dt(e) {
	return y(Object.fromEntries(Object.entries(ut.parse(e)).filter(([e]) => ![
		"authorization",
		"claimLeaseUntil",
		"commandDigest"
	].includes(e))));
}
async function ft(e) {
	if (e && typeof e == "object" && "operation" in e && e.operation === "describe") {
		let t = ut.parse(e);
		if (await dt(t) !== t.commandDigest) throw Error("node_probe_digest_mismatch");
		return t;
	}
	return $e(e);
}
var pt = e.strictObject({
	bindingRef: k,
	localBindingRef: k,
	agentInstanceId: k,
	storeIncarnation: k,
	capabilities: I,
	capabilitiesDigest: j,
	bundleDigest: j,
	contractDigest: j
}), mt = e.strictObject({
	reportKind: e.literal("probe").default("probe"),
	nodeCommandId: M,
	nodeGeneration: P,
	commandDigest: j,
	resultRevision: P,
	phase: e.enum([
		"described",
		"uncertain",
		"rejected"
	]),
	probeResult: pt.nullable().default(null),
	error: e.strictObject({
		code: k,
		retryable: e.boolean()
	}).nullable().default(null)
}).refine((e) => e.phase === "described" == (e.probeResult !== null), "Described probe requires exact Host result"), ht = (e) => mt.parse(e), gt = e.strictObject({
	status: e.enum([
		"succeeded",
		"failed",
		"cancelled",
		"interrupted"
	]),
	candidate: e.strictObject({
		result: O(0, Ie),
		artifacts: e.array(I).max(1e3).default([])
	}),
	usage: e.strictObject({ totalTokens: N }),
	terminalEvidence: Be,
	completionDigest: j
}).superRefine(We);
async function _t(e) {
	let t = gt.parse(e);
	if (await y(t.candidate) !== t.terminalEvidence.resultDigest) throw Error("candidate_digest_mismatch");
	let { completionDigest: n, ...r } = t;
	if (await y(r) !== n) throw Error("completion_digest_mismatch");
	return t;
}
var vt = e.strictObject({
	nodeCommandId: M,
	nodeGeneration: P,
	commandDigest: j,
	resultRevision: P,
	phase: e.enum([
		"prepared",
		"submitted",
		"running",
		"waiting",
		"terminal",
		"uncertain",
		"rejected",
		"control_applied"
	]),
	receipt: He.nullable().default(null),
	eventBatch: Ge.nullable().default(null),
	materialProof: e.strictObject({
		manifestRef: k,
		digest: j
	}).nullable().default(null),
	error: e.strictObject({
		code: k,
		retryable: e.boolean()
	}).nullable().default(null),
	operationResult: lt.nullable().default(null),
	executionResult: gt.nullable().default(null)
}).superRefine((e, t) => {
	e.phase === "prepared" && e.operationResult?.operation !== "prepare" && t.addIssue({
		code: "custom",
		message: "Prepared report requires durable preparation result"
	}), e.phase === "control_applied" && (!e.operationResult || e.operationResult.operation === "prepare") && t.addIssue({
		code: "custom",
		message: "Control report requires a typed mutation or lookup result"
	}), e.operationResult !== null && !["prepared", "control_applied"].includes(e.phase) && t.addIssue({
		code: "custom",
		message: "Operation result only belongs to preparation or control reports"
	}), e.phase === "terminal" && !e.receipt?.terminalEvidence && t.addIssue({
		code: "custom",
		message: "Terminal report requires canonical evidence"
	}), e.phase === "terminal" && (!e.executionResult || e.executionResult.status !== e.receipt?.nativeStatus || v(e.executionResult.terminalEvidence) !== v(e.receipt?.terminalEvidence ?? null)) && t.addIssue({
		code: "custom",
		message: "Terminal report requires matching canonical completion"
	}), e.phase !== "terminal" && e.executionResult !== null && t.addIssue({
		code: "custom",
		message: "Completion only belongs to terminal report"
	}), We(e, t);
}), yt = (e) => ze.parse(e), bt = (e) => He.parse(e), xt = (e) => Ge.parse(e), St = (e) => z.parse(e), Ct = async (e) => {
	let t = vt.parse(e);
	return t.executionResult && await _t(t.executionResult), t;
}, wt = (e) => lt.parse(e), Tt = {
	text: D,
	length: O,
	identifier: k,
	operationKey: A,
	digest: j,
	commandId: M,
	sequence: N,
	revision: P,
	timestamp: F,
	relativePath: et
}, Et = "workspace/v1", B = [
	"runSummaries",
	"taskSummaries",
	"pendingInteractions",
	"recentMessages",
	"artifactSummaries"
], V = e.string().min(1).max(256), H = e.number().int().min(0).max(2 ** 53 - 1), U = H.min(1), W = e.iso.datetime({ offset: !0 }).max(40).refine((e) => !e.startsWith("0000") && Number.isFinite(Date.parse(e)), "Invalid timestamp"), G = V.nullable(), K = e.string().max(2e3).nullable(), q = e.string().min(1).max(4096).nullable(), Dt = e.enum([
	"planning",
	"running",
	"waiting",
	"needs_attention",
	"awaiting_acceptance",
	"succeeded",
	"failed",
	"cancel_requested",
	"cancelled"
]), Ot = e.enum([
	"draft",
	"ready",
	"blocked",
	"running",
	"awaiting_acceptance",
	"succeeded",
	"failed",
	"cancel_requested",
	"cancelled"
]), J = e.strictObject({
	authorityId: V,
	ownerScopeRef: e.string().min(1).max(512),
	groupId: V
}), kt = J.extend({ origin: e.string().refine((e) => {
	try {
		let t = new URL(e);
		return ["http:", "https:"].includes(t.protocol) && t.origin === e;
	} catch {
		return !1;
	}
}, "Invalid workspace origin") }), At = e.strictObject({
	groupId: V,
	name: e.string().min(1).max(256),
	authorityRef: V,
	tenantId: V,
	ownerSubject: V,
	leaderMemberId: V,
	revision: U,
	status: e.enum(["active", "archived"]),
	createdAt: W,
	updatedAt: W,
	policy: e.strictObject({
		taskAcceptance: e.enum([
			"leader",
			"human",
			"result"
		]),
		peerWake: e.boolean()
	})
}), jt = e.strictObject({
	enqueue: e.boolean(),
	cancel: e.boolean(),
	steer: e.boolean(),
	restore: e.boolean(),
	interaction: e.boolean(),
	leader: e.boolean()
}), Mt = e.strictObject({
	bindingRef: V,
	providerRef: V,
	kind: e.enum([
		"local_build",
		"a2a",
		"cloud"
	]),
	agentId: V,
	capabilities: jt,
	availability: e.strictObject({
		state: e.enum([
			"ready",
			"unchecked",
			"unavailable"
		]),
		code: G,
		reason: K,
		action: e.string().max(256).nullable()
	})
}), Nt = e.strictObject({
	memberId: V,
	groupId: V,
	name: e.string().min(1).max(256),
	role: e.enum(["leader", "member"]),
	responsibility: e.string().max(2e3),
	bindingRef: V,
	binding: Mt,
	sessionId: V,
	revision: U,
	status: e.enum([
		"active",
		"removed",
		"unavailable"
	]),
	executionStatus: e.enum([
		"idle",
		"queued",
		"running",
		"waiting",
		"needs_attention",
		"unavailable"
	]),
	activeRunId: G,
	reason: K
}).refine((e) => e.bindingRef === e.binding.bindingRef, "Binding identity mismatch"), Pt = Nt.safeExtend({
	runMemberId: V,
	teamRunId: V,
	groupRevision: U
}), Ft = e.strictObject({
	state: e.enum([
		"armed",
		"fencing_old",
		"waiting_old_grant",
		"activating",
		"active",
		"blocked"
	]),
	standbyBindingRef: V,
	releaseRef: V,
	takeoverId: G,
	reason: K,
	newLeaderEpoch: U.nullable()
}), Y = e.strictObject({
	teamRunId: V,
	groupId: V,
	revision: U,
	groupRevision: U,
	goalMessageId: V,
	goal: e.string(),
	leaderMemberId: V,
	status: Dt,
	dispatchSuspended: e.boolean(),
	dispatchEpoch: U,
	taskCount: H,
	pendingCount: H,
	createdAt: W,
	updatedAt: W,
	reason: K,
	leaderStandby: Ft.optional()
}), It = e.strictObject({
	taskId: V,
	groupId: V,
	teamRunId: V,
	revision: U,
	title: e.string().min(1).max(2e3),
	ownerMemberId: G,
	dependencies: e.array(V).max(4096),
	status: Ot,
	attemptCount: H,
	reason: K
}).refine((e) => new Set(e.dependencies).size === e.dependencies.length && !e.dependencies.includes(e.taskId), "Invalid task dependencies"), Lt = e.strictObject({
	authorityRef: V,
	groupId: V,
	memberId: V,
	bindingRef: V,
	providerRef: V,
	sessionId: V,
	runId: V,
	itemId: V.optional()
}), Rt = Lt.extend({ interactionId: V }), zt = e.strictObject({
	ref: Rt,
	groupId: V,
	teamRunId: V,
	revision: U,
	title: e.string().max(2e3),
	kind: e.enum(["approval", "input"]),
	status: e.enum([
		"pending",
		"resolving",
		"resolved",
		"cancelled",
		"expired"
	]),
	createdAt: W
}), Bt = e.discriminatedUnion("kind", [e.strictObject({
	kind: e.literal("text"),
	text: e.string()
}), e.strictObject({
	kind: e.literal("attachment"),
	attachmentRef: V,
	mediaType: e.string().min(1).max(200),
	name: e.string().max(4096).optional()
})]), Vt = e.strictObject({
	messageId: V,
	groupId: V,
	teamRunId: G,
	revision: U,
	createdSeq: U,
	createdAt: W,
	senderPrincipal: V,
	senderName: e.string().max(256),
	groupRole: e.enum([
		"owner",
		"leader",
		"member",
		"system"
	]),
	memberId: G,
	parts: e.array(Bt).max(64),
	mentions: e.array(V).max(8),
	intent: e.enum([
		"start_goal",
		"followup",
		"directed",
		"note",
		"result",
		"progress"
	]),
	replyTo: G,
	sourceRefs: e.array(Lt).max(64),
	visibility: e.enum(["public", "internal"])
}), Ht = e.strictObject({
	artifactId: V,
	groupId: V,
	teamRunId: V,
	revision: U,
	name: e.string().max(4096),
	mediaType: e.string().min(1).max(200),
	source: Lt,
	digest: e.string().regex(/^sha256:[0-9a-f]{64}$/).length(71),
	sizeBytes: H,
	state: e.enum([
		"pending",
		"ready",
		"failed"
	])
});
function Ut(e, t) {
	try {
		if (new TextEncoder().encode(v(e)).byteLength <= 2 * 1024 * 1024) return;
	} catch {}
	t.addIssue({
		code: "custom",
		message: "Workspace response exceeds safe JSON / two MiB boundary"
	});
}
function X(e) {
	return JSON.stringify([
		e.authorityId,
		e.ownerScopeRef,
		e.groupId
	]);
}
function Wt(e) {
	return JSON.stringify([e.origin, X(e)]);
}
function Gt(e) {
	let t = e.ref;
	return JSON.stringify([
		t.authorityRef,
		t.groupId,
		t.memberId,
		t.bindingRef,
		t.providerRef,
		t.sessionId,
		t.runId,
		t.interactionId
	]);
}
function Z(e, t) {
	switch (e) {
		case "runSummaries": return t.teamRunId;
		case "taskSummaries": return t.taskId;
		case "pendingInteractions": return Gt(t);
		case "recentMessages": return t.messageId;
		case "artifactSummaries": return t.artifactId;
	}
}
function Kt(e, t) {
	return e.groupId === t.groupId && [
		...e.ref ? [e.ref] : [],
		...e.source ? [e.source] : [],
		...e.sourceRefs ?? []
	].every((e) => e.groupId === t.groupId && e.authorityRef === t.authorityId);
}
function qt(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set();
	for (let o of t) {
		let t = Z(e, o);
		(a.has(t) || !Kt(o, n)) && i.addIssue({
			code: "custom",
			message: "Duplicate row or foreign workspace scope"
		}), a.add(t), e !== "runSummaries" && o.teamRunId !== r && i.addIssue({
			code: "custom",
			message: "Collection belongs to another selected run"
		}), e === "pendingInteractions" && !["pending", "resolving"].includes(o.status) && i.addIssue({
			code: "custom",
			message: "Pending collection contains a terminal interaction"
		});
	}
	e === "recentMessages" && t.some((e, n) => n > 0 && t[n - 1].createdSeq >= e.createdSeq) && i.addIssue({
		code: "custom",
		message: "Message history must be ordered by creation sequence"
	});
}
var Jt = e.strictObject({
	runSummaries: q,
	taskSummaries: q,
	pendingInteractions: q,
	recentMessages: q,
	artifactSummaries: q
}), Yt = e.strictObject({
	apiVersion: e.literal(t),
	viewVersion: e.literal(Et),
	scope: J,
	snapshotId: V,
	watermark: H,
	group: At,
	members: e.array(Nt).max(8),
	runSummaries: e.array(Y).max(20),
	selectedRun: Y.nullable(),
	selectedRunMembers: e.array(Pt).max(8),
	taskSummaries: e.array(It).max(100),
	pendingInteractions: e.array(zt).max(50),
	recentMessages: e.array(Vt).max(50),
	artifactSummaries: e.array(Ht).max(50),
	cursors: Jt
}).superRefine((e, t) => {
	let n = (e) => t.addIssue({
		code: "custom",
		message: e
	});
	(e.group.groupId !== e.scope.groupId || e.group.authorityRef !== e.scope.authorityId) && n("Group scope mismatch"), (new Set(e.members.map((e) => e.memberId)).size !== e.members.length || e.members.some((t) => !Kt(t, e.scope))) && n("Invalid group roster"), e.members.some((t) => t.memberId === e.group.leaderMemberId) || n("Missing group Leader");
	let r = e.selectedRun?.teamRunId ?? null;
	for (let n of B) qt(n, e[n], e.scope, r, t);
	e.selectedRun && (!Kt(e.selectedRun, e.scope) || !e.selectedRunMembers.some((t) => t.memberId === e.selectedRun.leaderMemberId)) && n("Invalid selected run or frozen Leader roster");
	let i = e.runSummaries.find((e) => e.teamRunId === r);
	i && v(i) !== v(e.selectedRun) && n("Selected run and summary differ at snapshot watermark"), (new Set(e.selectedRunMembers.map((e) => e.runMemberId)).size !== e.selectedRunMembers.length || new Set(e.selectedRunMembers.map((e) => e.memberId)).size !== e.selectedRunMembers.length || e.selectedRunMembers.some((t) => !Kt(t, e.scope) || t.teamRunId !== r || t.groupRevision !== e.selectedRun?.groupRevision)) && n("Invalid frozen run roster"), r === null && (e.selectedRunMembers.length || B.slice(1).some((t) => e[t].length || e.cursors[t] !== null)) && n("Unselected view cannot contain run-specific rows"), e.recentMessages.some((t) => t.createdSeq > e.watermark) && n("Message creation is newer than snapshot watermark"), Ut(e, t);
}), Xt = {
	apiVersion: e.literal(t),
	viewVersion: e.literal(Et),
	scope: J,
	snapshotId: V,
	watermark: H,
	teamRunId: G,
	cursor: e.string().min(1).max(4096),
	nextCursor: q
}, Zt = e.discriminatedUnion("collection", [
	e.strictObject({
		...Xt,
		collection: e.literal("runSummaries"),
		items: e.array(Y).max(100)
	}),
	e.strictObject({
		...Xt,
		collection: e.literal("taskSummaries"),
		items: e.array(It).max(100)
	}),
	e.strictObject({
		...Xt,
		collection: e.literal("pendingInteractions"),
		items: e.array(zt).max(100)
	}),
	e.strictObject({
		...Xt,
		collection: e.literal("recentMessages"),
		items: e.array(Vt).max(100)
	}),
	e.strictObject({
		...Xt,
		collection: e.literal("artifactSummaries"),
		items: e.array(Ht).max(100)
	})
]).superRefine((e, t) => {
	qt(e.collection, e.items, e.scope, e.teamRunId, t), (e.collection === "runSummaries" ? e.teamRunId !== null : e.teamRunId === null) && t.addIssue({
		code: "custom",
		message: "Invalid page run scope"
	}), e.cursor === e.nextCursor && t.addIssue({
		code: "custom",
		message: "Page cursor did not advance"
	}), e.collection === "recentMessages" && e.items.some((t) => t.createdSeq > e.watermark) && t.addIssue({
		code: "custom",
		message: "Message creation exceeds snapshot watermark"
	}), Ut(e, t);
}), Qt = e.strictObject({
	collection: e.enum(B),
	snapshotId: V,
	watermark: H,
	teamRunId: G,
	cursor: e.string().min(1).max(4096),
	limit: e.number().int().min(1).max(100).optional()
}).refine((e) => e.collection === "runSummaries" ? e.teamRunId === null : e.teamRunId !== null, "Invalid collection run scope"), $t = e.discriminatedUnion("kind", [
	e.strictObject({
		kind: e.literal("group"),
		group: At
	}),
	e.strictObject({
		kind: e.literal("member"),
		member: Nt
	}),
	e.strictObject({
		kind: e.literal("run_member"),
		runMember: Pt
	}),
	e.strictObject({
		kind: e.literal("run"),
		run: Y
	}),
	e.strictObject({
		kind: e.literal("task"),
		task: It
	}),
	e.strictObject({
		kind: e.literal("interaction"),
		interaction: zt
	}),
	e.strictObject({
		kind: e.literal("message"),
		message: Vt
	}),
	e.strictObject({
		kind: e.literal("artifact"),
		artifact: Ht
	}),
	e.strictObject({
		kind: e.literal("invalidate"),
		teamRunId: G,
		collections: e.array(e.enum(B)).min(1).max(5)
	})
]), en = e.strictObject({
	apiVersion: e.literal(t),
	viewVersion: e.literal(Et),
	scope: J,
	eventId: V,
	groupSeq: U,
	type: e.literal("workspace.delta"),
	createdAt: W,
	changes: e.array($t).max(32)
}).superRefine((e, t) => {
	for (let n of e.changes) n.kind !== "invalidate" && ((!Kt(n.kind === "group" ? n.group : n.kind === "member" ? n.member : n.kind === "run_member" ? n.runMember : n.kind === "run" ? n.run : n.kind === "task" ? n.task : n.kind === "interaction" ? n.interaction : n.kind === "message" ? n.message : n.artifact, e.scope) || n.kind === "group" && n.group.authorityRef !== e.scope.authorityId) && t.addIssue({
		code: "custom",
		message: "Foreign row in workspace delta"
	}), n.kind === "message" && n.message.createdSeq > e.groupSeq && t.addIssue({
		code: "custom",
		message: "Future message in workspace event"
	}));
	Ut(e, t);
});
function tn(e, t) {
	try {
		return e.parse(t);
	} catch {
		throw new m("workspace_contract_mismatch", "团队工作区数据格式不兼容，需要重新读取。");
	}
}
function nn(e) {
	return tn(Yt, e);
}
function rn(e) {
	return tn(Zt, e);
}
function an(e) {
	return tn(en, e);
}
//#endregion
//#region src/core/teams/workspaceReducer.ts
var Q = (e) => {
	throw new m("reset_required", e);
}, on = class {
	value;
	baseWatermark;
	versions = /* @__PURE__ */ new Map();
	seenSeq = /* @__PURE__ */ new Map();
	seenIds = /* @__PURE__ */ new Map();
	dirty = /* @__PURE__ */ new Set();
	dirtyRuns = /* @__PURE__ */ new Set();
	usedCursors = /* @__PURE__ */ new Map();
	maxRows;
	constructor(e, t = {}) {
		if (this.value = nn(e), this.baseWatermark = this.value.watermark, this.maxRows = t.maxRowsPerCollection ?? 5e3, !Number.isSafeInteger(this.maxRows) || this.maxRows < 100 || this.maxRows > 5e4) throw new m("invalid_workspace_limit", "工作区缓存上限无效。");
		this.seedVersions();
	}
	snapshot() {
		return structuredClone(this.value);
	}
	watermark() {
		return this.value.watermark;
	}
	snapshotId() {
		return this.value.snapshotId;
	}
	projection() {
		return {
			snapshot: this.snapshot(),
			snapshotWatermark: this.baseWatermark,
			dirtyCollections: [...this.dirty],
			dirtyRunIds: [...this.dirtyRuns]
		};
	}
	seedVersions() {
		this.versions.clear();
		let e = (e, t) => this.versions.set(e, {
			revision: t.revision,
			digest: v(t),
			domainDigest: this.domainDigest(e, t),
			observedSeq: this.baseWatermark
		});
		e("group", this.value.group), this.value.members.forEach((t) => e(`members:${t.memberId}`, t)), this.value.selectedRunMembers.forEach((t) => e(`runMembers:${t.runMemberId}`, t));
		for (let t of B) for (let n of this.value[t]) e(`${t}:${Z(t, n)}`, n);
		this.value.selectedRun && e(`runSummaries:${this.value.selectedRun.teamRunId}`, this.value.selectedRun);
	}
	domainDigest(e, t) {
		if (!e.startsWith("runSummaries:")) return v(t);
		let n = { ...t };
		return delete n.taskCount, delete n.pendingCount, delete n.leaderStandby, v(n);
	}
	accept(e, t, n, r) {
		let i = e.get(t);
		if (i && (i.revision > n.revision || i.observedSeq > r)) return !1;
		let a = v(n), o = this.domainDigest(t, n);
		if (i?.revision === n.revision) {
			if (i.digest === a) return !1;
			(r <= i.observedSeq || i.domainDigest !== o) && Q("同一对象版本出现不同内容，需要重新读取。");
		}
		return e.set(t, {
			revision: n.revision,
			digest: a,
			domainDigest: o,
			observedSeq: r
		}), !0;
	}
	upsert(e, t, n) {
		let r = e.findIndex((e) => n(e) === n(t));
		return r < 0 && e.length >= this.maxRows && Q("工作区缓存已达到上限，需要重新读取分页视图。"), r < 0 ? [...e, t] : e.map((e, n) => n === r ? t : e);
	}
	mergeRow(e, t, n, r, i) {
		let a = Z(n, r);
		if (!this.accept(t, `${n}:${a}`, r, i)) {
			n === "runSummaries" && e.selectedRun?.teamRunId === a && !e.runSummaries.some((e) => e.teamRunId === a) && (e.runSummaries = this.upsert(e.runSummaries, e.selectedRun, (e) => e.teamRunId));
			return;
		}
		if (n === "pendingInteractions" && !["pending", "resolving"].includes(r.status)) {
			e.pendingInteractions = e.pendingInteractions.filter((e) => Z(n, e) !== a);
			return;
		}
		let o = this.upsert(e[n], r, (e) => Z(n, e));
		n === "recentMessages" && o.sort((e, t) => e.createdSeq - t.createdSeq || Z(n, e).localeCompare(Z(n, t))), Object.assign(e, { [n]: o });
	}
	replace(e) {
		let t = nn(e);
		if (X(t.scope) !== X(this.value.scope) || t.selectedRun?.teamRunId !== this.value.selectedRun?.teamRunId) throw new m("scope_mismatch", "刷新快照改变了工作区身份或所选协作任务。");
		return t.watermark < this.value.watermark || t.group.revision < this.value.group.revision || t.selectedRun && this.value.selectedRun && t.selectedRun.revision < this.value.selectedRun.revision ? !1 : (this.value = t, this.baseWatermark = t.watermark, this.seenSeq.clear(), this.seenIds.clear(), this.dirty.clear(), this.dirtyRuns.clear(), this.usedCursors.clear(), this.seedVersions(), !0);
	}
	apply(e) {
		let t = an(e);
		if (X(t.scope) !== X(this.value.scope)) throw new m("scope_mismatch", "事件不属于当前授权工作区。");
		let n = this.seenSeq.get(t.groupSeq);
		n && n !== t.eventId && Q("同一事件水位出现不同事件身份。");
		let r = this.seenIds.get(t.eventId);
		if (r !== void 0 && r !== t.groupSeq && Q("同一事件身份被用于不同水位。"), t.groupSeq <= this.value.watermark) return !1;
		t.groupSeq !== this.value.watermark + 1 && Q("团队事件存在缺口，需要重新读取工作区。");
		let i = { ...this.value }, a = new Map(this.versions), o = new Set(this.dirty), s = new Set(this.dirtyRuns), c = /* @__PURE__ */ new Set(), l = i.selectedRun?.teamRunId ?? null;
		for (let e of t.changes) {
			if (e.kind === "invalidate") {
				e.teamRunId === l || e.teamRunId === null ? e.collections.forEach((e) => o.add(e)) : s.add(e.teamRunId);
				continue;
			}
			if (e.kind === "group") {
				if (e.group.tenantId !== i.group.tenantId || e.group.ownerSubject !== i.group.ownerSubject) throw new m("scope_mismatch", "群事件改变了原始租户或主体。");
				this.accept(a, "group", e.group, t.groupSeq) && (i.group = e.group);
			} else if (e.kind === "member") this.accept(a, `members:${e.member.memberId}`, e.member, t.groupSeq) && (i.members = this.upsert(i.members, e.member, (e) => e.memberId));
			else if (e.kind === "run_member") {
				if (e.runMember.teamRunId !== l) {
					s.add(e.runMember.teamRunId);
					continue;
				}
				this.accept(a, `runMembers:${e.runMember.runMemberId}`, e.runMember, t.groupSeq) && (i.selectedRunMembers = this.upsert(i.selectedRunMembers, e.runMember, (e) => e.runMemberId));
			} else if (e.kind === "run") {
				let n = e.run;
				this.accept(a, `runSummaries:${n.teamRunId}`, n, t.groupSeq) && (i.runSummaries = this.upsert(i.runSummaries, n, (e) => e.teamRunId), n.teamRunId === l && (i.selectedRun = n)), c.add(n.teamRunId);
			} else {
				let [n, r] = e.kind === "task" ? ["taskSummaries", e.task] : e.kind === "interaction" ? ["pendingInteractions", e.interaction] : e.kind === "message" ? ["recentMessages", e.message] : ["artifactSummaries", e.artifact];
				if (r.teamRunId !== l) {
					r.teamRunId && s.add(r.teamRunId);
					continue;
				}
				this.mergeRow(i, a, n, r, t.groupSeq), (n === "taskSummaries" || n === "pendingInteractions") && (o.add("runSummaries"), r.teamRunId && s.add(r.teamRunId));
			}
		}
		if (c.forEach((e) => s.delete(e)), (!i.members.some((e) => e.memberId === i.group.leaderMemberId) || i.selectedRun && (!i.selectedRunMembers.some((e) => e.memberId === i.selectedRun.leaderMemberId) || i.selectedRunMembers.some((e) => e.groupRevision !== i.selectedRun.groupRevision))) && Q("Leader 变更缺少匹配成员投影。"), i.watermark = t.groupSeq, this.value = i, this.versions = a, this.dirty = o, this.dirtyRuns = s, this.seenSeq.set(t.groupSeq, t.eventId), this.seenIds.set(t.eventId, t.groupSeq), this.seenSeq.size > 1e4) {
			let e = this.seenSeq.entries().next().value;
			this.seenSeq.delete(e[0]), this.seenIds.delete(e[1]);
		}
		return !0;
	}
	pageRequest(e, t) {
		let n = this.value.cursors[e];
		if (n === null) return null;
		let r = e === "runSummaries" ? null : this.value.selectedRun?.teamRunId ?? null;
		if (e !== "runSummaries" && r === null) throw new m("scope_mismatch", "未选择任务，无法读取任务分页。");
		return {
			collection: e,
			snapshotId: this.value.snapshotId,
			watermark: this.baseWatermark,
			teamRunId: r,
			cursor: n,
			...t === void 0 ? {} : { limit: t }
		};
	}
	mergePage(e, t) {
		let n = rn(t);
		if (X(n.scope) !== X(this.value.scope)) throw new m("scope_mismatch", "分页返回了其他授权工作区。");
		let r = this.pageRequest(e.collection, e.limit);
		if (!r || e.snapshotId !== r.snapshotId || e.watermark !== r.watermark || e.cursor !== r.cursor || e.teamRunId !== r.teamRunId || n.snapshotId !== r.snapshotId || n.watermark !== r.watermark || n.cursor !== r.cursor || n.teamRunId !== r.teamRunId || n.collection !== r.collection) throw new m("workspace_page_mismatch", "分页与当前快照或任务不一致，需要重新读取。");
		if (n.nextCursor !== null && this.usedCursors.get(n.collection)?.has(n.nextCursor)) throw new m("workspace_page_mismatch", "分页游标出现循环，需要重新读取。");
		let i = {
			...this.value,
			cursors: { ...this.value.cursors }
		}, a = new Map(this.versions);
		for (let e of n.items) this.mergeRow(i, a, n.collection, e, n.watermark);
		i.cursors[n.collection] = n.nextCursor, this.value = i, this.versions = a;
		let o = this.usedCursors.get(n.collection) ?? /* @__PURE__ */ new Set();
		return o.add(n.cursor), this.usedCursors.set(n.collection, o), !0;
	}
}, sn = new Set([
	"reset_required",
	"snapshot_expired",
	"workspace_page_mismatch",
	"workspace_contract_mismatch"
]), cn = (e, t) => new Promise((n) => {
	if (t.aborted) {
		n();
		return;
	}
	let r = () => {
		clearTimeout(i), t.removeEventListener("abort", r), n();
	}, i = setTimeout(r, e);
	t.addEventListener("abort", r, { once: !0 });
}), ln = class {
	scope;
	cacheKey;
	transport;
	maxReconnects;
	retryDelay;
	value;
	reducer;
	listeners = /* @__PURE__ */ new Set();
	drafts = /* @__PURE__ */ new Map();
	pendingPages = /* @__PURE__ */ new Map();
	controller;
	streamController;
	generation = 0;
	disposed = !1;
	resyncRequested = !1;
	observingGeneration;
	constructor(e, t, n = {}) {
		if (this.scope = Object.freeze(kt.parse(e)), this.cacheKey = Wt(this.scope), this.transport = t, this.maxReconnects = n.maxReconnects ?? 6, !Number.isSafeInteger(this.maxReconnects) || this.maxReconnects < 0 || this.maxReconnects > 32) throw new m("invalid_reconnect_limit", "重连次数必须在 0–32 之间。");
		this.retryDelay = n.retryDelayMs ?? ((e) => Math.min(500 * 2 ** e, 1e4)), this.value = {
			scope: this.scope,
			selectedRunId: null,
			projection: null,
			connection: "closed",
			draft: "",
			errorCode: null,
			loadingPages: []
		};
	}
	getSnapshot = () => this.value;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	update(e) {
		this.disposed || (this.value = {
			...this.value,
			...e
		}, this.listeners.forEach((e) => e()));
	}
	setDraft(e) {
		this.drafts.set(this.value.selectedRunId ?? "", e), this.update({ draft: e });
	}
	acknowledgeDraft(e, t) {
		if (this.disposed) return !1;
		let n = e ?? "", r = this.value.selectedRunId === e ? this.value.draft : this.drafts.get(n);
		return r === void 0 || r.trim() !== t ? !1 : (this.drafts.set(n, ""), this.value.selectedRunId === e && this.update({ draft: "" }), !0);
	}
	disconnect() {
		this.generation++, this.controller?.abort(), this.streamController?.abort(), this.controller = void 0, this.observingGeneration = void 0, this.pendingPages.clear(), this.update({
			connection: "closed",
			loadingPages: []
		});
	}
	dispose() {
		this.disconnect(), this.reducer = void 0, this.drafts.clear(), this.update({
			projection: null,
			draft: "",
			selectedRunId: null,
			errorCode: null
		}), this.disposed = !0, this.listeners.clear();
	}
	refresh() {
		if (!this.disposed) {
			if (this.observingGeneration === void 0) {
				this.observe(this.value.selectedRunId ?? void 0);
				return;
			}
			this.resyncRequested = !0, this.update({ connection: "reconnecting" }), this.streamController?.abort();
		}
	}
	async observe(e) {
		if (this.disposed) throw new m("scope_disposed", "工作区观察已关闭。");
		let t = this.value.selectedRunId;
		this.disconnect();
		let n = ++this.generation;
		this.observingGeneration = n;
		let r = new AbortController();
		this.controller = r;
		let i = () => !this.disposed && n === this.generation && !r.signal.aborted;
		e !== t && (this.reducer = void 0), this.resyncRequested = !1, this.update({
			selectedRunId: e ?? null,
			projection: this.reducer?.projection() ?? null,
			draft: this.drafts.get(e ?? "") ?? "",
			connection: "connecting",
			errorCode: null
		});
		let a = e, o = !0, s = 0;
		try {
			for (; i();) try {
				if (o) {
					this.resyncRequested = !1, this.pendingPages.clear(), this.update({ loadingPages: [] });
					let e = await this.transport.read(this.scope, {
						teamRunId: a,
						signal: r.signal
					});
					if (!i()) return;
					if (X(e.scope) !== X(this.scope) || a !== void 0 && e.selectedRun?.teamRunId !== a) throw new m("scope_mismatch", "工作区快照与当前身份或所选任务不一致。");
					if (this.reducer) {
						if (!this.reducer.replace(e)) throw new m("reset_required", "工作区快照早于当前事件水位。");
					} else this.reducer = new on(e);
					a = e.selectedRun?.teamRunId;
					let t = a ?? null, n = this.value.selectedRunId === t ? this.value.draft : this.drafts.get(t ?? "") ?? this.value.draft;
					this.drafts.set(t ?? "", n), this.update({
						selectedRunId: t,
						projection: this.reducer.projection(),
						draft: n
					}), o = !1, this.resyncRequested = !1;
				}
				let e = this.reducer, t = new AbortController();
				this.streamController = t;
				let n = () => t.abort();
				r.signal.addEventListener("abort", n, { once: !0 }), this.update({
					connection: "connected",
					errorCode: null
				});
				try {
					await this.transport.subscribe(this.scope, e.watermark(), t.signal, (n) => {
						if (!(!i() || t.signal.aborted || this.reducer !== e) && e.apply(n)) {
							s = 0;
							let t = e.projection();
							this.update({ projection: t }), t.dirtyCollections.length && this.refresh();
						}
					});
				} finally {
					r.signal.removeEventListener("abort", n), t.abort();
				}
				if (!i()) return;
				if (this.resyncRequested) {
					o = !0;
					continue;
				}
				throw new m("stream_ended", "工作区事件连接已断开。");
			} catch (e) {
				if (!i()) return;
				if (this.resyncRequested) {
					o = !0;
					continue;
				}
				let t = e instanceof m ? e : new m("network_error", "工作区暂时无法连接。");
				if (t.code === "scope_mismatch" || [
					401,
					403,
					404
				].includes(t.status ?? 0) || (sn.has(t.code) && (o = !0), s++ >= this.maxReconnects)) throw t;
				this.update({
					connection: "reconnecting",
					errorCode: t.code
				});
				let n = this.retryDelay(s - 1);
				if (!Number.isFinite(n) || n < 0 || n > 6e4) throw new m("invalid_retry_delay", "工作区重试间隔无效。");
				await cn(n, r.signal);
			}
		} catch (e) {
			if (!i()) return;
			let t = e instanceof m ? e : new m("network_error", "工作区无法连接。");
			(t.code === "scope_mismatch" || [
				401,
				403,
				404
			].includes(t.status ?? 0)) && (this.reducer = void 0, this.drafts.clear(), this.update({
				projection: null,
				draft: ""
			})), this.update({
				connection: "offline",
				errorCode: t.code
			});
		} finally {
			this.observingGeneration === n && (this.observingGeneration = void 0);
		}
	}
	loadMore(e, t) {
		if (this.disposed) return Promise.reject(new m("scope_disposed", "工作区观察已关闭。"));
		let n = this.pendingPages.get(e);
		if (n) return n;
		let r = this.reducer, i = this.controller, a = this.generation;
		if (!r || !i || i.signal.aborted) return Promise.reject(new m("workspace_not_ready", "工作区尚未就绪。"));
		let o = r.pageRequest(e, t);
		if (!o) return Promise.resolve(!1);
		let s = () => !this.disposed && a === this.generation && !i.signal.aborted && r === this.reducer, c = () => s() && r.snapshotId() === o.snapshotId, l;
		return l = (async () => {
			this.update({ loadingPages: [...new Set([...this.value.loadingPages, e])] });
			try {
				let e = await this.transport.page(this.scope, o, i.signal);
				return c() ? (r.mergePage(o, e), this.update({ projection: r.projection() }), !0) : !1;
			} catch (e) {
				if (!c()) return !1;
				let t = e instanceof m ? e : new m("network_error", "分页加载失败。");
				throw t.code === "scope_mismatch" || [
					401,
					403,
					404
				].includes(t.status ?? 0) ? (this.disconnect(), this.reducer = void 0, this.drafts.clear(), this.update({
					projection: null,
					draft: "",
					connection: "offline",
					errorCode: t.code
				}), t) : (this.update({ errorCode: t.code }), sn.has(t.code) && this.refresh(), t);
			} finally {
				s() && this.pendingPages.get(e) === l && (this.pendingPages.delete(e), this.update({ loadingPages: this.value.loadingPages.filter((t) => t !== e) }));
			}
		})(), this.pendingPages.set(e, l), l;
	}
}, un = class {
	outbox;
	drainer;
	state = {
		operations: [],
		recovering: !1,
		errorCode: null
	};
	listeners = /* @__PURE__ */ new Set();
	work;
	disposed = !1;
	writable = !0;
	recoveryController;
	controller = new AbortController();
	constructor(e, t) {
		this.outbox = new je(e), this.drainer = new Me(this.outbox, t);
	}
	getSnapshot = () => this.state;
	subscribe = (e) => (this.listeners.add(e), () => {
		this.listeners.delete(e);
	});
	update(e) {
		this.disposed || (this.state = {
			...this.state,
			...e
		}, this.listeners.forEach((e) => e()));
	}
	async refresh() {
		this.disposed || this.update({ operations: await this.outbox.list({ limit: 1e4 }) });
	}
	setWritable(e) {
		this.writable = e, e || this.recoveryController?.abort();
	}
	async enqueue(e) {
		if (this.disposed || !this.writable) throw new b("cloud_read_only");
		let t = await this.outbox.enqueue(e, { reuseUnresolved: !0 });
		return await this.refresh(), t;
	}
	async recover() {
		if (this.disposed) return;
		if (this.work) return this.work;
		if (!this.writable) {
			await this.refresh();
			return;
		}
		this.update({
			recovering: !0,
			errorCode: null
		});
		let e = new AbortController();
		this.recoveryController = e;
		let t = () => e.abort();
		return this.controller.signal.addEventListener("abort", t, { once: !0 }), this.work = (async () => {
			try {
				await this.drainer.drain({
					signal: e.signal,
					maxOperations: 50,
					maxDurationMs: 3e4
				}), await this.refresh();
			} catch (e) {
				this.update({ errorCode: e instanceof b ? e.code : "outbox_unavailable" });
			} finally {
				this.controller.signal.removeEventListener("abort", t), this.recoveryController = void 0, this.update({ recovering: !1 }), this.work = void 0;
			}
		})(), this.work;
	}
	async submit(e) {
		let t = await this.enqueue(e);
		return await this.recover(), await this.outbox.get(t.operationId) ?? t;
	}
	dispose() {
		this.disposed = !0, this.controller.abort(), this.drainer.deactivate(), this.listeners.clear(), this.outbox.close().catch(() => void 0);
	}
}, $ = {
	fileBytes: 20 * 1024 * 1024,
	totalBytes: 64 * 1024 * 1024,
	files: 4096,
	manifestBytes: 2 * 1024 * 1024
}, dn = e.string().regex(/^sha256:[0-9a-f]{64}$/), fn = e.strictObject({
	materialId: e.string().regex(/^tm_[0-9a-f]{64}$/),
	manifestDigest: dn,
	state: e.enum([
		"pending",
		"ready",
		"expired"
	]),
	sizeBytes: e.number().int().min(0).max($.totalBytes),
	manifest: z
}), pn = e.strictObject({
	materialId: e.string().regex(/^tm_[0-9a-f]{64}$/),
	state: e.literal("pending"),
	missingBlobs: e.array(dn).max($.files)
}), mn = e.strictObject({
	digest: dn,
	sizeBytes: e.number().int().min(0).max($.fileBytes),
	state: e.literal("ready")
});
async function hn(e, t, n) {
	let r = fn.parse(e), i = await at(r.manifest);
	if (i !== r.manifestDigest || r.materialId !== `tm_${(await y([t.authorityId, i])).slice(7)}` || r.sizeBytes !== r.manifest.entries.reduce((e, t) => e + t.sizeBytes, 0) || n && i !== await at(n)) throw new m("material_identity_conflict", "材料回执与当前身份或所选文件不一致。");
	return r;
}
var gn = () => ({
	state: "idle",
	files: [],
	completed: 0,
	material: null,
	error: ""
}), _n = (e) => [
	"hashing",
	"creating",
	"uploading",
	"verifying"
].includes(e), vn = () => new DOMException("Aborted", "AbortError"), yn = class {
	snapshot = gn();
	selection = null;
	listeners = /* @__PURE__ */ new Set();
	port;
	scope;
	constructor(e, t) {
		this.port = e, this.scope = t;
	}
	getSnapshot = () => this.snapshot;
	subscribe = (e) => (this.listeners.add(e), () => {
		this.listeners.delete(e);
	});
	update(e) {
		this.snapshot = {
			...this.snapshot,
			...e
		};
		for (let e of this.listeners) e();
	}
	clear() {
		let e = this.selection;
		this.selection = null, e?.controller?.abort(), this.snapshot = gn();
		for (let e of this.listeners) e();
	}
	dispose() {
		this.clear(), this.listeners.clear();
	}
	cancel() {
		this.selection?.controller?.abort(), this.selection && _n(this.snapshot.state) && this.update({
			state: "cancelled",
			material: null,
			error: "上传已取消。重试或移除材料后再开始协作。"
		});
	}
	async select(e) {
		this.clear();
		let t = Array.from(e);
		if (!t.length) return;
		let n = {
			files: t,
			createKey: `material-create:${crypto.randomUUID()}`,
			finalizeKey: `material-finalize:${crypto.randomUUID()}`,
			controller: null
		};
		this.selection = n, this.update({ files: t.map((e) => ({
			name: e.name,
			size: e.size
		})) }), await this.run(n);
	}
	async retry() {
		this.selection && !_n(this.snapshot.state) && await this.run(this.selection);
	}
	async run(t) {
		let n = new AbortController();
		t.controller = n;
		let r = () => {
			if (n.signal.aborted || this.selection !== t || t.controller !== n) throw vn();
		}, i = setTimeout(() => n.abort(), 10 * 6e4);
		this.update({
			state: "hashing",
			completed: 0,
			error: "",
			material: null
		});
		try {
			if (t.files.length > $.files) throw Error("最多选择 4096 个文件。");
			if (t.files.some((e) => e.size > $.fileBytes)) throw Error("单个文件不能超过 20 MiB。");
			if (t.files.reduce((e, t) => e + t.size, 0) > $.totalBytes) throw Error("材料总大小不能超过 64 MiB。");
			let e = t.files.map((e) => ({
				path: e.name,
				sizeBytes: e.size,
				mediaType: e.type || "application/octet-stream",
				digest: `sha256:${"0".repeat(64)}`
			}));
			z.parse({
				kind: "files",
				entries: e
			});
			for (let n = 0; n < t.files.length; n++) {
				r();
				let i = await t.files[n].arrayBuffer();
				r();
				let a = await crypto.subtle.digest("SHA-256", i);
				r(), e[n].digest = `sha256:${Array.from(new Uint8Array(a), (e) => e.toString(16).padStart(2, "0")).join("")}`, this.update({ completed: n + 1 });
			}
			let i = it.parse({
				kind: "files",
				entries: e,
				idempotencyKey: t.createKey
			});
			if (new TextEncoder().encode(v(i)).byteLength > $.manifestBytes) throw Error("文件清单超过 2 MiB，请减少文件数量或缩短文件名。");
			let a = z.parse({
				kind: i.kind,
				entries: i.entries
			});
			this.update({
				state: "creating",
				completed: 0
			});
			let o = await this.port.createMaterial(this.scope, i, n.signal);
			if (r(), o = await hn(o, this.scope, a), r(), o.state === "expired") throw Error("材料已过期，请重新选择文件。");
			if (o.state !== "ready") {
				let i = /* @__PURE__ */ new Set();
				for (let a = 0; a < e.length; a++) r(), this.update({
					state: "uploading",
					completed: a
				}), i.has(e[a].digest) || (await this.port.uploadMaterialBlob(this.scope, o, e[a], t.files[a], n.signal), r(), i.add(e[a].digest)), this.update({ completed: a + 1 });
				this.update({ state: "verifying" }), o = await this.port.finalizeMaterial(this.scope, o, t.finalizeKey, n.signal), r(), o = await hn(o, this.scope, a), r();
			}
			if (o.state !== "ready") throw Error("服务端尚未验证全部文件，请重试原上传。");
			this.update({
				state: "ready",
				material: o
			});
		} catch (r) {
			if (this.selection !== t || t.controller !== n) return;
			n.signal.aborted ? this.update({
				state: "cancelled",
				material: null,
				error: "上传已取消或超时。重试或移除材料后再开始协作。"
			}) : this.update({
				state: "failed",
				material: null,
				error: r instanceof m ? `材料上传未完成（${r.code}），请重试原上传。` : r instanceof e.ZodError ? "文件名、类型或清单无效；同名文件不能同时上传。" : r instanceof Error ? r.message : "材料上传失败，请重试。"
			});
		} finally {
			clearTimeout(i), t.controller === n && (t.controller = null);
		}
	}
};
//#endregion
export { Re as $, Pt as A, pe as At, wt as B, ce as Bt, zt as C, xe as Ct, Qt as D, ge as Dt, Vt as E, _e as Et, Ne as F, fe as Ft, $e as G, re as Gt, St as H, s as Ht, E as I, ue as It, Ue as J, t as Jt, ft as K, oe as Kt, xt as L, u as Lt, X as M, h as Mt, J as N, se as Nt, Zt as O, m as Ot, It as P, de as Pt, gt as Q, yt as R, le as Rt, Gt as S, Ce as St, Nt as T, ve as Tt, ht as U, p as Ut, bt as V, d as Vt, Ct as W, f as Wt, ot as X, Tt as Y, ze as Z, $t as _, b as _t, hn as a, at, en as b, we as bt, on as c, Ze as ct, nn as d, mt as dt, st as et, an as f, pt as ft, Mt as g, je as gt, Ht as h, Me as ht, _n as i, tt as it, Y as j, me as jt, Z as k, te as kt, Et as l, ut as lt, Yt as m, Be as mt, mn as n, He as nt, un as o, z as ot, rn as p, vt as pt, Ge as q, he as qt, pn as r, it as rt, ln as s, Qe as st, yn as t, lt as tt, B as u, dt as ut, Wt as v, Se as vt, Ft as w, be as wt, At as x, y as xt, kt as y, v as yt, _t as z, c as zt };
