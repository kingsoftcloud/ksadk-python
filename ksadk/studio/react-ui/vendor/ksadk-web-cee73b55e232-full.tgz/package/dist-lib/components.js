import { g as e } from "./a2ui-B1x5yNaJ.js";
import { a as t, i as n, n as r, o as i, r as a, t as o } from "./ConnectedComposer-BkZNPn4n.js";
import { a as s, i as c, t as l } from "./AttachmentPreview-DxmVrUYz.js";
import { t as u } from "./MenuChip-CT8v3QtQ.js";
import { r as d, t as f } from "./MessageMarkdown-Lj01l-_B.js";
import { i as p, n as m, o as h, s as g, t as _ } from "./ConnectedMessageList-DSvFUAhq.js";
import { a as v, d as y, i as b, o as x, t as S } from "./WorkspacePanelContainer-DLUNPZLb.js";
import { t as C } from "./NativeTerminalPanel-beSt6mii.js";
import { t as w } from "./CodeBlock-DMIf4h33.js";
import { t as T } from "./MermaidBlock-H_0qzQDf.js";
import { t as E } from "./MathMessageMarkdown-BY98Kkdm.js";
import { n as D, t as O } from "./FilePreviewModal-D6yboVdb.js";
import k, { useEffect as A } from "react";
import { X as j } from "lucide-react";
import { jsx as M, jsxs as N } from "react/jsx-runtime";
//#region src/components/ToastContainer.tsx
function P() {
	let t = e((e) => e.toasts), n = e((e) => e.dismissToast);
	return A(() => {
		if (!t.length) return;
		let e = t[0], r = 3e3 - (Date.now() - e.createdAt);
		if (r <= 0) {
			n(e.id);
			return;
		}
		let i = setTimeout(() => n(e.id), r);
		return () => clearTimeout(i);
	}, [t, n]), t.length ? /* @__PURE__ */ M("div", {
		className: "fixed bottom-4 right-4 z-50 flex flex-col gap-2",
		children: t.map((e) => /* @__PURE__ */ N("div", {
			className: `flex items-center gap-2 rounded-lg px-4 py-3 text-sm shadow-lg transition-all ${e.variant === "error" ? "bg-red-600 text-white" : "bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900"}`,
			children: [/* @__PURE__ */ M("span", {
				className: "flex-1",
				children: e.message
			}), /* @__PURE__ */ M("button", {
				onClick: () => n(e.id),
				className: "shrink-0 rounded p-0.5 opacity-70 hover:opacity-100",
				children: /* @__PURE__ */ M(j, { size: 14 })
			})]
		}, e.id))
	}) : null;
}
//#endregion
//#region src/utils/chunk-load-error.ts
function F(e) {
	let t = e instanceof Error ? e.message : String(e || "");
	return /loading chunk|chunkloaderror|failed to fetch dynamically imported module|error loading dynamically imported module|importing a module script failed/i.test(t);
}
//#endregion
//#region src/components/ErrorBoundary.tsx
var I = "agentengine-ui:chunk-reload-attempted", L = class extends k.Component {
	constructor(e) {
		super(e), this.state = {
			hasError: !1,
			error: null
		};
	}
	static getDerivedStateFromError(e) {
		return {
			hasError: !0,
			error: e
		};
	}
	componentDidCatch(e, t) {
		if (console.error("UI 渲染错误:", e, t), F(e)) try {
			window.sessionStorage.getItem(I) || (window.sessionStorage.setItem(I, String(Date.now())), window.location.reload());
		} catch {
			window.location.reload();
		}
	}
	handleReload = () => {
		try {
			window.sessionStorage.removeItem(I);
		} catch {}
		this.setState({
			hasError: !1,
			error: null
		}), window.location.reload();
	};
	render() {
		return this.state.hasError ? /* @__PURE__ */ M("div", {
			className: "flex h-screen w-screen items-center justify-center bg-slate-50 dark:bg-slate-900",
			children: /* @__PURE__ */ N("div", {
				className: "max-w-md rounded-2xl border border-red-200 bg-white p-8 text-center shadow-lg dark:border-red-900 dark:bg-slate-950",
				children: [
					/* @__PURE__ */ M("div", {
						className: "mb-4 text-4xl",
						children: "⚠"
					}),
					/* @__PURE__ */ M("h1", {
						className: "mb-2 text-xl font-semibold text-red-600 dark:text-red-400",
						children: "页面渲染出错"
					}),
					/* @__PURE__ */ M("p", {
						className: "mb-6 text-sm text-slate-600 dark:text-slate-400",
						children: this.state.error?.message || "发生了未知错误，请刷新页面重试。"
					}),
					/* @__PURE__ */ M("button", {
						onClick: this.handleReload,
						className: "rounded-lg bg-blue-600 px-6 py-2.5 text-sm font-medium text-white transition hover:bg-blue-700",
						children: "刷新页面"
					})
				]
			})
		}) : this.props.children;
	}
};
//#endregion
export { s as A2UIActivityMessage, y as AgentAuthorizationBoundary, o as AgentConversationComposer, _ as AgentConversationTimeline, l as AttachmentPreview, r as ChatComposer, x as ChatHeader, m as ChatMessageList, v as ChatSidebar, w as CodeBlock, i as ContextUsageIndicator, L as ErrorBoundary, t as ExecutionModeMenu, O as FilePreviewHost, D as FilePreviewModal, g as InteractionHistoryAnchor, c as InteractionTray, E as MathMessageMarkdown, u as MenuChip, T as MermaidBlock, f as MessageMarkdown, n as ModelSettingsMenu, b as NativeRuntimeLauncher, C as NativeTerminalPanel, a as PermissionMenu, h as ProcessingBlocksView, p as StatusBanner, P as ToastContainer, S as WorkspacePanelContainer, d as openWorkspaceFilePreview };
