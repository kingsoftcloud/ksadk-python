import { type ReactNode } from 'react';
export type AgentAuthorizationBoundaryProps = {
    /** Stable opaque ID from the host's authenticated principal/tenant context.
     * Persist the new login context before updating this prop; a change reloads
     * the document. Omit to preserve the legacy single-identity integration. */
    authorizationScopeKey?: string;
    children: ReactNode;
};
export declare function AgentAuthorizationLoading(): import("react/jsx-runtime").JSX.Element;
/** 0.3.x stores are page-wide: do not remount them under a different principal.
 * Hide the old tree before paint and reload instead. This destroys outstanding
 * requests, streams, component drafts, previews and singleton caches together.
 * Custom useAgentChat consumers must put their controller inside this boundary.
 */
export declare function AgentAuthorizationBoundary({ authorizationScopeKey, children }: AgentAuthorizationBoundaryProps): string | number | bigint | boolean | import("react/jsx-runtime").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined;
//# sourceMappingURL=AgentAuthorizationBoundary.d.ts.map