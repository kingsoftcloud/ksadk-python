import React from 'react';
export declare const MessageMarkdown: React.FC<{
    content: string;
}>;
//# sourceMappingURL=MessageMarkdown.d.ts.map