export declare function ToastContainer(): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=ToastContainer.d.ts.map