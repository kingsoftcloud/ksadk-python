export declare function ArtifactsPanel(): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=ArtifactsPanel.d.ts.map