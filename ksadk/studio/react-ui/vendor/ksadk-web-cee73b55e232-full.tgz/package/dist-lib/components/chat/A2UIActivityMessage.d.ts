import { type A2UIClientEventMessage } from '@copilotkit/a2ui-renderer';
export declare function A2UIActivityMessage({ surfaceId, messages, onAction, }: {
    surfaceId: string;
    messages: Array<Record<string, unknown>>;
    onAction?: (message: A2UIClientEventMessage) => void;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=A2UIActivityMessage.d.ts.map