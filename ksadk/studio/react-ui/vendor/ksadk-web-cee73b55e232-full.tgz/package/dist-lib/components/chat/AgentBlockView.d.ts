import type { Message } from './types.js';
import type { AgentBlockActions } from '../../core/conversation/agent.js';
export type AgentBlockViewProps = {
    block: NonNullable<Message['agentBlock']>;
    actions?: AgentBlockActions;
};
/** One remote level. Children reuse trusted local renderers; nested delegation stays passive. */
export declare function AgentBlockView({ block, actions }: AgentBlockViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AgentBlockView.d.ts.map