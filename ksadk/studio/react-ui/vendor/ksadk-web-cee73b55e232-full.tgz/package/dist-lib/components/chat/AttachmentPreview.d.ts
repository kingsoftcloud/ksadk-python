import type { MessageAttachment, PreviewImageSize } from './types';
type AttachmentPreviewProps = {
    attachment: MessageAttachment | null;
    isMobile: boolean;
    previewImageSize: PreviewImageSize | null;
    onClose: () => void;
    onImageLoad: (size: PreviewImageSize) => void;
};
export declare function AttachmentPreview({ attachment, isMobile, previewImageSize, onClose, onImageLoad, }: AttachmentPreviewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AttachmentPreview.d.ts.map