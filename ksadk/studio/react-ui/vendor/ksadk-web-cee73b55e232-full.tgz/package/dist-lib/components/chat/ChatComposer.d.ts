import type { ChangeEvent, ClipboardEvent, RefObject, ReactNode } from 'react';
import type { ApprovalPolicyCapability } from '@/types/capabilities.js';
import type { RuntimeExecutionMode } from '@/core/run/types.js';
import type { RuntimeExecutionModeSupport } from './ExecutionModeMenu';
import type { ComposerContextIndicator } from './types';
export type ChatComposerProps = {
    /** Optional host controls, such as an Agent selector. */
    headerSlot?: ReactNode;
    onCompactContext?: () => Promise<void>;
    attachments: File[];
    composerContextIndicator: ComposerContextIndicator;
    composerMaxHeight: number;
    fileInputRef: RefObject<HTMLInputElement | null>;
    input: string;
    isMobile: boolean;
    isStreaming: boolean;
    attachmentsEnabled?: boolean;
    approvalEnabled?: boolean;
    approvalPolicy?: ApprovalPolicyCapability;
    thinkingEnabled?: boolean;
    executionMode?: RuntimeExecutionMode;
    executionModeSupport: RuntimeExecutionModeSupport;
    queuedDrafts: Array<{
        text: string;
        attachments: File[];
        executionMode?: RuntimeExecutionMode;
    }>;
    onAppendAttachments: (files: File[]) => void;
    onInputChange: (event: ChangeEvent<HTMLTextAreaElement>) => void;
    onSelectExecutionMode: (mode: RuntimeExecutionMode) => void;
    onPaste: (event: ClipboardEvent<HTMLTextAreaElement>) => void;
    onRemoveAttachment: (index: number) => void;
    onStopGeneration: () => void;
    onCancelRemote?: () => void;
    onSubmit: (text: string, attachments: File[]) => void;
    textareaRef: RefObject<HTMLTextAreaElement | null>;
    className?: string;
};
export declare function ChatComposer({ headerSlot, onCompactContext, attachments, composerContextIndicator, composerMaxHeight, fileInputRef, input, isMobile, isStreaming, attachmentsEnabled, approvalEnabled, approvalPolicy, thinkingEnabled, executionMode, executionModeSupport, queuedDrafts, onAppendAttachments, onInputChange, onSelectExecutionMode, onPaste, onRemoveAttachment, onStopGeneration, onCancelRemote, onSubmit, textareaRef, className, }: ChatComposerProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChatComposer.d.ts.map