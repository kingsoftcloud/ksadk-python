import type { ModelCatalogItem } from './types';
type ThinkingMode = 'auto' | 'enabled' | 'disabled';
type ModelSelectorProps = {
    availableModels: ModelCatalogItem[];
    selectedModel: string;
    onSelectModel: (modelId: string) => void;
    selectedModelLabel: string;
    modelCatalogLoaded: boolean;
    modelSource: string;
    thinkingEnabled: boolean;
    thinkingMode: ThinkingMode;
    onSelectThinkingMode: (mode: ThinkingMode) => void;
    compact?: boolean;
};
type ChatHeaderProps = ModelSelectorProps & {
    agentName: string;
    currentSessionId: string | null;
    nativeLauncherMode?: boolean;
    isMobile: boolean;
    sidebarOpen: boolean;
    mobileSidebarOpen: boolean;
    onToggleSidebar: () => void;
    mobileActionsOpen: boolean;
    onMobileActionsOpenChange: (open: boolean) => void;
    workspaceEnabled: boolean;
    onOpenWorkspace: () => void;
    nativeManagementLink?: {
        href: string;
        label: string;
        title: string;
    } | null;
    nativeTerminal?: {
        Enabled: boolean;
        Mode?: string | null;
        Protocol?: string | null;
        Path?: string | null;
    } | null;
};
export declare function ChatHeader({ agentName, currentSessionId, isMobile, sidebarOpen, mobileSidebarOpen, onToggleSidebar, availableModels, selectedModel, onSelectModel, selectedModelLabel, modelCatalogLoaded, modelSource, thinkingEnabled, thinkingMode, onSelectThinkingMode, mobileActionsOpen, onMobileActionsOpenChange, workspaceEnabled, onOpenWorkspace, nativeManagementLink, nativeTerminal, nativeLauncherMode, }: ChatHeaderProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ChatHeader.d.ts.map