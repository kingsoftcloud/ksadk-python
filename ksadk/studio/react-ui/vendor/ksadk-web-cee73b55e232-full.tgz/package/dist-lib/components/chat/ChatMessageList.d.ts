import type { AgentBlockActions } from '../../core/conversation/agent.js';
import { type ReactNode, type RefObject } from 'react';
import { type ProcessingBlocksViewProps } from './ProcessingBlocksView';
import type { RunActivity } from '../../stores/streaming.js';
import type { SessionCheckpoint } from '../../stores/checkpoint.js';
import type { ComposerContextIndicator, Message, MessageAttachment } from './types';
import type { A2UIClientEventMessage } from '@copilotkit/a2ui-renderer';
import type { Interaction } from '../../core/interaction/types.js';
export type ChatMessageListProps = {
    agentName: string;
    /** Hide repeated identity when the host supplies a run header. */
    showAgentHeader?: boolean;
    /** Host-owned welcome surface; null suppresses it. */
    emptyState?: ReactNode;
    isMobile: boolean;
    isStreaming: boolean;
    activity: RunActivity | null;
    contextIndicator: ComposerContextIndicator;
    messages: Message[];
    /** Show the explicit waiting state until the current run has emitted output. */
    showWaitingIndicator?: boolean;
    isLoadingInitialHistory?: boolean;
    onOpenAttachmentPreview: (attachment: MessageAttachment) => void;
    onRespondToApproval: (options: {
        approvalRequestId: string;
        approve: boolean;
        previousResponseId?: string;
    }) => void;
    onRespondToAguiApproval?: (options: {
        interruptId: string;
        approve: boolean;
    }) => void;
    onSubmitAguiAction?: (message: A2UIClientEventMessage) => void;
    onSubmitFeedback: (options: {
        message: Message;
        rating: 'up' | 'down';
        comment?: string;
    }) => void;
    onDeleteFeedback: (message: Message) => void;
    onStopGeneration?: () => void;
    onCancelRemote?: () => void;
    agentBlockActions?: AgentBlockActions;
    onScrollToBottom?: () => void;
    checkpoints?: SessionCheckpoint[];
    onResumeCheckpoint?: (params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
    }) => void;
    /** Interaction/v1 records for the current session; anchors replace inline buttons. */
    interactionRecords?: readonly Interaction[];
    scrollRef: RefObject<HTMLDivElement | null>;
    className?: string;
    /** Explicit navigation to a row that may be outside the virtual window. */
    revealMessage?: {
        id: string;
        request: number;
    } | null;
    /** A host that owns navigation can expand text without a second focus/highlight. */
    expandUserInput?: {
        id: string;
        request: number;
    } | null;
    renderProcessingBlock?: ProcessingBlocksViewProps['renderProcessingBlock'];
};
export declare function FeedbackControls({ isLastMessage, isStreaming, message, onDeleteFeedback, onSubmitFeedback, alwaysVisible, }: {
    isLastMessage: boolean;
    isStreaming: boolean;
    message: Message;
    onDeleteFeedback: (message: Message) => void;
    onSubmitFeedback: ChatMessageListProps['onSubmitFeedback'];
    /** Public demo and embedded review surfaces may keep the feedback controls visible. */
    alwaysVisible?: boolean;
}): import("react/jsx-runtime").JSX.Element | null;
export declare function ChatMessageList({ agentName, showAgentHeader, emptyState, isMobile, isStreaming, activity, contextIndicator, messages, showWaitingIndicator, isLoadingInitialHistory, onDeleteFeedback, onOpenAttachmentPreview, onRespondToApproval, onRespondToAguiApproval, onSubmitFeedback, onSubmitAguiAction, onStopGeneration, onCancelRemote, agentBlockActions, onScrollToBottom, checkpoints, onResumeCheckpoint, interactionRecords, scrollRef, className, revealMessage, expandUserInput, renderProcessingBlock, }: ChatMessageListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChatMessageList.d.ts.map