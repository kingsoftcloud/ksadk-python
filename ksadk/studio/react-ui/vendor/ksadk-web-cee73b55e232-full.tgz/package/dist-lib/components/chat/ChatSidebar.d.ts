import { type MouseEvent } from 'react';
import type { Session } from './types';
type ChatSidebarProps = {
    sessions: Session[];
    currentSessionId: string | null;
    onCreateNewSession: () => void;
    onSelectSession: (sessionId: string) => void;
    onDeleteSession: (sessionId: string, event: MouseEvent<HTMLButtonElement>) => void;
    onTogglePinSession: (sessionId: string, event: MouseEvent<HTMLButtonElement>) => void;
    onLoadMoreSessions?: () => void;
    sessionTitle: (session: Session) => string;
    pinnedSessionIds?: string[];
    hasMoreSessions?: boolean;
    isLoadingSessions?: boolean;
    className?: string;
};
export declare function ChatSidebar({ sessions, currentSessionId, onCreateNewSession, onSelectSession, onDeleteSession, onTogglePinSession, onLoadMoreSessions, sessionTitle, pinnedSessionIds, hasMoreSessions, isLoadingSessions, className, }: ChatSidebarProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ChatSidebar.d.ts.map