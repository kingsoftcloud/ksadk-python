import React from 'react';
import type { InteractionTrayRespondInput } from './InteractionTray';
import type { Interaction } from '../../core/interaction/types.js';
import type { ApprovalPolicyCapability } from '../../types/capabilities.js';
import type { RuntimeCapabilityMatrix } from '../../types/agent-control.js';
import type { RuntimeExecutionMode } from '../../core/run/types.js';
import { DraftStore, type ConversationId } from '../../core/conversation/studio-controller.js';
export type ConnectedComposerProps = {
    /** Stable Studio conversation identity. Keeps drafts independent from the runtime session id. */
    draftKey?: ConversationId;
    /** Scope storage to the Studio owner. Dispose it when identity changes. */
    draftStore?: DraftStore;
    /** Optional host controls inside the composer's single surface. */
    headerSlot?: React.ReactNode;
    onCompactContext?: () => Promise<void>;
    composerMaxHeight: number;
    submitDraft: (text: string, attachments: File[], responsesInput?: unknown, previousResponseId?: string, executionMode?: RuntimeExecutionMode) => Promise<boolean | void>;
    stopGeneration: () => void;
    cancelRemote?: () => void;
    isMobile: boolean;
    attachmentsEnabled?: boolean;
    approvalEnabled?: boolean;
    approvalPolicy?: ApprovalPolicyCapability;
    thinkingEnabled?: boolean;
    runtimeCapabilityMatrix?: RuntimeCapabilityMatrix;
    /** Pending interactions rendered in the tray above the composer. */
    pendingInteractions?: readonly Interaction[];
    onRespondInteraction?: (input: InteractionTrayRespondInput) => void;
    localCatalog?: unknown;
    className?: string;
};
export declare function ConnectedComposer({ draftKey, draftStore, headerSlot, onCompactContext, composerMaxHeight, submitDraft, stopGeneration, cancelRemote, isMobile, attachmentsEnabled, approvalEnabled, approvalPolicy, thinkingEnabled, runtimeCapabilityMatrix, pendingInteractions, onRespondInteraction, localCatalog, className, }: ConnectedComposerProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ConnectedComposer.d.ts.map