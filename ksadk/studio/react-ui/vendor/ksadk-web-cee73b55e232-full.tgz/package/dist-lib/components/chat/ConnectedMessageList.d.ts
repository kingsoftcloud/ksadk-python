import type { AgentBlockActions } from '../../core/conversation/agent.js';
import { type ReactNode } from 'react';
import type { Message } from './types';
import type { A2UIClientEventMessage } from '@copilotkit/a2ui-renderer';
export type ConnectedMessageListProps = {
    agentName: string;
    /** Replace the welcome surface without replacing the conversation renderer. */
    emptyState?: ReactNode;
    isMobile: boolean;
    onDeleteFeedback: (message: Message) => void;
    onSubmitFeedback: (options: {
        message: Message;
        rating: 'up' | 'down';
        comment?: string;
    }) => void;
    onRespondToApproval: (options: {
        approvalRequestId: string;
        approve: boolean;
        previousResponseId?: string;
    }) => void;
    onRespondToAguiApproval?: (options: {
        interruptId: string;
        approve: boolean;
    }) => void;
    onSubmitAguiAction?: (message: A2UIClientEventMessage) => void;
    onStopGeneration?: () => void;
    onCancelRemote?: () => void;
    agentBlockActions?: AgentBlockActions;
    checkpointResumeEnabled?: boolean;
    onResumeCheckpoint?: (params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
    }) => void;
    onLoadOlderSessionMessages?: (sessionId: string) => Promise<void>;
    interactionRecords?: readonly import('../../core/interaction/types.js').Interaction[];
    className?: string;
    revealMessage?: {
        id: string;
        request: number;
    } | null;
};
export declare function ConnectedMessageList({ agentName, emptyState, isMobile, onDeleteFeedback, onSubmitFeedback, onRespondToApproval, onRespondToAguiApproval, onSubmitAguiAction, onStopGeneration, onCancelRemote, agentBlockActions, checkpointResumeEnabled, onResumeCheckpoint, onLoadOlderSessionMessages, interactionRecords, className, revealMessage, }: ConnectedMessageListProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ConnectedMessageList.d.ts.map