import type { UiCapabilities } from '../../types/capabilities.js';
type ConnectedSidebarProps = {
    uiCapabilities: UiCapabilities;
    createNewSession: () => void;
    deleteSession: (sessionId: string) => void;
    loadSession: (sessionId: string) => void;
    loadMoreSessions?: () => void;
};
export declare function ConnectedSidebar({ uiCapabilities, createNewSession, deleteSession, loadSession, loadMoreSessions, }: ConnectedSidebarProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=ConnectedSidebar.d.ts.map