import type { ComposerContextIndicator } from './types';
type ContextUsageIndicatorProps = {
    indicator: Exclude<ComposerContextIndicator, null>;
    onCompact?: () => Promise<void>;
    disabled?: boolean;
};
export declare function ContextUsageIndicator({ indicator, onCompact, disabled }: ContextUsageIndicatorProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ContextUsageIndicator.d.ts.map