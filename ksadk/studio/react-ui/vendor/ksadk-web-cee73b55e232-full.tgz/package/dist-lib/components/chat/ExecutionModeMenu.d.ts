import type { RuntimeExecutionMode } from '@/core/run/types.js';
export type RuntimeExecutionModeSupport = Record<RuntimeExecutionMode, boolean>;
type ExecutionModeMenuProps = {
    attachmentsEnabled: boolean;
    mode?: RuntimeExecutionMode;
    support: RuntimeExecutionModeSupport;
    onSelectMode: (mode: RuntimeExecutionMode) => void;
    onUpload: () => void;
};
export declare function ExecutionModeMenu({ attachmentsEnabled, mode, support, onSelectMode, onUpload, }: ExecutionModeMenuProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=ExecutionModeMenu.d.ts.map