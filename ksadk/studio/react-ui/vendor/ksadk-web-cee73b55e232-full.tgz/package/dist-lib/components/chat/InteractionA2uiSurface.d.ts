import type { A2uiPresentation } from '../../core/interaction/types.js';
/**
 * Renders a validated A2UI v0.9.1 interaction surface. Only reached when
 * `validateA2uiPresentation` accepted the wire version and catalog
 * digest; any unknown component fails inside the renderer and the user
 * still has the explicit submit/cancel controls below.
 */
export declare function InteractionA2uiSurface({ a2ui, disabled, onSubmit, onCancel, }: {
    a2ui: A2uiPresentation;
    disabled: boolean;
    onSubmit: (payload: Record<string, unknown>) => void;
    onCancel: () => void;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InteractionA2uiSurface.d.ts.map