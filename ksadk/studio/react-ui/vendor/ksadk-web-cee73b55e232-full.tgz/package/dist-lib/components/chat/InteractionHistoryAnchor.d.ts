import type { Interaction } from '../../core/interaction/types.js';
/**
 * Read-only anchor for a resolved interaction in chat history.
 * Replaces historical interactive buttons: it retains the actor,
 * decision time, outcome, and a redacted response summary, and expands
 * into a fixed read-only snapshot (native details/summary — no buttons,
 * no inputs, nothing editable).
 */
export declare function InteractionHistoryAnchor({ interaction }: {
    interaction: Interaction;
}): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=InteractionHistoryAnchor.d.ts.map