/**
 * Canonical JSON-schema form fallback. Renders only when the A2UI
 * presentation cannot be validated; submission is always an explicit
 * user action — never an automatic approval.
 */
export declare function InteractionSchemaForm({ schema, values, onChange, disabled, onSubmit, onCancel, }: {
    schema: Record<string, unknown>;
    values: Record<string, unknown>;
    onChange: (values: Record<string, unknown>) => void;
    disabled: boolean;
    onSubmit: () => void;
    onCancel: () => void;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InteractionSchemaForm.d.ts.map