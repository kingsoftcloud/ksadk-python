import type { Interaction, InteractionAction } from '../../core/interaction/types.js';
export type InteractionTrayRespondInput = {
    interactionId: string;
    expectedRevision: number;
    action: InteractionAction;
    response: Record<string, unknown>;
    idempotencyKey: string;
};
export type InteractionTrayProps = {
    /** Pending (and in-flight) interactions for the current session. */
    interactions: readonly Interaction[];
    activeIndex: number;
    onSelectIndex: (index: number) => void;
    onRespond: (input: InteractionTrayRespondInput) => void | Promise<unknown>;
    /** Local pinned A2UI catalog used for digest validation. */
    localCatalog?: unknown;
    className?: string;
};
export declare function InteractionTray({ interactions, activeIndex, onSelectIndex, onRespond, localCatalog, className, }: InteractionTrayProps): import("react/jsx-runtime").JSX.Element | null;
export declare function InteractionOutcomeLabel({ outcome }: {
    outcome: string;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InteractionTray.d.ts.map