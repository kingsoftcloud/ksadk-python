/**
 * wework 风格自定义下拉 chip:点击触发器(label+chevron)弹 rounded-xl 卡片菜单,
 * 选项 hover bg-muted,选中高亮。替代原生 select(原生箭头/样式不可控)。
 */
type Option = {
    value: string;
    label: string;
};
type MenuChipProps = {
    /** 触发器显示的当前 label。 */
    label: string;
    options: Option[];
    value: string;
    onChange: (value: string) => void;
    title?: string;
};
export declare function MenuChip({ label, options, value, onChange, title }: MenuChipProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MenuChip.d.ts.map