import type { ThinkingMode } from '@/stores/model.js';
import type { ModelCatalogItem } from './types';
type ModelSettingsMenuProps = {
    availableModels: ModelCatalogItem[];
    selectedModel: string;
    thinkingEnabled: boolean;
    thinkingMode: ThinkingMode;
    onSelectModel: (modelId: string) => void;
    onSelectThinkingMode: (mode: ThinkingMode) => void;
};
export declare function ModelSettingsMenu({ availableModels, selectedModel, thinkingEnabled, thinkingMode, onSelectModel, onSelectThinkingMode, }: ModelSettingsMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ModelSettingsMenu.d.ts.map