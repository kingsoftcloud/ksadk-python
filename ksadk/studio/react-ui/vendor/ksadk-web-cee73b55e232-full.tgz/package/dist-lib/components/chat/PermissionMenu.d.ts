import type { ApprovalPolicyCapability } from '@/types/capabilities.js';
type PermissionMenuProps = {
    approvalPolicy?: ApprovalPolicyCapability;
};
export declare function PermissionMenu({ approvalPolicy }: PermissionMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=PermissionMenu.d.ts.map