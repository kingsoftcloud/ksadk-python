/**
 * 交错 "思考-行动-思考-输出" 渲染,照抄 Wegent/wework 的视觉节奏:
 * - 思考块:默认折叠；流式时只显示"思考中"动效，点击后才显示实时内容
 * - 工具块:单行活动行(图标+状态文案+duration),展开才出详情
 * - 正文块:平铺 markdown
 * 核心是"活动行优先、详情按需",不占大块视觉,保留时间线交错节奏。
 */
import { type ReactNode } from 'react';
import type { Message } from './types';
import type { ProcessingBlock } from '../../core/run/blocks';
import type { Interaction } from '../../core/interaction/types';
export interface ProcessingBlocksViewProps {
    message: Message;
    isStreaming: boolean;
    onRespondToApproval?: (p: {
        approvalRequestId: string;
        approve: boolean;
        previousResponseId?: string;
    }) => void;
    onRespondToAguiApproval?: (p: {
        interruptId: string;
        approve: boolean;
    }) => void;
    /** Interaction/v1 records; when present the read-only anchor replaces inline approval buttons. */
    interactionRecords?: readonly Interaction[];
    /** Host presentation at the canonical block position; undefined keeps the shared renderer. */
    renderProcessingBlock?: (block: ProcessingBlock, message: Message) => ReactNode | undefined;
    className?: string;
}
export declare function ProcessingBlocksView({ message, isStreaming, onRespondToApproval, onRespondToAguiApproval, interactionRecords, renderProcessingBlock, className, }: ProcessingBlocksViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ProcessingBlocksView.d.ts.map