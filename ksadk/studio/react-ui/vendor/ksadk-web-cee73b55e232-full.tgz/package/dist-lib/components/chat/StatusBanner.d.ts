/**
 * wework 风格错误/限流/重连内联状态条。
 * 从 streaming store 的 banner 字段驱动,内联在消息区底部(不白屏)。
 * - rate_limited:友好提示"请求过于频繁",带 Retry-After 倒计时(若有)
 * - network:网络异常重连中(spinner)
 * - error:运行失败 + 重试按钮
 */
type StatusBannerProps = {
    onRetry?: () => void;
};
export declare function StatusBanner({ onRetry }: StatusBannerProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=StatusBanner.d.ts.map