export declare function UserInputBody({ content, messageId, revealRequest }: {
    content: string;
    messageId: string;
    revealRequest?: number;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=UserInputBody.d.ts.map