export type InteractionRequestSchemaField = {
    name: string;
    title?: string;
    description?: string;
    allowOther?: boolean;
    secret?: boolean;
    type: 'string' | 'number' | 'boolean' | 'array' | 'unknown';
    required: boolean;
    enumValues?: unknown[];
};
/**
 * Extract renderable fields from a canonical JSON schema
 * (`{type:"object", properties, required}`).
 */
export declare function schemaFields(schema: Record<string, unknown>): InteractionRequestSchemaField[];
//# sourceMappingURL=schema-fields.d.ts.map