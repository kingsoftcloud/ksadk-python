export type MessageAttachment = {
    name: string;
    url: string;
    type: string;
    fileUri?: string;
    /** Optional provenance carried by generated conversation artifacts. */
    artifactId?: string;
    itemId?: string;
    runId?: string;
    sizeBytes?: number | null;
    status?: 'pending' | 'ready' | 'failed';
};
export type PreviewImageSize = {
    width: number;
    height: number;
};
export type Message = {
    agentBlock?: {
        /** Sanitized excerpt of an explicitly public child text item, prepared by the shared projector. */
        summary?: string;
        item: import('../../core/conversation/types.js').ConversationItem;
        messages: Message[];
    };
    id: string;
    role: 'user' | 'model' | 'tool' | 'system' | 'a2ui';
    content: string;
    timestamp: number;
    responseId?: string;
    invocationId?: string;
    eventId?: string;
    traceId?: string;
    rootSpanId?: string;
    eventType?: string;
    /**
     * schema v2 runtime item identity. 存在时渲染/反馈按 runId/scopeId/itemId/partId
     * 归并,替代 v1 的文本启发式去重。
     */
    runId?: string;
    scopeId?: string;
    itemId?: string;
    partId?: string;
    status?: 'running' | 'completed' | 'failed' | 'cancelled';
    /** Passive projection of explicit run acceptance, never inferred from final text. */
    runOutcome?: import('../../core/conversation/types.js').ConversationRunOutcome;
    /** Ordered public compaction boundary; contains no private summary or prompt. */
    contextActivity?: {
        status: 'running' | 'completed' | 'cancelled' | 'failed' | 'paused' | 'unknown';
        durationMs?: number;
        durationSource?: 'studio_observed';
    };
    summary?: string;
    trigger?: string;
    compactedUntilSeqId?: number;
    historical?: boolean;
    reasoning?: string;
    reasoningSource?: 'public_summary' | 'provider_reasoning' | 'runtime_progress' | 'reasoning';
    /**
     * 有序 "思考-行动-思考-输出" 交错 blocks(照抄 Wegent wework)。
     * 存在时渲染层按数组顺序交错展示;为空则回退 reasoning/tools/content 旧渲染。
     */
    blocks?: import('../../core/run/blocks.js').ProcessingBlock[];
    a2ui?: {
        surfaceId: string;
        surface: import('../../core/stream/types.js').A2UISurface;
        pendingInteraction?: {
            interactionId: string;
            kind: string;
            inputSchema: Record<string, unknown>;
        };
        ended?: boolean;
    };
    aguiActivity?: {
        surfaceId: string;
        messages: Array<Record<string, unknown>>;
    };
    aguiActivities?: Array<{
        surfaceId: string;
        messages: Array<Record<string, unknown>>;
    }>;
    tools?: {
        [name: string]: {
            name: string;
            /** Stable provider call identity used to join tool history to its approval. */
            callId?: string;
            toolDisplay?: Record<string, unknown>;
            args: string;
            output?: string;
            summary?: string;
            durationMs?: number;
            status: 'running' | 'completed' | 'error' | 'paused' | 'unknown';
            approvalRequestId?: string;
            previousResponseId?: string;
            serverLabel?: string;
            approvalStatus?: 'pending' | 'approved' | 'rejected' | 'cancelled';
            approvalProtocol?: 'responses' | 'ag-ui';
            approvalMessage?: string;
            approvalLevel?: string;
        };
    };
    attachments?: MessageAttachment[];
    feedback?: {
        agentId?: string;
        sessionId?: string;
        responseId?: string;
        eventId?: string;
        rating: 'up' | 'down';
        comment?: string;
        traceId?: string;
        rootSpanId?: string;
        updatedAt?: string;
        pending?: boolean;
        error?: string;
    };
};
export type Session = {
    SessionId: string;
    Title?: string;
    TitleSource?: string;
    Summary?: string;
    FirstPrompt?: string;
    LastPrompt?: string;
    UpdatedAt?: string | number | null;
    ActiveRunStatus?: string;
    ActiveInvocationId?: string;
    Model?: {
        id?: string;
        display_name?: string;
        [key: string]: unknown;
    } | null;
    ContextUsage?: {
        used_tokens?: number;
        context_window_tokens?: number;
        percent?: number;
        [key: string]: unknown;
    } | null;
};
export type ModelCatalogItem = {
    id: string;
    display_name?: string;
    context_window_tokens?: number;
    max_output_tokens?: number;
    auto_compact_threshold_tokens?: number;
    auto_compact_threshold_percentage?: number;
    limits?: {
        context_window_tokens?: number;
        max_input_tokens?: number;
        max_output_tokens?: number;
        max_reasoning_tokens?: number;
        rpm?: number;
        tpm?: number;
    };
    capabilities?: {
        function_calling?: boolean;
        structured_output?: boolean;
        context_caching?: boolean;
        multimodal_input_image?: boolean;
        multimodal_input_video?: boolean;
        multimodal_input_file?: boolean;
    };
    pricing?: Record<string, string | number>;
    [key: string]: unknown;
};
export type ComposerContextIndicator = {
    label: string;
    phase?: 'default' | 'normal' | 'warning' | 'compressing';
    percent?: number;
    usedTokens?: number;
    contextWindowTokens?: number;
    contextWindowSource?: 'runtime' | 'model';
} | null;
export type WorkspaceFilesCapability = {
    Enabled: boolean;
    MaxUploadBytes: number;
    SupportsDelete: boolean;
    RootLabel: string;
    EntryAction?: string;
    UploadAction?: string;
    ContentPath?: string;
};
export type WorkspaceEntry = {
    Name: string;
    Path: string;
    Type: 'file' | 'directory';
    SizeBytes?: number | null;
    MimeType?: string | null;
    ModifiedAt?: string | null;
};
//# sourceMappingURL=types.d.ts.map