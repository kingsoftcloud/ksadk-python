import React from 'react';
interface CodeBlockProps {
    language: string;
    value: string;
}
export declare const CodeBlock: React.FC<CodeBlockProps>;
export {};
//# sourceMappingURL=CodeBlock.d.ts.map