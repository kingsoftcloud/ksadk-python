import React from 'react';
import 'katex/dist/katex.min.css';
interface MathMessageMarkdownProps {
    content: string;
}
export declare const MathMessageMarkdown: React.FC<MathMessageMarkdownProps>;
export {};
//# sourceMappingURL=MathMessageMarkdown.d.ts.map