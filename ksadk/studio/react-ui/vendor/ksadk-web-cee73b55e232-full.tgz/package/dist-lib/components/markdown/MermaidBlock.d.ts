import React from 'react';
interface MermaidBlockProps {
    chart: string;
}
export declare const MermaidBlock: React.FC<MermaidBlockProps>;
export {};
//# sourceMappingURL=MermaidBlock.d.ts.map