type NativeManagementLink = {
    href: string;
    label: string;
    title: string;
};
type NativeTerminalCapability = {
    Enabled: boolean;
    Mode?: string | null;
    Path?: string | null;
};
type NativeRuntimeLauncherProps = {
    productLabel?: string;
    nativeManagementLink?: NativeManagementLink | null;
    nativeTerminal?: NativeTerminalCapability | null;
    workspaceEnabled: boolean;
    onOpenWorkspace: () => void;
};
export declare function NativeRuntimeLauncher({ productLabel, nativeManagementLink, nativeTerminal, workspaceEnabled, onOpenWorkspace, }: NativeRuntimeLauncherProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NativeRuntimeLauncher.d.ts.map