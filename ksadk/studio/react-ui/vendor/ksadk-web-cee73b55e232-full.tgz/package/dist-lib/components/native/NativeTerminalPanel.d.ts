import '@xterm/xterm/css/xterm.css';
type NativeTerminalCapability = {
    Enabled: boolean;
    Mode?: string | null;
    Protocol?: string | null;
    Path?: string | null;
};
type NativeTerminalPanelProps = {
    capability: NativeTerminalCapability;
    open: boolean;
    onClose: () => void;
    sessionId?: string | null;
    autoCreateWhenEmpty?: boolean;
};
export declare function NativeTerminalPanel({ capability, open, onClose, sessionId, autoCreateWhenEmpty, }: NativeTerminalPanelProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=NativeTerminalPanel.d.ts.map