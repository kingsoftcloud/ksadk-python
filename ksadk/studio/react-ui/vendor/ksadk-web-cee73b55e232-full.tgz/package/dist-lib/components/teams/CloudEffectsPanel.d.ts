import type { HttpCloudTeamsProductClient } from '../../core/teams/cloudProductClient.js';
import type { TeamsOperationPayload } from '../../core/teams/operationOutbox.js';
import { type WorkspaceClientScope } from '../../core/teams/workspaceContracts.js';
export interface CloudEffectsPanelProps {
    scope: WorkspaceClientScope;
    teamRunId: string;
    product: HttpCloudTeamsProductClient;
    canWrite: boolean;
    refreshKey: string;
    pendingEffectKeys: string[];
    command: (suffix: string, payload: TeamsOperationPayload) => Promise<unknown>;
}
/** Owner review never infers external completion or mutates a native run. */
export declare function CloudEffectsPanel({ scope, teamRunId, product, canWrite, refreshKey, pendingEffectKeys, command }: CloudEffectsPanelProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CloudEffectsPanel.d.ts.map