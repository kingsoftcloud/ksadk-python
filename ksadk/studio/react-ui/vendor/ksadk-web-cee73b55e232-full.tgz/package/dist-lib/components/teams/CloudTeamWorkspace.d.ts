import type { HttpCloudTeamsProductClient } from '../../core/teams/cloudProductClient.js';
import type { CloudWorkspaceTransport } from '../../core/teams/cloudClient.js';
import { type WorkspaceObservation } from '../../core/teams/workspaceObserver.js';
import { type WorkspaceClientScope, type WorkspaceCollection, type WorkspaceInteraction, type WorkspaceTaskSummary } from '../../core/teams/workspaceContracts.js';
export interface CloudTeamWorkspaceProps {
    scope: WorkspaceClientScope;
    transport: CloudWorkspaceTransport;
    product: HttpCloudTeamsProductClient;
    canWrite: boolean;
    effectsEnabled?: boolean;
    readOnlyReason?: string;
    initialRunId?: string;
    onSelectionChange?: (teamRunId: string | null) => void;
    onChanged?: () => void;
}
/** Cloud view owns a partial projection. It never constructs a legacy GroupSnapshot. */
export declare function CloudTeamWorkspace(props: CloudTeamWorkspaceProps): import("react/jsx-runtime").JSX.Element;
export interface CloudTeamWorkspaceViewProps {
    observation: WorkspaceObservation;
    canWrite: boolean;
    readOnlyReason?: string;
    error?: string;
    newGoal?: boolean;
    onRetry: () => void;
    onLoadMore: (collection: WorkspaceCollection) => void;
    onChooseRun: (id: string) => void;
    onNewGoal: () => void;
    composer?: React.ReactNode;
    operations?: React.ReactNode;
    effects?: React.ReactNode;
    renderTasks?: (task: WorkspaceTaskSummary) => React.ReactNode;
    renderInteraction?: (interaction: WorkspaceInteraction) => React.ReactNode;
    artifactUrl?: (id: string, teamRunId: string) => string;
    onControl?: (action: string) => void;
    onAcceptance?: (action: string, reason?: string) => void;
}
export declare function CloudTeamWorkspaceView(props: CloudTeamWorkspaceViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CloudTeamWorkspace.d.ts.map