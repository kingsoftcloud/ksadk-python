import type { ExecutionBinding, GroupCreateInput } from '../../core/teams/types.js';
export type TeamMemberCandidate = {
    memberId: string;
    name: string;
    description?: string;
    responsibility?: string;
    binding: ExecutionBinding;
};
export type CreateGroupDialogProps = {
    open: boolean;
    candidates: TeamMemberCandidate[];
    serverAuthority?: boolean;
    loading?: boolean;
    error?: string;
    onRefresh?: () => void;
    hasMore?: boolean;
    onLoadMore?: () => void;
    onClose: () => void;
    onCreate: (input: GroupCreateInput) => Promise<unknown>;
};
/** Selection belongs to the draft, not to a refreshed directory row. */
export declare function CreateGroupDialog({ open, candidates, serverAuthority, loading, error: directoryError, onRefresh, hasMore, onLoadMore, onClose, onCreate }: CreateGroupDialogProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CreateGroupDialog.d.ts.map