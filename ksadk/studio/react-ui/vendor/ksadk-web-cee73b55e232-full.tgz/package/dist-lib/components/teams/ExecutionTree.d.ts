import type { AgentMember, TeamTask, ExecutionNode, ExecutionSnapshot } from '../../core/teams/types.js';
export type ExecutionTreeProps = {
    tasks: TeamTask[];
    members: AgentMember[];
    selectedTaskId?: string;
    onSelect: (task: TeamTask) => void;
    execution?: ExecutionSnapshot | null;
    executionLoading?: boolean;
    executionError?: string;
    onRetryExecution?: () => void;
    onSelectNode?: (node: ExecutionNode) => void;
};
/** Read-only dependency view. Every node is a persisted task; no simulated state. */
export declare const ExecutionTree: import("react").NamedExoticComponent<ExecutionTreeProps>;
export declare function MemberTimeline({ tasks, members, onSelect }: Omit<ExecutionTreeProps, 'selectedTaskId'>): import("react/jsx-runtime").JSX.Element;
/** Host-projected run and child facts; task plans are labelled separately. */
export declare function InvocationTree({ execution, loading, error, onRetry, onSelect }: {
    execution?: ExecutionSnapshot | null;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    onSelect?: (node: ExecutionNode) => void;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ExecutionTree.d.ts.map