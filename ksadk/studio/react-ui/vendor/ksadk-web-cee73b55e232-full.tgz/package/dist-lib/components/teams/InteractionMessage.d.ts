export declare function InteractionMessage({ message }: {
    message: string;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InteractionMessage.d.ts.map