import type { TeamReconciliationRecord, TeamRun } from '../../core/teams/types.js';
export type ReconciliationActions = {
    onLoadReconciliation?: (run: TeamRun) => Promise<TeamReconciliationRecord[]>;
    onReconcile?: (record: TeamReconciliationRecord, action: 'confirm_ended' | 'use_result', reason: string) => Promise<unknown>;
};
export declare function TeamReconciliation({ run, onLoadReconciliation: load, onReconcile: reconcile }: ReconciliationActions & {
    run: TeamRun;
}): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=TeamReconciliation.d.ts.map