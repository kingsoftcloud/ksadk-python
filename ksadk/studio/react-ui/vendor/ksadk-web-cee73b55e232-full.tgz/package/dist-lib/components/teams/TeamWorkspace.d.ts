import { type ReactNode } from 'react';
import { type ReconciliationActions } from './TeamReconciliation.js';
import type { AgentMember, ConnectionStatus, GroupMessage, GroupMessageInput, GroupSnapshot, MemberObservation, TaskAction, TeamArtifact, TeamControlAction, TeamInteraction, TeamInteractionInput, TeamRun, TeamTask, ExecutionSnapshot, MemberStreamRef, ExecutionBinding, LeaderStandbyConfiguration } from '../../core/teams/types.js';
export declare function TeamStatusLabel({ status }: {
    status: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function GroupHeader({ snapshot, connection, onMembers, onManage }: {
    snapshot: GroupSnapshot;
    connection: ConnectionStatus;
    onProgress: () => void;
    onMembers: () => void;
    onManage?: () => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function GroupTimeline({ messages, children, emptyState, focusFinalDelivery }: {
    messages: GroupMessage[];
    children?: ReactNode;
    emptyState?: ReactNode;
    focusFinalDelivery?: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function TeamProgressCard({ run, tasks, pendingCount, onOpen, compact }: {
    run: TeamRun;
    tasks: TeamTask[];
    pendingCount: number;
    onOpen: () => void;
    compact?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function GroupComposer({ members, activeRun, value, onChange, onSend, disabled, recipientMemberId, onRecipientChange, focusRequest, artifacts, referenceArtifacts, serverAuthority }: {
    members: AgentMember[];
    activeRun: TeamRun | null;
    value: string;
    onChange: (value: string) => void;
    onSend: (input: GroupMessageInput) => Promise<unknown>;
    disabled?: boolean;
    recipientMemberId?: string;
    onRecipientChange?: (memberId: string) => void;
    focusRequest?: number;
    artifacts?: TeamArtifact[];
    referenceArtifacts?: TeamArtifact[];
    serverAuthority?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function TaskBoard({ tasks, members, selectedTaskId, onSelect }: {
    tasks: TeamTask[];
    members: AgentMember[];
    selectedTaskId?: string;
    onSelect: (task: TeamTask) => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function TaskDetail({ task, members, onAction, onOpenArtifact, onMemberSelect }: {
    task: TeamTask;
    members: AgentMember[];
    onAction?: (task: TeamTask, action: TaskAction, reason?: string) => Promise<unknown>;
    onOpenArtifact?: (artifact: TeamArtifact) => void;
    onMemberSelect?: (member: AgentMember) => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function TeamInteractionTray({ interactions, members, onRespond }: {
    interactions: TeamInteraction[];
    members: AgentMember[];
    onRespond: (input: TeamInteractionInput) => Promise<unknown>;
}): import("react/jsx-runtime").JSX.Element;
export declare function MemberRail({ members, selectedMemberId, onSelect }: {
    members: AgentMember[];
    selectedMemberId?: string;
    onSelect: (member: AgentMember) => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function MemberInspector({ member, observation, onDirectedMessage, onRetry, onCancel, cancelPending, cancelBusy }: {
    member: AgentMember;
    observation?: MemberObservation & {
        error?: string | null;
    };
    onDirectedMessage?: () => void;
    onRetry?: () => void;
    onCancel?: () => void;
    cancelPending?: boolean;
    cancelBusy?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export type TeamWorkspaceProps = ReconciliationActions & {
    snapshot: GroupSnapshot | null;
    loading?: boolean;
    error?: string | null;
    connection?: ConnectionStatus;
    draft?: string;
    onDraftChange?: (draft: string, teamRunId?: string) => void;
    initialDrafts?: Record<string, string>;
    initialSelection?: {
        teamRunId?: string;
        taskId?: string;
    };
    onSelectionChange?: (selection: {
        teamRunId: string;
        taskId: string;
    }) => void;
    onSend: (input: GroupMessageInput) => Promise<unknown>;
    onRetry?: () => void;
    onManage?: () => void;
    serverAuthority?: boolean;
    standbyCandidates?: ExecutionBinding[];
    onConfigureStandby?: (run: TeamRun, bindingRef: string) => Promise<LeaderStandbyConfiguration>;
    onControl?: (run: TeamRun, action: TeamControlAction) => Promise<unknown>;
    onAcceptRun?: (run: TeamRun, accepted: boolean, reason?: string) => Promise<unknown>;
    onTaskAction?: (task: TeamTask, action: TaskAction, reason?: string) => Promise<unknown>;
    onRespondInteraction?: (input: TeamInteractionInput) => Promise<unknown>;
    onOpenArtifact?: (artifact: TeamArtifact) => void;
    onMemberSelect?: (member: AgentMember) => void;
    renderMember?: (member: AgentMember, actions: {
        directedMessage: () => void;
        teamRunId?: string;
    }, source?: MemberStreamRef) => ReactNode;
    onLoadExecution?: (teamRunId: string, signal: AbortSignal) => Promise<ExecutionSnapshot>;
};
export declare function TeamWorkspace(props: TeamWorkspaceProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TeamWorkspace.d.ts.map