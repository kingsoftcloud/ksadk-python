type FileEditorProps = {
    content: string;
    path: string;
    readOnly?: boolean;
    onSave?: (content: string) => void;
    onDirtyChange?: (dirty: boolean) => void;
    onContentChange?: (content: string) => void;
    getContentRef?: React.MutableRefObject<(() => string) | null>;
};
export declare function FileEditor({ content, path, readOnly, onSave, onDirtyChange, onContentChange, getContentRef }: FileEditorProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FileEditor.d.ts.map