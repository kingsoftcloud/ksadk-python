type FilePreviewProps = {
    content: string | null;
    objectUrl?: string;
    kind: 'image' | 'pdf' | 'markdown' | 'text' | 'code' | 'unsupported';
    filename: string;
    mimeType: string;
    path?: string;
};
export declare function FilePreview({ content, objectUrl, kind, filename, path }: FilePreviewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FilePreview.d.ts.map