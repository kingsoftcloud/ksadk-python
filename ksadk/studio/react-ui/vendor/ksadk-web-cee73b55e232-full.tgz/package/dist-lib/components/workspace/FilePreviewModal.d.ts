export interface WorkspaceFilePayload {
    path: string;
    name: string;
    sizeBytes: number;
    contentType: string;
    mediaCategory: "markdown" | "image" | "text";
    content?: string;
    dataBase64?: string;
}
export type WorkspaceFileFetcher = (path: string) => Promise<Response>;
export interface FilePreviewModalProps {
    path: string | null;
    onClose: () => void;
    fetchFile?: WorkspaceFileFetcher;
}
export declare function FilePreviewModal({ path, onClose, fetchFile }: FilePreviewModalProps): import("react/jsx-runtime").JSX.Element | null;
/** Mount once per app; listens for openWorkspaceFilePreview requests. */
export declare function FilePreviewHost({ fetchFile }: {
    fetchFile?: WorkspaceFileFetcher;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FilePreviewModal.d.ts.map