type HtmlPreviewProps = {
    content: string;
    path: string;
    onSave: (content: string) => void;
    onDirtyChange: (dirty: boolean) => void;
    getContentRef: React.MutableRefObject<(() => string) | null>;
    isMobile: boolean;
    agentId: string;
    contentPath: string;
};
export declare function HtmlPreview({ content, path, onSave, onDirtyChange, getContentRef, isMobile, }: HtmlPreviewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=HtmlPreview.d.ts.map