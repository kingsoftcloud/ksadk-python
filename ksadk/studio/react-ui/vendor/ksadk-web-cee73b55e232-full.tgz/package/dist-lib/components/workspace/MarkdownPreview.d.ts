type MarkdownPreviewProps = {
    content: string;
    path: string;
    onSave: (content: string) => void;
    onDirtyChange: (dirty: boolean) => void;
    getContentRef: React.MutableRefObject<(() => string) | null>;
    isMobile: boolean;
};
export declare function MarkdownPreview({ content, path, onSave, onDirtyChange, getContentRef, isMobile, }: MarkdownPreviewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MarkdownPreview.d.ts.map