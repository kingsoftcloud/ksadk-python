import type { WorkspaceFilesCapability } from '../chat/types.js';
import type { ApiFacade } from '../../core/api/types.js';
type WorkspacePanelProps = {
    agentId: string;
    capability: WorkspaceFilesCapability;
    open: boolean;
    onClose?: () => void;
    isFullscreen?: boolean;
    onToggleFullscreen?: () => void;
    isMobile?: boolean;
    api: ApiFacade;
};
export declare function WorkspacePanel({ agentId, capability, open, onClose, isFullscreen, onToggleFullscreen, isMobile, api, }: WorkspacePanelProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WorkspacePanel.d.ts.map