import React from 'react';
import type { WorkspaceFilesCapability } from '../chat/types';
import type { ApiFacade } from '../../core/api/types.js';
type SheetSide = 'top' | 'bottom' | 'left' | 'right';
type WorkspacePanelContainerProps = {
    agentId: string;
    capability: WorkspaceFilesCapability;
    workspacePanelOpen: boolean;
    workspacePanelWidth: number;
    workspacePanelFullscreen: boolean;
    isMobile: boolean;
    workspaceEnabled: boolean;
    workspaceFiles: WorkspaceFilesCapability | null;
    workspacePanelPresentation: {
        renderMode: string;
        modal?: boolean;
        side?: SheetSide;
        showOverlay?: boolean;
        preventOutsideClose?: boolean;
    };
    closeWorkspacePanel: () => void;
    handleWorkspacePanelResizeStart: (event: React.PointerEvent<HTMLDivElement>) => void;
    api: ApiFacade;
};
export declare function WorkspacePanelContainer({ agentId, capability, workspacePanelOpen, workspacePanelWidth, workspacePanelFullscreen, isMobile, workspaceEnabled, workspaceFiles, workspacePanelPresentation, closeWorkspacePanel, handleWorkspacePanelResizeStart, api, }: WorkspacePanelContainerProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=WorkspacePanelContainer.d.ts.map