import { a as e, i as t, n, o as r, r as i, t as a } from "./studio-controller-Bz1aNDRN.js";
import { c as o, d as s, f as c, i as l, l as u, n as d, p as f, r as p, s as m, t as h, u as g } from "./reducer-mbYiX0wz.js";
import { C as _, D as v, E as y, O as b, T as x, n as S, t as C, w } from "./persisted-session-history-ChW9k7v9.js";
import { n as T, t as E } from "./history-search-CBd9v7MY.js";
//#region src/core/conversation/session-facade.ts
var D = class {
	bindings = /* @__PURE__ */ new Map();
	pendingBindings = /* @__PURE__ */ new Map();
	api;
	owner;
	constructor(e, t) {
		this.api = e, this.owner = t;
	}
	assertOwnedBinding(e) {
		if (e.agentId !== this.owner.agentId) throw Error("Conversation binding belongs to another Agent");
		if (this.owner.targetId !== void 0 && e.targetId !== this.owner.targetId) throw Error("Conversation binding belongs to another execution target");
		if (this.owner.tenantId !== void 0 && e.tenantId !== this.owner.tenantId) throw Error("Conversation binding belongs to another tenant");
		if (this.owner.workspaceId !== void 0 && e.workspaceId !== this.owner.workspaceId) throw Error("Conversation binding belongs to another workspace");
	}
	async listSessionSummaries(e = {}) {
		let t = await this.api.listSessions(this.owner.agentId, e), n = t.Sessions.map((e) => ({
			sessionId: String(e.SessionId || ""),
			title: e.Title ? String(e.Title) : void 0,
			updatedAt: e.UpdatedAt ? String(e.UpdatedAt) : void 0,
			activeRunStatus: e.ActiveRunStatus ? String(e.ActiveRunStatus) : void 0,
			activeInvocationId: e.ActiveInvocationId ? String(e.ActiveInvocationId) : void 0
		})).filter((e) => e.sessionId), r = e.page || 1, i = e.pageSize || n.length;
		return {
			items: n,
			total: Number(t.Total ?? n.length),
			nextPage: n.length >= i ? r + 1 : void 0
		};
	}
	async readHistoryWindow(e, t = {}) {
		if (this.assertOwnedBinding(e), !e.nativeSessionId) return {
			items: [],
			total: 0
		};
		let n = await this.api.listSessionMessages(e.nativeSessionId, {
			agentId: this.owner.agentId,
			afterSeqId: t.offset,
			limit: t.limit,
			signal: t.signal
		}), r = t.offset || 0;
		return {
			items: n.Messages,
			total: n.LatestSeqId,
			nextOffset: n.HasMore ? r + n.Messages.length : void 0
		};
	}
	async watchCurrentState(e, t = {}) {
		if (this.assertOwnedBinding(e), !e.nativeSessionId) return {
			sessionId: "",
			title: void 0
		};
		let n = await this.api.getSession(e.nativeSessionId, t);
		return {
			sessionId: n.SessionId,
			title: n.Title,
			updatedAt: n.UpdatedAt,
			activeRunStatus: n.ActiveRunStatus,
			activeInvocationId: n.ActiveInvocationId
		};
	}
	async ensureExecutionBinding(e, t = {}) {
		let n = this.bindings.get(e);
		if (n?.nativeSessionId) return n;
		let r = this.pendingBindings.get(e);
		if (r) return r;
		let i = this.api.createSession(this.owner.agentId, t).then((t) => {
			if (!t.SessionId) throw Error("Runtime returned no native session identity");
			let n = {
				conversationId: e,
				agentId: this.owner.agentId,
				targetId: this.owner.targetId,
				tenantId: this.owner.tenantId,
				workspaceId: this.owner.workspaceId,
				nativeSessionId: t.SessionId
			};
			return this.bindings.set(e, n), n;
		}).finally(() => {
			this.pendingBindings.get(e) === i && this.pendingBindings.delete(e);
		});
		return this.pendingBindings.set(e, i), i;
	}
	submit(e, t, n = {}) {
		try {
			this.assertOwnedBinding(e);
		} catch (e) {
			return Promise.reject(e);
		}
		if (!e.nativeSessionId) return Promise.reject(/* @__PURE__ */ Error("Execution binding is required before submit"));
		let r = [{
			type: "input_text",
			text: t.text
		}];
		return this.api.runAgent({
			AgentId: this.owner.agentId,
			SessionId: e.nativeSessionId,
			Messages: [{
				role: "user",
				content: r
			}],
			ResponsesInput: [{
				role: "user",
				content: r
			}],
			InvocationId: t.clientRequestId,
			IdempotencyKey: t.idempotencyKey,
			Metadata: { agentengine: { client_request_id: t.clientRequestId } },
			Stream: !0
		}, n);
	}
	interrupt(e, t, n = {}) {
		try {
			this.assertOwnedBinding(e);
		} catch (e) {
			return Promise.reject(e);
		}
		return e.nativeSessionId ? t.trim() ? this.api.cancelRun(this.owner.agentId, e.nativeSessionId, t, n) : Promise.reject(/* @__PURE__ */ Error("Invocation identity is required before interrupt")) : Promise.reject(/* @__PURE__ */ Error("Execution binding is required before interrupt"));
	}
	approve(e, t, n = {}) {
		try {
			this.assertOwnedBinding(e);
		} catch (e) {
			return Promise.reject(e);
		}
		return e.nativeSessionId ? this.api.submitInteraction({
			AgentId: this.owner.agentId,
			SessionId: e.nativeSessionId,
			RunId: t.runId,
			InteractionId: t.interactionId,
			ExpectedRevision: t.expectedRevision,
			Action: t.approve ? "approve" : "reject",
			Response: {},
			IdempotencyKey: t.idempotencyKey
		}, n) : Promise.reject(/* @__PURE__ */ Error("Execution binding is required before approve"));
	}
}, O = class {
	entries = /* @__PURE__ */ new Map();
	maxConversations;
	constructor(e = 32) {
		this.maxConversations = e;
	}
	apply(e, t, n = "live", r) {
		let i = this.entry(e, n), a = i.reducer.apply(t);
		return (a || r !== void 0) && (i.checkpoint = this.checkpoint(e, n, r)), a;
	}
	replace(e, t, n, r) {
		let i = new h();
		i.applyAll(t), this.entries.set(e, {
			reducer: i,
			checkpoint: this.checkpoint(e, n, r)
		}), this.evict();
	}
	snapshot(e) {
		return this.entries.get(e)?.reducer.snapshot();
	}
	checkpointFor(e) {
		return this.entries.get(e)?.checkpoint;
	}
	delete(e) {
		this.entries.delete(e);
	}
	clear() {
		this.entries.clear();
	}
	entry(e, t) {
		let n = this.entries.get(e);
		if (n && n.checkpoint.sourceRevision === t) return n;
		let r = {
			reducer: new h(),
			checkpoint: this.checkpoint(e, t)
		};
		return this.entries.set(e, r), this.evict(), r;
	}
	checkpoint(e, t, n) {
		return {
			conversationId: e,
			sourceRevision: t,
			projectionSchemaVersion: 1,
			cursor: n,
			updatedAt: Date.now()
		};
	}
	evict() {
		for (; this.entries.size > Math.max(1, this.maxConversations);) {
			let e = this.entries.keys().next().value;
			if (!e) return;
			this.entries.delete(e);
		}
	}
};
//#endregion
export { D as ApiSessionFacade, f as ConversationClientError, a as ConversationController, h as ConversationItemReducer, O as ConversationProjectionStore, n as DraftStore, x as HttpConversationClient, i as OutboxStore, v as RuntimeConversationIngress, l as agentBlockProfile, _ as agentBlockRendererCatalog, m as buildConversationInput, t as createConversationId, d as createConversationItemState, e as createNavigationEpoch, w as createTrustedRendererCatalog, o as decodeConversationInput, u as decodeConversationItem, g as decodeConversationSurface, r as isCurrentNavigation, C as persistedRuntimeFrame, s as preflightConversationInput, y as projectConversationItems, S as rebuildPersistedSessionHistory, p as reduceConversationItem, b as runtimeConversationIdentity, E as scanConversationHistory, T as searchConversationMessages, c as surfacePermitsInput };
