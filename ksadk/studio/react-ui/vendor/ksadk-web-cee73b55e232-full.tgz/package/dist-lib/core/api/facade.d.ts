import type { ApiFacade, CancelRunOptions } from './types.js';
import { type AgentEngineClientOptions } from '../../api/client.js';
/**
 * Instance-scoped AgentEngine action adapter.
 *
 * Hosted UI uses the zero-argument form. Embedded hosts create one instance
 * with their authenticated fetch and target agent, avoiding global fetch
 * mutation and cookie-based target selection.
 */
export declare class ApiFacadeImpl implements ApiFacade {
    private readonly client;
    constructor(options?: AgentEngineClientOptions);
    compactSession(agentId: string, sessionId: string): Promise<{
        Status: string;
    }>;
    listSessions(agentId: string, opts?: {
        page?: number;
        pageSize?: number;
        signal?: AbortSignal;
    }): Promise<{
        Sessions: unknown[];
        Total: number;
        Page: number;
        PageSize: number;
    }>;
    createSession(agentId: string, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        SessionId: string;
    }>;
    deleteSession(sessionId: string, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        Deleted?: boolean;
        RuntimeSync?: string;
    }>;
    getSession(sessionId: string, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        SessionId: string;
        AgentId?: string;
        Title?: string;
        UpdatedAt?: string;
        ActiveRunStatus?: string;
        ActiveInvocationId?: string;
        ActiveRunUpdatedAt?: string;
        ContextUsage?: {
            used_tokens: number;
            cached_tokens?: number;
            context_window_tokens: number;
            percent: number;
        } | null;
        TokenUsage?: {
            input_tokens: number;
            output_tokens: number;
            total_tokens: number;
            turns?: number;
            last_response_id?: string;
        } | null;
    }>;
    listSessionEvents(sessionId: string, opts?: {
        offset?: number;
        limit?: number;
        signal?: AbortSignal;
    }): Promise<{
        Events: unknown[];
        Total: number;
        Offset: number;
        Limit: number;
    }>;
    listSessionMessages(sessionId: string, opts?: {
        agentId?: string;
        afterSeqId?: number;
        beforeSeqId?: number;
        limit?: number;
        includeReasoning?: boolean;
        includeToolEvents?: boolean;
        includeAttachments?: boolean;
        signal?: AbortSignal;
    }): Promise<{
        Messages: unknown[];
        LatestSeqId: number;
        HasMore: boolean;
        NextCursor: number | null;
    }>;
    listSessionCheckpoints(params: {
        agentId: string;
        sessionId: string;
        runId?: string;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        Checkpoints: unknown[];
    }>;
    previewCheckpointResume(params: {
        agentId: string;
        sessionId: string;
        runId: string;
        checkpointId: string;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        Preview: unknown;
    }>;
    listToolReceipts(params: {
        agentId: string;
        sessionId: string;
        runId?: string;
        checkpointId?: string;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        ToolReceipts: unknown[];
    }>;
    runAgent(body: Record<string, unknown>, opts?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array<ArrayBufferLike>>>;
    resumeRun(params: {
        agentId: string;
        sessionId: string;
        runId: string;
        checkpointId: string;
        resumeAttemptId?: string;
        invocationId?: string;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array<ArrayBufferLike>>>;
    subscribeRunEvents(params: {
        sessionId: string;
        invocationId: string;
        afterSeqId: number;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array<ArrayBufferLike>>>;
    submitControl(command: {
        command_type: 'enqueue' | 'steer' | 'inject' | 'interrupt' | 'pause' | 'resume' | 'submit_interaction';
        idempotency_key: string;
        payload: Record<string, unknown>;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<import("../../types/agent-control.js").AgentControlReceipt>;
    submitInteraction(params: {
        AgentId: string;
        SessionId: string;
        RunId: string;
        InteractionId: string;
        ExpectedRevision: number;
        Action: 'approve' | 'reject' | 'submit' | 'cancel';
        Response: Record<string, unknown>;
        IdempotencyKey: string;
    }, opts?: {
        signal?: AbortSignal;
    }): Promise<import("../../types/agent-control.js").AgentControlReceipt>;
    getAgentStatus(opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    subscribeSessionEvents(sessionId: string, afterSeq: number, opts?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array<ArrayBufferLike>>>;
    cancelRun(agentId: string, sessionId: string, invocationId: string, opts?: CancelRunOptions): Promise<unknown>;
    getResponseFeedback(payload: Record<string, unknown>, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    upsertResponseFeedback(payload: Record<string, unknown>, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    deleteResponseFeedback(payload: Record<string, unknown>, opts?: {
        signal?: AbortSignal;
    }): Promise<void>;
    listWorkspaceFiles(agentId: string, path: string, recursive: boolean, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    addWorkspaceFile(formData: FormData, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    deleteWorkspaceFile(agentId: string, path: string, opts?: {
        signal?: AbortSignal;
    }): Promise<void>;
    getWorkspaceFileContent(agentId: string, path: string, opts?: {
        signal?: AbortSignal;
        asText?: boolean;
    }): Promise<string | Blob>;
    listAgentModels(agentId: string, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    getAgentUiBootstrap(agentId?: string, opts?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    uploadFile(formData: FormData, opts?: {
        signal?: AbortSignal;
    }): Promise<{
        FileData: {
            fileUri: string;
            displayName: string;
            mimeType: string;
        };
    }>;
}
//# sourceMappingURL=facade.d.ts.map