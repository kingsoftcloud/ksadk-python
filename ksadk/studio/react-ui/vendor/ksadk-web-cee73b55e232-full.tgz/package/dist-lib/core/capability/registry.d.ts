import type { CapabilityPlugin, CapabilitySlot, CapabilityContext } from './types.js';
import type { UiCapabilities } from '../../types/capabilities.js';
export declare class PluginRegistry {
    private plugins;
    register(plugin: CapabilityPlugin): void;
    getEnabled(capabilities: UiCapabilities): CapabilityPlugin[];
    getForSlot(slot: CapabilitySlot, capabilities: UiCapabilities, context: CapabilityContext): React.ComponentType[];
}
//# sourceMappingURL=registry.d.ts.map