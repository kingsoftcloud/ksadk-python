import type { ConversationItem, ConversationSurface } from './types.js';
import type { TrustedRendererCatalog } from './renderer-registry.js';
export type AgentExecutionStatus = 'submitted' | 'working' | 'input_required' | 'completed' | 'failed' | 'cancelled';
export type ExecutionScopeDescriptor = {
    schema: 'execution.scope/v1';
    scope_id: string;
    parent_scope_id: string;
    trigger_ref: {
        scope_id: string;
        item_id: string;
        call_id: string;
    };
    binding_id: string;
    agent: {
        id: string;
        name: string;
        version_id: string;
        protocol: string;
    };
    status: AgentExecutionStatus;
    started_at: number;
    ended_at: number | null;
    output_refs: Array<{
        scope_id: string;
        item_id: string;
        part_id?: string | null;
    }>;
    cancel: {
        capability: 'supported' | 'unsupported' | 'unknown';
        request_state: 'none' | 'cancel_requested' | 'unsupported' | 'unknown' | 'confirmed' | 'local_confirmed';
    };
};
export type AgentScopeAction = {
    sessionId: string;
    runId: string;
    scopeId: string;
    parentItemId: string;
};
/** Host-owned surface action. Interaction responses use the existing Interaction/v1 revision-CAS client. */
export type AgentCancelRequestState = 'none' | 'processing' | 'unknown' | 'unsupported';
export type AgentBlockActions = {
    cancel?: (action: AgentScopeAction) => void | AgentCancelRequestState | Promise<void | AgentCancelRequestState>;
    getCancelRequestState?: (action: AgentScopeAction) => AgentCancelRequestState;
};
/** Select only from a producer-declared, versioned surface and host renderer. */
export declare function bootstrapPresentationProfile(value: unknown, catalog?: TrustedRendererCatalog): 'agent-block-v1' | 'flat-v1';
export declare function agentBlockProfile(surface: ConversationSurface, catalog?: TrustedRendererCatalog): 'agent-block-v1' | 'flat-v1';
export declare function validateAgentItem(item: ConversationItem, previous?: ConversationItem): void;
//# sourceMappingURL=agent.d.ts.map