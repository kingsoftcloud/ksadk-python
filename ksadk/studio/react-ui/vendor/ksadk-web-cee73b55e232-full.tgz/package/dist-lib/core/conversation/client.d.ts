import type { ConversationClientOptions, ConversationItem, ConversationStreamResult, ConversationStreamTurnOptions, ConversationSurfaceBootstrap } from './types.js';
/**
 * Minimal HTTP/SSE reference client for ConversationSurface/Input/Item v1.
 *
 * It never accepts auth headers or credentials. Applications are expected to
 * inject a same-origin fetch implementation or an already-authenticated server
 * transport outside this protocol-neutral package.
 */
export declare class HttpConversationClient {
    private readonly fetcher?;
    private readonly ingressLane?;
    private readonly rendererCatalog?;
    private readonly baseUrl;
    private readonly maxReconnects;
    private readonly sleep;
    private readonly retryDelayMs;
    constructor(options?: ConversationClientOptions);
    private fetch;
    private url;
    private request;
    private assertOk;
    getSurface(agentId: string, sessionId: string, options?: {
        signal?: AbortSignal;
    }): Promise<ConversationSurfaceBootstrap>;
    streamTurn(options: ConversationStreamTurnOptions): Promise<ConversationStreamResult>;
}
export type { ConversationItem };
//# sourceMappingURL=client.d.ts.map