import type { ConversationItem } from './types.js';
export declare const CONTEXT_COMPACTION_SCHEMA = "conversation.item.context-compaction/v1";
export type ContextCompactionStatus = 'running' | 'completed' | 'cancelled' | 'failed' | 'paused' | 'unknown';
export declare const contextCompactionLabels: Record<ContextCompactionStatus, string>;
export declare function isContextCompaction(item: ConversationItem): boolean;
/** Passive view projection. The private summary and prompt never cross this boundary. */
export declare class ContextCompactionProjection {
    private readonly commit;
    private readonly active;
    constructor(commit: (item: ConversationItem) => void);
    accept(base: ConversationItem, kind: string, time: unknown): ConversationItem | null;
    settleRun(runId: string, eventType: string, eventId: string, time: unknown): void;
    private duration;
    private finish;
}
//# sourceMappingURL=context-compaction.d.ts.map