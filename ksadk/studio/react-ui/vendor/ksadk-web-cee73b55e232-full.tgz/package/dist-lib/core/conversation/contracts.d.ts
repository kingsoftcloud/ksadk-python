import type { ConversationItem, ConversationSurface, ConversationInput, ConversationInputDraft } from './types.js';
/** Decode the strict, provider-neutral ConversationInput/v1 contract. */
export declare function decodeConversationInput(value: unknown): ConversationInput | null;
/** Build only the frozen contract fields; callers must supply all identities. */
export declare function buildConversationInput(draft: ConversationInputDraft): ConversationInput;
/** Enforce the active Surface before any network request is created. */
export declare function preflightConversationInput(surface: ConversationSurface, input: ConversationInput): ConversationInput;
/** Decode the frozen ConversationSurface/v1 contract without guessing controls. */
export declare function decodeConversationSurface(value: unknown): ConversationSurface | null;
/**
 * Decode ConversationItem/v1. Future item kinds remain inspectable in the
 * canonical stream but are hidden from the default transcript.  A client must
 * never turn an additive provider event into a repeating user-facing fallback
 * card. Unknown contract versions or unsafe structural fields are rejected
 * instead of being guessed.
 */
export declare function decodeConversationItem(value: unknown): ConversationItem | null;
/** Whether this surface allows the browser to submit any of the named inputs. */
export declare function surfacePermitsInput(surface: ConversationSurface, ...names: string[]): boolean;
//# sourceMappingURL=contracts.d.ts.map