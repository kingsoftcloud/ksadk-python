import type { ConversationClientErrorCode, ConversationClientErrorDetails } from './types.js';
/** Stable, non-secret-bearing failures for headless conversation clients. */
export declare class ConversationClientError extends Error {
    readonly code: ConversationClientErrorCode;
    readonly status?: number;
    readonly capability?: string;
    readonly runId?: string;
    readonly cursor?: number;
    readonly cause?: unknown;
    constructor(code: ConversationClientErrorCode, message: string, details?: ConversationClientErrorDetails);
}
//# sourceMappingURL=errors.d.ts.map