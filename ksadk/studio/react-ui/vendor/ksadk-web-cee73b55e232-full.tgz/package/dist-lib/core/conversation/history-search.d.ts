import type { Message } from '../../components/chat/types.js';
export type HistorySearchMatch = {
    messageId: string;
    role: Message['role'];
    excerpt: string;
};
export type HistorySearchResult = {
    matches: HistorySearchMatch[];
    matchedMessages: number;
    searchedMessages: number;
    complete: boolean;
};
export type HistorySearchSnapshot = {
    owner: string;
    messages: Message[];
    hasMore: boolean;
    loading: boolean;
    checkpoint: string;
    error?: string;
};
/** Search readable projection data, including rows outside the virtual DOM.
 * Never index hidden reasoning or arbitrary protocol objects. */
export declare function searchConversationMessages(messages: Message[], query: string): HistorySearchResult;
/** Read existing history pages only. The owner and abort checks also guard
 * hosts whose transport resolves after cancellation. No execution is started. */
export declare function scanConversationHistory(options: {
    query: string;
    snapshot: () => HistorySearchSnapshot;
    readOlder: (signal: AbortSignal) => Promise<void>;
    signal: AbortSignal;
    onProgress?: (result: HistorySearchResult) => void;
}): Promise<HistorySearchResult>;
//# sourceMappingURL=history-search.d.ts.map