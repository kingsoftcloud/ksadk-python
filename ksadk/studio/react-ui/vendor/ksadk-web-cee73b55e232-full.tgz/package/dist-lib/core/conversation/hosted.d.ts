/**
 * Hosted UI presentation bridge for an already-reduced canonical snapshot.
 *
 * Identity, append/replace/completed, reconnect replay and terminal monotonicity
 * remain exclusively owned by ConversationItemReducer/HttpConversationClient.
 * This module only maps the passive shared projection into existing Hosted UI
 * view models; it never reduces provider events itself.
 */
import type { Message } from '../../components/chat/types.js';
import type { Interaction } from '../interaction/types.js';
import type { ConversationItem, ConversationStreamResult } from './types.js';
export type HostedConversationProjection = {
    messages: Message[];
    interactions: Interaction[];
};
/** Shared live/history notice projection; never reconstruct acceptance from prose. */
export declare function conversationRunOutcomeMessage(item: ConversationItem): Message | null;
/** Map one shared canonical snapshot to the existing Hosted UI view models. */
export declare function projectConversationStreamForHostedUi(result: ConversationStreamResult): HostedConversationProjection;
/**
 * Replace this run's transcript projection. Once a run has canonical items,
 * the durable legacy read model for the same run is a replay source, not a
 * second presentation owner. Other runs/transports remain untouched; equal
 * text from distinct canonical item IDs is never merged.
 */
export declare function mergeConversationRunMessages(previous: Message[], result: ConversationStreamResult, optimisticMessageId?: string): Message[];
//# sourceMappingURL=hosted.d.ts.map