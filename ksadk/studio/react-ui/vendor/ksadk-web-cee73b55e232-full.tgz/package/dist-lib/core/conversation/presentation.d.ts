import type { ConversationItem, ConversationItemReducerState, ConversationPresentation, ConversationProjectionOptions, ConversationRunOutcome } from './types.js';
/**
 * Return a run-level terminal state only for an explicit run status.
 *
 * Item lifecycle is scoped to one item. A completed user message, tool call,
 * approval, usage report, or provider notification must never unlock the
 * composer while the containing run is still active.
 */
export declare function conversationTerminalStatus(item: ConversationItem): 'completed' | 'failed' | undefined;
/** Completion settles execution. Acceptance is a separate, explicit host fact. */
export declare function conversationRunOutcome(item: ConversationItem): ConversationRunOutcome | undefined;
/**
 * Produce passive renderer data. Unknown kinds or payload schema versions are
 * converted to fallback cards; A2UI and approvals remain typed data and are
 * never executed by this projection.
 */
export declare function projectConversationItems(state: ConversationItemReducerState, options?: ConversationProjectionOptions): ConversationPresentation;
//# sourceMappingURL=presentation.d.ts.map