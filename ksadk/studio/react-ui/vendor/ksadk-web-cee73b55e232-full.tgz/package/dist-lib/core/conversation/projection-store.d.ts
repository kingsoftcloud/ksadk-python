import type { ConversationItem, ConversationItemReducerState } from './types.js';
import type { ConversationId } from './studio-controller.js';
export type ProjectionCheckpoint = {
    conversationId: ConversationId;
    sourceRevision: string;
    projectionSchemaVersion: 1;
    cursor?: number;
    updatedAt: number;
};
/** Bounded in-memory projection cache; the authoritative runtime log remains external. */
export declare class ConversationProjectionStore {
    private readonly entries;
    private readonly maxConversations;
    constructor(maxConversations?: number);
    apply(conversationId: ConversationId, item: ConversationItem, sourceRevision?: string, cursor?: number): boolean;
    replace(conversationId: ConversationId, items: Iterable<ConversationItem>, sourceRevision: string, cursor?: number): void;
    snapshot(conversationId: ConversationId): ConversationItemReducerState | undefined;
    checkpointFor(conversationId: ConversationId): ProjectionCheckpoint | undefined;
    delete(conversationId: ConversationId): void;
    clear(): void;
    private entry;
    private checkpoint;
    private evict;
}
//# sourceMappingURL=projection-store.d.ts.map