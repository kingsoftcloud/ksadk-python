import type { ConversationItem, ConversationItemReducerState } from './types.js';
export declare function createConversationItemState(): ConversationItemReducerState;
/**
 * Apply one item operation using wire identity only.
 *
 * Reconnect replay is idempotent per `(itemId, sourceEventId)`. The reducer
 * never compares authors or payload text, so two items with identical content
 * remain distinct. Once an item is terminal, a late streaming replay cannot
 * make it non-terminal again.
 */
export declare function reduceConversationItem(state: ConversationItemReducerState, incoming: ConversationItem): ConversationItemReducerState;
/** Small stateful facade for applications that do not keep their own store. */
export declare class ConversationItemReducer {
    private state;
    apply(item: ConversationItem): boolean;
    applyAll(items: Iterable<ConversationItem>): void;
    snapshot(): ConversationItemReducerState;
}
//# sourceMappingURL=reducer.d.ts.map