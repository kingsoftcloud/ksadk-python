import type { ConversationItem, ConversationItemKind } from './types.js';
/**
 * A renderer declaration compiled into the trusted frontend bundle.
 *
 * This is deliberately an immutable catalog, not a runtime plugin API. A
 * Provider may produce a schema only after the host frontend ships its
 * matching renderer; Runtime payloads never supply executable renderer code.
 */
export type TrustedConversationRenderer = {
    id: string;
    schemaRef: string;
    kinds: readonly ConversationItemKind[];
};
export type TrustedRendererCatalog = {
    resolve(item: ConversationItem): TrustedConversationRenderer | undefined;
    entries(): readonly TrustedConversationRenderer[];
};
/** Build and freeze the host's exact kind/schema dispatch table once. */
export declare function createTrustedRendererCatalog(renderers: readonly TrustedConversationRenderer[]): TrustedRendererCatalog;
export declare const agentBlockRendererCatalog: TrustedRendererCatalog;
//# sourceMappingURL=renderer-registry.d.ts.map