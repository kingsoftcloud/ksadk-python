import { ConversationItemReducer } from './reducer.js';
import type { ConversationItem, ConversationItemReducerState } from './types.js';
export declare const runtimeConversationIdentity: (run: string, scope: string, item: string) => string;
/** Compatibility ingress only. Native ConversationItem streams use their own authoritative lane. */
export declare class RuntimeConversationIngress {
    private readonly runtime;
    private readonly flatChildren;
    private readonly seen;
    private readonly parents;
    private readonly descriptorItemIds;
    private readonly descriptors;
    private rootScope;
    private runId;
    private readonly sessionId;
    private readonly conversation;
    private readonly profile;
    private readonly context;
    constructor(sessionId: string, conversation?: ConversationItemReducer, profile?: 'agent-block-v1' | 'flat-v1');
    private identity;
    snapshot(): ConversationItemReducerState;
    apply(frame: Record<string, unknown>): ConversationItem | null;
}
//# sourceMappingURL=runtime-ingress.d.ts.map