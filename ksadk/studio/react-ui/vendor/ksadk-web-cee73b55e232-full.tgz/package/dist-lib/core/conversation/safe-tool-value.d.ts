/** Defense in depth for public tool observations; never render credential/transport diagnostics. */
export declare function safeToolValue(value: unknown, depth?: number): unknown;
//# sourceMappingURL=safe-tool-value.d.ts.map