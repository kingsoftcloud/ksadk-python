import type { ApiFacade } from '../api/types.js';
import type { AgentBlockActions, AgentScopeAction } from './agent.js';
import type { ConversationItem } from './types.js';
/** Deterministic across remount, refresh and retry; the server owns deduplication. */
export declare function scopedCancelClientToken(agentId: string, action: AgentScopeAction): Promise<string>;
/** The host supplies the current authenticated session and canonical descriptors. */
export declare function createScopedAgentBlockActions(options: {
    api: Pick<ApiFacade, 'cancelRun'>;
    agentId: string;
    getContext: () => {
        sessionId: string;
        supported: boolean;
        items: readonly ConversationItem[];
    };
}): AgentBlockActions;
//# sourceMappingURL=scoped-cancel.d.ts.map