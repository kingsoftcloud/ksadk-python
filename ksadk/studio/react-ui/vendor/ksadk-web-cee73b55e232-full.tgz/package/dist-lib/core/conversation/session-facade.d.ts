import type { ApiFacade } from '../api/types.js';
import type { AgentControlReceipt } from '../../types/agent-control.js';
import type { ConversationBinding, ConversationId } from './studio-controller.js';
export type SessionSummary = {
    sessionId: string;
    title?: string;
    updatedAt?: string;
    activeRunStatus?: string;
    activeInvocationId?: string;
};
export type SessionOwner = {
    agentId: string;
    targetId?: string;
    tenantId?: string;
    workspaceId?: string;
};
export type SessionFacade = {
    listSessionSummaries(options?: {
        page?: number;
        pageSize?: number;
        signal?: AbortSignal;
    }): Promise<{
        items: SessionSummary[];
        total: number;
        nextPage?: number;
    }>;
    readHistoryWindow(binding: ConversationBinding, options?: {
        offset?: number;
        limit?: number;
        signal?: AbortSignal;
    }): Promise<{
        items: unknown[];
        total: number;
        nextOffset?: number;
    }>;
    watchCurrentState(binding: ConversationBinding, options?: {
        signal?: AbortSignal;
    }): Promise<SessionSummary>;
    ensureExecutionBinding(conversationId: ConversationId, options?: {
        signal?: AbortSignal;
    }): Promise<ConversationBinding>;
    submit(binding: ConversationBinding, input: {
        text: string;
        clientRequestId: string;
        idempotencyKey: string;
    }, options?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array>>;
    interrupt(binding: ConversationBinding, invocationId: string, options?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    approve(binding: ConversationBinding, input: {
        interactionId: string;
        runId: string;
        expectedRevision: number;
        approve: boolean;
        idempotencyKey: string;
    }, options?: {
        signal?: AbortSignal;
    }): Promise<AgentControlReceipt>;
};
/** Adapter that gives Studio one Query / Command / Feed boundary over the existing API. */
export declare class ApiSessionFacade implements SessionFacade {
    private readonly bindings;
    private readonly pendingBindings;
    private readonly api;
    private readonly owner;
    constructor(api: ApiFacade, owner: SessionOwner);
    private assertOwnedBinding;
    listSessionSummaries(options?: {
        page?: number;
        pageSize?: number;
        signal?: AbortSignal;
    }): Promise<{
        items: {
            sessionId: string;
            title: string | undefined;
            updatedAt: string | undefined;
            activeRunStatus: string | undefined;
            activeInvocationId: string | undefined;
        }[];
        total: number;
        nextPage: number | undefined;
    }>;
    readHistoryWindow(binding: ConversationBinding, options?: {
        offset?: number;
        limit?: number;
        signal?: AbortSignal;
    }): Promise<{
        items: never[];
        total: number;
        nextOffset?: undefined;
    } | {
        items: unknown[];
        total: number;
        nextOffset: number | undefined;
    }>;
    watchCurrentState(binding: ConversationBinding, options?: {
        signal?: AbortSignal;
    }): Promise<{
        sessionId: string;
        title: undefined;
        updatedAt?: undefined;
        activeRunStatus?: undefined;
        activeInvocationId?: undefined;
    } | {
        sessionId: string;
        title: string | undefined;
        updatedAt: string | undefined;
        activeRunStatus: string | undefined;
        activeInvocationId: string | undefined;
    }>;
    ensureExecutionBinding(conversationId: ConversationId, options?: {
        signal?: AbortSignal;
    }): Promise<ConversationBinding>;
    submit(binding: ConversationBinding, input: {
        text: string;
        clientRequestId: string;
        idempotencyKey: string;
    }, options?: {
        signal?: AbortSignal;
    }): Promise<ReadableStream<Uint8Array<ArrayBufferLike>>>;
    interrupt(binding: ConversationBinding, invocationId: string, options?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    approve(binding: ConversationBinding, input: {
        interactionId: string;
        runId: string;
        expectedRevision: number;
        approve: boolean;
        idempotencyKey: string;
    }, options?: {
        signal?: AbortSignal;
    }): Promise<AgentControlReceipt>;
}
//# sourceMappingURL=session-facade.d.ts.map