/** Stable client-side conversation primitives used by Studio shells. */
export type ConversationId = `conversation_${string}`;
export type ConversationBinding = {
    conversationId: ConversationId;
    nativeSessionId?: string;
    agentId: string;
    targetId?: string;
    /** Optional identity dimensions used by host adapters for owner checks. */
    tenantId?: string;
    workspaceId?: string;
};
export type DraftSession = {
    conversationId: ConversationId;
    text: string;
    revision: number;
    updatedAt: number;
    /** Files stay in this owner's memory; they are never serialized as credentials or URLs. */
    attachments: File[];
};
export type DraftConflict = {
    conversationId: ConversationId;
    local: DraftSession;
    remote: Pick<DraftSession, 'text' | 'revision' | 'updatedAt'> | null;
    detectedAt: number;
};
export type OutboxStatus = 'pending' | 'sending' | 'unknown' | 'failed' | 'delivered' | 'completed' | 'cancelled';
export type OutboxAttachment = {
    name: string;
    type: string;
    size: number;
};
export type OutboxEntry = {
    requestId: string;
    conversationId: ConversationId;
    agentId: string;
    text: string;
    attachments: OutboxAttachment[];
    executionMode?: string;
    nativeSessionId?: string;
    invocationId?: string;
    status: OutboxStatus;
    attempt: number;
    createdAt: number;
    updatedAt: number;
    error?: string;
};
/**
 * Durable client submission ledger. It stores intent and file metadata only;
 * file bytes stay in the in-memory composer until the runtime accepts them.
 * Unknown outcomes are retained for reconciliation and are never retried by
 * this class implicitly.
 */
export declare class OutboxStore {
    private readonly entries;
    private readonly storageKey;
    private readonly maxEntries;
    private readonly listeners;
    /** File bytes are runtime-only; restored entries intentionally have none. */
    private readonly runtimeAttachments;
    constructor(storageKey?: string, maxEntries?: number);
    enqueue(input: Omit<OutboxEntry, 'requestId' | 'status' | 'attempt' | 'createdAt' | 'updatedAt'> & {
        requestId?: string;
    }): OutboxEntry;
    get(requestId: string): OutboxEntry | undefined;
    setRuntimeAttachments(requestId: string, files: File[]): void;
    getRuntimeAttachments(requestId: string): File[];
    subscribe(listener: () => void): () => void;
    list(conversationId?: ConversationId): OutboxEntry[];
    /** Entries that need an explicit reconciliation or retry decision. */
    listUnresolved(conversationId?: ConversationId): OutboxEntry[];
    update(requestId: string, patch: Partial<Pick<OutboxEntry, 'status' | 'error' | 'nativeSessionId' | 'invocationId'>> & {
        attempt?: number;
    }): OutboxEntry | undefined;
    markSending(requestId: string): OutboxEntry | undefined;
    /**
     * Requeue a failed/unknown intent after the host has explicitly decided to
     * retry it. Completed, cancelled, and currently sending entries are never
     * silently reopened.
     */
    requeue(requestId: string): OutboxEntry | undefined;
    remove(requestId: string): void;
    clear(): void;
    private evict;
    private restore;
    private persist;
}
export declare function createConversationId(random?: () => number): ConversationId;
export declare function createNavigationEpoch(): {
    readonly current: number;
    next: () => number;
};
export declare class DraftStore {
    private readonly drafts;
    private readonly conflicts;
    private readonly listeners;
    private readonly storageKey;
    private readonly maxEntries;
    private readonly storageListener?;
    constructor(storageKey?: string, maxEntries?: number);
    get(conversationId: ConversationId): DraftSession;
    set(conversationId: ConversationId, text: string, attachments?: File[]): DraftSession;
    delete(conversationId: ConversationId): void;
    clear(): void;
    size(): number;
    subscribe(listener: () => void): () => void;
    getConflict(conversationId: ConversationId): DraftConflict | undefined;
    resolveConflict(conversationId: ConversationId, choice: 'local' | 'remote'): DraftSession | undefined;
    dispose(): void;
    private restore;
    /** Keep recent editable state bounded while leaving native session facts intact. */
    private evict;
    private persist;
    private notify;
    private applyExternal;
}
/** Coordinates view identity without owning a runtime or cancelling runs. */
export declare class ConversationController {
    readonly drafts: DraftStore;
    readonly outbox: OutboxStore;
    private readonly storageKey;
    private readonly ids;
    private readonly bindings;
    /** In-memory order of local drafts that have not acquired a native session. */
    private readonly unboundDrafts;
    private readonly epoch;
    constructor(storageKey?: string);
    navigate(): number;
    get navigationEpoch(): number;
    getOrCreate(agentId: string, sessionId: string | null, targetId?: string): ConversationId;
    bindNative(conversationId: ConversationId, nativeSessionId: string): ConversationBinding;
    /** Each explicit new action creates a distinct local draft, without touching a host. */
    createDraft(agentId: string, targetId?: string): ConversationId;
    /** Discard all owner-scoped state on logout or workspace disposal. */
    clear(): void;
    private restoreIds;
    private persistIds;
    /** Bound local drafts cannot evict native sessions or unresolved commands. */
    private pruneUnboundDrafts;
    private key;
    binding(conversationId: ConversationId): ConversationBinding | undefined;
}
export declare function isCurrentNavigation(epoch: number, expected: number): boolean;
//# sourceMappingURL=studio-controller.d.ts.map