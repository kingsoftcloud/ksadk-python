/**
 * A2UI v0.9.1 presentation validation with a safe fallback ladder.
 *
 * The production wire is locked to v0.9.1 with a pinned catalog digest.
 * When the wire version or catalog digest does not match, the tray falls
 * back to the canonical JSON schema form; when that is unsupported it
 * falls back to plain approve/reject/text controls. A validation failure
 * is never mapped to an approval.
 */
import type { A2uiPresentation } from './types.js';
export declare const A2UI_WIRE_VERSION = "0.9.1";
/** Deterministic digest of the local A2UI catalog. */
export declare function computeA2uiCatalogDigest(catalog: unknown): string;
export type A2uiRenderMode = 'a2ui' | 'json-schema-form' | 'basic-controls';
/**
 * Decide how an Interaction's presentation may render. Unknown components
 * or a catalog mismatch never yield 'a2ui'; the safest usable fallback
 * wins.
 */
export declare function validateA2uiPresentation(presentation: A2uiPresentation | null | undefined, localCatalog: unknown): A2uiRenderMode;
//# sourceMappingURL=a2ui-validate.d.ts.map