/**
 * AG-UI transport adapter.
 *
 * Normalizes an AG-UI interrupt-driven approval request (RunEvent
 * `approval_requested` with protocol `ag-ui`, or an AG-UI interrupt
 * payload) into the shared Interaction shape. The original interrupt id
 * is preserved in `extensions.interrupt_id` so the 0.3.1
 * `resumeAguiInterrupt` fallback still works for servers that do not
 * advertise `interaction_v1`.
 */
import type { Interaction } from '../types.js';
export type AguiInterruptRequest = {
    interruptId: string;
    sessionId: string;
    runId?: string | null;
    toolCallId?: string | null;
    name?: string;
    message?: string;
    reason?: string;
    requestSchema?: Record<string, unknown> | null;
};
export declare function interactionFromAguiInterrupt(request: AguiInterruptRequest): Interaction | null;
//# sourceMappingURL=agui.d.ts.map