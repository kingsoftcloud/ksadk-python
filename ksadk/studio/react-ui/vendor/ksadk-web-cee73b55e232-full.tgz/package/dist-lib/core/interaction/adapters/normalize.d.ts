/**
 * Shared normalization helpers for Interaction transport adapters.
 *
 * Every adapter produces the same Interaction shape so the store, tray,
 * and submit path never branch on the transport protocol.
 */
import type { Interaction, InteractionSource } from '../types.js';
export type RawInteractionFields = {
    interactionId: string;
    sessionId: string;
    runId?: unknown;
    kind?: unknown;
    title?: unknown;
    message?: unknown;
    requestSchema?: unknown;
    presentation?: unknown;
    status?: unknown;
    revision?: unknown;
    createdAt?: unknown;
    expiresAt?: unknown;
    resolvedAt?: unknown;
    actor?: unknown;
    outcome?: unknown;
    responseSummary?: unknown;
    extensions?: Record<string, unknown>;
    source: InteractionSource;
};
export declare function normalizeInteraction(fields: RawInteractionFields): Interaction;
//# sourceMappingURL=normalize.d.ts.map