/**
 * Responses transport adapter (`/v1/responses` official semantics).
 *
 * Normalizes the official `mcp_approval_request` item (delivered either
 * as a stream action or as a SessionEvent record) into the shared
 * Interaction shape. Responses-driven submissions keep the official
 * `mcp_approval_response` path — the adapter marks the record
 * `source: "responses"` so the submit path can route accordingly without
 * components ever branching on protocol.
 */
import type { Interaction } from '../types.js';
export type ResponsesApprovalRequest = {
    approvalRequestId: string;
    sessionId: string;
    runId?: string | null;
    name?: string;
    message?: string;
    approvalLevel?: string;
    args?: string;
    requestSchema?: Record<string, unknown> | null;
};
export declare function interactionFromResponsesApproval(request: ResponsesApprovalRequest): Interaction | null;
/** Build the official Responses `mcp_approval_response` input item. */
export declare function buildMcpApprovalResponse(approvalRequestId: string, approve: boolean): Record<string, unknown>;
//# sourceMappingURL=responses.d.ts.map