/**
 * AgentEngine Interaction/v1 SessionEvent adapter.
 *
 * `SessionEventEnvelope.payload` carries the public Interaction facts:
 * event_type `interaction.requested` / `ksadk.interaction/v1.requested`
 * creates a pending Interaction; `interaction.resolved` (outcome in
 * payload) closes it. Rejection is `resolved.outcome="rejected"`, not a
 * fifth terminal event type.
 */
import type { Interaction } from '../types.js';
/**
 * Normalize an Interaction/v1 SessionEvent payload (or envelope) into the
 * shared Interaction shape. Returns null when the event is not an
 * interaction event.
 */
export declare function interactionFromSessionEvent(raw: unknown, fallbackSessionId?: string): Interaction | null;
//# sourceMappingURL=session-events.d.ts.map