/**
 * Headless InteractionClient implementation.
 *
 * One submit path per record source:
 * - `interaction_v1` (AgentEngine Interaction/v1): every action is one
 *   `POST /agentengine/api/v1/SubmitInteraction` call with revision CAS
 *   and an idempotency key.
 * - `responses`: official `/v1/responses` `mcp_approval_response` path
 *   (0.3.1 fallback for servers without `interaction_v1`).
 * - `agui`: `resumeAguiInterrupt` (0.3.1 fallback).
 *
 * Components never branch on the source — they call `respond()`.
 */
import { type Interaction, type InteractionAction, type InteractionClient, type InteractionEvent, type InteractionReceipt, type InteractionSubmitInput } from './types.js';
import { InteractionStore } from './store.js';
export type SubmitInteractionTransport = (params: {
    AgentId: string;
    SessionId: string;
    RunId: string;
    InteractionId: string;
    ExpectedRevision: number;
    Action: InteractionAction;
    Response: Record<string, unknown>;
    IdempotencyKey: string;
}) => Promise<unknown>;
export type InteractionClientDeps = {
    agentId: string;
    store?: InteractionStore;
    submitInteraction: SubmitInteractionTransport;
    /**
     * When bootstrap advertises `interaction_v1`, every action goes through
     * SubmitInteraction regardless of the transport that produced the
     * pending record.
     */
    interactionV1Enabled?: boolean;
    /** @deprecated 0.3.1 Responses `mcp_approval_response` fallback. */
    legacyResponsesApproval?: (interactionId: string, approve: boolean) => boolean | void | Promise<boolean | void>;
    /** @deprecated 0.3.1 AG-UI `resumeAguiInterrupt` fallback. */
    legacyAguiResume?: (interruptId: string, status: 'resolved' | 'cancelled', payload?: unknown) => boolean;
};
export declare class InteractionClientImpl implements InteractionClient {
    readonly store: InteractionStore;
    private deps;
    /** interactionId -> in-flight idempotency key (double-submit guard). */
    private inFlight;
    constructor(deps: InteractionClientDeps);
    listPending(sessionId: string): readonly Interaction[];
    /** Update capability routing after bootstrap capabilities change. */
    setInteractionV1Enabled(enabled: boolean): void;
    subscribe(listener: (event: InteractionEvent) => void): () => void;
    /** Normalize + persist an incoming Interaction (adapter output). */
    ingest(interaction: Interaction): void;
    /**
     * Restore state from replayed history. Only upserts server facts —
     * never issues a submit — so a refresh/replay restores a pending
     * Interaction without creating a second request.
     */
    ingestHistory(interactions: readonly Interaction[]): void;
    private findByInteractionId;
    respond(input: InteractionSubmitInput): Promise<InteractionReceipt>;
    private resolveLocal;
}
//# sourceMappingURL=client.d.ts.map