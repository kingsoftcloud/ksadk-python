/**
 * Single Interaction store.
 *
 * Holds the normalized Interaction records for all sessions and enforces
 * first-wins terminal semantics locally: a terminal record never
 * regresses to pending, so a replayed history or a racing second tab
 * cannot resurrect an already-resolved decision.
 */
import { type Interaction, type InteractionEvent } from './types.js';
export type InteractionStoreListener = (event: InteractionEvent) => void;
export declare class InteractionStore {
    /** key: `${sessionId}\u0000${interactionId}` */
    private records;
    /** Run terminal facts can arrive before replay reaches its interaction. */
    private terminalRuns;
    private rejectedCommands;
    private listeners;
    private key;
    private runKey;
    subscribe(listener: InteractionStoreListener): () => void;
    private emit;
    get(sessionId: string, interactionId: string): Interaction | null;
    listPending(sessionId: string): readonly Interaction[];
    listAll(sessionId: string): readonly Interaction[];
    all(): readonly Interaction[];
    /**
     * Insert or merge an Interaction. Returns the emitted event.
     *
     * - A terminal record never regresses to a non-terminal status
     *   (first-wins).
     * - A newer revision of the same status wins (revision CAS).
     * - Terminal facts (actor, outcome, resolvedAt, responseSummary) are
     *   preserved on merge.
     */
    upsert(interaction: Interaction): InteractionEvent;
    /** Locally mark a record as resolving while a submit is in flight. */
    markResolving(sessionId: string, interactionId: string): void;
    /** Locally resolve a record (optimistic legacy paths). */
    resolveLocally(sessionId: string, interactionId: string, patch: Partial<Pick<Interaction, 'status' | 'outcome' | 'actor' | 'responseSummary' | 'resolvedAt' | 'revision'>>): void;
    /** Correlate durable Inbox receipts with later execution rejections. */
    recordCommand(sessionId: string, interactionId: string, commandId: string): void;
    rejectCommand(sessionId: string, commandId: string, reason: string): void;
    /** Attach an idempotency key to a resolving record (replay correlation). */
    recordIdempotencyKey(sessionId: string, interactionId: string, key: string): void;
    /** Locally mark a submit as failed after a definitive receipt rejection. */
    markFailed(sessionId: string, interactionId: string, error: {
        code: string;
        message: string;
        retryable: boolean;
    }): void;
    /** Revert a resolving record to pending (retryable receipt, legacy rejection). */
    revertToPending(sessionId: string, interactionId: string): void;
    /** Close every actionable interaction when its owning run reaches a terminal state. */
    markRunTerminal(sessionId: string, runId: string): void;
    /** Close the active session's open cards when a transport terminal is run-scoped only implicitly. */
    markSessionTerminal(sessionId: string): void;
    remove(sessionId: string, interactionId: string): void;
    clearSession(sessionId: string): void;
}
//# sourceMappingURL=store.d.ts.map