/**
 * Interaction/v1 client-side types.
 *
 * Mirrors the canonical `contracts/agent-kernel/v1/interaction.schema.json`:
 * one durable Interaction identity per human decision, revision-based
 * optimistic concurrency, and first-wins terminal semantics. Responses
 * approval requests and AG-UI interrupts are transport adapters that
 * normalize into this single shape — components never branch on
 * `approvalProtocol`.
 */
import type { AgentControlReceipt } from '../../types/agent-control.js';
export type InteractionStatus = 'pending' | 'resolving' | 'failed' | 'resolved' | 'cancelled' | 'expired';
export type InteractionAction = 'approve' | 'reject' | 'submit' | 'cancel';
export type InteractionKind = 'approval' | 'structured_input' | 'plan_review' | 'custom';
/** Which transport surface produced the normalized Interaction. */
export type InteractionSource = 'interaction_v1' | 'responses' | 'agui';
export type A2uiPresentation = {
    /** Production wire is locked to "0.9.1". */
    wireVersion: string;
    /** Pinned catalog digest required before rendering A2UI. */
    catalogDigest: string;
    messages: Array<Record<string, unknown>>;
};
export type InteractionPresentation = {
    a2ui?: A2uiPresentation;
};
export type InteractionOutcome = 'approved' | 'rejected' | 'submitted' | 'cancelled' | 'expired';
/**
 * The single normalized Interaction record. Internal provider fields
 * (native targets, checkpoints, permits) never appear here — the server
 * redacts them before emitting public events.
 */
export type Interaction = {
    interactionId: string;
    sessionId: string;
    runId: string | null;
    kind: InteractionKind;
    title: string;
    message: string;
    requestSchema: Record<string, unknown> | null;
    presentation: InteractionPresentation | null;
    status: InteractionStatus;
    revision: number;
    createdAt: string;
    expiresAt: string | null;
    resolvedAt: string | null;
    actor: string | null;
    outcome: InteractionOutcome | null;
    /** Redacted summary of the submitted response; never raw secrets. */
    responseSummary: string | null;
    source: InteractionSource;
    extensions: Record<string, unknown>;
};
export type InteractionEvent = {
    type: 'interaction_requested';
    interaction: Interaction;
} | {
    type: 'interaction_updated';
    interaction: Interaction;
} | {
    type: 'interaction_resolved';
    interaction: Interaction;
} | {
    type: 'interaction_removed';
    interactionId: string;
};
export type InteractionSubmitInput = {
    interactionId: string;
    expectedRevision: number;
    action: InteractionAction;
    response: Record<string, unknown>;
    idempotencyKey: string;
};
export type InteractionReceipt = AgentControlReceipt;
/**
 * Headless public API. Transport-agnostic: every AgentEngine
 * Interaction/v1 action goes through one `respond` call.
 */
export interface InteractionClient {
    listPending(sessionId: string): readonly Interaction[];
    subscribe(listener: (event: InteractionEvent) => void): () => void;
    respond(input: InteractionSubmitInput): Promise<InteractionReceipt>;
}
/** Statuses that may only be set by an authoritative terminal SessionEvent. */
export declare const TERMINAL_INTERACTION_STATUSES: ReadonlySet<InteractionStatus>;
export declare function isTerminalInteraction(status: InteractionStatus): boolean;
/** Default idempotency key derivation: stable per (id, revision). */
export declare function interactionIdempotencyKey(interactionId: string, expectedRevision: number): string;
/** Redact a response payload into a short human-readable summary. */
export declare function summarizeResponse(action: InteractionAction, response: Record<string, unknown>): string;
//# sourceMappingURL=types.d.ts.map