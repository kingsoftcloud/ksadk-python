export declare const ksadkA2uiCatalog: import("@copilotkit/a2ui-renderer").Catalog<import("@copilotkit/a2ui-renderer").ReactComponentImplementation>;
export declare const ksadkA2uiAgentContext: {
    description: string;
    value: string;
};
/**
 * CopilotKit's v0.9 React renderer always begins rendering at component id
 * `root`. Early local A2UI events used a surface-specific `*-root` id and
 * were persisted that way. Keep the repair deliberately narrow so a valid
 * A2UI tree is never rewritten.
 */
export declare function normalizeA2uiOperations(operations: Array<Record<string, unknown>>): Array<Record<string, unknown>>;
/** Read-only recovery for the retired Codex question form, absent from basicCatalog. */
export declare function legacyQuestionSummary(operations: Array<Record<string, unknown>>): string[] | null;
//# sourceMappingURL=a2ui.d.ts.map