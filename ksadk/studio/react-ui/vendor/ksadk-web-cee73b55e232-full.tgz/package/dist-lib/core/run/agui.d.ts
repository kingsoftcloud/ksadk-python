import { type RunAgentResult } from '@ag-ui/client';
import type { RunEvent } from './types.js';
type AguiRunStatus = 'completed' | 'interrupted' | 'failed' | 'cancelled';
type AguiRunResult = {
    status: AguiRunStatus;
    result: RunAgentResult;
};
type AguiRunClientOptions = {
    url: string;
    agentId: string;
    threadId: string;
    onEvent: (event: RunEvent) => void;
    fetch?: typeof fetch;
};
export declare class AguiRunClient {
    private readonly agent;
    private readonly onEvent;
    private readonly tools;
    private readonly runMessageIds;
    private readonly pendingByRun;
    private activeRunId;
    constructor(options: AguiRunClientOptions);
    run(text: string, runId: string, signal?: AbortSignal): Promise<AguiRunResult>;
    resume(runId: string, response: {
        interruptId: string;
        status: 'resolved' | 'cancelled';
        payload?: unknown;
    }): Promise<AguiRunResult>;
    abort(): void;
    private controllerFor;
    private execute;
    private project;
}
export {};
//# sourceMappingURL=agui.d.ts.map