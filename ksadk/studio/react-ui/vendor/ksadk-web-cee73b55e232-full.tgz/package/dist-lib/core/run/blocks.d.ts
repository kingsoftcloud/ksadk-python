/**
 * 交错 "思考-行动-思考-输出" 的有序 block 模型(照抄 Wegent wework 的
 * workbench ProcessingBlock 方案,见 packages/chat-core/workbench-message-reducer.ts)。
 *
 * 核心思想:一条 assistant message 不是 "reasoning 单串 + tools map + content",
 * 而是一个**有序的 ProcessingBlock 数组**。思考块会被工具调用"切断"成多段,
 * 从而自然形成 [思考1][工具][思考2][正文] 的时间线交错布局。
 */
export type BlockStatus = 'streaming' | 'done' | 'error';
export interface ThinkingBlock {
    id: string;
    type: 'thinking';
    content: string;
    status: BlockStatus;
    source?: 'public_summary' | 'provider_reasoning' | 'runtime_progress' | 'reasoning';
}
export interface ToolBlock {
    id: string;
    type: 'tool';
    toolName: string;
    args: string;
    output?: string;
    summary?: string;
    durationMs?: number;
    status: 'running' | 'completed' | 'error' | 'paused' | 'unknown';
    /** 透传现有 Message.tools 的附加字段(approval 等),渲染层按需取。 */
    extra?: Record<string, unknown>;
}
export interface TextBlock {
    id: string;
    type: 'text';
    content: string;
    status: BlockStatus;
}
export type ProcessingBlock = ThinkingBlock | ToolBlock | TextBlock;
/** 追加思考 delta(对应 wework appendThinkingChunk):
 *  最后一个块是流式 thinking 则追加,否则新建一个 thinking 块。 */
export declare function appendThinkingBlock(blocks: ProcessingBlock[] | undefined, delta: string, identity?: {
    itemId?: string;
    source?: ThinkingBlock['source'];
}): ProcessingBlock[];
/** Close only the acknowledged segment; a late end must not close its successor. */
export declare function completeThinkingBlock(blocks: ProcessingBlock[] | undefined, itemId?: string, text?: string): ProcessingBlock[];
/** 追加正文 delta:先关闭打开的 thinking,再追加到最后一个流式 text 块(或新建)。 */
export declare function appendTextBlock(blocks: ProcessingBlock[] | undefined, delta: string): ProcessingBlock[];
/** 正文收尾(text_final):把最后一个流式 text 块设为终值并关闭。 */
export declare function finalizeTextBlock(blocks: ProcessingBlock[] | undefined, text: string): ProcessingBlock[];
/**
 * Compatibility for runtimes that mislabeled a streamed final answer as the
 * tail of reasoning and only emitted the answer's authoritative snapshot at
 * completion. This is deliberately narrow: it touches only the last thinking
 * block and only when that block ends with the exact terminal answer.
 */
export declare function stripMirroredTerminalAnswerFromThinking(blocks: ProcessingBlock[] | undefined, terminalAnswer: string): ProcessingBlock[];
/** upsert 工具块(对应 wework mergeProcessingBlock + finalize):
 *  先关闭打开的 thinking 块,再按 toolName 找已有 tool 块更新,否则新建。 */
export declare function upsertToolBlock(blocks: ProcessingBlock[] | undefined, toolName: string, patch: Partial<Omit<ToolBlock, 'id' | 'type' | 'toolName'>>): ProcessingBlock[];
/** 关闭最后一个 thinking 块(turn 结束/被工具打断后调用)。 */
export declare function finalizeThinkingBlocks(blocks: ProcessingBlock[] | undefined): ProcessingBlock[];
/** 取某 message 的有序 blocks(无则空数组,便于渲染层判空回退)。 */
export declare function getProcessingBlocks(blocks: ProcessingBlock[] | undefined): ProcessingBlock[];
/**
 * 从旧版历史字段(reasoning/tools/content)重建交错 blocks。
 * 新版 KsADK 会提供有序 Blocks 时间线；只有旧服务或旧会话缺少该时间线时
 * 才走这里的兼容回退，让历史消息仍走 ProcessingBlocksView。
 *
 * 顺序原因:ksadk 流式时思考在工具前、正文在工具后(appendTextBlock 先关 thinking)。
 * 旧记录无法还原多段思考被工具切断的真实交错,只能近似单段思考+工具+正文。
 */
export declare function buildBlocksFromHistory(input: {
    reasoning?: string;
    reasoningSource?: ThinkingBlock['source'];
    tools?: Record<string, {
        name: string;
        callId?: string;
        args?: string;
        output?: string;
        status?: string;
        toolDisplay?: Record<string, unknown>;
    }>;
    content?: string;
}): ProcessingBlock[];
//# sourceMappingURL=blocks.d.ts.map