import type { RunEvent } from './types.js';
export declare function dispatchRunEventToStores(event: RunEvent, projection?: {
    visible: boolean;
    draftId?: string;
}): void;
export declare function resetDispatcherState(): void;
//# sourceMappingURL=dispatcher.d.ts.map