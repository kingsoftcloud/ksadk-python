import type { RunControlState, RunEngine, RunStage, RunEvent, RunEngineConfig, RuntimeExecutionMode, RunSettlement, SubmitControlCommand } from './types.js';
import type { ApiFacade } from '../api/types.js';
export declare class RunEngineImpl implements RunEngine {
    private _stage;
    private listeners;
    private abortController;
    private activeCompactionId;
    private activeSessionId;
    private invocationId;
    /** Monotonic owner epoch; disconnect invalidates late async finalizers. */
    private operationEpoch;
    private lastSeqId;
    private pendingConfig;
    private readonly projection;
    private aguiClient;
    private aguiThreadSessionId;
    private api;
    private controlStateValue;
    private lastControlCommand;
    private config;
    constructor(api: ApiFacade, projection?: {
        isVisible?: () => boolean;
        draftId?: string;
    });
    get activeInvocationId(): string;
    private get streamingKey();
    private publishInvocation;
    private recordCursor;
    private stopActivity;
    get stage(): RunStage;
    get controlState(): RunControlState;
    /**
     * Submit an agent-kernel/v1 control command. Receipt semantics:
     * accepted/duplicate -> queued (never treated as completion), queue_full ->
     * retryable with the same idempotency key, unsupported -> surfaces the
     * capability reason, persistence_uncertain -> confirm status before retry.
     */
    submitControl(command: SubmitControlCommand): Promise<RunControlState>;
    private controlStateFor;
    /** Retry the last control command, reusing its idempotency key. */
    retryControl(): Promise<RunControlState>;
    updateConfig(config: RunEngineConfig): void;
    private emit;
    private getAguiClient;
    private setStage;
    subscribe(listener: (event: RunEvent) => void): () => void;
    start(draft: {
        text: string;
        attachments: File[];
        optimisticMessageId?: string;
        responsesInput?: unknown;
        previousResponseId?: string;
        executionMode?: RuntimeExecutionMode;
        sessionId?: string | null;
        onSessionCreated?: (sessionId: string) => void;
        onInvocationCreated?: (invocationId: string) => void;
        onSessionUpsert?: (sessionId: string) => void;
        /** Legacy Responses HTTP admission, before the output stream finishes. */
        onDispatchResult?: (accepted: boolean) => void;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement, submission?: {
            accepted: true;
        }) => void;
    }): boolean;
    stop(): void;
    disconnect(): void;
    cancelRemote(invocationId: string): Promise<void>;
    resumeRun(params: {
        sessionId: string;
        invocationId: string;
        afterSeqId: number;
        onSessionReloadNeeded?: () => void;
    }): Promise<void>;
    resumeCheckpoint(params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
        resumeAttemptId?: string;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement) => void;
    }): boolean;
    resumeAguiInterrupt(params: {
        sessionId?: string | null;
        interruptId: string;
        status: 'resolved' | 'cancelled';
        payload?: unknown;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement) => void;
    }): boolean;
    private createSession;
    private getConversationBootstrap;
    private buildCanonicalConversationInput;
    private uploadCanonicalAttachments;
    private uploadFiles;
    private imageFileToDataUrl;
    private buildRequestBody;
    private buildExecutionMetadata;
    /**
     * Consume an AgentKernel run: the receipt proved the durable enqueue; the
     * run output arrives on SubscribeSessionEvents as raw kernel frames which
     * are translated to legacy SessionEventRecords (dispatcher handles the
     * message merge + interaction ingestion). Reconnects resume from the last
     * observed kernel seq.
     */
    private consumeKernelRunEvents;
    private consumeStream;
    private isCompactionChunk;
    private dispatchAction;
    private upsertCompactionMessage;
    private failCompaction;
}
//# sourceMappingURL=engine.d.ts.map