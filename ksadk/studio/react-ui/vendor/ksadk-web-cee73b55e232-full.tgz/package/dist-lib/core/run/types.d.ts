import type { RuntimeApiFormat } from '../../types/api.js';
import type { AgentControlError, AgentControlReceipt } from '../../types/agent-control.js';
import type { HostedChatTransport } from '../../types/api.js';
import type { ModelCatalogItem } from '../../components/chat/types.js';
import type { RuntimeCapabilityMatrix } from '../../types/agent-control.js';
import type { ConversationClient, ConversationStreamResult } from '../conversation/types.js';
export type RunStage = 'idle' | 'creating-session' | 'uploading-files' | 'connecting' | 'streaming' | 'stopping' | 'completing' | 'recovering' | 'error' | 'cancelled';
/** Default approval policy applied to a newly started conversation run. */
export type PermissionMode = 'ask' | 'risk' | 'full';
/**
 * User-selectable execution controls.
 *
 * A runtime's agent loop is its internal execution machinery, not a turn mode.
 * Only Plan and Goal have distinct public request semantics.
 */
export type RuntimeExecutionMode = 'plan' | 'goal';
export type RunEvent = {
    type: 'stage_changed';
    stage: RunStage;
    sessionId?: string | null;
} | {
    type: 'activity';
    sessionId?: string | null;
    phase: string;
    source?: 'run' | 'restore';
    status?: 'connecting' | 'running' | 'waiting' | 'stopped' | 'completed' | 'failed';
    detail?: string;
    countEvent?: boolean;
} | {
    type: 'user_message_added';
    messageId: string;
    sessionId?: string | null;
} | {
    type: 'assistant_message_created';
    messageId: string;
    invocationId?: string;
    sessionId?: string | null;
} | {
    type: 'text_delta';
    messageId: string;
    delta: string;
    sessionId?: string | null;
} | {
    type: 'text_final';
    messageId: string;
    text: string;
    sessionId?: string | null;
} | {
    type: 'reasoning_delta';
    messageId: string;
    delta: string;
    itemId?: string;
    source?: 'public_summary' | 'provider_reasoning' | 'runtime_progress' | 'reasoning';
    sessionId?: string | null;
} | {
    type: 'reasoning_done';
    messageId: string;
    text?: string;
    itemId?: string;
    sessionId?: string | null;
} | {
    type: 'tool_upsert';
    messageId: string;
    name: string;
    args: string;
    status: string;
    extra?: Record<string, unknown>;
    sessionId?: string | null;
} | {
    type: 'tool_result';
    messageId: string;
    name: string;
    output: string;
    callId?: string;
    sessionId?: string | null;
} | {
    type: 'approval_requested';
    messageId: string;
    approvalRequestId: string;
    protocol: 'ag-ui' | 'responses';
    name: string;
    args: string;
    message?: string;
    approvalLevel?: string;
    runId?: string;
    sessionId?: string | null;
} | {
    type: 'approval_resolved';
    approvalRequestId: string;
    decision: 'approved' | 'rejected' | 'cancelled';
    revision?: number;
    sessionId?: string | null;
} | {
    type: 'compaction';
    phase: string;
    trigger?: string;
    compactedUntilSeqId?: number;
    sessionId?: string | null;
} | {
    type: 'system_message';
    content: string;
    sessionId?: string | null;
} | {
    type: 'stream_ended';
    sessionId?: string | null;
    runId?: string | null;
} | {
    type: 'error';
    error: Error;
    sessionId?: string | null;
} | {
    type: 'rate_limited';
    retryAfterSec?: number;
    message?: string;
    sessionId?: string | null;
} | {
    type: 'terminal';
    status: string;
    sessionId?: string | null;
} | {
    type: 'stream_event';
    event: import('../../types/session-events.js').SessionEventRecord;
    sessionId?: string | null;
} | {
    type: 'conversation_snapshot';
    result: ConversationStreamResult;
    sessionId?: string | null;
    optimisticMessageId?: string;
} | {
    type: 'a2ui_surface_begin';
    surfaceId: string;
    surface: import('../stream/types.js').A2UISurface;
    sessionId?: string | null;
} | {
    type: 'a2ui_surface_update';
    surfaceId: string;
    surface: import('../stream/types.js').A2UISurface;
    sessionId?: string | null;
} | {
    type: 'a2ui_surface_end';
    surfaceId: string;
    sessionId?: string | null;
} | {
    type: 'a2ui_interaction';
    surfaceId: string;
    interactionId: string;
    kind: string;
    inputSchema: Record<string, unknown>;
    sessionId?: string | null;
} | {
    type: 'agui_activity';
    messageId: string;
    surfaceId: string;
    messages: Array<Record<string, unknown>>;
    sessionId?: string | null;
};
export type RunEngineConfig = {
    agentId: string;
    apiFormats: RuntimeApiFormat[];
    agentFramework: string;
    selectedModel: string;
    selectedModelMetadata?: ModelCatalogItem | null;
    thinkingMode: string;
    permissionMode?: PermissionMode;
    runtimeCapabilityMatrix?: RuntimeCapabilityMatrix;
    hostedChatTransport?: HostedChatTransport;
    checkpointResumePreviewEnabled?: boolean;
    /** RunAgent receipt + canonical SubscribeSessionEvents supported by this endpoint. */
    kernelSessionEventsEnabled?: boolean;
    presentationProfile?: 'flat-v1' | 'agent-block-v1';
    /** Optional headless ConversationSurface/Input/Item v1 transport. */
    conversationClient?: ConversationClient;
};
export interface RunEngine {
    readonly activeInvocationId: string;
    updateConfig(config: RunEngineConfig): void;
    start(draft: {
        text: string;
        attachments: File[];
        optimisticMessageId?: string;
        responsesInput?: unknown;
        previousResponseId?: string;
        executionMode?: RuntimeExecutionMode;
        sessionId?: string | null;
        onSessionCreated?: (sessionId: string) => void;
        onInvocationCreated?: (invocationId: string) => void;
        onSessionUpsert?: (sessionId: string) => void;
        /** Legacy Responses HTTP admission, before the output stream finishes. */
        onDispatchResult?: (accepted: boolean) => void;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement, submission?: {
            accepted: true;
        }) => void;
    }): boolean;
    disconnect(): void;
    stop(): void;
    cancelRemote(invocationId: string): Promise<void>;
    resumeRun(params: {
        sessionId: string;
        invocationId: string;
        afterSeqId: number;
        onSessionReloadNeeded?: () => void;
    }): void;
    resumeCheckpoint(params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
        resumeAttemptId?: string;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement) => void;
    }): boolean;
    resumeAguiInterrupt(params: {
        sessionId?: string | null;
        interruptId: string;
        status: 'resolved' | 'cancelled';
        payload?: unknown;
        onSettled?: (sessionId: string | null, outcome?: RunSettlement) => void;
    }): boolean;
    readonly stage: RunStage;
    readonly controlState: RunControlState;
    submitControl(command: SubmitControlCommand): Promise<RunControlState>;
    retryControl(): Promise<RunControlState>;
    subscribe(listener: (event: RunEvent) => void): () => void;
}
export type RunSettlement = 'completed' | 'awaiting-input' | 'failed' | 'cancelled' | 'unknown';
/**
 * agent-kernel/v1 control surface state. `accepted`/`duplicate` receipts move
 * the run to queued — they never imply completion.
 */
export type RunControlPhase = 'idle' | 'queued' | 'retryable' | 'unsupported' | 'confirming' | 'contract_mismatch' | 'rejected';
export type RunControlState = {
    phase: RunControlPhase;
    /** Idempotency key to reuse when retrying (queue_full/confirming). */
    retryKey?: string;
    /** Populated for unsupported/rejected receipts. */
    error?: AgentControlError | null;
    receipt?: AgentControlReceipt | null;
};
export type SubmitControlCommand = {
    command_type: 'enqueue' | 'steer' | 'inject' | 'interrupt' | 'pause' | 'resume' | 'submit_interaction';
    idempotency_key: string;
    payload: Record<string, unknown>;
};
//# sourceMappingURL=types.d.ts.map