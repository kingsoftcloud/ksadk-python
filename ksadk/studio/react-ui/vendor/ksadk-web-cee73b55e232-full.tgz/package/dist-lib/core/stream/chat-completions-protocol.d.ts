import type { StreamProtocol, StreamAction } from './types.js';
import type { TransportEvent } from '../transport/types.js';
export declare class ChatCompletionsProtocol implements StreamProtocol {
    readonly id = "chat_completions";
    createState(): Record<string, unknown>;
    parse(event: TransportEvent): StreamAction[];
}
//# sourceMappingURL=chat-completions-protocol.d.ts.map