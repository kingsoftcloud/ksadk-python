import type { StreamProtocol } from './types.js';
export declare function createProtocol(apiFormat: string): StreamProtocol;
export type { StreamProtocol, StreamAction } from './types.js';
export { RuntimeItemReducer, legacyAssistantIdentity, projectRuntimeItems, responsesEventToItemOperations, sessionEventToItemOperation, } from './runtime-items.js';
export type { RuntimeItem, RuntimeItemOperation, RuntimeItemProjection, RuntimeItemSnapshot, } from './runtime-items.js';
//# sourceMappingURL=index.d.ts.map