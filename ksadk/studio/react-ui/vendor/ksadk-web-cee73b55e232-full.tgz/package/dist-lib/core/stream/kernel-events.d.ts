/**
 * agent-kernel/v1 session event frames → legacy SessionEventRecord.
 *
 * RunAgent on a kernel-backed agent returns an AgentControl receipt (JSON)
 * instead of a Responses SSE stream. The engine then subscribes to
 * SubscribeSessionEvents (raw kernel envelopes) and translates each frame
 * into the legacy session-event read model so the existing dispatcher /
 * message merge / interaction ingestion paths keep working unchanged.
 *
 * Interaction/v1 frames are passed through verbatim: the interaction
 * adapter already understands the kernel envelope shape.
 */
export type KernelSessionEventFrame = Record<string, unknown>;
export type LegacySessionEventRecord = {
    EventId?: string;
    EventType?: string;
    SessionId?: string;
    InvocationId?: string;
    Content?: Record<string, unknown>;
    Metadata?: Record<string, unknown>;
    SeqId?: number;
    Timestamp?: string;
    [key: string]: unknown;
};
/**
 * Stateful translator: accumulates item.updated text deltas per part so the
 * emitted assistant_stream_snapshot records are cumulative (the legacy read
 * model treats snapshots as full-text snapshots, not deltas).
 */
export declare class KernelRunEventTranslator {
    private readonly textByPart;
    private readonly toolNameByCallId;
    private readonly toolCallByItemId;
    private readonly toolResultByItemId;
    private readonly sessionId;
    constructor(sessionId: string);
    translate(frame: KernelSessionEventFrame): LegacySessionEventRecord | null;
}
/** Parsed RunAgent receipt on the kernel control path (ActionResponse.Data). */
export type KernelRunReceipt = {
    status: string;
    commandId?: string | null;
    presentationProfile?: 'flat-v1' | 'agent-block-v1';
    messageId?: string | null;
    runId?: string | null;
    acceptedSeq?: number | null;
    error?: {
        code?: string;
        message?: string;
    } | null;
};
/**
 * Detect the kernel receipt JSON body on a RunAgent response stream. Returns
 * the receipt, or a stream with the already-read bytes prepended when the
 * body is an SSE stream (legacy runtime path).
 */
export declare function peekKernelReceipt(stream: ReadableStream<Uint8Array>): Promise<{
    receipt: KernelRunReceipt | null;
    stream: ReadableStream<Uint8Array>;
}>;
//# sourceMappingURL=kernel-events.d.ts.map