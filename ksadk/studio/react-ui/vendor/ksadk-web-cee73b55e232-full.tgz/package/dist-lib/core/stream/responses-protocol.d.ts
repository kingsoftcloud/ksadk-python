import type { StreamProtocol, StreamAction } from './types.js';
import type { TransportEvent } from '../transport/types.js';
import { type RuntimeItemOperation } from './runtime-items.js';
export declare class ResponsesProtocol implements StreamProtocol {
    readonly id = "responses";
    createState(): Record<string, unknown>;
    /**
     * Identity-aware item operations for one transport event, keyed by the
     * Responses output item id. This is the schema-v2 path; `parse` remains the
     * legacy action projection for the existing dispatcher.
     */
    parseItemOperations(event: TransportEvent, runId: string, scopeId: string): RuntimeItemOperation[];
    parse(event: TransportEvent, state: Record<string, unknown>): StreamAction[];
}
//# sourceMappingURL=responses-protocol.d.ts.map