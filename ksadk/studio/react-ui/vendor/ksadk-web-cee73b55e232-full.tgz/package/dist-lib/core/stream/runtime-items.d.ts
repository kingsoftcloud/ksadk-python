/**
 * Identity-aware runtime item reducer (schema v2).
 *
 * This is the single canonical store for streaming output. It reduces
 * identity-addressed item operations into a per-run projection, replacing the
 * legacy v1 heuristic dedup (lastText / per-agent accumulator / startswith /
 * suffix overlap / text hash). Every mutation is keyed by
 * `runId / scopeId / itemId / partId`; nothing here inspects body text to
 * decide identity.
 *
 * Ingress adapters normalize three sources into the same item operations:
 *   - Responses SSE output item ids      -> {@link responsesEventToItemOperations}
 *   - Session events `Metadata.RuntimeItem` -> {@link sessionEventToItemOperation}
 *   - Legacy server events (no identity)  -> synthesized `${invocationId}:legacy-assistant`
 */
export type RuntimeItemKind = 'message' | 'reasoning' | 'tool_call' | 'tool_result' | 'artifact' | 'data' | 'status';
export type RuntimeItemPhase = 'commentary' | 'final_answer';
export type RuntimeItemStatus = 'open' | 'completed' | 'failed';
export type RunStatus = 'running' | 'interrupted' | 'completed' | 'failed' | 'canceled';
/** A single content part, addressed by `partId` within an item. */
export type RuntimeItemPart = {
    partId: string;
    contentType: 'text' | 'json' | 'data' | 'artifact' | 'tool_call' | 'tool_result';
    text?: string;
    value?: unknown;
};
/**
 * Normalized item operation. This is the only input the reducer accepts; all
 * ingress adapters produce this shape.
 */
export type RuntimeItemOperation = {
    type: 'run_started';
    runId: string;
    scopeId?: string;
    eventId?: string;
    seq?: number;
} | {
    type: 'run_completed' | 'run_failed' | 'run_canceled' | 'run_interrupted';
    runId: string;
    scopeId?: string;
    eventId?: string;
    seq?: number;
} | {
    type: 'item_started';
    runId: string;
    scopeId: string;
    itemId: string;
    itemKind: RuntimeItemKind;
    phase?: RuntimeItemPhase;
    eventId?: string;
    seq?: number;
    initialParts?: RuntimeItemPart[];
} | {
    type: 'item_updated';
    runId: string;
    scopeId: string;
    itemId: string;
    itemKind?: RuntimeItemKind;
    partId: string;
    op: 'append' | 'replace';
    part: RuntimeItemPart;
    eventId?: string;
    seq?: number;
} | {
    type: 'item_snapshot_replaced';
    runId: string;
    scopeId: string;
    itemId: string;
    itemKind?: RuntimeItemKind;
    parts: RuntimeItemPart[];
    eventId?: string;
    seq?: number;
} | {
    type: 'item_completed' | 'item_failed';
    runId: string;
    scopeId: string;
    itemId: string;
    itemKind?: RuntimeItemKind;
    parts?: RuntimeItemPart[];
    eventId?: string;
    seq?: number;
};
export type RuntimeItem = {
    runId: string;
    scopeId: string;
    itemId: string;
    itemKind: RuntimeItemKind;
    phase?: RuntimeItemPhase;
    status: RuntimeItemStatus;
    parts: RuntimeItemPart[];
};
export type RuntimeItemSnapshot = {
    runId: string | null;
    status: RunStatus | null;
    items: RuntimeItem[];
};
/** Flat, render-ready projection of one item, keyed by its full identity. */
export type RuntimeItemProjection = {
    runId: string;
    scopeId: string;
    itemId: string;
    partId: string;
    itemKind: RuntimeItemKind;
    phase?: RuntimeItemPhase;
    completed: boolean;
    text: string;
};
/**
 * Reduces identity-addressed operations into a run projection.
 *
 * Identity rules (no heuristics):
 *   - An item is uniquely `(scopeId, itemId)`; a part is uniquely `partId`
 *     within that item.
 *   - `item_updated` with `op: 'append'` concatenates text onto the existing
 *     part; `op: 'replace'` overwrites it.
 *   - `item_snapshot_replaced` / `item_completed` replace the item's parts
 *     wholesale, so a completed snapshot never double-appends.
 *   - Re-applying an event with an already-seen `eventId` is an idempotent
 *     no-op (event-id replay), never a text comparison.
 */
export declare class RuntimeItemReducer {
    private runId;
    private status;
    private readonly items;
    private readonly seenEventIds;
    apply(operation: RuntimeItemOperation): void;
    /** Apply a full event log. Idempotent per `eventId`, so replay is safe. */
    applyAll(operations: Iterable<RuntimeItemOperation>): void;
    snapshot(): RuntimeItemSnapshot;
    private ensureItem;
    private startItem;
    private updateItem;
    private replaceSnapshot;
    private closeItem;
}
/**
 * Project a reducer snapshot into flat, render-ready items. Distinct item ids
 * are always preserved, even when their text is identical.
 */
export declare function projectRuntimeItems(snapshot: RuntimeItemSnapshot): RuntimeItemProjection[];
/** The single synthesized identity path for legacy server ingress. */
export declare function legacyAssistantIdentity(invocationId: string): {
    scopeId: string;
    itemId: string;
};
/**
 * Normalize one session event into a reducer operation.
 *
 * Canonical events carry `Metadata.RuntimeItem` with the full identity; legacy
 * `assistant_stream_snapshot` / `assistant_message` events fall back to the
 * synthesized `${invocationId}:legacy-assistant` identity. Identity is never
 * inferred from previous messages or body text.
 *
 * Returns `null` for events that do not mutate an item.
 */
export declare function sessionEventToItemOperation(event: {
    EventType?: string;
    InvocationId?: string;
    EventId?: string;
    SeqId?: number;
    Content?: {
        parts?: Array<{
            text?: string;
        }>;
    };
    Metadata?: Record<string, unknown>;
}): RuntimeItemOperation | null;
/**
 * Normalize one Responses SSE event into reducer operations, keyed by the
 * Responses output item id. Returns an empty array for events that do not
 * mutate an item.
 */
export declare function responsesEventToItemOperations(eventName: string, data: Record<string, unknown>, runId: string, scopeId: string): RuntimeItemOperation[];
//# sourceMappingURL=runtime-items.d.ts.map