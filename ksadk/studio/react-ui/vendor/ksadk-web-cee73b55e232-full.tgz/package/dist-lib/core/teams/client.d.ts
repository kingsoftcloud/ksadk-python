import { TeamsError } from './contracts.js';
import type { LeaderStandbyConfiguration, MemberStreamRef, ConnectionStatus, ExecutionSnapshot, GroupCreateInput, GroupList, GroupMessageInput, GroupReceipt, GroupSnapshot, TaskAction, TeamControlAction, TeamInteractionInput } from './types.js';
export type TeamsFetch = (url: string, init?: RequestInit) => Promise<Response>;
export type TeamsClientOptions = {
    fetch?: TeamsFetch;
    baseUrl?: string;
    maxReconnects?: number;
    retryDelayMs?: (attempt: number) => number;
};
export type GroupWatchOptions = {
    signal: AbortSignal;
    onSnapshot: (snapshot: GroupSnapshot) => void;
    onConnection?: (status: ConnectionStatus) => void;
    onError?: (error: TeamsError) => void;
};
/** Read-only SSE consumption; frames never contain executable extensions. */
export declare function consumeTeamsSse(response: Response, signal: AbortSignal, onFrame: (type: string, data: unknown) => void): Promise<void>;
/** Authenticated transport is injected by the host. No ambient selected-Agent state. */
export declare class HttpTeamsClient {
    private readonly fetcher;
    private readonly baseUrl;
    private readonly reconnects;
    private readonly retryDelay;
    constructor(options?: TeamsClientOptions);
    private path;
    private request;
    private json;
    private post;
    list(options?: {
        cursor?: string;
        limit?: number;
        signal?: AbortSignal;
    }): Promise<GroupList>;
    snapshot(groupId: string, signal?: AbortSignal): Promise<GroupSnapshot>;
    create(input: GroupCreateInput, signal?: AbortSignal): Promise<GroupSnapshot>;
    update(groupId: string, input: {
        expectedRevision: number;
        name?: string;
        leaderMemberId?: string;
        removeMemberId?: string;
        addMember?: {
            memberId: string;
            name: string;
            bindingRef: string;
        };
        rebindMember?: {
            memberId: string;
            name: string;
            bindingRef: string;
        };
        taskAcceptance?: 'leader' | 'human' | 'result';
        peerWake?: boolean;
        archived?: boolean;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<GroupSnapshot>;
    send(groupId: string, input: GroupMessageInput, signal?: AbortSignal): Promise<GroupReceipt>;
    start(groupId: string, input: {
        goalMessageId: string;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<GroupReceipt>;
    taskAction(groupId: string, taskId: string, input: {
        action: TaskAction;
        expectedRevision: number;
        idempotencyKey: string;
        memberId?: string;
        reason?: string;
    }, signal?: AbortSignal): Promise<GroupReceipt>;
    control(groupId: string, teamRunId: string, input: {
        action: TeamControlAction;
        expectedRevision: number;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<GroupReceipt>;
    acceptRun(groupId: string, teamRunId: string, input: {
        accepted?: boolean;
        action?: 'accept' | 'request_changes' | 'reject';
        reason?: string;
        expectedRevision: number;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<GroupReceipt>;
    configureLeaderStandby(groupId: string, teamRunId: string, input: {
        bindingRef: string;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<LeaderStandbyConfiguration>;
    interaction(groupId: string, input: TeamInteractionInput, signal?: AbortSignal): Promise<GroupReceipt>;
    cancelMember(groupId: string, memberId: string, input: {
        ref: MemberStreamRef;
        idempotencyKey: string;
    }, signal?: AbortSignal): Promise<{
        status: 'cancel_requested';
        runId: string;
    }>;
    execution(groupId: string, teamRunId?: string, signal?: AbortSignal): Promise<ExecutionSnapshot>;
    markRead(groupId: string, watermark: number, signal?: AbortSignal): Promise<void>;
    reconciliation(groupId: string, teamRunId: string): Promise<import('./types.js').TeamReconciliationRecord[]>;
    reconcile(groupId: string, commandId: string, input: {
        receiptDigest: string;
        action: 'confirm_ended' | 'use_result';
        reason: string;
        idempotencyKey: string;
    }): Promise<{
        status: string;
    }>;
    /** Snapshot + watermark subscription. Aborting closes observation only. */
    watch(groupId: string, options: GroupWatchOptions): Promise<void>;
}
//# sourceMappingURL=client.d.ts.map