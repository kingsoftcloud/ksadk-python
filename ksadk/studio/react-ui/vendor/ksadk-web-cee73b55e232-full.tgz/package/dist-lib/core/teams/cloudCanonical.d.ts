/** New Teams cloud wire hashing only. Native AgentControl hashing is unchanged. */
export declare class TeamsCanonicalJsonError extends Error {
    constructor();
}
export declare function isTeamsUnicodeScalarString(value: string): boolean;
/** RFC 8785 object/string/number serialization, with Teams' safe integer input boundary. */
export declare function canonicalTeamsJson(value: unknown): string;
export declare function digestTeamsJson(value: unknown, subtle?: SubtleCrypto): Promise<string>;
/** Material list ordering follows Python path ordering; object key ordering remains JCS. */
export declare function compareTeamsMaterialPaths(a: string, b: string): number;
//# sourceMappingURL=cloudCanonical.d.ts.map