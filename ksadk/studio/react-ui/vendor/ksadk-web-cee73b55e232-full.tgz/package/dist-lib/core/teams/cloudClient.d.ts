import { type TeamsFetch } from './client.js';
import { type TeamWorkspaceSnapshot, type WorkspaceClientScope, type WorkspaceEvent, type WorkspacePage, type WorkspacePageRequest } from './workspaceContracts.js';
export interface CloudWorkspaceTransport {
    read(scope: WorkspaceClientScope, options: {
        teamRunId?: string;
        signal: AbortSignal;
    }): Promise<TeamWorkspaceSnapshot>;
    page(scope: WorkspaceClientScope, request: WorkspacePageRequest, signal: AbortSignal): Promise<WorkspacePage>;
    subscribe(scope: WorkspaceClientScope, after: number, signal: AbortSignal, onEvent: (event: WorkspaceEvent) => void): Promise<void>;
}
/** Read-only cloud projection adapter. User commands belong to the durable operation outbox. */
export declare class HttpCloudWorkspaceClient implements CloudWorkspaceTransport {
    readonly origin: string;
    private readonly base;
    private readonly fetcher;
    constructor(options: {
        origin: string;
        baseUrl?: string;
        fetch?: TeamsFetch;
    });
    private path;
    private get;
    read(scope: WorkspaceClientScope, options: {
        teamRunId?: string;
        signal: AbortSignal;
    }): Promise<TeamWorkspaceSnapshot>;
    page(scope: WorkspaceClientScope, request: WorkspacePageRequest, signal: AbortSignal): Promise<WorkspacePage>;
    subscribe(scope: WorkspaceClientScope, after: number, signal: AbortSignal, onEvent: (event: WorkspaceEvent) => void): Promise<void>;
}
//# sourceMappingURL=cloudClient.d.ts.map