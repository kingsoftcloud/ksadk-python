import { z } from 'zod';
/** Parsing validates data, never authority. Hosts must verify signed permits and persisted scope. */
export declare const TEAMS_NODE_VERSION: "teams-node/v1";
export declare const TEAMS_HOST_VERSION: "teams-host/v1";
export type TeamsCloudJson = null | boolean | number | string | TeamsCloudJson[] | {
    [key: string]: TeamsCloudJson;
};
export declare const teamsExecutionTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"node">;
    nodeId: z.ZodString;
    nodeGeneration: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"cloud_agent">;
    agentId: z.ZodString;
    versionId: z.ZodString;
    runtimeId: z.ZodString;
    agentInstanceId: z.ZodString;
}, z.core.$strict>], "kind">;
export declare const teamsExecutionRefSchema: z.ZodObject<{
    authorityId: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    memberId: z.ZodString;
    runMemberId: z.ZodString;
    taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    attemptId: z.ZodString;
    deliveryId: z.ZodString;
    bindingRef: z.ZodString;
    providerRef: z.ZodString;
    sessionId: z.ZodString;
    commandId: z.ZodString;
    idempotencyKey: z.ZodString;
    schedulerEpoch: z.ZodNumber;
    leaderEpoch: z.ZodNumber;
    dispatchEpoch: z.ZodNumber;
    attemptEpoch: z.ZodNumber;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"node">;
        nodeId: z.ZodString;
        nodeGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"cloud_agent">;
        agentId: z.ZodString;
        versionId: z.ZodString;
        runtimeId: z.ZodString;
        agentInstanceId: z.ZodString;
    }, z.core.$strict>], "kind">;
    bundleDigest: z.ZodString;
    contractDigest: z.ZodString;
    capabilitiesDigest: z.ZodString;
    nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export type TeamsExecutionRef = z.infer<typeof teamsExecutionRefSchema>;
export declare const teamsTerminalEvidenceSchema: z.ZodObject<{
    sessionId: z.ZodString;
    runId: z.ZodString;
    commandId: z.ZodString;
    terminalSeq: z.ZodNumber;
    terminalEventDigest: z.ZodString;
    resultDigest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const teamsHostReceiptSchema: z.ZodObject<{
    status: z.ZodEnum<{
        uncertain: "uncertain";
        rejected: "rejected";
        accepted: "accepted";
        missing: "missing";
        duplicate: "duplicate";
    }>;
    commandId: z.ZodString;
    idempotencyKey: z.ZodString;
    payloadDigest: z.ZodString;
    storeIncarnation: z.ZodString;
    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    acceptedSeq: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    nativeStatus: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
        running: "running";
        waiting: "waiting";
        failed: "failed";
        cancelled: "cancelled";
        interrupted: "interrupted";
        succeeded: "succeeded";
        queued: "queued";
        awaiting_approval: "awaiting_approval";
        waiting_for_node: "waiting_for_node";
    }>>>;
    terminalEvidence: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        sessionId: z.ZodString;
        runId: z.ZodString;
        commandId: z.ZodString;
        terminalSeq: z.ZodNumber;
        terminalEventDigest: z.ZodString;
        resultDigest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type TeamsHostReceipt = z.infer<typeof teamsHostReceiptSchema>;
export declare const teamsCanonicalEventSchema: z.ZodObject<{
    eventId: z.ZodString;
    sessionId: z.ZodString;
    runId: z.ZodString;
    seq: z.ZodNumber;
    family: z.ZodString;
    type: z.ZodString;
    payload: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
    sourceRef: z.ZodObject<{
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        parentRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        nativeEventType: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const teamsCanonicalEventBatchSchema: z.ZodObject<{
    sessionId: z.ZodString;
    storeIncarnation: z.ZodString;
    afterSeq: z.ZodNumber;
    nextSeq: z.ZodNumber;
    snapshotUpperSeq: z.ZodNumber;
    hasMore: z.ZodBoolean;
    items: z.ZodArray<z.ZodObject<{
        eventId: z.ZodString;
        sessionId: z.ZodString;
        runId: z.ZodString;
        seq: z.ZodNumber;
        family: z.ZodString;
        type: z.ZodString;
        payload: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
        sourceRef: z.ZodObject<{
            nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            parentRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            nativeEventType: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TeamsCanonicalEventBatch = z.infer<typeof teamsCanonicalEventBatchSchema>;
export declare const teamsNodeCommandSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    operation: z.ZodLiteral<"prepare">;
    lane: z.ZodLiteral<"execution">;
    payload: z.ZodObject<{
        contextRef: z.ZodString;
        contextDigest: z.ZodString;
        materialManifestRef: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"submit">;
    lane: z.ZodLiteral<"execution">;
    payload: z.ZodObject<{
        command: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
        payloadDigest: z.ZodString;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"lookup">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        payloadDigest: z.ZodString;
        storeIncarnation: z.ZodString;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"set_grant">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        grantId: z.ZodString;
        expectedRevision: z.ZodNumber;
        state: z.ZodEnum<{
            active: "active";
            suspended: "suspended";
            revoked: "revoked";
        }>;
        attemptEpoch: z.ZodNumber;
        expiresAt: z.ZodString;
        renewalId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        controlId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"set_admission">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        grantId: z.ZodString;
        expectedAdmissionRevision: z.ZodNumber;
        admissionAllowed: z.ZodBoolean;
        attemptEpoch: z.ZodNumber;
        controlId: z.ZodString;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"get_grant">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        grantId: z.ZodString;
        renewalId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"cancel">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        controlCommandId: z.ZodString;
        controlIdempotencyKey: z.ZodString;
        targetRunId: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"respond_interaction">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        controlCommandId: z.ZodString;
        controlIdempotencyKey: z.ZodString;
        interactionId: z.ZodString;
        expectedRevision: z.ZodNumber;
        action: z.ZodEnum<{
            cancel: "cancel";
            submit: "submit";
            reject: "reject";
            approve: "approve";
        }>;
        response: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"observe">;
    lane: z.ZodLiteral<"control">;
    payload: z.ZodObject<{
        sessionId: z.ZodString;
        afterSeq: z.ZodNumber;
        limit: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>;
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operationKey: z.ZodString;
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
    issuedAt: z.ZodString;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        permit: z.ZodString;
        grantRevision: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strict>;
}, z.core.$strict>], "operation">;
export type TeamsNodeCommand = z.infer<typeof teamsNodeCommandSchema>;
export declare function teamsNodeCommandDigest(value: TeamsNodeCommand): Promise<string>;
export declare function parseTeamsNodeCommand(raw: unknown): Promise<TeamsNodeCommand>;
export declare const teamsMaterialEntrySchema: z.ZodObject<{
    path: z.ZodString;
    digest: z.ZodString;
    sizeBytes: z.ZodNumber;
    mediaType: z.ZodString;
}, z.core.$strict>;
export declare const teamsMaterialManifestSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        files: "files";
        git_snapshot: "git_snapshot";
    }>;
    sourceCommit: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    entries: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
        mediaType: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const teamsMaterialCreateSchema: z.ZodObject<{
    idempotencyKey: z.ZodString;
    kind: z.ZodEnum<{
        files: "files";
        git_snapshot: "git_snapshot";
    }>;
    sourceCommit: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    entries: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
        mediaType: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TeamsMaterialManifest = z.infer<typeof teamsMaterialManifestSchema>;
export type TeamsMaterialCreateInput = z.infer<typeof teamsMaterialCreateSchema>;
export declare function teamsMaterialManifestDigest(raw: unknown): Promise<string>;
export declare const teamsExecutionGrantSnapshotSchema: z.ZodObject<{
    storeIncarnation: z.ZodString;
    grant: z.ZodObject<{
        grantId: z.ZodString;
        state: z.ZodEnum<{
            active: "active";
            suspended: "suspended";
            revoked: "revoked";
        }>;
        revision: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        expiresAt: z.ZodString;
        admissionAllowed: z.ZodBoolean;
        admissionRevision: z.ZodNumber;
    }, z.core.$strict>;
    barrier: z.ZodObject<{
        queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
            messageId: z.ZodString;
            commandId: z.ZodString;
            idempotencyKey: z.ZodString;
            inboxState: z.ZodEnum<{
                completed: "completed";
                accepted: "accepted";
                claimed: "claimed";
                discarded: "discarded";
            }>;
            runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                running: "running";
                waiting: "waiting";
                completed: "completed";
                failed: "failed";
                pending: "pending";
                cancelled: "cancelled";
                interrupted: "interrupted";
                paused: "paused";
            }>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const teamsGrantMutationReceiptSchema: z.ZodObject<{
    operationId: z.ZodString;
    status: z.ZodDefault<z.ZodLiteral<"applied">>;
    snapshot: z.ZodObject<{
        storeIncarnation: z.ZodString;
        grant: z.ZodObject<{
            grantId: z.ZodString;
            state: z.ZodEnum<{
                active: "active";
                suspended: "suspended";
                revoked: "revoked";
            }>;
            revision: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            expiresAt: z.ZodString;
            admissionAllowed: z.ZodBoolean;
            admissionRevision: z.ZodNumber;
        }, z.core.$strict>;
        barrier: z.ZodObject<{
            queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                messageId: z.ZodString;
                commandId: z.ZodString;
                idempotencyKey: z.ZodString;
                inboxState: z.ZodEnum<{
                    completed: "completed";
                    accepted: "accepted";
                    claimed: "claimed";
                    discarded: "discarded";
                }>;
                runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    running: "running";
                    waiting: "waiting";
                    completed: "completed";
                    failed: "failed";
                    pending: "pending";
                    cancelled: "cancelled";
                    interrupted: "interrupted";
                    paused: "paused";
                }>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const teamsHostOperationResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    operation: z.ZodLiteral<"prepare">;
    contextRef: z.ZodString;
    contextDigest: z.ZodString;
    snapshot: z.ZodObject<{
        storeIncarnation: z.ZodString;
        grant: z.ZodObject<{
            grantId: z.ZodString;
            state: z.ZodEnum<{
                active: "active";
                suspended: "suspended";
                revoked: "revoked";
            }>;
            revision: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            expiresAt: z.ZodString;
            admissionAllowed: z.ZodBoolean;
            admissionRevision: z.ZodNumber;
        }, z.core.$strict>;
        barrier: z.ZodObject<{
            queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                messageId: z.ZodString;
                commandId: z.ZodString;
                idempotencyKey: z.ZodString;
                inboxState: z.ZodEnum<{
                    completed: "completed";
                    accepted: "accepted";
                    claimed: "claimed";
                    discarded: "discarded";
                }>;
                runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    running: "running";
                    waiting: "waiting";
                    completed: "completed";
                    failed: "failed";
                    pending: "pending";
                    cancelled: "cancelled";
                    interrupted: "interrupted";
                    paused: "paused";
                }>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"set_grant">;
    mutationReceipt: z.ZodObject<{
        operationId: z.ZodString;
        status: z.ZodDefault<z.ZodLiteral<"applied">>;
        snapshot: z.ZodObject<{
            storeIncarnation: z.ZodString;
            grant: z.ZodObject<{
                grantId: z.ZodString;
                state: z.ZodEnum<{
                    active: "active";
                    suspended: "suspended";
                    revoked: "revoked";
                }>;
                revision: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                expiresAt: z.ZodString;
                admissionAllowed: z.ZodBoolean;
                admissionRevision: z.ZodNumber;
            }, z.core.$strict>;
            barrier: z.ZodObject<{
                queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    messageId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    inboxState: z.ZodEnum<{
                        completed: "completed";
                        accepted: "accepted";
                        claimed: "claimed";
                        discarded: "discarded";
                    }>;
                    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        running: "running";
                        waiting: "waiting";
                        completed: "completed";
                        failed: "failed";
                        pending: "pending";
                        cancelled: "cancelled";
                        interrupted: "interrupted";
                        paused: "paused";
                    }>>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"set_admission">;
    mutationReceipt: z.ZodObject<{
        operationId: z.ZodString;
        status: z.ZodDefault<z.ZodLiteral<"applied">>;
        snapshot: z.ZodObject<{
            storeIncarnation: z.ZodString;
            grant: z.ZodObject<{
                grantId: z.ZodString;
                state: z.ZodEnum<{
                    active: "active";
                    suspended: "suspended";
                    revoked: "revoked";
                }>;
                revision: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                expiresAt: z.ZodString;
                admissionAllowed: z.ZodBoolean;
                admissionRevision: z.ZodNumber;
            }, z.core.$strict>;
            barrier: z.ZodObject<{
                queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    messageId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    inboxState: z.ZodEnum<{
                        completed: "completed";
                        accepted: "accepted";
                        claimed: "claimed";
                        discarded: "discarded";
                    }>;
                    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        running: "running";
                        waiting: "waiting";
                        completed: "completed";
                        failed: "failed";
                        pending: "pending";
                        cancelled: "cancelled";
                        interrupted: "interrupted";
                        paused: "paused";
                    }>>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    operation: z.ZodLiteral<"get_grant">;
    storeIncarnation: z.ZodString;
    current: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        storeIncarnation: z.ZodString;
        grant: z.ZodObject<{
            grantId: z.ZodString;
            state: z.ZodEnum<{
                active: "active";
                suspended: "suspended";
                revoked: "revoked";
            }>;
            revision: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            expiresAt: z.ZodString;
            admissionAllowed: z.ZodBoolean;
            admissionRevision: z.ZodNumber;
        }, z.core.$strict>;
        barrier: z.ZodObject<{
            queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
            commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                messageId: z.ZodString;
                commandId: z.ZodString;
                idempotencyKey: z.ZodString;
                inboxState: z.ZodEnum<{
                    completed: "completed";
                    accepted: "accepted";
                    claimed: "claimed";
                    discarded: "discarded";
                }>;
                runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    running: "running";
                    waiting: "waiting";
                    completed: "completed";
                    failed: "failed";
                    pending: "pending";
                    cancelled: "cancelled";
                    interrupted: "interrupted";
                    paused: "paused";
                }>>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
    }, z.core.$strict>>>;
    lookupOperationId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    mutationReceipt: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        operationId: z.ZodString;
        status: z.ZodDefault<z.ZodLiteral<"applied">>;
        snapshot: z.ZodObject<{
            storeIncarnation: z.ZodString;
            grant: z.ZodObject<{
                grantId: z.ZodString;
                state: z.ZodEnum<{
                    active: "active";
                    suspended: "suspended";
                    revoked: "revoked";
                }>;
                revision: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                expiresAt: z.ZodString;
                admissionAllowed: z.ZodBoolean;
                admissionRevision: z.ZodNumber;
            }, z.core.$strict>;
            barrier: z.ZodObject<{
                queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    messageId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    inboxState: z.ZodEnum<{
                        completed: "completed";
                        accepted: "accepted";
                        claimed: "claimed";
                        discarded: "discarded";
                    }>;
                    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        running: "running";
                        waiting: "waiting";
                        completed: "completed";
                        failed: "failed";
                        pending: "pending";
                        cancelled: "cancelled";
                        interrupted: "interrupted";
                        paused: "paused";
                    }>>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "operation">;
export type TeamsExecutionGrantSnapshot = z.infer<typeof teamsExecutionGrantSnapshotSchema>;
export type TeamsGrantMutationReceipt = z.infer<typeof teamsGrantMutationReceiptSchema>;
export type TeamsHostOperationResult = z.infer<typeof teamsHostOperationResultSchema>;
/** Pre-execution probes deliberately carry no fabricated execution/run reference. */
export declare const teamsNodeProbeCommandSchema: z.ZodObject<{
    protocolVersion: z.ZodDefault<z.ZodLiteral<"teams-node/v1">>;
    nodeCommandId: z.ZodString;
    operation: z.ZodLiteral<"describe">;
    lane: z.ZodDefault<z.ZodLiteral<"control">>;
    operationKey: z.ZodString;
    authorityId: z.ZodString;
    nodeId: z.ZodString;
    bindingRef: z.ZodString;
    localBindingRef: z.ZodString;
    expectedDigests: z.ZodObject<{
        bundle: z.ZodString;
        contract: z.ZodString;
        capabilities: z.ZodString;
    }, z.core.$strict>;
    nodeGeneration: z.ZodNumber;
    claimLeaseUntil: z.ZodString;
    authorization: z.ZodObject<{
        permitKind: z.ZodLiteral<"probe">;
        permit: z.ZodString;
    }, z.core.$strict>;
    commandDigest: z.ZodString;
}, z.core.$strict>;
export type TeamsNodeProbeCommand = z.infer<typeof teamsNodeProbeCommandSchema>;
export declare function teamsNodeProbeDigest(raw: unknown): Promise<string>;
export declare function parseTeamsNodeMessage(raw: unknown): Promise<TeamsNodeCommand | TeamsNodeProbeCommand>;
export declare const teamsNodeProbeResultSchema: z.ZodObject<{
    bindingRef: z.ZodString;
    localBindingRef: z.ZodString;
    agentInstanceId: z.ZodString;
    storeIncarnation: z.ZodString;
    capabilities: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
    capabilitiesDigest: z.ZodString;
    bundleDigest: z.ZodString;
    contractDigest: z.ZodString;
}, z.core.$strict>;
export declare const teamsNodeProbeReportSchema: z.ZodObject<{
    reportKind: z.ZodDefault<z.ZodLiteral<"probe">>;
    nodeCommandId: z.ZodString;
    nodeGeneration: z.ZodNumber;
    commandDigest: z.ZodString;
    resultRevision: z.ZodNumber;
    phase: z.ZodEnum<{
        uncertain: "uncertain";
        rejected: "rejected";
        described: "described";
    }>;
    probeResult: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        bindingRef: z.ZodString;
        localBindingRef: z.ZodString;
        agentInstanceId: z.ZodString;
        storeIncarnation: z.ZodString;
        capabilities: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
        capabilitiesDigest: z.ZodString;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
    }, z.core.$strict>>>;
    error: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        code: z.ZodString;
        retryable: z.ZodBoolean;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type TeamsNodeProbeResult = z.infer<typeof teamsNodeProbeResultSchema>;
export type TeamsNodeProbeReport = z.infer<typeof teamsNodeProbeReportSchema>;
export declare const decodeTeamsNodeProbeReport: (raw: unknown) => TeamsNodeProbeReport;
/** Structural validation; use decodeTeamsExecutionResult to also verify both JCS digests. */
export declare const teamsExecutionResultSchema: z.ZodObject<{
    status: z.ZodEnum<{
        failed: "failed";
        cancelled: "cancelled";
        interrupted: "interrupted";
        succeeded: "succeeded";
    }>;
    candidate: z.ZodObject<{
        result: z.ZodString;
        artifacts: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>>>;
    }, z.core.$strict>;
    usage: z.ZodObject<{
        totalTokens: z.ZodNumber;
    }, z.core.$strict>;
    terminalEvidence: z.ZodObject<{
        sessionId: z.ZodString;
        runId: z.ZodString;
        commandId: z.ZodString;
        terminalSeq: z.ZodNumber;
        terminalEventDigest: z.ZodString;
        resultDigest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    completionDigest: z.ZodString;
}, z.core.$strict>;
export type TeamsExecutionResult = z.infer<typeof teamsExecutionResultSchema>;
export declare function decodeTeamsExecutionResult(raw: unknown): Promise<TeamsExecutionResult>;
/** Structural validation; decodeTeamsNodeReport additionally verifies completion digests. */
export declare const teamsNodeReportSchema: z.ZodObject<{
    nodeCommandId: z.ZodString;
    nodeGeneration: z.ZodNumber;
    commandDigest: z.ZodString;
    resultRevision: z.ZodNumber;
    phase: z.ZodEnum<{
        running: "running";
        waiting: "waiting";
        terminal: "terminal";
        uncertain: "uncertain";
        rejected: "rejected";
        prepared: "prepared";
        submitted: "submitted";
        control_applied: "control_applied";
    }>;
    receipt: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        status: z.ZodEnum<{
            uncertain: "uncertain";
            rejected: "rejected";
            accepted: "accepted";
            missing: "missing";
            duplicate: "duplicate";
        }>;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        payloadDigest: z.ZodString;
        storeIncarnation: z.ZodString;
        runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        acceptedSeq: z.ZodDefault<z.ZodNullable<z.ZodNumber>>;
        nativeStatus: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            interrupted: "interrupted";
            succeeded: "succeeded";
            queued: "queued";
            awaiting_approval: "awaiting_approval";
            waiting_for_node: "waiting_for_node";
        }>>>;
        terminalEvidence: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            sessionId: z.ZodString;
            runId: z.ZodString;
            commandId: z.ZodString;
            terminalSeq: z.ZodNumber;
            terminalEventDigest: z.ZodString;
            resultDigest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
    eventBatch: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        sessionId: z.ZodString;
        storeIncarnation: z.ZodString;
        afterSeq: z.ZodNumber;
        nextSeq: z.ZodNumber;
        snapshotUpperSeq: z.ZodNumber;
        hasMore: z.ZodBoolean;
        items: z.ZodArray<z.ZodObject<{
            eventId: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            seq: z.ZodNumber;
            family: z.ZodString;
            type: z.ZodString;
            payload: z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>;
            sourceRef: z.ZodObject<{
                nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                parentRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                nativeEventType: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    materialProof: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        manifestRef: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>>;
    error: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        code: z.ZodString;
        retryable: z.ZodBoolean;
    }, z.core.$strict>>>;
    operationResult: z.ZodDefault<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        operation: z.ZodLiteral<"prepare">;
        contextRef: z.ZodString;
        contextDigest: z.ZodString;
        snapshot: z.ZodObject<{
            storeIncarnation: z.ZodString;
            grant: z.ZodObject<{
                grantId: z.ZodString;
                state: z.ZodEnum<{
                    active: "active";
                    suspended: "suspended";
                    revoked: "revoked";
                }>;
                revision: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                expiresAt: z.ZodString;
                admissionAllowed: z.ZodBoolean;
                admissionRevision: z.ZodNumber;
            }, z.core.$strict>;
            barrier: z.ZodObject<{
                queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    messageId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    inboxState: z.ZodEnum<{
                        completed: "completed";
                        accepted: "accepted";
                        claimed: "claimed";
                        discarded: "discarded";
                    }>;
                    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        running: "running";
                        waiting: "waiting";
                        completed: "completed";
                        failed: "failed";
                        pending: "pending";
                        cancelled: "cancelled";
                        interrupted: "interrupted";
                        paused: "paused";
                    }>>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"set_grant">;
        mutationReceipt: z.ZodObject<{
            operationId: z.ZodString;
            status: z.ZodDefault<z.ZodLiteral<"applied">>;
            snapshot: z.ZodObject<{
                storeIncarnation: z.ZodString;
                grant: z.ZodObject<{
                    grantId: z.ZodString;
                    state: z.ZodEnum<{
                        active: "active";
                        suspended: "suspended";
                        revoked: "revoked";
                    }>;
                    revision: z.ZodNumber;
                    attemptEpoch: z.ZodNumber;
                    expiresAt: z.ZodString;
                    admissionAllowed: z.ZodBoolean;
                    admissionRevision: z.ZodNumber;
                }, z.core.$strict>;
                barrier: z.ZodObject<{
                    queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        messageId: z.ZodString;
                        commandId: z.ZodString;
                        idempotencyKey: z.ZodString;
                        inboxState: z.ZodEnum<{
                            completed: "completed";
                            accepted: "accepted";
                            claimed: "claimed";
                            discarded: "discarded";
                        }>;
                        runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                        runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                            running: "running";
                            waiting: "waiting";
                            completed: "completed";
                            failed: "failed";
                            pending: "pending";
                            cancelled: "cancelled";
                            interrupted: "interrupted";
                            paused: "paused";
                        }>>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"set_admission">;
        mutationReceipt: z.ZodObject<{
            operationId: z.ZodString;
            status: z.ZodDefault<z.ZodLiteral<"applied">>;
            snapshot: z.ZodObject<{
                storeIncarnation: z.ZodString;
                grant: z.ZodObject<{
                    grantId: z.ZodString;
                    state: z.ZodEnum<{
                        active: "active";
                        suspended: "suspended";
                        revoked: "revoked";
                    }>;
                    revision: z.ZodNumber;
                    attemptEpoch: z.ZodNumber;
                    expiresAt: z.ZodString;
                    admissionAllowed: z.ZodBoolean;
                    admissionRevision: z.ZodNumber;
                }, z.core.$strict>;
                barrier: z.ZodObject<{
                    queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        messageId: z.ZodString;
                        commandId: z.ZodString;
                        idempotencyKey: z.ZodString;
                        inboxState: z.ZodEnum<{
                            completed: "completed";
                            accepted: "accepted";
                            claimed: "claimed";
                            discarded: "discarded";
                        }>;
                        runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                        runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                            running: "running";
                            waiting: "waiting";
                            completed: "completed";
                            failed: "failed";
                            pending: "pending";
                            cancelled: "cancelled";
                            interrupted: "interrupted";
                            paused: "paused";
                        }>>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"get_grant">;
        storeIncarnation: z.ZodString;
        current: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            storeIncarnation: z.ZodString;
            grant: z.ZodObject<{
                grantId: z.ZodString;
                state: z.ZodEnum<{
                    active: "active";
                    suspended: "suspended";
                    revoked: "revoked";
                }>;
                revision: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                expiresAt: z.ZodString;
                admissionAllowed: z.ZodBoolean;
                admissionRevision: z.ZodNumber;
            }, z.core.$strict>;
            barrier: z.ZodObject<{
                queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    messageId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    inboxState: z.ZodEnum<{
                        completed: "completed";
                        accepted: "accepted";
                        claimed: "claimed";
                        discarded: "discarded";
                    }>;
                    runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        running: "running";
                        waiting: "waiting";
                        completed: "completed";
                        failed: "failed";
                        pending: "pending";
                        cancelled: "cancelled";
                        interrupted: "interrupted";
                        paused: "paused";
                    }>>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
        }, z.core.$strict>>>;
        lookupOperationId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        mutationReceipt: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            operationId: z.ZodString;
            status: z.ZodDefault<z.ZodLiteral<"applied">>;
            snapshot: z.ZodObject<{
                storeIncarnation: z.ZodString;
                grant: z.ZodObject<{
                    grantId: z.ZodString;
                    state: z.ZodEnum<{
                        active: "active";
                        suspended: "suspended";
                        revoked: "revoked";
                    }>;
                    revision: z.ZodNumber;
                    attemptEpoch: z.ZodNumber;
                    expiresAt: z.ZodString;
                    admissionAllowed: z.ZodBoolean;
                    admissionRevision: z.ZodNumber;
                }, z.core.$strict>;
                barrier: z.ZodObject<{
                    queuedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    inFlightMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    discardedMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    settledMessageIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    commands: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        messageId: z.ZodString;
                        commandId: z.ZodString;
                        idempotencyKey: z.ZodString;
                        inboxState: z.ZodEnum<{
                            completed: "completed";
                            accepted: "accepted";
                            claimed: "claimed";
                            discarded: "discarded";
                        }>;
                        runId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                        runState: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                            running: "running";
                            waiting: "waiting";
                            completed: "completed";
                            failed: "failed";
                            pending: "pending";
                            cancelled: "cancelled";
                            interrupted: "interrupted";
                            paused: "paused";
                        }>>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "operation">>>;
    executionResult: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        status: z.ZodEnum<{
            failed: "failed";
            cancelled: "cancelled";
            interrupted: "interrupted";
            succeeded: "succeeded";
        }>;
        candidate: z.ZodObject<{
            result: z.ZodString;
            artifacts: z.ZodDefault<z.ZodArray<z.ZodRecord<z.ZodString, z.ZodType<TeamsCloudJson, unknown, z.core.$ZodTypeInternals<TeamsCloudJson, unknown>>>>>;
        }, z.core.$strict>;
        usage: z.ZodObject<{
            totalTokens: z.ZodNumber;
        }, z.core.$strict>;
        terminalEvidence: z.ZodObject<{
            sessionId: z.ZodString;
            runId: z.ZodString;
            commandId: z.ZodString;
            terminalSeq: z.ZodNumber;
            terminalEventDigest: z.ZodString;
            resultDigest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
        completionDigest: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type TeamsNodeReport = z.infer<typeof teamsNodeReportSchema>;
export declare const decodeTeamsExecutionRef: (raw: unknown) => TeamsExecutionRef;
export declare const decodeTeamsHostReceipt: (raw: unknown) => TeamsHostReceipt;
export declare const decodeTeamsCanonicalEventBatch: (raw: unknown) => TeamsCanonicalEventBatch;
export declare const decodeTeamsMaterialManifest: (raw: unknown) => TeamsMaterialManifest;
export declare const decodeTeamsNodeReport: (raw: unknown) => Promise<TeamsNodeReport>;
export declare const decodeTeamsHostOperationResult: (raw: unknown) => TeamsHostOperationResult;
/** Reuse identical scalar rules in the additional frozen wire contracts. */
export declare const teamsCloudScalarSchemas: {
    text: z.ZodString;
    length: (min: number, max: number) => z.ZodString;
    identifier: z.ZodString;
    operationKey: z.ZodString;
    digest: z.ZodString;
    commandId: z.ZodString;
    sequence: z.ZodNumber;
    revision: z.ZodNumber;
    timestamp: z.ZodString;
    relativePath: z.ZodString;
};
//# sourceMappingURL=cloudContracts.d.ts.map