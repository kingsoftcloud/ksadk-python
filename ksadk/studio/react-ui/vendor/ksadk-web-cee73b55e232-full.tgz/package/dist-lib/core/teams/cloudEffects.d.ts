import { z } from 'zod';
export declare const cloudEffectOutcomeSchema: z.ZodObject<{
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
    }>;
    external_ref: z.ZodNullable<z.ZodString>;
    evidence_ref: z.ZodString;
    result_digest: z.ZodNullable<z.ZodString>;
    definitively_not_applied: z.ZodBoolean;
}, z.core.$strict>;
export declare const cloudEffectResolutionSchema: z.ZodObject<{
    resolutionId: z.ZodString;
    expectedRevision: z.ZodNumber;
    expectedEvidenceDigest: z.ZodString;
    decision: z.ZodEnum<{
        confirmed_applied: "confirmed_applied";
        confirmed_not_applied: "confirmed_not_applied";
        accept_risk: "accept_risk";
    }>;
    evidenceRef: z.ZodString;
    reason: z.ZodString;
    kind: z.ZodEnum<{
        manual_risk_acceptance: "manual_risk_acceptance";
        external_evidence: "external_evidence";
    }>;
    actorSubject: z.ZodString;
    ownerScopeRef: z.ZodString;
    verifiedOutcome: z.ZodNullable<z.ZodObject<{
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
        }>;
        external_ref: z.ZodNullable<z.ZodString>;
        evidence_ref: z.ZodString;
        result_digest: z.ZodNullable<z.ZodString>;
        definitively_not_applied: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const cloudEffectSchema: z.ZodObject<{
    effectKey: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    toolName: z.ZodString;
    effectClass: z.ZodEnum<{
        external_idempotent: "external_idempotent";
        external_reconcilable: "external_reconcilable";
    }>;
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        resolved: "resolved";
        unknown: "unknown";
        prepared: "prepared";
    }>;
    revision: z.ZodNumber;
    evidenceDigest: z.ZodString;
    resolution: z.ZodNullable<z.ZodObject<{
        resolutionId: z.ZodString;
        expectedRevision: z.ZodNumber;
        expectedEvidenceDigest: z.ZodString;
        decision: z.ZodEnum<{
            confirmed_applied: "confirmed_applied";
            confirmed_not_applied: "confirmed_not_applied";
            accept_risk: "accept_risk";
        }>;
        evidenceRef: z.ZodString;
        reason: z.ZodString;
        kind: z.ZodEnum<{
            manual_risk_acceptance: "manual_risk_acceptance";
            external_evidence: "external_evidence";
        }>;
        actorSubject: z.ZodString;
        ownerScopeRef: z.ZodString;
        verifiedOutcome: z.ZodNullable<z.ZodObject<{
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>;
            external_ref: z.ZodNullable<z.ZodString>;
            evidence_ref: z.ZodString;
            result_digest: z.ZodNullable<z.ZodString>;
            definitively_not_applied: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    resolutionConflict: z.ZodBoolean;
    outcome: z.ZodNullable<z.ZodObject<{
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
        }>;
        external_ref: z.ZodNullable<z.ZodString>;
        evidence_ref: z.ZodString;
        result_digest: z.ZodNullable<z.ZodString>;
        definitively_not_applied: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CloudEffect = z.infer<typeof cloudEffectSchema>;
export declare const cloudEffectPageSchema: z.ZodObject<{
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    teamRunId: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        effectKey: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        toolName: z.ZodString;
        effectClass: z.ZodEnum<{
            external_idempotent: "external_idempotent";
            external_reconcilable: "external_reconcilable";
        }>;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            resolved: "resolved";
            unknown: "unknown";
            prepared: "prepared";
        }>;
        revision: z.ZodNumber;
        evidenceDigest: z.ZodString;
        resolution: z.ZodNullable<z.ZodObject<{
            resolutionId: z.ZodString;
            expectedRevision: z.ZodNumber;
            expectedEvidenceDigest: z.ZodString;
            decision: z.ZodEnum<{
                confirmed_applied: "confirmed_applied";
                confirmed_not_applied: "confirmed_not_applied";
                accept_risk: "accept_risk";
            }>;
            evidenceRef: z.ZodString;
            reason: z.ZodString;
            kind: z.ZodEnum<{
                manual_risk_acceptance: "manual_risk_acceptance";
                external_evidence: "external_evidence";
            }>;
            actorSubject: z.ZodString;
            ownerScopeRef: z.ZodString;
            verifiedOutcome: z.ZodNullable<z.ZodObject<{
                phase: z.ZodEnum<{
                    completed: "completed";
                    failed: "failed";
                }>;
                external_ref: z.ZodNullable<z.ZodString>;
                evidence_ref: z.ZodString;
                result_digest: z.ZodNullable<z.ZodString>;
                definitively_not_applied: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        resolutionConflict: z.ZodBoolean;
        outcome: z.ZodNullable<z.ZodObject<{
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>;
            external_ref: z.ZodNullable<z.ZodString>;
            evidence_ref: z.ZodString;
            result_digest: z.ZodNullable<z.ZodString>;
            definitively_not_applied: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodNumber>;
}, z.core.$strict>;
export type CloudEffectPage = z.infer<typeof cloudEffectPageSchema>;
//# sourceMappingURL=cloudEffects.d.ts.map