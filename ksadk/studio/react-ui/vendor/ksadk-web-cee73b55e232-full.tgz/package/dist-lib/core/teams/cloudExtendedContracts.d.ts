/** Additional frozen Teams DTOs. Python exports the published JSON Schemas;
 * shared generated fixtures test these browser semantic decoders against them.
 * Decoding proves shape, never a permit signature or execution authorization.
 */
import { z } from 'zod';
export declare const TEAMS_EFFECTS_PORT_VERSION: "teams-effects/v1";
export declare const TEAMS_BUILD_VERSION: "teams-build/v1";
export declare const TEAMS_LOADED_BUILD_VERSION: "teams-loaded-build/v1";
export declare const teamsEffectRequestSchema: z.ZodObject<{
    ref: z.ZodObject<{
        authorityId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        memberId: z.ZodString;
        runMemberId: z.ZodString;
        taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        attemptId: z.ZodString;
        deliveryId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        idempotencyKey: z.ZodString;
        schedulerEpoch: z.ZodNumber;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"node">;
            nodeId: z.ZodString;
            nodeGeneration: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cloud_agent">;
            agentId: z.ZodString;
            versionId: z.ZodString;
            runtimeId: z.ZodString;
            agentInstanceId: z.ZodString;
        }, z.core.$strict>], "kind">;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        capabilitiesDigest: z.ZodString;
        nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    context_ref: z.ZodString;
    store_incarnation: z.ZodString;
    journal_incarnation: z.ZodString;
    native_run_id: z.ZodString;
    tool_call_id: z.ZodString;
    effect_index: z.ZodNumber;
    tool_name: z.ZodString;
    adapter_version: z.ZodString;
    effect_class: z.ZodEnum<{
        external_idempotent: "external_idempotent";
        external_reconcilable: "external_reconcilable";
    }>;
    payload_digest: z.ZodString;
}, z.core.$strict>;
export declare const teamsEffectOutcomeSchema: z.ZodObject<{
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
    }>;
    external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    evidence_ref: z.ZodString;
    result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export declare const teamsEffectPreparedReceiptSchema: z.ZodObject<{
    effect_key: z.ZodString;
    payload_digest: z.ZodString;
    request_digest: z.ZodString;
    revision: z.ZodNumber;
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        resolved: "resolved";
        unknown: "unknown";
        prepared: "prepared";
    }>;
}, z.core.$strict>;
export declare const teamsEffectRecordSchema: z.ZodObject<{
    request: z.ZodObject<{
        ref: z.ZodObject<{
            authorityId: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            memberId: z.ZodString;
            runMemberId: z.ZodString;
            taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            attemptId: z.ZodString;
            deliveryId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            commandId: z.ZodString;
            idempotencyKey: z.ZodString;
            schedulerEpoch: z.ZodNumber;
            leaderEpoch: z.ZodNumber;
            dispatchEpoch: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"node">;
                nodeId: z.ZodString;
                nodeGeneration: z.ZodNumber;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"cloud_agent">;
                agentId: z.ZodString;
                versionId: z.ZodString;
                runtimeId: z.ZodString;
                agentInstanceId: z.ZodString;
            }, z.core.$strict>], "kind">;
            bundleDigest: z.ZodString;
            contractDigest: z.ZodString;
            capabilitiesDigest: z.ZodString;
            nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
        context_ref: z.ZodString;
        store_incarnation: z.ZodString;
        journal_incarnation: z.ZodString;
        native_run_id: z.ZodString;
        tool_call_id: z.ZodString;
        effect_index: z.ZodNumber;
        tool_name: z.ZodString;
        adapter_version: z.ZodString;
        effect_class: z.ZodEnum<{
            external_idempotent: "external_idempotent";
            external_reconcilable: "external_reconcilable";
        }>;
        payload_digest: z.ZodString;
    }, z.core.$strict>;
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        unknown: "unknown";
        prepared: "prepared";
    }>;
    revision: z.ZodNumber;
    evidence_digest: z.ZodString;
    outcome: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
        }>;
        external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        evidence_ref: z.ZodString;
        result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const teamsEffectReportReceiptSchema: z.ZodObject<{
    effectKey: z.ZodString;
    journalRevision: z.ZodNumber;
    evidenceDigest: z.ZodString;
    authorityRevision: z.ZodNumber;
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        resolved: "resolved";
        unknown: "unknown";
        prepared: "prepared";
    }>;
}, z.core.$strict>;
export declare const teamsEffectReconcileInputSchema: z.ZodObject<{
    expectedRevision: z.ZodNumber;
    expectedEvidenceDigest: z.ZodString;
    decision: z.ZodEnum<{
        confirmed_applied: "confirmed_applied";
        confirmed_not_applied: "confirmed_not_applied";
        accept_risk: "accept_risk";
    }>;
    evidenceRef: z.ZodString;
    reason: z.ZodString;
    idempotencyKey: z.ZodString;
}, z.core.$strict>;
export declare const teamsEffectProjectionSchema: z.ZodObject<{
    effectClass: z.ZodEnum<{
        external_idempotent: "external_idempotent";
        external_reconcilable: "external_reconcilable";
    }>;
    phase: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        resolved: "resolved";
        unknown: "unknown";
        prepared: "prepared";
    }>;
    revision: z.ZodNumber;
    evidenceDigest: z.ZodString;
    resolutionConflict: z.ZodBoolean;
    effectKey: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    toolName: z.ZodString;
    resolution: z.ZodNullable<z.ZodObject<{
        resolutionId: z.ZodString;
        expectedRevision: z.ZodNumber;
        expectedEvidenceDigest: z.ZodString;
        decision: z.ZodEnum<{
            confirmed_applied: "confirmed_applied";
            confirmed_not_applied: "confirmed_not_applied";
            accept_risk: "accept_risk";
        }>;
        evidenceRef: z.ZodString;
        reason: z.ZodString;
        kind: z.ZodEnum<{
            manual_risk_acceptance: "manual_risk_acceptance";
            external_evidence: "external_evidence";
        }>;
        actorSubject: z.ZodString;
        ownerScopeRef: z.ZodString;
        verifiedOutcome: z.ZodNullable<z.ZodObject<{
            phase: z.ZodNonOptional<z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>>;
            external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            evidence_ref: z.ZodNonOptional<z.ZodString>;
            result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    outcome: z.ZodNullable<z.ZodObject<{
        phase: z.ZodNonOptional<z.ZodEnum<{
            completed: "completed";
            failed: "failed";
        }>>;
        external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
        evidence_ref: z.ZodNonOptional<z.ZodString>;
        result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
        definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const teamsEffectProjectionPageSchema: z.ZodObject<{
    nextCursor: z.ZodNullable<z.ZodNumber>;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    teamRunId: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        effectClass: z.ZodEnum<{
            external_idempotent: "external_idempotent";
            external_reconcilable: "external_reconcilable";
        }>;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            resolved: "resolved";
            unknown: "unknown";
            prepared: "prepared";
        }>;
        revision: z.ZodNumber;
        evidenceDigest: z.ZodString;
        resolutionConflict: z.ZodBoolean;
        effectKey: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        toolName: z.ZodString;
        resolution: z.ZodNullable<z.ZodObject<{
            resolutionId: z.ZodString;
            expectedRevision: z.ZodNumber;
            expectedEvidenceDigest: z.ZodString;
            decision: z.ZodEnum<{
                confirmed_applied: "confirmed_applied";
                confirmed_not_applied: "confirmed_not_applied";
                accept_risk: "accept_risk";
            }>;
            evidenceRef: z.ZodString;
            reason: z.ZodString;
            kind: z.ZodEnum<{
                manual_risk_acceptance: "manual_risk_acceptance";
                external_evidence: "external_evidence";
            }>;
            actorSubject: z.ZodString;
            ownerScopeRef: z.ZodString;
            verifiedOutcome: z.ZodNullable<z.ZodObject<{
                phase: z.ZodNonOptional<z.ZodEnum<{
                    completed: "completed";
                    failed: "failed";
                }>>;
                external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                evidence_ref: z.ZodNonOptional<z.ZodString>;
                result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        outcome: z.ZodNullable<z.ZodObject<{
            phase: z.ZodNonOptional<z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>>;
            external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            evidence_ref: z.ZodNonOptional<z.ZodString>;
            result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const teamsExecutionEffectsPageSchema: z.ZodObject<{
    contextRef: z.ZodString;
    storeIncarnation: z.ZodString;
    nativeRunId: z.ZodString;
    journalIncarnation: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        request: z.ZodObject<{
            ref: z.ZodObject<{
                authorityId: z.ZodString;
                groupId: z.ZodString;
                teamRunId: z.ZodString;
                memberId: z.ZodString;
                runMemberId: z.ZodString;
                taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                attemptId: z.ZodString;
                deliveryId: z.ZodString;
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                sessionId: z.ZodString;
                commandId: z.ZodString;
                idempotencyKey: z.ZodString;
                schedulerEpoch: z.ZodNumber;
                leaderEpoch: z.ZodNumber;
                dispatchEpoch: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"node">;
                    nodeId: z.ZodString;
                    nodeGeneration: z.ZodNumber;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"cloud_agent">;
                    agentId: z.ZodString;
                    versionId: z.ZodString;
                    runtimeId: z.ZodString;
                    agentInstanceId: z.ZodString;
                }, z.core.$strict>], "kind">;
                bundleDigest: z.ZodString;
                contractDigest: z.ZodString;
                capabilitiesDigest: z.ZodString;
                nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>;
            context_ref: z.ZodString;
            store_incarnation: z.ZodString;
            journal_incarnation: z.ZodString;
            native_run_id: z.ZodString;
            tool_call_id: z.ZodString;
            effect_index: z.ZodNumber;
            tool_name: z.ZodString;
            adapter_version: z.ZodString;
            effect_class: z.ZodEnum<{
                external_idempotent: "external_idempotent";
                external_reconcilable: "external_reconcilable";
            }>;
            payload_digest: z.ZodString;
        }, z.core.$strict>;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            unknown: "unknown";
            prepared: "prepared";
        }>;
        revision: z.ZodNumber;
        evidence_digest: z.ZodString;
        outcome: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>;
            external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            evidence_ref: z.ZodString;
            result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    nextCursor: z.ZodDefault<z.ZodNullable<z.ZodString>>;
}, z.core.$strict>;
export declare const teamsExecutionEffectsRequestSchema: z.ZodObject<{
    contextRef: z.ZodString;
    expectedIncarnation: z.ZodString;
    permit: z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodLiteral<1>>;
        issuer: z.ZodString;
        kid: z.ZodString;
        authorityId: z.ZodString;
        issuedAt: z.ZodString;
        expiresAt: z.ZodString;
        nonce: z.ZodString;
        signature: z.ZodDefault<z.ZodString>;
        audience: z.ZodDefault<z.ZodLiteral<"agentengine-teams-runtime">>;
        permitKind: z.ZodEnum<{
            execute: "execute";
            recovery: "recovery";
        }>;
        subjectRef: z.ZodString;
        agentInstanceId: z.ZodString;
        sessionId: z.ZodString;
        commandId: z.ZodString;
        allowedOperations: z.ZodArray<z.ZodString>;
        payloadDigest: z.ZodString;
        policyDigest: z.ZodString;
        leaderEpoch: z.ZodNumber;
        dispatchEpoch: z.ZodNumber;
        attemptEpoch: z.ZodNumber;
        grantRevision: z.ZodNumber;
    }, z.core.$strict>;
    after: z.ZodDefault<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const teamsBuildManifestSchema: z.ZodObject<{
    materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
    }, z.core.$strict>>;
    agentDefinitionDigest: z.ZodString;
    toolsPolicyDigest: z.ZodString;
    dependencyLockDigest: z.ZodString;
    behaviorConfigDigest: z.ZodString;
    schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
    entrypoint: z.ZodString;
}, z.core.$strict>;
export declare const teamsLoadedBuildEvidenceSchema: z.ZodObject<{
    materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
    immutableWorkspace: z.ZodLiteral<true>;
    externalMutableInputs: z.ZodLiteral<false>;
    agentDefinitionDigest: z.ZodString;
    toolsPolicyDigest: z.ZodString;
    dependencyLockDigest: z.ZodString;
    behaviorConfigDigest: z.ZodString;
    schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-loaded-build/v1">>;
    codeArtifactDigest: z.ZodString;
    buildManifestDigest: z.ZodString;
}, z.core.$strict>;
export declare const teamsBuildArtifactReceiptSchema: z.ZodObject<{
    buildArtifactRef: z.ZodString;
    state: z.ZodLiteral<"verified">;
    authorityId: z.ZodString;
    codeArtifactDigest: z.ZodString;
    buildManifestDigest: z.ZodString;
    sizeBytes: z.ZodNumber;
    manifest: z.ZodObject<{
        materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            sizeBytes: z.ZodNumber;
        }, z.core.$strict>>;
        agentDefinitionDigest: z.ZodString;
        toolsPolicyDigest: z.ZodString;
        dependencyLockDigest: z.ZodString;
        behaviorConfigDigest: z.ZodString;
        schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
        entrypoint: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const teamsBuildArtifactLookupInputSchema: z.ZodObject<{
    idempotencyKey: z.ZodString;
}, z.core.$strict>;
export declare const teamsBuildArtifactLookupResultSchema: z.ZodUnion<readonly [z.ZodObject<{
    status: z.ZodLiteral<"missing">;
}, z.core.$strict>, z.ZodObject<{
    buildArtifactRef: z.ZodString;
    state: z.ZodLiteral<"verified">;
    authorityId: z.ZodString;
    codeArtifactDigest: z.ZodString;
    buildManifestDigest: z.ZodString;
    sizeBytes: z.ZodNumber;
    manifest: z.ZodObject<{
        materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            sizeBytes: z.ZodNumber;
        }, z.core.$strict>>;
        agentDefinitionDigest: z.ZodString;
        toolsPolicyDigest: z.ZodString;
        dependencyLockDigest: z.ZodString;
        behaviorConfigDigest: z.ZodString;
        schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
        entrypoint: z.ZodString;
    }, z.core.$strict>;
    status: z.ZodLiteral<"recorded">;
}, z.core.$strict>]>;
export declare const teamsDeploymentArtifactReceiptSchema: z.ZodObject<{
    agentId: z.ZodString;
    versionId: z.ZodString;
    instanceId: z.ZodString;
    codeArtifactDigest: z.ZodString;
    buildManifestDigest: z.ZodString;
    bundleDigest: z.ZodString;
    contractDigest: z.ZodString;
    deployedAt: z.ZodString;
}, z.core.$strict>;
export declare const teamsReleaseVerifyInputSchema: z.ZodObject<{
    buildArtifactRef: z.ZodString;
    localBindingRef: z.ZodString;
    cloudBindingRef: z.ZodString;
    idempotencyKey: z.ZodString;
}, z.core.$strict>;
export declare const teamsReleaseVerificationReceiptSchema: z.ZodObject<{
    releaseRef: z.ZodString;
    buildArtifactRef: z.ZodString;
    localBindingRef: z.ZodString;
    cloudBindingRef: z.ZodString;
    evidenceDigest: z.ZodString;
    verifiedAt: z.ZodString;
}, z.core.$strict>;
export declare const teamsExtendedContractSchemas: {
    readonly 'effect-request': z.ZodObject<{
        ref: z.ZodObject<{
            authorityId: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            memberId: z.ZodString;
            runMemberId: z.ZodString;
            taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            attemptId: z.ZodString;
            deliveryId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            commandId: z.ZodString;
            idempotencyKey: z.ZodString;
            schedulerEpoch: z.ZodNumber;
            leaderEpoch: z.ZodNumber;
            dispatchEpoch: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"node">;
                nodeId: z.ZodString;
                nodeGeneration: z.ZodNumber;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"cloud_agent">;
                agentId: z.ZodString;
                versionId: z.ZodString;
                runtimeId: z.ZodString;
                agentInstanceId: z.ZodString;
            }, z.core.$strict>], "kind">;
            bundleDigest: z.ZodString;
            contractDigest: z.ZodString;
            capabilitiesDigest: z.ZodString;
            nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>;
        context_ref: z.ZodString;
        store_incarnation: z.ZodString;
        journal_incarnation: z.ZodString;
        native_run_id: z.ZodString;
        tool_call_id: z.ZodString;
        effect_index: z.ZodNumber;
        tool_name: z.ZodString;
        adapter_version: z.ZodString;
        effect_class: z.ZodEnum<{
            external_idempotent: "external_idempotent";
            external_reconcilable: "external_reconcilable";
        }>;
        payload_digest: z.ZodString;
    }, z.core.$strict>;
    readonly 'effect-outcome': z.ZodObject<{
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
        }>;
        external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        evidence_ref: z.ZodString;
        result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>;
    readonly 'effect-prepared-receipt': z.ZodObject<{
        effect_key: z.ZodString;
        payload_digest: z.ZodString;
        request_digest: z.ZodString;
        revision: z.ZodNumber;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            resolved: "resolved";
            unknown: "unknown";
            prepared: "prepared";
        }>;
    }, z.core.$strict>;
    readonly 'effect-record': z.ZodObject<{
        request: z.ZodObject<{
            ref: z.ZodObject<{
                authorityId: z.ZodString;
                groupId: z.ZodString;
                teamRunId: z.ZodString;
                memberId: z.ZodString;
                runMemberId: z.ZodString;
                taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                attemptId: z.ZodString;
                deliveryId: z.ZodString;
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                sessionId: z.ZodString;
                commandId: z.ZodString;
                idempotencyKey: z.ZodString;
                schedulerEpoch: z.ZodNumber;
                leaderEpoch: z.ZodNumber;
                dispatchEpoch: z.ZodNumber;
                attemptEpoch: z.ZodNumber;
                target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"node">;
                    nodeId: z.ZodString;
                    nodeGeneration: z.ZodNumber;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"cloud_agent">;
                    agentId: z.ZodString;
                    versionId: z.ZodString;
                    runtimeId: z.ZodString;
                    agentInstanceId: z.ZodString;
                }, z.core.$strict>], "kind">;
                bundleDigest: z.ZodString;
                contractDigest: z.ZodString;
                capabilitiesDigest: z.ZodString;
                nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>;
            context_ref: z.ZodString;
            store_incarnation: z.ZodString;
            journal_incarnation: z.ZodString;
            native_run_id: z.ZodString;
            tool_call_id: z.ZodString;
            effect_index: z.ZodNumber;
            tool_name: z.ZodString;
            adapter_version: z.ZodString;
            effect_class: z.ZodEnum<{
                external_idempotent: "external_idempotent";
                external_reconcilable: "external_reconcilable";
            }>;
            payload_digest: z.ZodString;
        }, z.core.$strict>;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            unknown: "unknown";
            prepared: "prepared";
        }>;
        revision: z.ZodNumber;
        evidence_digest: z.ZodString;
        outcome: z.ZodDefault<z.ZodNullable<z.ZodObject<{
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>;
            external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            evidence_ref: z.ZodString;
            result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly 'effect-report-receipt': z.ZodObject<{
        effectKey: z.ZodString;
        journalRevision: z.ZodNumber;
        evidenceDigest: z.ZodString;
        authorityRevision: z.ZodNumber;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            resolved: "resolved";
            unknown: "unknown";
            prepared: "prepared";
        }>;
    }, z.core.$strict>;
    readonly 'effect-reconcile-input': z.ZodObject<{
        expectedRevision: z.ZodNumber;
        expectedEvidenceDigest: z.ZodString;
        decision: z.ZodEnum<{
            confirmed_applied: "confirmed_applied";
            confirmed_not_applied: "confirmed_not_applied";
            accept_risk: "accept_risk";
        }>;
        evidenceRef: z.ZodString;
        reason: z.ZodString;
        idempotencyKey: z.ZodString;
    }, z.core.$strict>;
    readonly 'effect-projection': z.ZodObject<{
        effectClass: z.ZodEnum<{
            external_idempotent: "external_idempotent";
            external_reconcilable: "external_reconcilable";
        }>;
        phase: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            resolved: "resolved";
            unknown: "unknown";
            prepared: "prepared";
        }>;
        revision: z.ZodNumber;
        evidenceDigest: z.ZodString;
        resolutionConflict: z.ZodBoolean;
        effectKey: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        toolName: z.ZodString;
        resolution: z.ZodNullable<z.ZodObject<{
            resolutionId: z.ZodString;
            expectedRevision: z.ZodNumber;
            expectedEvidenceDigest: z.ZodString;
            decision: z.ZodEnum<{
                confirmed_applied: "confirmed_applied";
                confirmed_not_applied: "confirmed_not_applied";
                accept_risk: "accept_risk";
            }>;
            evidenceRef: z.ZodString;
            reason: z.ZodString;
            kind: z.ZodEnum<{
                manual_risk_acceptance: "manual_risk_acceptance";
                external_evidence: "external_evidence";
            }>;
            actorSubject: z.ZodString;
            ownerScopeRef: z.ZodString;
            verifiedOutcome: z.ZodNullable<z.ZodObject<{
                phase: z.ZodNonOptional<z.ZodEnum<{
                    completed: "completed";
                    failed: "failed";
                }>>;
                external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                evidence_ref: z.ZodNonOptional<z.ZodString>;
                result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        outcome: z.ZodNullable<z.ZodObject<{
            phase: z.ZodNonOptional<z.ZodEnum<{
                completed: "completed";
                failed: "failed";
            }>>;
            external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            evidence_ref: z.ZodNonOptional<z.ZodString>;
            result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
            definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'effect-projection-page': z.ZodObject<{
        nextCursor: z.ZodNullable<z.ZodNumber>;
        scope: z.ZodObject<{
            authorityId: z.ZodString;
            ownerScopeRef: z.ZodString;
            groupId: z.ZodString;
        }, z.core.$strict>;
        teamRunId: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            effectClass: z.ZodEnum<{
                external_idempotent: "external_idempotent";
                external_reconcilable: "external_reconcilable";
            }>;
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                resolved: "resolved";
                unknown: "unknown";
                prepared: "prepared";
            }>;
            revision: z.ZodNumber;
            evidenceDigest: z.ZodString;
            resolutionConflict: z.ZodBoolean;
            effectKey: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            toolName: z.ZodString;
            resolution: z.ZodNullable<z.ZodObject<{
                resolutionId: z.ZodString;
                expectedRevision: z.ZodNumber;
                expectedEvidenceDigest: z.ZodString;
                decision: z.ZodEnum<{
                    confirmed_applied: "confirmed_applied";
                    confirmed_not_applied: "confirmed_not_applied";
                    accept_risk: "accept_risk";
                }>;
                evidenceRef: z.ZodString;
                reason: z.ZodString;
                kind: z.ZodEnum<{
                    manual_risk_acceptance: "manual_risk_acceptance";
                    external_evidence: "external_evidence";
                }>;
                actorSubject: z.ZodString;
                ownerScopeRef: z.ZodString;
                verifiedOutcome: z.ZodNullable<z.ZodObject<{
                    phase: z.ZodNonOptional<z.ZodEnum<{
                        completed: "completed";
                        failed: "failed";
                    }>>;
                    external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                    evidence_ref: z.ZodNonOptional<z.ZodString>;
                    result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                    definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            outcome: z.ZodNullable<z.ZodObject<{
                phase: z.ZodNonOptional<z.ZodEnum<{
                    completed: "completed";
                    failed: "failed";
                }>>;
                external_ref: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                evidence_ref: z.ZodNonOptional<z.ZodString>;
                result_digest: z.ZodNonOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
                definitively_not_applied: z.ZodNonOptional<z.ZodDefault<z.ZodBoolean>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'execution-effects-request': z.ZodObject<{
        contextRef: z.ZodString;
        expectedIncarnation: z.ZodString;
        permit: z.ZodObject<{
            schemaVersion: z.ZodDefault<z.ZodLiteral<1>>;
            issuer: z.ZodString;
            kid: z.ZodString;
            authorityId: z.ZodString;
            issuedAt: z.ZodString;
            expiresAt: z.ZodString;
            nonce: z.ZodString;
            signature: z.ZodDefault<z.ZodString>;
            audience: z.ZodDefault<z.ZodLiteral<"agentengine-teams-runtime">>;
            permitKind: z.ZodEnum<{
                execute: "execute";
                recovery: "recovery";
            }>;
            subjectRef: z.ZodString;
            agentInstanceId: z.ZodString;
            sessionId: z.ZodString;
            commandId: z.ZodString;
            allowedOperations: z.ZodArray<z.ZodString>;
            payloadDigest: z.ZodString;
            policyDigest: z.ZodString;
            leaderEpoch: z.ZodNumber;
            dispatchEpoch: z.ZodNumber;
            attemptEpoch: z.ZodNumber;
            grantRevision: z.ZodNumber;
        }, z.core.$strict>;
        after: z.ZodDefault<z.ZodString>;
        limit: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>;
    readonly 'execution-effects-page': z.ZodObject<{
        contextRef: z.ZodString;
        storeIncarnation: z.ZodString;
        nativeRunId: z.ZodString;
        journalIncarnation: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            request: z.ZodObject<{
                ref: z.ZodObject<{
                    authorityId: z.ZodString;
                    groupId: z.ZodString;
                    teamRunId: z.ZodString;
                    memberId: z.ZodString;
                    runMemberId: z.ZodString;
                    taskId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    attemptId: z.ZodString;
                    deliveryId: z.ZodString;
                    bindingRef: z.ZodString;
                    providerRef: z.ZodString;
                    sessionId: z.ZodString;
                    commandId: z.ZodString;
                    idempotencyKey: z.ZodString;
                    schedulerEpoch: z.ZodNumber;
                    leaderEpoch: z.ZodNumber;
                    dispatchEpoch: z.ZodNumber;
                    attemptEpoch: z.ZodNumber;
                    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"node">;
                        nodeId: z.ZodString;
                        nodeGeneration: z.ZodNumber;
                    }, z.core.$strict>, z.ZodObject<{
                        kind: z.ZodLiteral<"cloud_agent">;
                        agentId: z.ZodString;
                        versionId: z.ZodString;
                        runtimeId: z.ZodString;
                        agentInstanceId: z.ZodString;
                    }, z.core.$strict>], "kind">;
                    bundleDigest: z.ZodString;
                    contractDigest: z.ZodString;
                    capabilitiesDigest: z.ZodString;
                    nativeRunId: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>;
                context_ref: z.ZodString;
                store_incarnation: z.ZodString;
                journal_incarnation: z.ZodString;
                native_run_id: z.ZodString;
                tool_call_id: z.ZodString;
                effect_index: z.ZodNumber;
                tool_name: z.ZodString;
                adapter_version: z.ZodString;
                effect_class: z.ZodEnum<{
                    external_idempotent: "external_idempotent";
                    external_reconcilable: "external_reconcilable";
                }>;
                payload_digest: z.ZodString;
            }, z.core.$strict>;
            phase: z.ZodEnum<{
                completed: "completed";
                failed: "failed";
                unknown: "unknown";
                prepared: "prepared";
            }>;
            revision: z.ZodNumber;
            evidence_digest: z.ZodString;
            outcome: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                phase: z.ZodEnum<{
                    completed: "completed";
                    failed: "failed";
                }>;
                external_ref: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                evidence_ref: z.ZodString;
                result_digest: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                definitively_not_applied: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        nextCursor: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>;
    readonly 'build-manifest': z.ZodObject<{
        materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            sizeBytes: z.ZodNumber;
        }, z.core.$strict>>;
        agentDefinitionDigest: z.ZodString;
        toolsPolicyDigest: z.ZodString;
        dependencyLockDigest: z.ZodString;
        behaviorConfigDigest: z.ZodString;
        schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
        entrypoint: z.ZodString;
    }, z.core.$strict>;
    readonly 'loaded-build-evidence': z.ZodObject<{
        materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
        immutableWorkspace: z.ZodLiteral<true>;
        externalMutableInputs: z.ZodLiteral<false>;
        agentDefinitionDigest: z.ZodString;
        toolsPolicyDigest: z.ZodString;
        dependencyLockDigest: z.ZodString;
        behaviorConfigDigest: z.ZodString;
        schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-loaded-build/v1">>;
        codeArtifactDigest: z.ZodString;
        buildManifestDigest: z.ZodString;
    }, z.core.$strict>;
    readonly 'build-artifact-receipt': z.ZodObject<{
        buildArtifactRef: z.ZodString;
        state: z.ZodLiteral<"verified">;
        authorityId: z.ZodString;
        codeArtifactDigest: z.ZodString;
        buildManifestDigest: z.ZodString;
        sizeBytes: z.ZodNumber;
        manifest: z.ZodObject<{
            materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                sizeBytes: z.ZodNumber;
            }, z.core.$strict>>;
            agentDefinitionDigest: z.ZodString;
            toolsPolicyDigest: z.ZodString;
            dependencyLockDigest: z.ZodString;
            behaviorConfigDigest: z.ZodString;
            schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
            entrypoint: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'build-artifact-lookup-input': z.ZodObject<{
        idempotencyKey: z.ZodString;
    }, z.core.$strict>;
    readonly 'build-artifact-lookup-result': z.ZodUnion<readonly [z.ZodObject<{
        status: z.ZodLiteral<"missing">;
    }, z.core.$strict>, z.ZodObject<{
        buildArtifactRef: z.ZodString;
        state: z.ZodLiteral<"verified">;
        authorityId: z.ZodString;
        codeArtifactDigest: z.ZodString;
        buildManifestDigest: z.ZodString;
        sizeBytes: z.ZodNumber;
        manifest: z.ZodObject<{
            materialContractVersion: z.ZodDefault<z.ZodLiteral<"materials/v1">>;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                sizeBytes: z.ZodNumber;
            }, z.core.$strict>>;
            agentDefinitionDigest: z.ZodString;
            toolsPolicyDigest: z.ZodString;
            dependencyLockDigest: z.ZodString;
            behaviorConfigDigest: z.ZodString;
            schemaVersion: z.ZodDefault<z.ZodLiteral<"teams-build/v1">>;
            entrypoint: z.ZodString;
        }, z.core.$strict>;
        status: z.ZodLiteral<"recorded">;
    }, z.core.$strict>]>;
    readonly 'deployment-artifact-receipt': z.ZodObject<{
        agentId: z.ZodString;
        versionId: z.ZodString;
        instanceId: z.ZodString;
        codeArtifactDigest: z.ZodString;
        buildManifestDigest: z.ZodString;
        bundleDigest: z.ZodString;
        contractDigest: z.ZodString;
        deployedAt: z.ZodString;
    }, z.core.$strict>;
    readonly 'release-verify-input': z.ZodObject<{
        buildArtifactRef: z.ZodString;
        localBindingRef: z.ZodString;
        cloudBindingRef: z.ZodString;
        idempotencyKey: z.ZodString;
    }, z.core.$strict>;
    readonly 'release-verification-receipt': z.ZodObject<{
        releaseRef: z.ZodString;
        buildArtifactRef: z.ZodString;
        localBindingRef: z.ZodString;
        cloudBindingRef: z.ZodString;
        evidenceDigest: z.ZodString;
        verifiedAt: z.ZodString;
    }, z.core.$strict>;
};
export declare function decodeTeamsExtendedContract(model: string, value: unknown): unknown;
export type TeamsBuildManifest = z.infer<typeof teamsBuildManifestSchema>;
export type TeamsLoadedBuildEvidence = z.infer<typeof teamsLoadedBuildEvidenceSchema>;
export type TeamsReleaseVerificationReceipt = z.infer<typeof teamsReleaseVerificationReceiptSchema>;
export type TeamsEffectRecord = z.infer<typeof teamsEffectRecordSchema>;
//# sourceMappingURL=cloudExtendedContracts.d.ts.map