import { z } from 'zod';
import { type TeamsMaterialCreateInput, type TeamsMaterialManifest } from './cloudContracts.js';
import type { WorkspaceClientScope } from './workspaceContracts.js';
export declare const CLOUD_MATERIAL_LIMITS: {
    readonly fileBytes: number;
    readonly totalBytes: number;
    readonly files: 4096;
    readonly manifestBytes: number;
};
export declare const cloudMaterialSchema: z.ZodObject<{
    materialId: z.ZodString;
    manifestDigest: z.ZodString;
    state: z.ZodEnum<{
        ready: "ready";
        pending: "pending";
        expired: "expired";
    }>;
    sizeBytes: z.ZodNumber;
    manifest: z.ZodObject<{
        kind: z.ZodEnum<{
            files: "files";
            git_snapshot: "git_snapshot";
        }>;
        sourceCommit: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        entries: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            sizeBytes: z.ZodNumber;
            mediaType: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const cloudMaterialMissingSchema: z.ZodObject<{
    materialId: z.ZodString;
    state: z.ZodLiteral<"pending">;
    missingBlobs: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const cloudMaterialBlobSchema: z.ZodObject<{
    digest: z.ZodString;
    sizeBytes: z.ZodNumber;
    state: z.ZodLiteral<"ready">;
}, z.core.$strict>;
export type CloudMaterial = z.infer<typeof cloudMaterialSchema>;
export type CloudMaterialScope = Omit<WorkspaceClientScope, 'groupId'>;
export type CloudMaterialEntry = TeamsMaterialManifest['entries'][number];
export interface CloudMaterialPort {
    createMaterial(scope: CloudMaterialScope, input: TeamsMaterialCreateInput, signal: AbortSignal): Promise<CloudMaterial>;
    uploadMaterialBlob(scope: CloudMaterialScope, material: CloudMaterial, entry: CloudMaterialEntry, file: Blob, signal: AbortSignal): Promise<void>;
    finalizeMaterial(scope: CloudMaterialScope, material: CloudMaterial, idempotencyKey: string, signal: AbortSignal): Promise<CloudMaterial>;
}
/** The Server derives this ID from authority and the immutable manifest, not from a URL supplied by the browser. */
export declare function verifyCloudMaterial(raw: unknown, scope: CloudMaterialScope, expectedManifest?: TeamsMaterialManifest): Promise<CloudMaterial>;
export type CloudMaterialState = 'idle' | 'hashing' | 'creating' | 'uploading' | 'verifying' | 'ready' | 'failed' | 'cancelled';
export interface CloudMaterialSnapshot {
    state: CloudMaterialState;
    files: ReadonlyArray<{
        name: string;
        size: number;
    }>;
    completed: number;
    material: CloudMaterial | null;
    error: string;
}
export declare const materialIsBusy: (state: CloudMaterialState) => boolean;
/** Files stay in memory. Only a verified ready reference may enter the durable goal outbox. */
export declare class CloudMaterialUpload {
    private snapshot;
    private selection;
    private listeners;
    private readonly port;
    private readonly scope;
    constructor(port: CloudMaterialPort, scope: CloudMaterialScope);
    getSnapshot: () => CloudMaterialSnapshot;
    subscribe: (listener: () => void) => () => void;
    private update;
    clear(): void;
    dispose(): void;
    cancel(): void;
    select(files: Iterable<File>): Promise<void>;
    retry(): Promise<void>;
    private run;
}
//# sourceMappingURL=cloudMaterials.d.ts.map