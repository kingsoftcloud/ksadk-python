import { TeamsOperationOutbox, type EnqueueTeamsOperation, type TeamsOperation, type TeamsOperationOutboxOptions, type TeamsOperationTransport } from './operationOutbox.js';
export interface CloudOperationsState {
    operations: TeamsOperation[];
    recovering: boolean;
    errorCode: string | null;
}
/** Owns one authenticated scope. A view change never generates another command identity. */
export declare class CloudOperations {
    readonly outbox: TeamsOperationOutbox;
    private readonly drainer;
    private state;
    private listeners;
    private work?;
    private disposed;
    private writable;
    private recoveryController?;
    private readonly controller;
    constructor(options: TeamsOperationOutboxOptions, transport: TeamsOperationTransport);
    getSnapshot: () => CloudOperationsState;
    subscribe: (listener: () => void) => () => void;
    private update;
    refresh(): Promise<void>;
    /** Read-only degradation may inspect the queue, but must not silently resume delivery. */
    setWritable(value: boolean): void;
    enqueue(input: EnqueueTeamsOperation): Promise<TeamsOperation>;
    recover(): Promise<void>;
    submit(input: EnqueueTeamsOperation): Promise<TeamsOperation>;
    dispose(): void;
}
//# sourceMappingURL=cloudOperations.d.ts.map