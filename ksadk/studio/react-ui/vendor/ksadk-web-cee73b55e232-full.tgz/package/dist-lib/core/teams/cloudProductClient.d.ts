import { z } from 'zod';
import { type CloudEffectPage } from './cloudEffects.js';
import { type CloudMaterial, type CloudMaterialEntry, type CloudMaterialScope, type CloudMaterialPort } from './cloudMaterials.js';
import { type TeamsMaterialCreateInput } from './cloudContracts.js';
import type { TeamsFetch } from './client.js';
import type { TeamsOperation, TeamsOperationOutcome, TeamsOperationTransport } from './operationOutbox.js';
import { type TeamTask } from './types.js';
import { type WorkspaceClientScope, type WorkspaceInteraction } from './workspaceContracts.js';
export declare const cloudDirectorySchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
    }, z.core.$strict>;
    items: z.ZodArray<z.ZodObject<{
        groupId: z.ZodString;
        name: z.ZodString;
        authorityRef: z.ZodString;
        tenantId: z.ZodString;
        ownerSubject: z.ZodString;
        leaderMemberId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            active: "active";
            archived: "archived";
        }>;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        policy: z.ZodObject<{
            taskAcceptance: z.ZodEnum<{
                leader: "leader";
                human: "human";
                result: "result";
            }>;
            peerWake: z.ZodBoolean;
        }, z.core.$strict>;
        memberCount: z.ZodNumber;
        pendingCount: z.ZodNumber;
        unreadCount: z.ZodNumber;
        lastMessage: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type CloudDirectory = z.infer<typeof cloudDirectorySchema>;
export declare const cloudDirectoryBindingSchema: z.ZodObject<{
    bindingRef: z.ZodString;
    providerRef: z.ZodString;
    kind: z.ZodEnum<{
        local_build: "local_build";
        a2a: "a2a";
        cloud: "cloud";
    }>;
    agentId: z.ZodString;
    capabilities: z.ZodObject<{
        enqueue: z.ZodBoolean;
        cancel: z.ZodBoolean;
        steer: z.ZodBoolean;
        restore: z.ZodBoolean;
        interaction: z.ZodBoolean;
        leader: z.ZodBoolean;
    }, z.core.$strict>;
    availability: z.ZodObject<{
        state: z.ZodEnum<{
            unavailable: "unavailable";
            ready: "ready";
            unchecked: "unchecked";
        }>;
        code: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
        action: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    name: z.ZodString;
    revision: z.ZodNumber;
    authorityRef: z.ZodString;
}, z.core.$strict>;
export declare const cloudBindingDirectorySchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
    }, z.core.$strict>;
    items: z.ZodArray<z.ZodObject<{
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        kind: z.ZodEnum<{
            local_build: "local_build";
            a2a: "a2a";
            cloud: "cloud";
        }>;
        agentId: z.ZodString;
        capabilities: z.ZodObject<{
            enqueue: z.ZodBoolean;
            cancel: z.ZodBoolean;
            steer: z.ZodBoolean;
            restore: z.ZodBoolean;
            interaction: z.ZodBoolean;
            leader: z.ZodBoolean;
        }, z.core.$strict>;
        availability: z.ZodObject<{
            state: z.ZodEnum<{
                unavailable: "unavailable";
                ready: "ready";
                unchecked: "unchecked";
            }>;
            code: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            action: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        name: z.ZodString;
        revision: z.ZodNumber;
        authorityRef: z.ZodString;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type CloudBindingDirectory = z.infer<typeof cloudBindingDirectorySchema>;
export declare const cloudInteractionDetailSchema: z.ZodObject<{
    ref: z.ZodObject<{
        authorityRef: z.ZodString;
        groupId: z.ZodString;
        memberId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        runId: z.ZodString;
        itemId: z.ZodOptional<z.ZodString>;
        interactionId: z.ZodString;
    }, z.core.$strict>;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    revision: z.ZodNumber;
    title: z.ZodString;
    kind: z.ZodEnum<{
        input: "input";
        approval: "approval";
    }>;
    status: z.ZodEnum<{
        pending: "pending";
        resolving: "resolving";
        resolved: "resolved";
        cancelled: "cancelled";
        expired: "expired";
    }>;
    createdAt: z.ZodISODateTime;
    message: z.ZodString;
    requestSchema: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strict>;
export type CloudInteractionDetail = z.infer<typeof cloudInteractionDetailSchema>;
/** Fixed-origin authenticated adapter; reads remain separate from durable mutations. */
export declare class HttpCloudTeamsProductClient implements TeamsOperationTransport, CloudMaterialPort {
    readonly origin: string;
    private readonly fetcher;
    private readonly groupsBase;
    private readonly teamsBase;
    constructor(options: {
        origin: string;
        fetch?: TeamsFetch;
        groupsBase?: string;
        teamsBase?: string;
    });
    private json;
    list(scope: Omit<WorkspaceClientScope, 'groupId'>, signal: AbortSignal, cursor?: string): Promise<CloudDirectory>;
    bindings(scope: Omit<WorkspaceClientScope, 'groupId'>, signal: AbortSignal, cursor?: string): Promise<CloudBindingDirectory>;
    private target;
    private outcome;
    lookup(operation: Readonly<TeamsOperation>, signal: AbortSignal): Promise<TeamsOperationOutcome | {
        status: 'missing';
    }>;
    send(operation: Readonly<TeamsOperation>, signal: AbortSignal): Promise<TeamsOperationOutcome>;
    interaction(scope: WorkspaceClientScope, summary: WorkspaceInteraction, signal: AbortSignal): Promise<CloudInteractionDetail>;
    task(scope: WorkspaceClientScope, taskId: string, teamRunId: string, signal: AbortSignal): Promise<TeamTask>;
    effects(scope: WorkspaceClientScope, teamRunId: string, signal: AbortSignal, after?: number): Promise<CloudEffectPage>;
    createMaterial(scope: CloudMaterialScope, input: TeamsMaterialCreateInput, signal: AbortSignal): Promise<CloudMaterial>;
    uploadMaterialBlob(scope: CloudMaterialScope, raw: CloudMaterial, entry: CloudMaterialEntry, file: Blob, signal: AbortSignal): Promise<void>;
    finalizeMaterial(scope: CloudMaterialScope, raw: CloudMaterial, idempotencyKey: string, signal: AbortSignal): Promise<CloudMaterial>;
    artifactUrl(scope: WorkspaceClientScope, artifactId: string, teamRunId: string): string;
}
//# sourceMappingURL=cloudProductClient.d.ts.map