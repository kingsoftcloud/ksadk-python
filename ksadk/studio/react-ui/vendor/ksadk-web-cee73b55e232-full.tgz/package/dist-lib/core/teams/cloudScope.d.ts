/** Preconditions only. The authenticated Server derives and compares its own identity. */
export declare function cloudScopeHeaders(scope: {
    authorityId: string;
    ownerScopeRef: string;
}): Record<string, string>;
//# sourceMappingURL=cloudScope.d.ts.map