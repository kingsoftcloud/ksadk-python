import type { TeamMemberCandidate } from '../../components/teams/CreateGroupDialog.js';
export declare const candidateKey: (candidate: TeamMemberCandidate) => string;
export declare const available: (candidate: TeamMemberCandidate) => boolean;
export declare function groupTeamCandidates(candidates: TeamMemberCandidate[]): TeamMemberCandidate[][];
//# sourceMappingURL=grouping.d.ts.map