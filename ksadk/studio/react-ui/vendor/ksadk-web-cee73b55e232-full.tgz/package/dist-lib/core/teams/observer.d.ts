import type { ConversationItem } from '../conversation/types.js';
import { type TeamsFetch } from './client.js';
import type { ConnectionStatus, MemberObservation, MemberStreamRef } from './types.js';
export type MemberHistory = {
    ref: MemberStreamRef;
    items: ConversationItem[];
    cursor: number;
};
export type MemberFrame = {
    ref: MemberStreamRef;
    item: ConversationItem;
    cursor: number;
};
export type MemberObservationTransport = {
    read(ref: MemberStreamRef, signal: AbortSignal): Promise<MemberHistory>;
    subscribe(ref: MemberStreamRef, after: number, signal: AbortSignal, onFrame: (frame: MemberFrame) => void): Promise<void>;
};
export type ChatScopeSnapshot = MemberObservation & {
    draft: string;
    error: string | null;
};
/** A member scope owns its requests, reducer and draft. It has no send/delete API. */
export declare class MemberChatScope {
    readonly ref: Readonly<MemberStreamRef>;
    private value;
    private reducer;
    private listeners;
    private abort?;
    private generation;
    private disposed;
    constructor(ref: MemberStreamRef);
    getSnapshot: () => ChatScopeSnapshot;
    subscribe: (listener: () => void) => (() => void);
    private update;
    setDraft(draft: string): void;
    private assertRef;
    private decode;
    ingest(frame: MemberFrame): void;
    restore(history: MemberHistory): void;
    observe(transport: MemberObservationTransport): Promise<void>;
    setConnection(connection: ConnectionStatus): void;
    /** Close the observation; intentionally never invokes cancel/control. */
    disconnect(): void;
    dispose(): void;
}
export declare function createChatScope(ref: MemberStreamRef): MemberChatScope;
/** Optional same-origin HTTP adapter. Hosts may inject an existing authorized observer. */
export declare function createHttpMemberTransport(options?: {
    fetch?: TeamsFetch;
    baseUrl?: string;
}): MemberObservationTransport;
//# sourceMappingURL=observer.d.ts.map