/** Durable user intent only. Authentication belongs to the injected transport, never this store. */
export type TeamsOperationStatus = 'queued' | 'sending' | 'confirmed' | 'rejected' | 'uncertain';
export type TeamsOperationJson = null | boolean | number | string | TeamsOperationJson[] | {
    [key: string]: TeamsOperationJson;
};
export type TeamsOperationPayload = {
    [key: string]: TeamsOperationJson;
};
export interface TeamsOperationScope {
    origin: string;
    ownerScopeRef: string;
    authorityId: string;
    /** Empty only for authority-level operations, such as creating a group. */
    groupId: string;
}
export interface TeamsOperation {
    scope: TeamsOperationScope;
    operationId: string;
    /** Stable business operation, including its resource target, not a URL carrying credentials. */
    operation: string;
    idempotencyKey: string;
    payload: TeamsOperationPayload;
    payloadDigest: string;
    createdAt: number;
    updatedAt: number;
    status: TeamsOperationStatus;
    revision: number;
    attempts: number;
    serverOperationId?: string;
    receipt?: TeamsOperationPayload;
    errorCode?: string;
    leaseOwner?: string;
    leaseToken?: string;
    leaseExpiresAt?: number;
}
export interface EnqueueTeamsOperation {
    operationId?: string;
    operation: string;
    idempotencyKey?: string;
    /** Business JSON only; transport headers, request IDs and credentials are rejected. */
    payload: TeamsOperationPayload;
}
export type TeamsOperationOutcome = {
    status: 'confirmed';
    serverOperationId?: string;
    receipt?: TeamsOperationPayload;
} | {
    status: 'rejected';
    serverOperationId?: string;
    code: string;
    receipt?: TeamsOperationPayload;
} | {
    status: 'uncertain' | 'pending';
    serverOperationId?: string;
};
export interface TeamsOperationTransport {
    /** A definitive missing reply permits resending the SAME operation/key/payload only. */
    lookup(operation: Readonly<TeamsOperation>, signal: AbortSignal): Promise<TeamsOperationOutcome | {
        status: 'missing';
    }>;
    send(operation: Readonly<TeamsOperation>, signal: AbortSignal): Promise<TeamsOperationOutcome>;
}
export declare class TeamsOperationOutboxError extends Error {
    readonly code: string;
    constructor(code: string);
}
export interface TeamsOperationOutboxOptions {
    scope: TeamsOperationScope;
    databaseName?: string;
    indexedDB?: IDBFactory;
    crypto?: Pick<Crypto, 'subtle' | 'randomUUID'>;
    now?: () => number;
    /** Per scope. Terminal rows may be evicted, unresolved intent is never evicted. */
    maxEntries?: number;
    maxPayloadBytes?: number;
}
/** One immutable authenticated owner scope per instance; never a process-wide current-user store. */
export declare class TeamsOperationOutbox {
    readonly scope: Readonly<TeamsOperationScope>;
    private readonly factory;
    private readonly cryptography;
    private readonly now;
    private readonly databaseName;
    private readonly maxEntries;
    private readonly maxPayloadBytes;
    private database?;
    private closed;
    constructor(options: TeamsOperationOutboxOptions);
    private open;
    private key;
    private transaction;
    private digest;
    enqueue(input: EnqueueTeamsOperation, options?: {
        reuseUnresolved?: boolean;
    }): Promise<TeamsOperation>;
    get(operationId: string): Promise<TeamsOperation | undefined>;
    list(options?: {
        statuses?: TeamsOperationStatus[];
        limit?: number;
    }): Promise<TeamsOperation[]>;
    /** A payload may change only before the first claim, with explicit revision CAS. */
    updateDraft(operationId: string, expectedRevision: number, value: TeamsOperationPayload): Promise<TeamsOperation>;
    /** IndexedDB serializes overlapping read/write transactions across tabs. */
    claimNext(leaseOwner: string, leaseMs: number, excludedIds?: ReadonlySet<string>): Promise<TeamsOperation | undefined>;
    private owns;
    renew(claim: TeamsOperation, leaseMs: number): Promise<boolean>;
    /** Late responses from an expired owner can never overwrite a newer tab's receipt. */
    settle(claim: TeamsOperation, outcome: TeamsOperationOutcome, failureCode?: string): Promise<boolean>;
    close(): Promise<void>;
}
export interface TeamsOperationDrainOptions {
    signal?: AbortSignal;
    maxOperations?: number;
    maxDurationMs?: number;
    requestTimeoutMs?: number;
    leaseMs?: number;
}
export interface TeamsOperationDrainResult {
    processed: number;
    confirmed: number;
    rejected: number;
    uncertain: number;
    aborted: boolean;
}
/** Bounded, cancellable recovery. Call deactivate on logout/identity change before creating another drainer. */
export declare class TeamsOperationDrainer {
    private readonly outbox;
    private readonly transport;
    private readonly tabId;
    private active?;
    private deactivated;
    constructor(outbox: TeamsOperationOutbox, transport: TeamsOperationTransport, tabId?: string);
    deactivate(): void;
    drain(options?: TeamsOperationDrainOptions): Promise<TeamsOperationDrainResult>;
    private recover;
    private call;
}
//# sourceMappingURL=operationOutbox.d.ts.map