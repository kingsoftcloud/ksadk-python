import type { GroupSnapshot, TeamTask, TaskStatus, TeamStatus } from './types.js';
export declare const TEAM_STATUS_LABELS: Record<TeamStatus | TaskStatus, string>;
export declare const isTeamRunActive: (status: string) => boolean;
export declare function currentTeamRun(snapshot: GroupSnapshot): import("./types.js").TeamRun | null;
export declare function taskSection(task: TeamTask): 'attention' | 'running' | 'waiting' | 'done';
/** A completed candidate supersedes an earlier approval wait; retain failure details. */
export declare function taskDisplayReason(task: {
    status: string;
    reason?: string | null;
}): string | undefined;
export declare function safeArtifactUri(uri?: string | null): string | null;
/** Stable dependency levels. Invalid cycles remain explicit, never fake a graph. */
export declare function taskDependencyLevels(tasks: TeamTask[]): {
    levels: TeamTask[][];
    invalidIds: string[];
};
//# sourceMappingURL=presentation.d.ts.map