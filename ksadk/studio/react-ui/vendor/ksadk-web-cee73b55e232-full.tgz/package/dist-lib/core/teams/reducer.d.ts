import type { GroupEvent, GroupSnapshot, InteractionRef, MemberStreamRef } from './types.js';
export declare function memberStreamKey(ref: MemberStreamRef): string;
export declare function interactionRefKey(ref: InteractionRef): string;
/** One reducer per authorized group. It never mutates source ConversationItems. */
export declare class GroupReducer {
    private value;
    private seenIds;
    constructor(snapshot: GroupSnapshot);
    snapshot(): GroupSnapshot;
    replace(raw: unknown): boolean;
    apply(raw: GroupEvent): boolean;
}
//# sourceMappingURL=reducer.d.ts.map