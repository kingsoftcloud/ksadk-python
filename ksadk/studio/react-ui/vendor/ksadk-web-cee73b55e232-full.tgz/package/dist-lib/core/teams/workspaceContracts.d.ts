import { z } from 'zod';
export declare const TEAMS_WORKSPACE_VERSION: "workspace/v1";
export declare const WORKSPACE_COLLECTIONS: readonly ["runSummaries", "taskSummaries", "pendingInteractions", "recentMessages", "artifactSummaries"];
export type WorkspaceCollection = typeof WORKSPACE_COLLECTIONS[number];
export declare const workspaceScopeSchema: z.ZodObject<{
    authorityId: z.ZodString;
    ownerScopeRef: z.ZodString;
    groupId: z.ZodString;
}, z.core.$strict>;
export type WorkspaceScope = z.infer<typeof workspaceScopeSchema>;
export type WorkspaceClientScope = WorkspaceScope & {
    origin: string;
};
export declare const workspaceClientScopeSchema: z.ZodObject<{
    authorityId: z.ZodString;
    ownerScopeRef: z.ZodString;
    groupId: z.ZodString;
    origin: z.ZodString;
}, z.core.$strict>;
export declare const workspaceGroupSchema: z.ZodObject<{
    groupId: z.ZodString;
    name: z.ZodString;
    authorityRef: z.ZodString;
    tenantId: z.ZodString;
    ownerSubject: z.ZodString;
    leaderMemberId: z.ZodString;
    revision: z.ZodNumber;
    status: z.ZodEnum<{
        active: "active";
        archived: "archived";
    }>;
    createdAt: z.ZodISODateTime;
    updatedAt: z.ZodISODateTime;
    policy: z.ZodObject<{
        taskAcceptance: z.ZodEnum<{
            leader: "leader";
            human: "human";
            result: "result";
        }>;
        peerWake: z.ZodBoolean;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const workspaceBindingSchema: z.ZodObject<{
    bindingRef: z.ZodString;
    providerRef: z.ZodString;
    kind: z.ZodEnum<{
        local_build: "local_build";
        a2a: "a2a";
        cloud: "cloud";
    }>;
    agentId: z.ZodString;
    capabilities: z.ZodObject<{
        enqueue: z.ZodBoolean;
        cancel: z.ZodBoolean;
        steer: z.ZodBoolean;
        restore: z.ZodBoolean;
        interaction: z.ZodBoolean;
        leader: z.ZodBoolean;
    }, z.core.$strict>;
    availability: z.ZodObject<{
        state: z.ZodEnum<{
            unavailable: "unavailable";
            ready: "ready";
            unchecked: "unchecked";
        }>;
        code: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
        action: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const workspaceMemberSchema: z.ZodObject<{
    memberId: z.ZodString;
    groupId: z.ZodString;
    name: z.ZodString;
    role: z.ZodEnum<{
        leader: "leader";
        member: "member";
    }>;
    responsibility: z.ZodString;
    bindingRef: z.ZodString;
    binding: z.ZodObject<{
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        kind: z.ZodEnum<{
            local_build: "local_build";
            a2a: "a2a";
            cloud: "cloud";
        }>;
        agentId: z.ZodString;
        capabilities: z.ZodObject<{
            enqueue: z.ZodBoolean;
            cancel: z.ZodBoolean;
            steer: z.ZodBoolean;
            restore: z.ZodBoolean;
            interaction: z.ZodBoolean;
            leader: z.ZodBoolean;
        }, z.core.$strict>;
        availability: z.ZodObject<{
            state: z.ZodEnum<{
                unavailable: "unavailable";
                ready: "ready";
                unchecked: "unchecked";
            }>;
            code: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            action: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    sessionId: z.ZodString;
    revision: z.ZodNumber;
    status: z.ZodEnum<{
        unavailable: "unavailable";
        active: "active";
        removed: "removed";
    }>;
    executionStatus: z.ZodEnum<{
        unavailable: "unavailable";
        running: "running";
        waiting: "waiting";
        idle: "idle";
        needs_attention: "needs_attention";
        queued: "queued";
    }>;
    activeRunId: z.ZodNullable<z.ZodString>;
    reason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const workspaceRunMemberSchema: z.ZodObject<{
    memberId: z.ZodString;
    groupId: z.ZodString;
    name: z.ZodString;
    role: z.ZodEnum<{
        leader: "leader";
        member: "member";
    }>;
    responsibility: z.ZodString;
    bindingRef: z.ZodString;
    binding: z.ZodObject<{
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        kind: z.ZodEnum<{
            local_build: "local_build";
            a2a: "a2a";
            cloud: "cloud";
        }>;
        agentId: z.ZodString;
        capabilities: z.ZodObject<{
            enqueue: z.ZodBoolean;
            cancel: z.ZodBoolean;
            steer: z.ZodBoolean;
            restore: z.ZodBoolean;
            interaction: z.ZodBoolean;
            leader: z.ZodBoolean;
        }, z.core.$strict>;
        availability: z.ZodObject<{
            state: z.ZodEnum<{
                unavailable: "unavailable";
                ready: "ready";
                unchecked: "unchecked";
            }>;
            code: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            action: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    sessionId: z.ZodString;
    revision: z.ZodNumber;
    status: z.ZodEnum<{
        unavailable: "unavailable";
        active: "active";
        removed: "removed";
    }>;
    executionStatus: z.ZodEnum<{
        unavailable: "unavailable";
        running: "running";
        waiting: "waiting";
        idle: "idle";
        needs_attention: "needs_attention";
        queued: "queued";
    }>;
    activeRunId: z.ZodNullable<z.ZodString>;
    reason: z.ZodNullable<z.ZodString>;
    runMemberId: z.ZodString;
    teamRunId: z.ZodString;
    groupRevision: z.ZodNumber;
}, z.core.$strict>;
export declare const workspaceLeaderStandbySchema: z.ZodObject<{
    state: z.ZodEnum<{
        blocked: "blocked";
        active: "active";
        armed: "armed";
        fencing_old: "fencing_old";
        waiting_old_grant: "waiting_old_grant";
        activating: "activating";
    }>;
    standbyBindingRef: z.ZodString;
    releaseRef: z.ZodString;
    takeoverId: z.ZodNullable<z.ZodString>;
    reason: z.ZodNullable<z.ZodString>;
    newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strict>;
export type WorkspaceLeaderStandby = z.infer<typeof workspaceLeaderStandbySchema>;
export declare const workspaceRunSummarySchema: z.ZodObject<{
    teamRunId: z.ZodString;
    groupId: z.ZodString;
    revision: z.ZodNumber;
    groupRevision: z.ZodNumber;
    goalMessageId: z.ZodString;
    goal: z.ZodString;
    leaderMemberId: z.ZodString;
    status: z.ZodEnum<{
        running: "running";
        waiting: "waiting";
        failed: "failed";
        cancelled: "cancelled";
        planning: "planning";
        needs_attention: "needs_attention";
        awaiting_acceptance: "awaiting_acceptance";
        succeeded: "succeeded";
        cancel_requested: "cancel_requested";
    }>;
    dispatchSuspended: z.ZodBoolean;
    dispatchEpoch: z.ZodNumber;
    taskCount: z.ZodNumber;
    pendingCount: z.ZodNumber;
    createdAt: z.ZodISODateTime;
    updatedAt: z.ZodISODateTime;
    reason: z.ZodNullable<z.ZodString>;
    leaderStandby: z.ZodOptional<z.ZodObject<{
        state: z.ZodEnum<{
            blocked: "blocked";
            active: "active";
            armed: "armed";
            fencing_old: "fencing_old";
            waiting_old_grant: "waiting_old_grant";
            activating: "activating";
        }>;
        standbyBindingRef: z.ZodString;
        releaseRef: z.ZodString;
        takeoverId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
        newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const workspaceTaskSummarySchema: z.ZodObject<{
    taskId: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    revision: z.ZodNumber;
    title: z.ZodString;
    ownerMemberId: z.ZodNullable<z.ZodString>;
    dependencies: z.ZodArray<z.ZodString>;
    status: z.ZodEnum<{
        running: "running";
        failed: "failed";
        ready: "ready";
        cancelled: "cancelled";
        awaiting_acceptance: "awaiting_acceptance";
        succeeded: "succeeded";
        cancel_requested: "cancel_requested";
        draft: "draft";
        blocked: "blocked";
    }>;
    attemptCount: z.ZodNumber;
    reason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const workspaceInteractionSchema: z.ZodObject<{
    ref: z.ZodObject<{
        authorityRef: z.ZodString;
        groupId: z.ZodString;
        memberId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        runId: z.ZodString;
        itemId: z.ZodOptional<z.ZodString>;
        interactionId: z.ZodString;
    }, z.core.$strict>;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    revision: z.ZodNumber;
    title: z.ZodString;
    kind: z.ZodEnum<{
        input: "input";
        approval: "approval";
    }>;
    status: z.ZodEnum<{
        pending: "pending";
        resolving: "resolving";
        resolved: "resolved";
        cancelled: "cancelled";
        expired: "expired";
    }>;
    createdAt: z.ZodISODateTime;
}, z.core.$strict>;
export declare const workspaceMessageSchema: z.ZodObject<{
    messageId: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodNullable<z.ZodString>;
    revision: z.ZodNumber;
    createdSeq: z.ZodNumber;
    createdAt: z.ZodISODateTime;
    senderPrincipal: z.ZodString;
    senderName: z.ZodString;
    groupRole: z.ZodEnum<{
        system: "system";
        owner: "owner";
        leader: "leader";
        member: "member";
    }>;
    memberId: z.ZodNullable<z.ZodString>;
    parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"text">;
        text: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"attachment">;
        attachmentRef: z.ZodString;
        mediaType: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>], "kind">>;
    mentions: z.ZodArray<z.ZodString>;
    intent: z.ZodEnum<{
        progress: "progress";
        note: "note";
        result: "result";
        start_goal: "start_goal";
        followup: "followup";
        directed: "directed";
    }>;
    replyTo: z.ZodNullable<z.ZodString>;
    sourceRefs: z.ZodArray<z.ZodObject<{
        authorityRef: z.ZodString;
        groupId: z.ZodString;
        memberId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        runId: z.ZodString;
        itemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    visibility: z.ZodEnum<{
        public: "public";
        internal: "internal";
    }>;
}, z.core.$strict>;
export declare const workspaceArtifactSchema: z.ZodObject<{
    artifactId: z.ZodString;
    groupId: z.ZodString;
    teamRunId: z.ZodString;
    revision: z.ZodNumber;
    name: z.ZodString;
    mediaType: z.ZodString;
    source: z.ZodObject<{
        authorityRef: z.ZodString;
        groupId: z.ZodString;
        memberId: z.ZodString;
        bindingRef: z.ZodString;
        providerRef: z.ZodString;
        sessionId: z.ZodString;
        runId: z.ZodString;
        itemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    digest: z.ZodString;
    sizeBytes: z.ZodNumber;
    state: z.ZodEnum<{
        failed: "failed";
        ready: "ready";
        pending: "pending";
    }>;
}, z.core.$strict>;
export type WorkspaceGroup = z.infer<typeof workspaceGroupSchema>;
export type WorkspaceMember = z.infer<typeof workspaceMemberSchema>;
export type WorkspaceRunMember = z.infer<typeof workspaceRunMemberSchema>;
export type WorkspaceRunSummary = z.infer<typeof workspaceRunSummarySchema>;
export type WorkspaceTaskSummary = z.infer<typeof workspaceTaskSummarySchema>;
export type WorkspaceInteraction = z.infer<typeof workspaceInteractionSchema>;
export type WorkspaceMessage = z.infer<typeof workspaceMessageSchema>;
export type WorkspaceArtifact = z.infer<typeof workspaceArtifactSchema>;
export type WorkspaceRow = WorkspaceRunSummary | WorkspaceTaskSummary | WorkspaceInteraction | WorkspaceMessage | WorkspaceArtifact;
export declare function workspaceScopeKey(scope: WorkspaceScope): string;
export declare function workspaceClientScopeKey(scope: WorkspaceClientScope): string;
export declare function workspaceInteractionKey(value: WorkspaceInteraction): string;
export declare function workspaceRowKey(collection: WorkspaceCollection, value: WorkspaceRow): string;
export declare const teamWorkspaceSnapshotSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    group: z.ZodObject<{
        groupId: z.ZodString;
        name: z.ZodString;
        authorityRef: z.ZodString;
        tenantId: z.ZodString;
        ownerSubject: z.ZodString;
        leaderMemberId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            active: "active";
            archived: "archived";
        }>;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        policy: z.ZodObject<{
            taskAcceptance: z.ZodEnum<{
                leader: "leader";
                human: "human";
                result: "result";
            }>;
            peerWake: z.ZodBoolean;
        }, z.core.$strict>;
    }, z.core.$strict>;
    members: z.ZodArray<z.ZodObject<{
        memberId: z.ZodString;
        groupId: z.ZodString;
        name: z.ZodString;
        role: z.ZodEnum<{
            leader: "leader";
            member: "member";
        }>;
        responsibility: z.ZodString;
        bindingRef: z.ZodString;
        binding: z.ZodObject<{
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            kind: z.ZodEnum<{
                local_build: "local_build";
                a2a: "a2a";
                cloud: "cloud";
            }>;
            agentId: z.ZodString;
            capabilities: z.ZodObject<{
                enqueue: z.ZodBoolean;
                cancel: z.ZodBoolean;
                steer: z.ZodBoolean;
                restore: z.ZodBoolean;
                interaction: z.ZodBoolean;
                leader: z.ZodBoolean;
            }, z.core.$strict>;
            availability: z.ZodObject<{
                state: z.ZodEnum<{
                    unavailable: "unavailable";
                    ready: "ready";
                    unchecked: "unchecked";
                }>;
                code: z.ZodNullable<z.ZodString>;
                reason: z.ZodNullable<z.ZodString>;
                action: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        sessionId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            unavailable: "unavailable";
            active: "active";
            removed: "removed";
        }>;
        executionStatus: z.ZodEnum<{
            unavailable: "unavailable";
            running: "running";
            waiting: "waiting";
            idle: "idle";
            needs_attention: "needs_attention";
            queued: "queued";
        }>;
        activeRunId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    runSummaries: z.ZodArray<z.ZodObject<{
        teamRunId: z.ZodString;
        groupId: z.ZodString;
        revision: z.ZodNumber;
        groupRevision: z.ZodNumber;
        goalMessageId: z.ZodString;
        goal: z.ZodString;
        leaderMemberId: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            planning: "planning";
            needs_attention: "needs_attention";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
        }>;
        dispatchSuspended: z.ZodBoolean;
        dispatchEpoch: z.ZodNumber;
        taskCount: z.ZodNumber;
        pendingCount: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        reason: z.ZodNullable<z.ZodString>;
        leaderStandby: z.ZodOptional<z.ZodObject<{
            state: z.ZodEnum<{
                blocked: "blocked";
                active: "active";
                armed: "armed";
                fencing_old: "fencing_old";
                waiting_old_grant: "waiting_old_grant";
                activating: "activating";
            }>;
            standbyBindingRef: z.ZodString;
            releaseRef: z.ZodString;
            takeoverId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    selectedRun: z.ZodNullable<z.ZodObject<{
        teamRunId: z.ZodString;
        groupId: z.ZodString;
        revision: z.ZodNumber;
        groupRevision: z.ZodNumber;
        goalMessageId: z.ZodString;
        goal: z.ZodString;
        leaderMemberId: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            planning: "planning";
            needs_attention: "needs_attention";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
        }>;
        dispatchSuspended: z.ZodBoolean;
        dispatchEpoch: z.ZodNumber;
        taskCount: z.ZodNumber;
        pendingCount: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        reason: z.ZodNullable<z.ZodString>;
        leaderStandby: z.ZodOptional<z.ZodObject<{
            state: z.ZodEnum<{
                blocked: "blocked";
                active: "active";
                armed: "armed";
                fencing_old: "fencing_old";
                waiting_old_grant: "waiting_old_grant";
                activating: "activating";
            }>;
            standbyBindingRef: z.ZodString;
            releaseRef: z.ZodString;
            takeoverId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    selectedRunMembers: z.ZodArray<z.ZodObject<{
        memberId: z.ZodString;
        groupId: z.ZodString;
        name: z.ZodString;
        role: z.ZodEnum<{
            leader: "leader";
            member: "member";
        }>;
        responsibility: z.ZodString;
        bindingRef: z.ZodString;
        binding: z.ZodObject<{
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            kind: z.ZodEnum<{
                local_build: "local_build";
                a2a: "a2a";
                cloud: "cloud";
            }>;
            agentId: z.ZodString;
            capabilities: z.ZodObject<{
                enqueue: z.ZodBoolean;
                cancel: z.ZodBoolean;
                steer: z.ZodBoolean;
                restore: z.ZodBoolean;
                interaction: z.ZodBoolean;
                leader: z.ZodBoolean;
            }, z.core.$strict>;
            availability: z.ZodObject<{
                state: z.ZodEnum<{
                    unavailable: "unavailable";
                    ready: "ready";
                    unchecked: "unchecked";
                }>;
                code: z.ZodNullable<z.ZodString>;
                reason: z.ZodNullable<z.ZodString>;
                action: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        sessionId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            unavailable: "unavailable";
            active: "active";
            removed: "removed";
        }>;
        executionStatus: z.ZodEnum<{
            unavailable: "unavailable";
            running: "running";
            waiting: "waiting";
            idle: "idle";
            needs_attention: "needs_attention";
            queued: "queued";
        }>;
        activeRunId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
        runMemberId: z.ZodString;
        teamRunId: z.ZodString;
        groupRevision: z.ZodNumber;
    }, z.core.$strict>>;
    taskSummaries: z.ZodArray<z.ZodObject<{
        taskId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        ownerMemberId: z.ZodNullable<z.ZodString>;
        dependencies: z.ZodArray<z.ZodString>;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            ready: "ready";
            cancelled: "cancelled";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
            draft: "draft";
            blocked: "blocked";
        }>;
        attemptCount: z.ZodNumber;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    pendingInteractions: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
            interactionId: z.ZodString;
        }, z.core.$strict>;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        kind: z.ZodEnum<{
            input: "input";
            approval: "approval";
        }>;
        status: z.ZodEnum<{
            pending: "pending";
            resolving: "resolving";
            resolved: "resolved";
            cancelled: "cancelled";
            expired: "expired";
        }>;
        createdAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    recentMessages: z.ZodArray<z.ZodObject<{
        messageId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodNullable<z.ZodString>;
        revision: z.ZodNumber;
        createdSeq: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        senderPrincipal: z.ZodString;
        senderName: z.ZodString;
        groupRole: z.ZodEnum<{
            system: "system";
            owner: "owner";
            leader: "leader";
            member: "member";
        }>;
        memberId: z.ZodNullable<z.ZodString>;
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"attachment">;
            attachmentRef: z.ZodString;
            mediaType: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>], "kind">>;
        mentions: z.ZodArray<z.ZodString>;
        intent: z.ZodEnum<{
            progress: "progress";
            note: "note";
            result: "result";
            start_goal: "start_goal";
            followup: "followup";
            directed: "directed";
        }>;
        replyTo: z.ZodNullable<z.ZodString>;
        sourceRefs: z.ZodArray<z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        visibility: z.ZodEnum<{
            public: "public";
            internal: "internal";
        }>;
    }, z.core.$strict>>;
    artifactSummaries: z.ZodArray<z.ZodObject<{
        artifactId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        name: z.ZodString;
        mediaType: z.ZodString;
        source: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
        state: z.ZodEnum<{
            failed: "failed";
            ready: "ready";
            pending: "pending";
        }>;
    }, z.core.$strict>>;
    cursors: z.ZodObject<{
        runSummaries: z.ZodNullable<z.ZodString>;
        taskSummaries: z.ZodNullable<z.ZodString>;
        pendingInteractions: z.ZodNullable<z.ZodString>;
        recentMessages: z.ZodNullable<z.ZodString>;
        artifactSummaries: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type TeamWorkspaceSnapshot = z.infer<typeof teamWorkspaceSnapshotSchema>;
export declare const workspacePageSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    collection: z.ZodLiteral<"runSummaries">;
    items: z.ZodArray<z.ZodObject<{
        teamRunId: z.ZodString;
        groupId: z.ZodString;
        revision: z.ZodNumber;
        groupRevision: z.ZodNumber;
        goalMessageId: z.ZodString;
        goal: z.ZodString;
        leaderMemberId: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            planning: "planning";
            needs_attention: "needs_attention";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
        }>;
        dispatchSuspended: z.ZodBoolean;
        dispatchEpoch: z.ZodNumber;
        taskCount: z.ZodNumber;
        pendingCount: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        reason: z.ZodNullable<z.ZodString>;
        leaderStandby: z.ZodOptional<z.ZodObject<{
            state: z.ZodEnum<{
                blocked: "blocked";
                active: "active";
                armed: "armed";
                fencing_old: "fencing_old";
                waiting_old_grant: "waiting_old_grant";
                activating: "activating";
            }>;
            standbyBindingRef: z.ZodString;
            releaseRef: z.ZodString;
            takeoverId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    collection: z.ZodLiteral<"taskSummaries">;
    items: z.ZodArray<z.ZodObject<{
        taskId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        ownerMemberId: z.ZodNullable<z.ZodString>;
        dependencies: z.ZodArray<z.ZodString>;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            ready: "ready";
            cancelled: "cancelled";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
            draft: "draft";
            blocked: "blocked";
        }>;
        attemptCount: z.ZodNumber;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    collection: z.ZodLiteral<"pendingInteractions">;
    items: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
            interactionId: z.ZodString;
        }, z.core.$strict>;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        kind: z.ZodEnum<{
            input: "input";
            approval: "approval";
        }>;
        status: z.ZodEnum<{
            pending: "pending";
            resolving: "resolving";
            resolved: "resolved";
            cancelled: "cancelled";
            expired: "expired";
        }>;
        createdAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    collection: z.ZodLiteral<"recentMessages">;
    items: z.ZodArray<z.ZodObject<{
        messageId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodNullable<z.ZodString>;
        revision: z.ZodNumber;
        createdSeq: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        senderPrincipal: z.ZodString;
        senderName: z.ZodString;
        groupRole: z.ZodEnum<{
            system: "system";
            owner: "owner";
            leader: "leader";
            member: "member";
        }>;
        memberId: z.ZodNullable<z.ZodString>;
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"attachment">;
            attachmentRef: z.ZodString;
            mediaType: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>], "kind">>;
        mentions: z.ZodArray<z.ZodString>;
        intent: z.ZodEnum<{
            progress: "progress";
            note: "note";
            result: "result";
            start_goal: "start_goal";
            followup: "followup";
            directed: "directed";
        }>;
        replyTo: z.ZodNullable<z.ZodString>;
        sourceRefs: z.ZodArray<z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        visibility: z.ZodEnum<{
            public: "public";
            internal: "internal";
        }>;
    }, z.core.$strict>>;
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    collection: z.ZodLiteral<"artifactSummaries">;
    items: z.ZodArray<z.ZodObject<{
        artifactId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        name: z.ZodString;
        mediaType: z.ZodString;
        source: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
        state: z.ZodEnum<{
            failed: "failed";
            ready: "ready";
            pending: "pending";
        }>;
    }, z.core.$strict>>;
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    nextCursor: z.ZodNullable<z.ZodString>;
}, z.core.$strict>], "collection">;
export type WorkspacePage = z.infer<typeof workspacePageSchema>;
export type WorkspacePageRequest = {
    collection: WorkspaceCollection;
    snapshotId: string;
    watermark: number;
    teamRunId: string | null;
    cursor: string;
    limit?: number;
};
export declare const workspacePageRequestSchema: z.ZodObject<{
    collection: z.ZodEnum<{
        runSummaries: "runSummaries";
        taskSummaries: "taskSummaries";
        pendingInteractions: "pendingInteractions";
        recentMessages: "recentMessages";
        artifactSummaries: "artifactSummaries";
    }>;
    snapshotId: z.ZodString;
    watermark: z.ZodNumber;
    teamRunId: z.ZodNullable<z.ZodString>;
    cursor: z.ZodString;
    limit: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const workspaceChangeSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"group">;
    group: z.ZodObject<{
        groupId: z.ZodString;
        name: z.ZodString;
        authorityRef: z.ZodString;
        tenantId: z.ZodString;
        ownerSubject: z.ZodString;
        leaderMemberId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            active: "active";
            archived: "archived";
        }>;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        policy: z.ZodObject<{
            taskAcceptance: z.ZodEnum<{
                leader: "leader";
                human: "human";
                result: "result";
            }>;
            peerWake: z.ZodBoolean;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"member">;
    member: z.ZodObject<{
        memberId: z.ZodString;
        groupId: z.ZodString;
        name: z.ZodString;
        role: z.ZodEnum<{
            leader: "leader";
            member: "member";
        }>;
        responsibility: z.ZodString;
        bindingRef: z.ZodString;
        binding: z.ZodObject<{
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            kind: z.ZodEnum<{
                local_build: "local_build";
                a2a: "a2a";
                cloud: "cloud";
            }>;
            agentId: z.ZodString;
            capabilities: z.ZodObject<{
                enqueue: z.ZodBoolean;
                cancel: z.ZodBoolean;
                steer: z.ZodBoolean;
                restore: z.ZodBoolean;
                interaction: z.ZodBoolean;
                leader: z.ZodBoolean;
            }, z.core.$strict>;
            availability: z.ZodObject<{
                state: z.ZodEnum<{
                    unavailable: "unavailable";
                    ready: "ready";
                    unchecked: "unchecked";
                }>;
                code: z.ZodNullable<z.ZodString>;
                reason: z.ZodNullable<z.ZodString>;
                action: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        sessionId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            unavailable: "unavailable";
            active: "active";
            removed: "removed";
        }>;
        executionStatus: z.ZodEnum<{
            unavailable: "unavailable";
            running: "running";
            waiting: "waiting";
            idle: "idle";
            needs_attention: "needs_attention";
            queued: "queued";
        }>;
        activeRunId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"run_member">;
    runMember: z.ZodObject<{
        memberId: z.ZodString;
        groupId: z.ZodString;
        name: z.ZodString;
        role: z.ZodEnum<{
            leader: "leader";
            member: "member";
        }>;
        responsibility: z.ZodString;
        bindingRef: z.ZodString;
        binding: z.ZodObject<{
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            kind: z.ZodEnum<{
                local_build: "local_build";
                a2a: "a2a";
                cloud: "cloud";
            }>;
            agentId: z.ZodString;
            capabilities: z.ZodObject<{
                enqueue: z.ZodBoolean;
                cancel: z.ZodBoolean;
                steer: z.ZodBoolean;
                restore: z.ZodBoolean;
                interaction: z.ZodBoolean;
                leader: z.ZodBoolean;
            }, z.core.$strict>;
            availability: z.ZodObject<{
                state: z.ZodEnum<{
                    unavailable: "unavailable";
                    ready: "ready";
                    unchecked: "unchecked";
                }>;
                code: z.ZodNullable<z.ZodString>;
                reason: z.ZodNullable<z.ZodString>;
                action: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        sessionId: z.ZodString;
        revision: z.ZodNumber;
        status: z.ZodEnum<{
            unavailable: "unavailable";
            active: "active";
            removed: "removed";
        }>;
        executionStatus: z.ZodEnum<{
            unavailable: "unavailable";
            running: "running";
            waiting: "waiting";
            idle: "idle";
            needs_attention: "needs_attention";
            queued: "queued";
        }>;
        activeRunId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
        runMemberId: z.ZodString;
        teamRunId: z.ZodString;
        groupRevision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"run">;
    run: z.ZodObject<{
        teamRunId: z.ZodString;
        groupId: z.ZodString;
        revision: z.ZodNumber;
        groupRevision: z.ZodNumber;
        goalMessageId: z.ZodString;
        goal: z.ZodString;
        leaderMemberId: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            planning: "planning";
            needs_attention: "needs_attention";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
        }>;
        dispatchSuspended: z.ZodBoolean;
        dispatchEpoch: z.ZodNumber;
        taskCount: z.ZodNumber;
        pendingCount: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
        reason: z.ZodNullable<z.ZodString>;
        leaderStandby: z.ZodOptional<z.ZodObject<{
            state: z.ZodEnum<{
                blocked: "blocked";
                active: "active";
                armed: "armed";
                fencing_old: "fencing_old";
                waiting_old_grant: "waiting_old_grant";
                activating: "activating";
            }>;
            standbyBindingRef: z.ZodString;
            releaseRef: z.ZodString;
            takeoverId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"task">;
    task: z.ZodObject<{
        taskId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        ownerMemberId: z.ZodNullable<z.ZodString>;
        dependencies: z.ZodArray<z.ZodString>;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            ready: "ready";
            cancelled: "cancelled";
            awaiting_acceptance: "awaiting_acceptance";
            succeeded: "succeeded";
            cancel_requested: "cancel_requested";
            draft: "draft";
            blocked: "blocked";
        }>;
        attemptCount: z.ZodNumber;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"interaction">;
    interaction: z.ZodObject<{
        ref: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
            interactionId: z.ZodString;
        }, z.core.$strict>;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        title: z.ZodString;
        kind: z.ZodEnum<{
            input: "input";
            approval: "approval";
        }>;
        status: z.ZodEnum<{
            pending: "pending";
            resolving: "resolving";
            resolved: "resolved";
            cancelled: "cancelled";
            expired: "expired";
        }>;
        createdAt: z.ZodISODateTime;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"message">;
    message: z.ZodObject<{
        messageId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodNullable<z.ZodString>;
        revision: z.ZodNumber;
        createdSeq: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        senderPrincipal: z.ZodString;
        senderName: z.ZodString;
        groupRole: z.ZodEnum<{
            system: "system";
            owner: "owner";
            leader: "leader";
            member: "member";
        }>;
        memberId: z.ZodNullable<z.ZodString>;
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"attachment">;
            attachmentRef: z.ZodString;
            mediaType: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>], "kind">>;
        mentions: z.ZodArray<z.ZodString>;
        intent: z.ZodEnum<{
            progress: "progress";
            note: "note";
            result: "result";
            start_goal: "start_goal";
            followup: "followup";
            directed: "directed";
        }>;
        replyTo: z.ZodNullable<z.ZodString>;
        sourceRefs: z.ZodArray<z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        visibility: z.ZodEnum<{
            public: "public";
            internal: "internal";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"artifact">;
    artifact: z.ZodObject<{
        artifactId: z.ZodString;
        groupId: z.ZodString;
        teamRunId: z.ZodString;
        revision: z.ZodNumber;
        name: z.ZodString;
        mediaType: z.ZodString;
        source: z.ZodObject<{
            authorityRef: z.ZodString;
            groupId: z.ZodString;
            memberId: z.ZodString;
            bindingRef: z.ZodString;
            providerRef: z.ZodString;
            sessionId: z.ZodString;
            runId: z.ZodString;
            itemId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        digest: z.ZodString;
        sizeBytes: z.ZodNumber;
        state: z.ZodEnum<{
            failed: "failed";
            ready: "ready";
            pending: "pending";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"invalidate">;
    teamRunId: z.ZodNullable<z.ZodString>;
    collections: z.ZodArray<z.ZodEnum<{
        runSummaries: "runSummaries";
        taskSummaries: "taskSummaries";
        pendingInteractions: "pendingInteractions";
        recentMessages: "recentMessages";
        artifactSummaries: "artifactSummaries";
    }>>;
}, z.core.$strict>], "kind">;
export type WorkspaceChange = z.infer<typeof workspaceChangeSchema>;
export declare const workspaceEventSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"teams.ksadk.io/v1">;
    viewVersion: z.ZodLiteral<"workspace/v1">;
    scope: z.ZodObject<{
        authorityId: z.ZodString;
        ownerScopeRef: z.ZodString;
        groupId: z.ZodString;
    }, z.core.$strict>;
    eventId: z.ZodString;
    groupSeq: z.ZodNumber;
    type: z.ZodLiteral<"workspace.delta">;
    createdAt: z.ZodISODateTime;
    changes: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"group">;
        group: z.ZodObject<{
            groupId: z.ZodString;
            name: z.ZodString;
            authorityRef: z.ZodString;
            tenantId: z.ZodString;
            ownerSubject: z.ZodString;
            leaderMemberId: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                active: "active";
                archived: "archived";
            }>;
            createdAt: z.ZodISODateTime;
            updatedAt: z.ZodISODateTime;
            policy: z.ZodObject<{
                taskAcceptance: z.ZodEnum<{
                    leader: "leader";
                    human: "human";
                    result: "result";
                }>;
                peerWake: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"member">;
        member: z.ZodObject<{
            memberId: z.ZodString;
            groupId: z.ZodString;
            name: z.ZodString;
            role: z.ZodEnum<{
                leader: "leader";
                member: "member";
            }>;
            responsibility: z.ZodString;
            bindingRef: z.ZodString;
            binding: z.ZodObject<{
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                kind: z.ZodEnum<{
                    local_build: "local_build";
                    a2a: "a2a";
                    cloud: "cloud";
                }>;
                agentId: z.ZodString;
                capabilities: z.ZodObject<{
                    enqueue: z.ZodBoolean;
                    cancel: z.ZodBoolean;
                    steer: z.ZodBoolean;
                    restore: z.ZodBoolean;
                    interaction: z.ZodBoolean;
                    leader: z.ZodBoolean;
                }, z.core.$strict>;
                availability: z.ZodObject<{
                    state: z.ZodEnum<{
                        unavailable: "unavailable";
                        ready: "ready";
                        unchecked: "unchecked";
                    }>;
                    code: z.ZodNullable<z.ZodString>;
                    reason: z.ZodNullable<z.ZodString>;
                    action: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            sessionId: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                unavailable: "unavailable";
                active: "active";
                removed: "removed";
            }>;
            executionStatus: z.ZodEnum<{
                unavailable: "unavailable";
                running: "running";
                waiting: "waiting";
                idle: "idle";
                needs_attention: "needs_attention";
                queued: "queued";
            }>;
            activeRunId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"run_member">;
        runMember: z.ZodObject<{
            memberId: z.ZodString;
            groupId: z.ZodString;
            name: z.ZodString;
            role: z.ZodEnum<{
                leader: "leader";
                member: "member";
            }>;
            responsibility: z.ZodString;
            bindingRef: z.ZodString;
            binding: z.ZodObject<{
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                kind: z.ZodEnum<{
                    local_build: "local_build";
                    a2a: "a2a";
                    cloud: "cloud";
                }>;
                agentId: z.ZodString;
                capabilities: z.ZodObject<{
                    enqueue: z.ZodBoolean;
                    cancel: z.ZodBoolean;
                    steer: z.ZodBoolean;
                    restore: z.ZodBoolean;
                    interaction: z.ZodBoolean;
                    leader: z.ZodBoolean;
                }, z.core.$strict>;
                availability: z.ZodObject<{
                    state: z.ZodEnum<{
                        unavailable: "unavailable";
                        ready: "ready";
                        unchecked: "unchecked";
                    }>;
                    code: z.ZodNullable<z.ZodString>;
                    reason: z.ZodNullable<z.ZodString>;
                    action: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            sessionId: z.ZodString;
            revision: z.ZodNumber;
            status: z.ZodEnum<{
                unavailable: "unavailable";
                active: "active";
                removed: "removed";
            }>;
            executionStatus: z.ZodEnum<{
                unavailable: "unavailable";
                running: "running";
                waiting: "waiting";
                idle: "idle";
                needs_attention: "needs_attention";
                queued: "queued";
            }>;
            activeRunId: z.ZodNullable<z.ZodString>;
            reason: z.ZodNullable<z.ZodString>;
            runMemberId: z.ZodString;
            teamRunId: z.ZodString;
            groupRevision: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"run">;
        run: z.ZodObject<{
            teamRunId: z.ZodString;
            groupId: z.ZodString;
            revision: z.ZodNumber;
            groupRevision: z.ZodNumber;
            goalMessageId: z.ZodString;
            goal: z.ZodString;
            leaderMemberId: z.ZodString;
            status: z.ZodEnum<{
                running: "running";
                waiting: "waiting";
                failed: "failed";
                cancelled: "cancelled";
                planning: "planning";
                needs_attention: "needs_attention";
                awaiting_acceptance: "awaiting_acceptance";
                succeeded: "succeeded";
                cancel_requested: "cancel_requested";
            }>;
            dispatchSuspended: z.ZodBoolean;
            dispatchEpoch: z.ZodNumber;
            taskCount: z.ZodNumber;
            pendingCount: z.ZodNumber;
            createdAt: z.ZodISODateTime;
            updatedAt: z.ZodISODateTime;
            reason: z.ZodNullable<z.ZodString>;
            leaderStandby: z.ZodOptional<z.ZodObject<{
                state: z.ZodEnum<{
                    blocked: "blocked";
                    active: "active";
                    armed: "armed";
                    fencing_old: "fencing_old";
                    waiting_old_grant: "waiting_old_grant";
                    activating: "activating";
                }>;
                standbyBindingRef: z.ZodString;
                releaseRef: z.ZodString;
                takeoverId: z.ZodNullable<z.ZodString>;
                reason: z.ZodNullable<z.ZodString>;
                newLeaderEpoch: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"task">;
        task: z.ZodObject<{
            taskId: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            revision: z.ZodNumber;
            title: z.ZodString;
            ownerMemberId: z.ZodNullable<z.ZodString>;
            dependencies: z.ZodArray<z.ZodString>;
            status: z.ZodEnum<{
                running: "running";
                failed: "failed";
                ready: "ready";
                cancelled: "cancelled";
                awaiting_acceptance: "awaiting_acceptance";
                succeeded: "succeeded";
                cancel_requested: "cancel_requested";
                draft: "draft";
                blocked: "blocked";
            }>;
            attemptCount: z.ZodNumber;
            reason: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"interaction">;
        interaction: z.ZodObject<{
            ref: z.ZodObject<{
                authorityRef: z.ZodString;
                groupId: z.ZodString;
                memberId: z.ZodString;
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                sessionId: z.ZodString;
                runId: z.ZodString;
                itemId: z.ZodOptional<z.ZodString>;
                interactionId: z.ZodString;
            }, z.core.$strict>;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            revision: z.ZodNumber;
            title: z.ZodString;
            kind: z.ZodEnum<{
                input: "input";
                approval: "approval";
            }>;
            status: z.ZodEnum<{
                pending: "pending";
                resolving: "resolving";
                resolved: "resolved";
                cancelled: "cancelled";
                expired: "expired";
            }>;
            createdAt: z.ZodISODateTime;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"message">;
        message: z.ZodObject<{
            messageId: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodNullable<z.ZodString>;
            revision: z.ZodNumber;
            createdSeq: z.ZodNumber;
            createdAt: z.ZodISODateTime;
            senderPrincipal: z.ZodString;
            senderName: z.ZodString;
            groupRole: z.ZodEnum<{
                system: "system";
                owner: "owner";
                leader: "leader";
                member: "member";
            }>;
            memberId: z.ZodNullable<z.ZodString>;
            parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"attachment">;
                attachmentRef: z.ZodString;
                mediaType: z.ZodString;
                name: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>], "kind">>;
            mentions: z.ZodArray<z.ZodString>;
            intent: z.ZodEnum<{
                progress: "progress";
                note: "note";
                result: "result";
                start_goal: "start_goal";
                followup: "followup";
                directed: "directed";
            }>;
            replyTo: z.ZodNullable<z.ZodString>;
            sourceRefs: z.ZodArray<z.ZodObject<{
                authorityRef: z.ZodString;
                groupId: z.ZodString;
                memberId: z.ZodString;
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                sessionId: z.ZodString;
                runId: z.ZodString;
                itemId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            visibility: z.ZodEnum<{
                public: "public";
                internal: "internal";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"artifact">;
        artifact: z.ZodObject<{
            artifactId: z.ZodString;
            groupId: z.ZodString;
            teamRunId: z.ZodString;
            revision: z.ZodNumber;
            name: z.ZodString;
            mediaType: z.ZodString;
            source: z.ZodObject<{
                authorityRef: z.ZodString;
                groupId: z.ZodString;
                memberId: z.ZodString;
                bindingRef: z.ZodString;
                providerRef: z.ZodString;
                sessionId: z.ZodString;
                runId: z.ZodString;
                itemId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            digest: z.ZodString;
            sizeBytes: z.ZodNumber;
            state: z.ZodEnum<{
                failed: "failed";
                ready: "ready";
                pending: "pending";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"invalidate">;
        teamRunId: z.ZodNullable<z.ZodString>;
        collections: z.ZodArray<z.ZodEnum<{
            runSummaries: "runSummaries";
            taskSummaries: "taskSummaries";
            pendingInteractions: "pendingInteractions";
            recentMessages: "recentMessages";
            artifactSummaries: "artifactSummaries";
        }>>;
    }, z.core.$strict>], "kind">>;
}, z.core.$strict>;
export type WorkspaceEvent = z.infer<typeof workspaceEventSchema>;
export declare function decodeTeamWorkspaceSnapshot(raw: unknown): TeamWorkspaceSnapshot;
export declare function decodeWorkspacePage(raw: unknown): WorkspacePage;
export declare function decodeWorkspaceEvent(raw: unknown): WorkspaceEvent;
//# sourceMappingURL=workspaceContracts.d.ts.map