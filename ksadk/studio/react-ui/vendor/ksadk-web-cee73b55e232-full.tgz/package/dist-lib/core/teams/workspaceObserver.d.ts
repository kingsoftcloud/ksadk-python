import type { CloudWorkspaceTransport } from './cloudClient.js';
import type { ConnectionStatus } from './types.js';
import { type WorkspaceClientScope, type WorkspaceCollection } from './workspaceContracts.js';
import { type WorkspaceProjection } from './workspaceReducer.js';
export interface WorkspaceObservation {
    scope: Readonly<WorkspaceClientScope>;
    selectedRunId: string | null;
    projection: WorkspaceProjection | null;
    connection: ConnectionStatus;
    draft: string;
    errorCode: string | null;
    loadingPages: WorkspaceCollection[];
}
/** Requests, reducers, pages and drafts are owned by one immutable authenticated scope. */
export declare class WorkspaceObserver {
    readonly scope: Readonly<WorkspaceClientScope>;
    readonly cacheKey: string;
    private readonly transport;
    private readonly maxReconnects;
    private readonly retryDelay;
    private value;
    private reducer?;
    private listeners;
    private drafts;
    private pendingPages;
    private controller?;
    private streamController?;
    private generation;
    private disposed;
    private resyncRequested;
    private observingGeneration?;
    constructor(scope: WorkspaceClientScope, transport: CloudWorkspaceTransport, options?: {
        maxReconnects?: number;
        retryDelayMs?: (attempt: number) => number;
    });
    getSnapshot: () => WorkspaceObservation;
    subscribe: (listener: () => void) => (() => void);
    private update;
    setDraft(draft: string): void;
    /** A recovered ACK clears only its original, unchanged draft, even after a run switch. */
    acknowledgeDraft(teamRunId: string | null, submittedText: string): boolean;
    /** Ends only observation; never dispatches, stops or cancels an Agent execution. */
    disconnect(): void;
    dispose(): void;
    refresh(): void;
    observe(teamRunId?: string): Promise<void>;
    loadMore(collection: WorkspaceCollection, limit?: number): Promise<boolean>;
}
//# sourceMappingURL=workspaceObserver.d.ts.map