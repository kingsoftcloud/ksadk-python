import { type TeamWorkspaceSnapshot, type WorkspaceCollection, type WorkspacePageRequest } from './workspaceContracts.js';
export interface WorkspaceProjection {
    snapshot: TeamWorkspaceSnapshot;
    /** The immutable pagination boundary; live snapshot.watermark can advance beyond this. */
    snapshotWatermark: number;
    dirtyCollections: WorkspaceCollection[];
    dirtyRunIds: string[];
}
/** A partial cloud projection only. It never invokes or subclasses the full local GroupReducer. */
export declare class WorkspaceReducer {
    private value;
    private baseWatermark;
    private versions;
    private seenSeq;
    private seenIds;
    private dirty;
    private dirtyRuns;
    private usedCursors;
    private readonly maxRows;
    constructor(raw: unknown, options?: {
        maxRowsPerCollection?: number;
    });
    snapshot(): TeamWorkspaceSnapshot;
    watermark(): number;
    snapshotId(): string;
    projection(): WorkspaceProjection;
    private seedVersions;
    private domainDigest;
    private accept;
    private upsert;
    private mergeRow;
    replace(raw: unknown): boolean;
    apply(raw: unknown): boolean;
    pageRequest(collection: WorkspaceCollection, limit?: number): WorkspacePageRequest | null;
    mergePage(request: WorkspacePageRequest, raw: unknown): boolean;
}
//# sourceMappingURL=workspaceReducer.d.ts.map