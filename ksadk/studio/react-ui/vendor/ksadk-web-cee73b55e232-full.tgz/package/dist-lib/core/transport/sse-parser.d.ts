import type { TransportEvent } from './types.js';
export declare function parseSseChunk(chunk: string): TransportEvent[];
export declare function splitSseBuffer(buffer: string): {
    chunks: string[];
    remainder: string;
};
//# sourceMappingURL=sse-parser.d.ts.map