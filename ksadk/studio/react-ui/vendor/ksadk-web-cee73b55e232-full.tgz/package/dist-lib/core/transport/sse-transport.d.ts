import type { RuntimeTransport, TransportCallbacks } from './types.js';
export declare class SsePostTransport implements RuntimeTransport {
    readonly protocol = "sse-post";
    connect(options: {
        action: string;
        method?: 'POST' | 'GET';
        body?: Record<string, unknown>;
        params?: Record<string, string>;
        signal?: AbortSignal;
    }, callbacks: TransportCallbacks): Promise<() => void>;
}
export declare class SseGetTransport implements RuntimeTransport {
    readonly protocol = "sse-get";
    connect(options: {
        action: string;
        method?: 'POST' | 'GET';
        body?: Record<string, unknown>;
        params?: Record<string, string>;
        signal?: AbortSignal;
    }, callbacks: TransportCallbacks): Promise<() => void>;
}
//# sourceMappingURL=sse-transport.d.ts.map