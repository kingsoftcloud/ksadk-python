import { create as e } from "zustand";
//#region src/stores/message.ts
var t = e()((e) => ({
	messages: [],
	setMessages: (t) => e({ messages: t }),
	patchMessages: (t) => e((e) => ({ messages: t(e.messages) }))
})), n = [], r = [];
function i(e) {
	return typeof e == "string" ? e.trim() : "";
}
function a(e) {
	let t = typeof e == "number" ? e : Number(e);
	return Number.isFinite(t) ? t : void 0;
}
function o(e) {
	return typeof e == "string" || typeof e == "number" ? e : void 0;
}
function s(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : void 0;
}
function c(e) {
	return e !== null;
}
function l(e) {
	return e !== null;
}
function u(e) {
	return [...e].sort((e, t) => {
		let n = t.seqId ?? -1, r = e.seqId ?? -1;
		return n === r ? (Date.parse(String(t.timestamp || "")) || 0) - (Date.parse(String(e.timestamp || "")) || 0) : n - r;
	});
}
function d(e) {
	return [...e].sort((e, t) => {
		let n = t.seqId ?? -1, r = e.seqId ?? -1;
		return n === r ? (Date.parse(String(t.timestamp || "")) || 0) - (Date.parse(String(e.timestamp || "")) || 0) : n - r;
	});
}
function f(e) {
	return u(e)[0]?.runId || "";
}
function p(e) {
	let t = f(e);
	return t ? e.filter((e) => e.runId === t) : [];
}
function m(e) {
	let t = s(e);
	if (!t) return null;
	let n = s(t.Metadata ?? t.metadata), r = s(t.Content ?? t.content), c = i(t.CheckpointId ?? t.checkpointId ?? t.checkpoint_id ?? n?.checkpoint_id ?? n?.checkpointId ?? r?.checkpoint_id ?? r?.checkpointId), l = i(t.RunId ?? t.runId ?? t.run_id ?? n?.run_id ?? n?.runId ?? r?.run_id ?? r?.runId);
	return !c || !l ? null : {
		checkpointId: c,
		runId: l,
		sessionId: i(t.SessionId ?? t.sessionId ?? t.session_id) || void 0,
		invocationId: i(t.InvocationId ?? t.invocationId ?? t.invocation_id) || void 0,
		seqId: a(t.SeqId ?? t.seqId ?? t.seq_id),
		timestamp: o(t.Timestamp ?? t.timestamp ?? t.CreatedAt ?? t.createdAt),
		framework: i(t.Framework ?? t.framework ?? n?.framework ?? r?.framework) || void 0,
		frameworkRef: s(t.FrameworkRef ?? t.frameworkRef ?? t.framework_ref ?? n?.framework_ref ?? n?.frameworkRef),
		phase: i(t.Phase ?? t.phase ?? n?.phase ?? r?.phase) || void 0,
		stage: i(t.Stage ?? t.stage ?? n?.stage ?? n?.title) || void 0,
		summary: i(t.Summary ?? t.summary ?? n?.summary ?? n?.description) || void 0,
		nextAction: i(t.NextAction ?? t.nextAction ?? t.next_action ?? n?.nextAction ?? n?.next_action) || void 0,
		status: i(t.Status ?? t.status ?? n?.status ?? r?.status) || void 0,
		metadata: n
	};
}
function h(e) {
	let t = s(e);
	if (!t) return null;
	let n = i(t.ReceiptId ?? t.receiptId ?? t.receipt_id), r = i(t.IdempotencyKey ?? t.idempotencyKey ?? t.idempotency_key), c = i(t.ToolName ?? t.toolName ?? t.tool_name);
	return !n || !r || !c ? null : {
		receiptId: n,
		idempotencyKey: r,
		toolName: c,
		toolCallId: i(t.ToolCallId ?? t.toolCallId ?? t.tool_call_id) || void 0,
		runId: i(t.RunId ?? t.runId ?? t.run_id) || void 0,
		checkpointId: i(t.CheckpointId ?? t.checkpointId ?? t.checkpoint_id) || void 0,
		sessionId: i(t.SessionId ?? t.sessionId ?? t.session_id) || void 0,
		invocationId: i(t.InvocationId ?? t.invocationId ?? t.invocation_id) || void 0,
		seqId: a(t.SeqId ?? t.seqId ?? t.seq_id),
		timestamp: o(t.Timestamp ?? t.timestamp ?? t.CreatedAt ?? t.createdAt),
		status: i(t.Status ?? t.status) || void 0,
		replayed: !!(t.Replayed ?? t.replayed),
		metadata: s(t.Metadata ?? t.metadata)
	};
}
var g = e()((e, t) => ({
	checkpointsBySessionId: {},
	toolReceiptsBySessionId: {},
	setSessionCheckpoints: (t, n) => e((e) => ({ checkpointsBySessionId: {
		...e.checkpointsBySessionId,
		[t]: u(p(n.map(m).filter(c).map((e) => ({
			...e,
			sessionId: e.sessionId || t
		}))))
	} })),
	upsertSessionCheckpoint: (t, n) => {
		let r = m(n);
		r && e((e) => {
			let n = e.checkpointsBySessionId[t] || [];
			r.sessionId = r.sessionId || t;
			let i = new Map(n.map((e) => [e.checkpointId, e]));
			i.set(r.checkpointId, {
				...i.get(r.checkpointId),
				...r
			});
			let a = p([...i.values()]);
			return { checkpointsBySessionId: {
				...e.checkpointsBySessionId,
				[t]: u(a)
			} };
		});
	},
	getSessionCheckpoints: (e) => {
		let r = String(e || "");
		return r && t().checkpointsBySessionId[r] || n;
	},
	setSessionToolReceipts: (t, n) => e((e) => ({ toolReceiptsBySessionId: {
		...e.toolReceiptsBySessionId,
		[t]: d(n.map(h).filter(l).map((e) => ({
			...e,
			sessionId: e.sessionId || t
		})))
	} })),
	getSessionToolReceipts: (e) => {
		let n = String(e || "");
		return n && t().toolReceiptsBySessionId[n] || r;
	},
	clearSessionCheckpoints: (t) => e((e) => {
		let n = String(t || "");
		if (!n) return {
			checkpointsBySessionId: {},
			toolReceiptsBySessionId: {}
		};
		let r = { ...e.checkpointsBySessionId }, i = { ...e.toolReceiptsBySessionId };
		return delete r[n], delete i[n], {
			checkpointsBySessionId: r,
			toolReceiptsBySessionId: i
		};
	})
}));
//#endregion
//#region src/utils/feedback.js
function _(e) {
	return String(e || "").trim();
}
function v(e) {
	let t = _(e).toLowerCase();
	return t === "up" || t === "down" ? t : "";
}
function y(e) {
	if (!e || typeof e != "object") return null;
	let t = v(e.Rating || e.rating);
	return t ? {
		agentId: _(e.AgentId || e.agentId),
		sessionId: _(e.SessionId || e.sessionId),
		responseId: _(e.ResponseId || e.responseId),
		eventId: _(e.EventId || e.eventId),
		rating: t,
		comment: String(e.Comment ?? e.comment ?? ""),
		traceId: _(e.TraceId || e.traceId),
		rootSpanId: _(e.RootSpanId || e.rootSpanId),
		updatedAt: _(e.UpdatedAt || e.updatedAt)
	} : null;
}
function b(e, t, n) {
	return !!(e?.role === "model" && _(e.responseId) && !(t && n));
}
function x({ agentId: e, sessionId: t, message: n }) {
	let r = _(n?.responseId);
	if (!r) throw Error("Message missing response id");
	return {
		AgentId: _(e),
		SessionId: _(t),
		ResponseId: r
	};
}
function S({ agentId: e, sessionId: t, message: n, rating: r, comment: i = "" }) {
	let a = v(r);
	if (!a) throw Error("Feedback rating must be up or down");
	return {
		...x({
			agentId: e,
			sessionId: t,
			message: n
		}),
		Rating: a,
		Comment: String(i || ""),
		TraceId: _(n?.traceId),
		RootSpanId: _(n?.rootSpanId)
	};
}
function C(e, { messageId: t, rating: n, comment: r = "" }) {
	let i = e.find((e) => e.id === t), a = i?.feedback ? { ...i.feedback } : null, o = v(n);
	return {
		nextMessages: e.map((e) => e.id === t ? {
			...e,
			feedback: {
				...e.feedback || {},
				responseId: _(e.responseId),
				eventId: _(e.eventId),
				rating: o,
				comment: String(r || ""),
				pending: !0,
				error: ""
			}
		} : e),
		previousFeedback: a
	};
}
function w(e, { messageId: t, feedback: n }) {
	let r = y(n) || n;
	return e.map((e) => e.id === t ? {
		...e,
		feedback: r ? {
			...r,
			pending: !1,
			error: ""
		} : void 0
	} : e);
}
function T(e, { messageId: t, previousFeedback: n }) {
	return e.map((e) => {
		if (e.id !== t) return e;
		if (!n) {
			let { feedback: t, ...n } = e;
			return n;
		}
		return {
			...e,
			feedback: n
		};
	});
}
function E(e, { messageId: t }) {
	return e.map((e) => {
		if (e.id !== t) return e;
		let { feedback: n, ...r } = e;
		return r;
	});
}
//#endregion
export { w as a, b as c, E as i, g as l, x as n, y as o, S as r, T as s, C as t, t as u };
