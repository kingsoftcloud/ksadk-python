//#region src/core/conversation/history-search.ts
function e(e, t) {
	let n = t.trim().toLocaleLowerCase(), r = [], i = 0;
	for (let t of e) {
		if (!n) break;
		let e = [
			t.content,
			...(t.blocks || []).flatMap((e) => e.type === "text" ? [e.content] : e.type === "tool" ? [e.toolName, e.output || ""] : []),
			...Object.values(t.tools || {}).flatMap((e) => [e.name, e.output || ""]),
			...(t.attachments || []).map((e) => e.name)
		];
		for (let a of e) {
			let e = a.toLocaleLowerCase().indexOf(n);
			if (!(e < 0)) {
				if (i += 1, r.length < 200) {
					let i = Math.max(0, e - 48), o = Math.min(a.length, e + n.length + 112);
					r.push({
						messageId: t.id,
						role: t.role,
						excerpt: `${i ? "…" : ""}${a.slice(i, o)}${o < a.length ? "…" : ""}`
					});
				}
				break;
			}
		}
	}
	return {
		matches: r,
		matchedMessages: i,
		searchedMessages: e.length,
		complete: !1
	};
}
async function t(t) {
	let n = t.snapshot().owner, r = () => {
		t.signal.throwIfAborted();
		let e = t.snapshot();
		if (e.owner !== n) throw new DOMException("Conversation changed", "AbortError");
		return e;
	}, i = () => new Promise((e) => setTimeout(e, 16));
	for (;;) {
		let n = r();
		if (n.loading) {
			await i();
			continue;
		}
		let a = e(n.messages, t.query);
		if (a.complete = !n.hasMore && !n.error, t.onProgress?.(a), n.error) throw Error(n.error);
		if (a.complete || !t.query.trim()) return a;
		let o = n.checkpoint;
		await t.readOlder(t.signal);
		let s = r();
		if (s.hasMore && s.checkpoint === o && !s.loading) throw Error("更早历史未返回新内容，请重试。当前结果只包含已加载的消息。");
		await i();
	}
}
//#endregion
export { e as n, t };
