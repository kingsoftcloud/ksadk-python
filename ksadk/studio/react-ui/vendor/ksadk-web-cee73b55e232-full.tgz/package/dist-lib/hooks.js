import { d as e, g as t, h as n, m as r } from "./a2ui-B1x5yNaJ.js";
import { n as i } from "./permission-BWNFYYw-.js";
import { u as a } from "./feedback-CuC5jRi_.js";
import { t as ee } from "./history-search-CBd9v7MY.js";
import { C as te, S as ne, T as re, a as ie, f as ae, h as oe, t as se, w as o, x as ce } from "./useSessionLifecycle-hKAAD9mt.js";
import { useCallback as s, useEffect as c, useMemo as l, useRef as u, useState as le } from "react";
//#region src/hooks/useAgentChat.ts
function d(d = {}) {
	let f = l(() => new re(), []), p = d.api || f, m = String(d.agentId || "").trim() || void 0, h = String(d.targetId || "").trim() || void 0, ue = o((e) => e.status), de = o((e) => e.errorMessage), g = o((e) => e.agentId), fe = o((e) => e.agentName), _ = o((e) => e.agentFramework), pe = o((e) => e.apiFormats), v = o((e) => e.capabilities), y = e((e) => e.currentSessionId), [, me] = le(0), b = d.conversationController, x = u(m || g), he = x.current !== (m || g);
	c(() => {
		x.current = m || g;
	}, [g, m]);
	let S = b?.getOrCreate(m || g, he ? null : y, h), C = u(S);
	C.current = S;
	let ge = e((e) => y ? e.messageHistory[y] : void 0), w = e((e) => e.sessions), _e = e((e) => e.isLoadingSessions), ve = e((e) => e.hasMoreSessions), ye = a((e) => e.messages), be = r((e) => e.modelCatalogLoaded), T = r((e) => e.selectedModel), E = r((e) => e.availableModels), D = r((e) => e.thinkingMode), O = i((e) => e.permissionMode), xe = t((e) => e.queuedDrafts), k = n((e) => e.getSessionActivity(y || S)), A = n((e) => e.isSessionStreaming(y || S)), { isMobile: j } = ae(), M = u([]), N = u(null), { fetchSessions: P, loadMoreSessions: Se, loadSession: F, followAcceptedInteraction: Ce, loadOlderSessionMessages: I, historySearchSnapshot: L, createNewSession: we, startNewConversation: R, adoptCreatedSession: Te, waitForPendingSessionCreation: Ee, deleteSession: De, currentSessionIdRef: z, agentIdRef: B, runSubscriptionAbortRef: V } = se({
		agentId: g,
		currentSessionId: y,
		isMobile: j,
		uiCapabilities: v,
		api: p,
		resetCompaction: () => {},
		disconnectRun: () => N.current?.(),
		restoreSession: d.restoreSession
	}), H = s((e, t = B.current) => {
		!e || t !== B.current || P(t, e);
	}, [B, P]), { submitDraft: U, isOutboxRequestActive: W, stopGeneration: G, disconnectRun: K, resumeCheckpoint: Oe, submitAguiAction: ke, respondToAguiApproval: q } = ie({
		agentId: g,
		currentSessionId: y,
		agentFramework: _,
		apiFormats: pe,
		selectedModel: T,
		selectedModelMetadata: l(() => E.find((e) => e.id === T) || null, [E, T]),
		thinkingMode: D,
		permissionMode: O,
		uiCapabilities: v,
		isMobile: j,
		api: p,
		currentSessionIdRef: z,
		agentIdRef: B,
		queuedDraftRef: M,
		onRunSettled: H,
		conversationIdRef: b ? C : void 0,
		conversationId: S,
		onSessionCreated: (e, t, n = g) => {
			b && t && b.bindNative(t, e), !(B.current !== n || b && C.current !== t) && Te(e, !0);
		},
		waitForPendingSessionCreation: Ee,
		conversationClient: d.conversationClient,
		outbox: b?.outbox
	});
	c(() => {
		N.current = K;
	}, [K]);
	let Ae = s(() => {
		let e = z.current;
		V.current?.abort(), n.getState().stopActivity(), n.getState().stopSessionActivity(e), G();
	}, [
		z,
		V,
		G
	]), je = s(async () => {
		let e = z.current, t = n.getState(), r = t.getSessionActivity(e)?.runId || "";
		!e || !r || (await p.cancelRun(g, e, r), t.stopSessionActivity(e, "取消请求已发送。", B.current === g && z.current === e), H(e, g));
	}, [
		g,
		B,
		p,
		z,
		H
	]), { submitResponseFeedback: Me, deleteResponseFeedback: Ne, respondToApproval: J } = ce({
		agentId: g,
		currentSessionId: y,
		isStreaming: A,
		api: p,
		submitDraft: U
	}), Y = u(J), X = u(q);
	c(() => {
		Y.current = J, X.current = q;
	}, [J, q]);
	let { pending: Z, records: Pe, respond: Q, localCatalog: Fe } = oe({
		agentId: g,
		getAgentId: () => B.current,
		currentSessionId: y,
		api: p,
		interactionV1Enabled: !!v.InteractionV1,
		onAcceptedInteraction: Ce,
		legacyResponsesApproval: (e, t) => Y.current({
			approvalRequestId: e,
			approve: t
		}),
		legacyAguiResume: (e, t) => X.current({
			interruptId: e,
			approve: t === "resolved"
		})
	}), Ie = s(async (e) => {
		let t = await Q(e), n = e.action === "cancel" ? String(e.response.feedback || "").trim() : "";
		return t.status === "accepted" && n && await U(n, []), t;
	}, [Q, U]);
	c(() => {
		m && (V.current?.abort(), z.current = null, B.current = m, o.getState().setAgentId(m), e.getState().resetSessionPagination(m), e.getState().setCurrentSessionId(null), e.getState().clearSessionMessageHistory(), a.getState().setMessages([]), n.getState().setCurrentRunId(""), n.getState().clearActivity(), r.getState().resetCatalog());
	}, [
		B,
		z,
		m,
		V
	]), ne({ fetchSessions: P }, m, p), c(() => {
		B.current = g, te(g, y);
	}, [
		g,
		y,
		B
	]), c(() => () => V.current?.abort(), [V]);
	let Le = s((e, t = {}) => {
		U(e, t.attachments || [], void 0, void 0, t.executionMode);
	}, [U]), $ = u(/* @__PURE__ */ new Set()), Re = s(async (e) => {
		if (!b || !S) return !1;
		let t = b.outbox.get(e);
		if (!t || t.conversationId !== S || t.agentId !== g || B.current !== g || C.current !== S || ![
			"pending",
			"failed",
			"unknown"
		].includes(t.status) || $.current.has(e) || W(e)) return !1;
		$.current.add(e);
		try {
			if (t.status === "unknown") {
				let n = (n) => (b.outbox.get(e) === t && b.outbox.update(e, { error: n }), !1);
				if (!t.nativeSessionId || !t.invocationId) return n("尚未取得原任务的完整标识，请先查看会话记录确认结果。");
				let r;
				try {
					r = await p.getSession(t.nativeSessionId);
				} catch {
					return n("暂时无法查询原任务状态，请稍后重新查询。");
				}
				if (b.outbox.get(e) !== t) return !1;
				if (r.SessionId !== t.nativeSessionId || r.AgentId && r.AgentId !== t.agentId || r.ActiveInvocationId !== t.invocationId) return n("当前会话状态未对应原任务，请查看原任务记录确认结果。");
				let i = String(r.ActiveRunStatus || "").trim().toLowerCase(), a = [
					"completed",
					"succeeded",
					"success",
					"done"
				].includes(i) ? "completed" : [
					"failed",
					"error",
					"interrupted",
					"timed_out"
				].includes(i) ? "delivered" : [
					"cancelled",
					"canceled",
					"stopped",
					"aborted"
				].includes(i) ? "cancelled" : void 0;
				return a ? b.outbox.update(e, {
					status: a,
					error: void 0
				}) : n([
					"running",
					"in_progress",
					"resuming",
					"waiting",
					"paused",
					"awaiting_approval"
				].includes(i) ? "原任务仍在执行或等待处理，请在会话中查看进度。" : "原任务尚未返回可确认的结果，请稍后重新查询。"), !1;
			}
			let n = b.outbox.getRuntimeAttachments(e);
			return t.attachments.length > 0 && n.length !== t.attachments.length ? !1 : (b.outbox.requeue(e), await U(t.text, n, void 0, void 0, t.executionMode, e), !0);
		} finally {
			$.current.delete(e);
		}
	}, [
		g,
		B,
		p,
		b,
		S,
		W,
		U
	]), ze = s((t) => {
		e.getState().setCurrentSessionId(t), t && F(t);
	}, [F]), Be = s(() => {
		b?.navigate(), C.current = b?.createDraft(m || g, h), R(), me((e) => e + 1);
	}, [
		g,
		b,
		m,
		R,
		h
	]), Ve = s((e) => I(e || z.current || ""), [z, I]), He = s((e, t, n) => {
		let r = z.current || "";
		return ee({
			query: e,
			signal: t,
			onProgress: n,
			snapshot: L,
			readOlder: (e) => I(r, e)
		});
	}, [
		z,
		L,
		I
	]), Ue = s(async () => {
		await P(B.current, z.current), z.current && await F(z.current);
	}, [
		B,
		z,
		P,
		F
	]), We = s(async () => {
		if (!y || !p.compactSession || !v.ContextCompaction) throw Error("当前会话尚不支持手动压缩");
		if ((await p.compactSession(g, y)).Status !== "completed") throw Error("运行时尚未确认压缩完成");
		await P(g, y);
	}, [
		p,
		g,
		y,
		v.ContextCompaction,
		P
	]);
	return {
		bootstrapStatus: ue,
		bootstrapErrorMessage: de,
		agentId: g,
		agentName: fe,
		agentFramework: _,
		uiCapabilities: v,
		sessions: w,
		currentSessionId: y,
		conversationId: S,
		conversationDrafts: b?.drafts,
		conversationOutbox: b?.outbox,
		messageHistory: ge,
		isLoadingSessions: _e,
		hasMoreSessions: ve,
		isMobile: j,
		selectSession: ze,
		createNewSession: we,
		startNewConversation: Be,
		deleteSession: De,
		loadMoreSessions: Se,
		loadOlderMessages: Ve,
		refresh: Ue,
		searchConversation: He,
		messages: ye,
		activity: k,
		compactContext: We,
		isStreaming: A,
		queuedDrafts: xe,
		send: Le,
		retryOutbox: Re,
		isOutboxRequestActive: W,
		stop: Ae,
		cancelRemote: je,
		resumeCheckpoint: Oe,
		pendingInteractions: Z,
		interactionRecords: Pe,
		respondInteraction: Ie,
		localCatalog: Fe,
		respondToApproval: J,
		submitAguiAction: ke,
		models: E,
		selectedModel: T,
		setModel: (e) => r.getState().setSelectedModel(e),
		modelCatalogLoaded: be,
		thinkingMode: D,
		setThinkingMode: (e) => r.getState().setThinkingMode(e),
		permissionMode: O,
		setPermissionMode: (e) => i.getState().setPermissionMode(e),
		submitResponseFeedback: Me,
		deleteResponseFeedback: Ne
	};
}
//#endregion
export { d as useAgentChat };
