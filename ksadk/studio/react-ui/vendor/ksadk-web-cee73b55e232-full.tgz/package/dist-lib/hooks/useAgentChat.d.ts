import type { Message, ModelCatalogItem } from '../components/chat/types.js';
import type { ApiFacade } from '../core/api/types.js';
import type { ConversationClient } from '../core/conversation/types.js';
import type { ConversationController } from '../core/conversation/studio-controller.js';
import { type HistorySearchResult } from '../core/conversation/history-search.js';
import type { PermissionMode, RuntimeExecutionMode } from '../core/run/types.js';
import { type ThinkingMode } from '../stores/model.js';
import type { UiCapabilities } from '../types/capabilities.js';
export type AgentChatSendOptions = {
    attachments?: File[];
    executionMode?: RuntimeExecutionMode;
};
export type AgentChatOptions = {
    api?: ApiFacade;
    agentId?: string;
    /** Optional deployment/target identity used to scope local conversation state. */
    targetId?: string;
    /** Whether opening an Agent should automatically restore its last session. */
    restoreSession?: boolean;
    /** Owner-scoped Studio identity and drafts; omit to retain Hosted UI behavior. */
    conversationController?: ConversationController;
    /**
     * Omit for Hosted UI canonical negotiation. Pass `null` when the embedding
     * host intentionally exposes only `/agentengine/api/v1` actions.
     */
    conversationClient?: ConversationClient | null;
};
/**
 * Shared chat controller used by Hosted UI shells, Studio, and custom hosts.
 * It owns bootstrap, session replay, streaming, interactions, approvals, and
 * feedback while leaving layout and styles to exported components.
 *
 * The current 0.3.x runtime supports one mounted controller per page. A future
 * provider-scoped store can lift this constraint without changing this API.
 */
export declare function useAgentChat(options?: AgentChatOptions): {
    bootstrapStatus: import("../stores/bootstrap.js").BootstrapStatus;
    bootstrapErrorMessage: string;
    agentId: string;
    agentName: string;
    agentFramework: string;
    uiCapabilities: UiCapabilities;
    sessions: import("../public/chat-composer.js").Session[];
    currentSessionId: string | null;
    conversationId: `conversation_${string}` | undefined;
    conversationDrafts: import("../public/conversation.js").DraftStore | undefined;
    conversationOutbox: import("../public/conversation.js").OutboxStore | undefined;
    messageHistory: {
        nextCursor: number | null;
        hasMore: boolean;
        isLoadingInitial: boolean;
        isLoadingOlder: boolean;
    } | undefined;
    isLoadingSessions: boolean;
    hasMoreSessions: boolean;
    isMobile: boolean;
    selectSession: (sessionId: string | null) => void;
    createNewSession: () => Promise<void>;
    startNewConversation: () => void;
    deleteSession: (sessionId: string) => Promise<boolean>;
    loadMoreSessions: () => Promise<void>;
    loadOlderMessages: (sessionId?: string) => Promise<void>;
    refresh: () => Promise<void>;
    searchConversation: (query: string, signal: AbortSignal, onProgress?: (result: HistorySearchResult) => void) => Promise<HistorySearchResult>;
    messages: Message[];
    activity: import("../stores/streaming.js").RunActivity | null;
    compactContext: () => Promise<void>;
    isStreaming: boolean;
    queuedDrafts: {
        text: string;
        attachments: File[];
        executionMode?: RuntimeExecutionMode;
    }[];
    send: (text: string, sendOptions?: AgentChatSendOptions) => void;
    retryOutbox: (requestId: string) => Promise<boolean>;
    isOutboxRequestActive: (requestId: string) => boolean;
    stop: () => void;
    cancelRemote: () => Promise<void>;
    resumeCheckpoint: (params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
    }) => boolean;
    pendingInteractions: readonly import("../public/runtime.js").Interaction[];
    interactionRecords: readonly import("../public/runtime.js").Interaction[];
    respondInteraction: (input: Parameters<(input: {
        interactionId: string;
        expectedRevision: number;
        action: import("../public/runtime.js").InteractionAction;
        response: Record<string, unknown>;
        idempotencyKey: string;
    }) => Promise<import("../public/runtime.js").InteractionReceipt>>[0]) => Promise<import("../types/agent-control.js").AgentControlReceipt>;
    localCatalog: import("@copilotkit/a2ui-renderer").Catalog<import("@copilotkit/a2ui-renderer").ReactComponentImplementation>;
    respondToApproval: (options: {
        approvalRequestId: string;
        approve: boolean;
        previousResponseId?: string;
    }) => Promise<boolean>;
    submitAguiAction: (message: import("@copilotkit/a2ui-renderer").A2UIClientEventMessage) => boolean;
    models: ModelCatalogItem[];
    selectedModel: string;
    setModel: (modelId: string) => void;
    modelCatalogLoaded: boolean;
    thinkingMode: ThinkingMode;
    setThinkingMode: (mode: ThinkingMode) => void;
    permissionMode: PermissionMode;
    setPermissionMode: (mode: PermissionMode) => void;
    submitResponseFeedback: (options: {
        message: Message;
        rating: "up" | "down";
        comment?: string;
    }) => Promise<void>;
    deleteResponseFeedback: (message: Message) => Promise<void>;
};
export type AgentChatController = ReturnType<typeof useAgentChat>;
//# sourceMappingURL=useAgentChat.d.ts.map