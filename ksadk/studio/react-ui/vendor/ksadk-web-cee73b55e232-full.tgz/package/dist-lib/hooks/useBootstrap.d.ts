import type { ApiFacade } from '../core/api/types.js';
export declare function classifyBootstrapFailure(error: unknown): 'auth-required' | 'error';
export declare function fetchModels(targetAgentId: string, api?: ApiFacade): Promise<void>;
type SessionCallbacks = {
    fetchSessions: (agentId: string, preferredSessionId: string | null) => Promise<void>;
};
export declare function useBootstrap(sessionCallbacks: SessionCallbacks, explicitAgentId?: string, api?: ApiFacade, initialBootstrap?: unknown): void;
export {};
//# sourceMappingURL=useBootstrap.d.ts.map