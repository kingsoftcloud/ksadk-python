import type { Message } from '../components/chat/types.js';
import type { ApiFacade } from '../core/api/types.js';
type UseFeedbackContext = {
    agentId: string;
    currentSessionId: string | null;
    isStreaming: boolean;
    api: ApiFacade;
    submitDraft: (text: string, attachments: File[], responsesInput?: unknown, previousResponseId?: string) => Promise<boolean>;
};
export declare function useFeedback(ctx: UseFeedbackContext): {
    submitResponseFeedback: (options: {
        message: Message;
        rating: "up" | "down";
        comment?: string;
    }) => Promise<void>;
    deleteResponseFeedback: (message: Message) => Promise<void>;
    respondToApproval: (options: {
        approvalRequestId: string;
        approve: boolean;
        previousResponseId?: string;
    }) => Promise<boolean>;
};
export {};
//# sourceMappingURL=useFeedback.d.ts.map