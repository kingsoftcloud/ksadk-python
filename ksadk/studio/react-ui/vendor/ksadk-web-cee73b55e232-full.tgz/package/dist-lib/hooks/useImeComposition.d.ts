/**
 * Tracks IME composition state so a keydown handler can tell an IME
 * confirmation Enter apart from a send Enter.
 *
 * `event.nativeEvent.isComposing` is unreliable across browsers: some
 * engines fire `compositionend` before the matching `keydown(Enter)`,
 * leaving `isComposing` already false when the confirmation Enter
 * arrives. The `keyCode === 229` fallback helps on engines that report
 * it, but not all do. This hook tracks `compositionstart`/`compositionend`
 * explicitly with a ref, so the handler reads a stable value that does
 * not depend on per-engine timing.
 *
 * Returns a function `isComposing(event)` to call inside `onKeyDown`.
 */
export declare function useImeComposition(): (event: {
    nativeEvent: {
        isComposing?: boolean;
        keyCode?: number;
    };
}) => boolean;
//# sourceMappingURL=useImeComposition.d.ts.map