import { InteractionClientImpl } from '../core/interaction/index.js';
import type { Interaction, InteractionAction, InteractionReceipt } from '../core/interaction/types.js';
import type { ApiFacade } from '../core/api/types.js';
type UseInteractionsContext = {
    agentId: string;
    /** Read the current agent id at submit time (bootstrap may arrive late). */
    getAgentId?: () => string;
    currentSessionId: string | null;
    api: ApiFacade;
    /**
     * Bootstrap-advertised `interaction_v1`. When absent the client keeps
     * the 0.3.1 Responses/AG-UI fallback callbacks.
     */
    interactionV1Enabled: boolean;
    onAcceptedInteraction?: (interaction: Interaction) => void;
    /** 0.3.1 fallback: official `mcp_approval_response` submission. */
    legacyResponsesApproval?: (approvalRequestId: string, approve: boolean) => boolean | void | Promise<boolean | void>;
    /** 0.3.1 fallback: AG-UI `resumeAguiInterrupt`. */
    legacyAguiResume?: (interruptId: string, status: 'resolved' | 'cancelled', payload?: unknown) => boolean;
};
export declare function useInteractions(ctx: UseInteractionsContext): {
    client: InteractionClientImpl;
    pending: readonly Interaction[];
    records: readonly Interaction[];
    respond: (input: {
        interactionId: string;
        expectedRevision: number;
        action: InteractionAction;
        response: Record<string, unknown>;
        idempotencyKey: string;
    }) => Promise<InteractionReceipt>;
    localCatalog: import("@copilotkit/a2ui-renderer").Catalog<import("@copilotkit/a2ui-renderer").ReactComponentImplementation>;
};
export {};
//# sourceMappingURL=useInteractions.d.ts.map