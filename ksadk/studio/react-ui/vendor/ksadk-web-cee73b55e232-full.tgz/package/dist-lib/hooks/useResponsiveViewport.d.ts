type ResponsiveViewport = {
    isMobile: boolean;
    viewportHeight: number;
};
export declare function useResponsiveViewport(): ResponsiveViewport;
export {};
//# sourceMappingURL=useResponsiveViewport.d.ts.map