import type { RuntimeApiFormat } from '../types/api.js';
import type { UiCapabilities } from '../types/capabilities.js';
import type { ApiFacade } from '../core/api/types.js';
import type { ModelCatalogItem } from '../components/chat/types.js';
import type { A2UIClientEventMessage } from '@copilotkit/a2ui-renderer';
import type { PermissionMode, RuntimeExecutionMode } from '../core/run/types.js';
import { type OutboxStore } from '../core/conversation/index.js';
import type { ConversationClient } from '../core/conversation/types.js';
import type { ConversationId } from '../core/conversation/studio-controller.js';
type QueuedDraft = {
    text: string;
    attachments: File[];
    executionMode?: RuntimeExecutionMode;
    optimisticMessageId?: string;
};
type RunAgentContext = {
    agentId: string;
    currentSessionId: string | null;
    agentFramework: string;
    apiFormats: RuntimeApiFormat[];
    selectedModel: string;
    selectedModelMetadata?: ModelCatalogItem | null;
    thinkingMode: string;
    permissionMode: PermissionMode;
    uiCapabilities: UiCapabilities;
    isMobile: boolean;
    api: ApiFacade;
    currentSessionIdRef: React.MutableRefObject<string | null>;
    agentIdRef: React.MutableRefObject<string>;
    queuedDraftRef: React.MutableRefObject<QueuedDraft[]>;
    onRunSettled?: (sessionId: string | null, agentId?: string, outcome?: import('../core/run/types.js').RunSettlement) => void;
    onSessionCreated?: (sessionId: string, conversationId?: string, agentId?: string) => void;
    /** Stable owner before native creation. Omit for the legacy Hosted shell. */
    conversationIdRef?: React.MutableRefObject<ConversationId | undefined>;
    /** Reactive selected owner, including null-to-null native draft switches. */
    conversationId?: ConversationId;
    waitForPendingSessionCreation?: () => Promise<string | null>;
    /** `null` keeps an embedded host on the legacy action transport. */
    conversationClient?: ConversationClient | null;
    outbox?: OutboxStore;
};
export declare function useRunAgent(ctx: RunAgentContext): {
    submitDraft: (draftText: string, draftAttachments: File[], responsesInput?: unknown, previousResponseId?: string, executionMode?: RuntimeExecutionMode, outboxRequestId?: string) => Promise<boolean>;
    isOutboxRequestActive: (requestId: string) => boolean;
    stopGeneration: () => void;
    disconnectRun: () => void;
    resumeCheckpoint: (params: {
        sessionId: string;
        runId: string;
        checkpointId: string;
    }) => boolean;
    submitAguiAction: (message: A2UIClientEventMessage) => boolean;
    respondToAguiApproval: (options: {
        interruptId: string;
        approve: boolean;
    }) => boolean;
    resetCompaction: () => void;
};
export {};
//# sourceMappingURL=useRunAgent.d.ts.map