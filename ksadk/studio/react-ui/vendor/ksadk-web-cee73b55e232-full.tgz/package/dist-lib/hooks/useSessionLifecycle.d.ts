import type { Message } from '../components/chat/types.js';
import type { UiCapabilities } from '../types/capabilities.js';
import type { ApiFacade } from '../core/api/types.js';
import type { Interaction } from '../core/interaction/types.js';
type SessionLifecycleContext = {
    agentId: string;
    currentSessionId: string | null;
    isMobile: boolean;
    uiCapabilities: UiCapabilities;
    api: ApiFacade;
    resetCompaction: () => void;
    disconnectRun?: () => void;
    restoreSession?: boolean;
};
export declare function useSessionLifecycle(ctx: SessionLifecycleContext): {
    historySearchSnapshot: () => {
        owner: string;
        messages: Message[];
        hasMore: boolean;
        loading: boolean;
        checkpoint: string;
        error: string | undefined;
    };
    followAcceptedInteraction: (interaction: Interaction) => void;
    fetchSessions: (targetAgentId?: string, preferredSessionId?: string | null) => Promise<void>;
    loadMoreSessions: () => Promise<void>;
    loadSession: (sessionId: string) => Promise<void>;
    loadOlderSessionMessages: (sessionId: string, signal?: AbortSignal) => Promise<void>;
    createNewSession: () => Promise<void>;
    startNewConversation: () => void;
    adoptCreatedSession: (newId: string, preserveMessages?: boolean) => void;
    waitForPendingSessionCreation: () => Promise<string | null>;
    deleteSession: (sessionId: string) => Promise<boolean>;
    currentSessionIdRef: import("react").RefObject<string | null>;
    agentIdRef: import("react").RefObject<string>;
    runSubscriptionAbortRef: import("react").RefObject<AbortController | null>;
};
export {};
//# sourceMappingURL=useSessionLifecycle.d.ts.map