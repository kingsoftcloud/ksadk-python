import { HttpTeamsClient } from '../core/teams/client.js';
import type { ConnectionStatus, GroupMessageInput, GroupSnapshot } from '../core/teams/types.js';
export declare function useTeamChat(options: {
    client: HttpTeamsClient;
    groupId: string;
    authorityRef: string;
}): {
    loading: boolean;
    setDraft: (draft: string) => void;
    send: (input: GroupMessageInput) => Promise<import("../public/teams.js").GroupReceipt>;
    reconnect: () => void;
    snapshot: GroupSnapshot | null;
    connection: ConnectionStatus;
    error: string | null;
    draft: string;
};
//# sourceMappingURL=useTeamChat.d.ts.map