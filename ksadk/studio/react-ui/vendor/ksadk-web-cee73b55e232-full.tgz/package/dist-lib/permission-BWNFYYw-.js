import { p as e } from "./a2ui-B1x5yNaJ.js";
import { create as t } from "zustand";
//#region src/stores/permission.ts
var n = "ksadk.web.permission-mode";
function r() {
	try {
		let t = globalThis.localStorage?.getItem(e.key(n));
		return t === "ask" || t === "full" || t === "risk" ? t : "risk";
	} catch {
		return "risk";
	}
}
function i(t) {
	if (e.writable) try {
		globalThis.localStorage?.setItem(e.key(n), t);
	} catch {}
}
var a = t()((e) => ({
	permissionMode: r(),
	setPermissionMode: (t) => {
		i(t), e({ permissionMode: t });
	}
}));
//#endregion
export { a as n, r as t };
