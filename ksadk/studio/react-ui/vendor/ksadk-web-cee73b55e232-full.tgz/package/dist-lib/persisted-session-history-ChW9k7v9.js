import { t as e } from "./runtime-items-VPq7711E.js";
import { n as t, r as n } from "./tool-display-C9BgteMa.js";
import { d as r, i, l as a, o, p as s, t as c, u as l } from "./reducer-mbYiX0wz.js";
//#region src/core/conversation/safe-tool-value.ts
var u = [
	"authorization",
	"credential",
	"password",
	"secret",
	"token",
	"cookie",
	"apikey",
	"accesskey",
	"secretaccesskey",
	"clientsecret",
	"refreshtoken",
	"accesstoken",
	"setcookie",
	"traceback",
	"stack",
	"exception"
];
function d(e) {
	return e.normalize("NFKC").toLowerCase().replace(/[^a-z0-9]/g, "");
}
function f(e) {
	let t = d(e);
	return u.some((e) => t.includes(e));
}
function p(e) {
	let t = e.split(".");
	if (t.length > 4 || t.some((e) => e.length === 0)) return null;
	let n = t.map((e) => {
		let t = /^0x/i.test(e) ? 16 : e.length > 1 && e.startsWith("0") ? 8 : 10, n = t === 16 ? e.slice(2) : e;
		if (!n || !RegExp("^[0-9a-f]+$", "i").test(n)) return null;
		let r = Number.parseInt(n, t);
		return Number.isSafeInteger(r) ? r : null;
	});
	if (n.some((e) => e === null)) return null;
	let r = n, i = 2 ** (8 * (5 - r.length));
	return r.slice(0, -1).some((e) => e > 255) || r.at(-1) >= i ? null : r.slice(0, -1).reduce((e, t, n) => e + t * 2 ** (8 * (3 - n)), r.at(-1));
}
function m(e) {
	return e >>> 24 == 0 || e >>> 24 == 10 || e >>> 24 == 127 || e >>> 16 == 43518 || e >>> 16 == 49320 || e >>> 20 == 2753;
}
function h(e) {
	let t;
	try {
		t = decodeURIComponent(e).toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
	} catch {
		return !0;
	}
	if (t === "localhost" || t.endsWith(".localhost") || t.endsWith(".local") || t.endsWith(".internal")) return !0;
	let n = t.match(/^::ffff:(\d+(?:\.\d+){0,3})$/)?.[1], r = t.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i), i = r ? Number.parseInt(r[1], 16) * 65536 + Number.parseInt(r[2], 16) : p(n || t);
	if (i !== null) return m(i);
	let a = Number.parseInt(t.split(":", 1)[0], 16);
	return t === "::" || t === "::1" || Number.isInteger(a) && (a & 65024) == 64512 || Number.isInteger(a) && (a & 65472) == 65152;
}
function g(e) {
	return (e.match(/https?:\/\/\[[^\]]+\](?::\d+)?[^\s<>{}"']*|https?:\/\/[^\s<>{}"'[\]()]+/gi) || []).some((e) => {
		let t = e.replace(/[.,;:!?]+$/, "").replace(/\\/g, "/");
		try {
			let e = new URL(t);
			return !!(e.username || e.password) || h(e.hostname);
		} catch {
			return !0;
		}
	});
}
function _(e, t = 0) {
	return t > 8 ? "[truncated]" : typeof e == "string" ? /bearer\s+\S+|traceback|(?:token|authorization|api[_ .-]?key|access[_ .-]?token|refresh[_ .-]?token|secretaccesskey|accesstoken|refreshtoken|cookie|password|secret)\s*["']?\s*[=:]/i.test(e) || g(e) ? "[redacted]" : e.length > 8192 ? `${e.slice(0, 8192)}[truncated]` : e : Array.isArray(e) ? e.slice(0, 128).map((e) => _(e, t + 1)) : e && typeof e == "object" ? Object.fromEntries(Object.entries(e).slice(0, 128).filter(([e]) => !f(e)).map(([e, n]) => [e, _(n, t + 1)])) : e;
}
//#endregion
//#region src/core/conversation/context-compaction.ts
var v = "conversation.item.context-compaction/v1", y = {
	running: "正在压缩上下文",
	completed: "上下文已压缩",
	cancelled: "上下文压缩已取消",
	failed: "上下文压缩失败",
	paused: "上下文压缩已暂停",
	unknown: "上下文压缩状态未确认"
};
function b(e) {
	return e.kind === "progress" && e.payloadSchemaRef === "conversation.item.context-compaction/v1";
}
function x(e) {
	if (typeof e == "number" && Number.isFinite(e) && e > 0) return e < 1e11 ? e * 1e3 : e;
	if (typeof e != "string" || !e.trim()) return;
	let t = Number(e);
	if (Number.isFinite(t) && t > 0) return x(t);
	let n = Date.parse(e);
	return Number.isFinite(n) ? n : void 0;
}
var S = class {
	commit;
	active = /* @__PURE__ */ new Map();
	constructor(e) {
		this.commit = e;
	}
	accept(e, t, n) {
		let r = t === "context.compaction_started" ? "running" : t === "context.compaction_completed" ? "completed" : t === "context.compaction_failed" ? "failed" : null;
		if (!r) return null;
		let i = String(e.nativeRef.scopeId || ""), a = JSON.stringify([e.runId, i]), o = this.active.get(a);
		r === "running" && o && this.finish(a, o, "unknown", e.sourceEventIds, n);
		let s = r === "running" ? void 0 : o, c = {
			...e,
			itemId: s?.item.itemId || `context-compaction:${e.itemId}`,
			kind: "progress",
			payloadSchemaRef: v,
			payload: { contextStatus: r },
			lifecycle: r === "running" ? "streaming" : r === "failed" ? "failed" : "completed",
			operation: r === "running" ? "replace" : "completed"
		};
		return s && (c.sourceEventIds = [...s.item.sourceEventIds, ...e.sourceEventIds], this.duration(c, s.startedAt, n)), r === "running" ? this.active.set(a, {
			item: c,
			startedAt: x(n)
		}) : this.active.delete(a), c;
	}
	settleRun(e, t, n, r) {
		let i = ["run.canceled", "run.cancelled"].includes(t) ? "cancelled" : t === "run.failed" ? "failed" : t === "run.interrupted" ? "paused" : t === "run.completed" ? "unknown" : void 0;
		if (i) for (let [t, a] of this.active) a.item.runId === e && this.finish(t, a, i, [n], r);
	}
	duration(e, t, n) {
		let r = x(n);
		t !== void 0 && r !== void 0 && r >= t && (e.payload.durationMs = r - t, e.payload.durationSource = "studio_observed");
	}
	finish(e, t, n, r, i) {
		let a = {
			...t.item,
			operation: "completed",
			lifecycle: n === "failed" ? "failed" : "completed",
			payload: { contextStatus: n },
			sourceEventIds: [...t.item.sourceEventIds, ...r]
		};
		this.duration(a, t.startedAt, i), this.commit(a), this.active.delete(e);
	}
}, C = (e) => e && typeof e == "object" && !Array.isArray(e) ? e : {}, w = (e, t, n) => JSON.stringify([
	e,
	t,
	n
]), T = class {
	runtime = new e();
	flatChildren = new c();
	seen = /* @__PURE__ */ new Set();
	parents = /* @__PURE__ */ new Map();
	descriptorItemIds = /* @__PURE__ */ new Map();
	descriptors = /* @__PURE__ */ new Map();
	rootScope = "";
	runId = "";
	sessionId;
	conversation;
	profile;
	context = new S((e) => {
		(this.profile === "flat-v1" && e.nativeRef.parentScopeId ? this.flatChildren : this.conversation).apply(e);
	});
	constructor(e, t = new c(), n = "flat-v1") {
		this.sessionId = e, this.conversation = t, this.profile = n;
	}
	identity(e, t, n, r = !1) {
		return this.profile === "agent-block-v1" || r ? w(e, t, n) : n;
	}
	snapshot() {
		let e = this.conversation.snapshot();
		if (this.profile !== "flat-v1") return e;
		let t = this.flatChildren.snapshot();
		return {
			items: [...e.items, ...t.items],
			appliedSources: [...e.appliedSources, ...t.appliedSources]
		};
	}
	apply(e) {
		if (e.schema_version !== 2) return null;
		let t = String(e.run_id || ""), r = String(e.scope_id || ""), i = String(e.event_id || ""), a = String(e.event_type || "");
		if (!a.startsWith("item.") && !a.startsWith("run.")) return null;
		if (!t || !r || !i) throw Error("RuntimeEvent identity missing");
		if (this.runId && this.runId !== t) throw Error("RuntimeEvent run identity changed");
		if (this.seen.has(i)) return null;
		let s = String(e.parent_scope_id ?? this.descriptors.get(r)?.parent_scope_id ?? this.parents.get(r) ?? ""), c = C(e.source), l = [
			"adk",
			"langgraph",
			"codex"
		].includes(String(c.framework)) && !this.descriptors.has(r);
		if (l && s && a === "run.progress") return null;
		if (a.startsWith("run.") && (s || !l && this.rootScope && r !== this.rootScope)) throw Error("Child scope cannot transition root run");
		if (this.parents.has(r) && this.parents.get(r) !== s) throw Error("Scope parent changed");
		let u = String(e.item_id || ""), d = this.identity(t, r, u || i, !!s), f = Object.fromEntries(Object.entries({
			framework: c.framework,
			protocol: c.protocol,
			eventId: c.native_event_id,
			cursor: c.native_cursor,
			runId: c.native_run_id,
			itemId: c.native_item_id,
			scopeId: r,
			runtimeItemId: u || void 0,
			parentScopeId: s || void 0,
			phase: e.phase
		}).filter(([, e]) => e != null)), p = {
			apiVersion: "conversation.ksadk.io/v1",
			kindVersion: 1,
			itemId: d,
			sessionId: this.sessionId,
			runId: t,
			sourceEventIds: [i],
			kind: "progress",
			operation: "replace",
			lifecycle: "streaming",
			visibility: "public",
			payloadSchemaRef: "conversation.item.progress/v1",
			payload: {},
			nativeRef: f
		}, m = C(C(e.source).metadata).conversation_visibility;
		if ([
			"public",
			"internal",
			"hidden"
		].includes(String(m)) ? p.visibility = m : s && e.item_kind === "reasoning" && (p.visibility = "hidden"), a.startsWith("run.")) this.context.settleRun(t, a, i, e.timestamp), this.rootScope = r, p.payload = {
			status: ["run.started", "run.progress"].includes(a) ? "running" : a.slice(4),
			...e.output_refs ? { outputRefs: e.output_refs } : {}
		}, a === "run.progress" && Object.assign(p.payload, {
			progress: e.progress,
			message: e.message
		}), a === "run.interrupted" && (p.payload.reason = e.reason || ""), p.operation = ["run.started", "run.progress"].includes(a) ? "append" : "completed", [
			"run.failed",
			"run.canceled",
			"run.cancelled"
		].includes(a) && (p.kind = "error", p.payloadSchemaRef = "conversation.item.error/v1", p.payload.error = C(e.error).message || e.reason || ""), p.lifecycle = ["run.completed", "run.interrupted"].includes(a) ? "completed" : [
			"run.failed",
			"run.canceled",
			"run.cancelled"
		].includes(a) ? "failed" : "streaming";
		else {
			if (!u) throw Error("RuntimeEvent item identity missing");
			let f = C(e.snapshot || e.initial), h = a === "item.updated" ? [C(e.update)] : Array.isArray(f.parts) ? f.parts : [], g = h.map((e) => {
				let t = C(e);
				return {
					partId: String(t.part_id || "part"),
					contentType: String(t.content_type || "data"),
					...typeof t.text == "string" ? { text: t.text } : {},
					value: t
				};
			}), v = h.map((e) => C(C(e).data)).find((e) => e.schema === "execution.scope/v1");
			if (s && !v && !l) {
				let e = this.descriptorItemIds.get(r);
				if (!e) throw Error("Child content requires its scope descriptor first");
				p.parentItemId = e;
			}
			if (v) {
				if (this.descriptorItemIds.has(r) && this.descriptorItemIds.get(r) !== d) throw Error("Scope descriptor item identity changed");
				let e = C(v.trigger_ref);
				if (v.scope_id !== r || v.parent_scope_id !== s || e.scope_id !== s || !e.item_id || !e.call_id || !s) throw Error("Invalid scope descriptor locator");
				let t = this.runtime.snapshot().items.find((t) => t.scopeId === e.scope_id && t.itemId === e.item_id);
				if (t && !t.parts.some((t) => C(t.value).call_id === e.call_id)) throw Error("Scope trigger call mismatch");
				let n = this.descriptors.get(r);
				o({
					...p,
					kind: "agent",
					payloadSchemaRef: "conversation.item.agent/v1",
					payload: v
				}, n ? {
					...p,
					kind: "agent",
					payload: n
				} : void 0), this.descriptors.set(r, v), this.descriptorItemIds.set(r, d);
			}
			for (let e of this.descriptors.values()) {
				let t = C(e.trigger_ref);
				if (t.scope_id === r && t.item_id === u && g.length && !g.some((e) => C(e.value).call_id === t.call_id)) throw Error("Scope trigger call mismatch");
			}
			let y = this.runtime.snapshot().items.find((e) => e.scopeId === r && e.itemId === u);
			if (s && y && y.status !== "open") {
				if (a === "item.updated" || a === "item.started") throw Error("Remote item cannot reopen");
				if (Array.isArray(f.parts) && JSON.stringify(y.parts) !== JSON.stringify(g)) throw Error("Remote terminal content conflict");
			}
			let b = {
				type: a.replaceAll(".", "_"),
				runId: t,
				scopeId: r,
				itemId: u,
				itemKind: e.item_kind,
				eventId: i,
				initialParts: g,
				phase: e.phase,
				...Array.isArray(f.parts) ? { parts: g } : {},
				...a === "item.updated" ? {
					partId: g[0]?.partId,
					part: g[0],
					op: e.op || "replace"
				} : {}
			};
			this.runtime.apply(b);
			let x = this.runtime.snapshot().items.find((e) => e.scopeId === r && e.itemId === u);
			if (!x || s && x.itemKind === "status" && x.status === "open" && !x.parts.length) return null;
			if (s && [
				"artifact",
				"tool_call",
				"tool_result"
			].includes(x.itemKind) && !x.parts.length) return this.runId = t, this.parents.set(r, s), this.seen.add(i), null;
			let S = x.parts.map((e) => C(e.value)), w = S.map((e) => C(e.data)).find((e) => e.schema === "execution.scope/v1"), T = a === "item.completed" && x.itemKind === "status" && C(c.metadata).engine_kind === "native" ? S.map((e) => C(e.data)).find((e) => typeof e.native_event_kind == "string") : void 0, E = T && this.context.accept(p, String(T.native_event_kind), e.timestamp);
			if (p.lifecycle = x.status === "open" ? a === "item.started" ? "pending" : "streaming" : x.status, p.operation = ["completed", "failed"].includes(p.lifecycle) ? "completed" : a === "item.started" ? "append" : "replace", E) Object.assign(p, E);
			else if (w) p.operation = ["completed", "failed"].includes(p.lifecycle) ? "completed" : "replace", p.kind = "agent", p.payloadSchemaRef = "conversation.item.agent/v1", p.payload = w, p.parentItemId = this.identity(t, String(C(w.trigger_ref).scope_id), String(C(w.trigger_ref).item_id), !!this.parents.get(String(C(w.trigger_ref).scope_id))), p.capabilityRef = "agent.block";
			else if (x.itemKind === "tool_call" || x.itemKind === "tool_result") {
				let e = S.find((e) => e.content_type === "tool_call"), t = S.find((e) => e.content_type === "tool_result");
				p.kind = "tool_call", p.capabilityRef = "tool.inspect", p.payloadSchemaRef = "conversation.item.tool-call/v1", p.payload = {
					...n(C(c.metadata).tool_display) ? { toolDisplay: n(C(c.metadata).tool_display) } : {},
					...e ? {
						callId: e.call_id,
						tool: e.name,
						args: _(e.arguments)
					} : {},
					...t ? {
						callId: t.call_id,
						output: _(t.result),
						isError: t.is_error
					} : {},
					executionStatus: x.status === "failed" ? "failed" : t && x.status !== "open" ? t.is_error ? "failed" : "completed" : x.itemKind === "tool_result" ? "unknown" : "running",
					sourceKind: x.itemKind
				};
			} else if (x.itemKind === "message" || x.itemKind === "reasoning" || x.itemKind === "artifact" && x.parts.length > 0 && x.parts.every((e) => e.contentType === "text")) p.kind = x.itemKind === "reasoning" ? "reasoning" : C(C(e.source).metadata).native_item_kind === "userMessage" ? "user_message" : "assistant_text", p.payloadSchemaRef = `conversation.item.${p.kind}/v1`, p.payload = {
				text: x.parts.map((e) => e.text || "").join(""),
				...x.itemKind === "reasoning" ? { presentationSource: C(c.metadata).public_summary === !0 ? "public_summary" : C(c.metadata).provider_reasoning === !0 ? "provider_reasoning" : "reasoning" } : {}
			}, a === "item.updated" && e.op === "append" && (p.operation = "append", p.payload.text = C(e.update).text || "");
			else if (x.itemKind === "artifact") {
				let e = S.find((e) => e.content_type === "artifact") || {};
				p.kind = "artifact", p.payloadSchemaRef = "conversation.item.artifact/v1", p.payload = {
					name: e.name,
					mimeType: e.mime_type,
					uri: e.uri
				};
			} else if (x.status === "failed") {
				let t = C(e.error);
				p.kind = "error", p.payloadSchemaRef = "conversation.item.error/v1", p.payload = { error: String(t.message || t.code || "Remote call failed") };
			} else p.visibility = m === "public" ? "public" : "hidden", p.kind = "unknown", p.payloadSchemaRef = "conversation.item.unknown/v1", p.payload = { summary: "Unsupported runtime content" };
		}
		return this.runId = t, this.parents.set(r, s), this.seen.add(i), (this.profile === "flat-v1" && s ? this.flatChildren : this.conversation).apply(p), p;
	}
}, E = {
	user_message: "conversation.item.user_message/v1",
	assistant_text: "conversation.item.assistant_text/v1",
	reasoning: "conversation.item.reasoning/v1",
	tool_call: "conversation.item.tool-call/v1",
	agent: "conversation.item.agent/v1",
	approval: "conversation.item.approval/v1",
	artifact: "conversation.item.artifact/v1",
	a2ui: "conversation.item.a2ui/v1",
	error: "conversation.item.error/v1"
};
function D(e) {
	return e.lifecycle === "completed" || e.lifecycle === "failed";
}
var ee = new Set([
	"aborted",
	"canceled",
	"cancelled",
	"failed",
	"incomplete",
	"interrupted"
]);
function O(e) {
	if (b(e) || e.parentItemId || e.nativeRef.parentScopeId || e.nativeRef.parent_scope_id || e.kind !== "progress" && e.kind !== "error" || !D(e)) return;
	let t = typeof e.payload.status == "string" ? e.payload.status.toLowerCase() : "";
	if (t === "completed") return "completed";
	if (ee.has(t)) return "failed";
}
function te(e) {
	let t = O(e), n = e.payload.outcome;
	if (!t || typeof n != "string" || ![
		"verified",
		"unverified",
		"partial",
		"blocked"
	].includes(n)) return;
	let r = {
		status: t,
		outcome: n
	};
	for (let t of [
		"reason",
		"contractRevision",
		"verificationReportRef"
	]) {
		let n = e.payload[t];
		typeof n == "string" && n && (r[t] = n);
	}
	return Array.isArray(e.payload.verificationItems) && (r.verificationItems = e.payload.verificationItems.flatMap((e) => typeof e != "object" || !e || Array.isArray(e) || typeof e.acceptanceId != "string" || !e.acceptanceId || typeof e.status != "string" || ![
		"passed",
		"failed",
		"not_run",
		"blocked"
	].includes(e.status) ? [] : [{
		acceptanceId: e.acceptanceId,
		status: e.status
	}])), r;
}
function ne(e) {
	let t = E[e.kind];
	return t === void 0 || t === e.payloadSchemaRef;
}
function re(e) {
	if (typeof e != "string" || e.length === 0) return null;
	try {
		let t = new URL(e);
		return t.protocol !== "http:" && t.protocol !== "https:" || t.username || t.password ? null : t.toString();
	} catch {
		return null;
	}
}
function ie(e) {
	return {
		id: e.itemId,
		parentId: e.parentItemId || null,
		runId: e.runId,
		kind: e.kind,
		text: typeof e.payload.text == "string" ? e.payload.text : "",
		lifecycle: e.lifecycle
	};
}
function ae(e) {
	let t = typeof e.payload.artifactId == "string" && e.payload.artifactId ? e.payload.artifactId : e.itemId, n = e.payload.sizeBytes ?? e.payload.size, r = typeof n == "number" && Number.isFinite(n) && n >= 0 ? n : null, i = re(e.payload.uri);
	return {
		artifactId: t,
		itemId: e.itemId,
		runId: e.runId,
		sourceEventIds: [...e.sourceEventIds],
		id: e.itemId,
		name: typeof e.payload.name == "string" && e.payload.name ? e.payload.name : "Artifact",
		mimeType: typeof e.payload.mimeType == "string" && e.payload.mimeType ? e.payload.mimeType : "application/octet-stream",
		sizeBytes: r,
		status: e.lifecycle === "failed" ? "failed" : e.lifecycle === "completed" ? i ? "ready" : "failed" : "pending",
		uri: i
	};
}
function oe(e, t) {
	let n = e.payload[t];
	return typeof n == "string" && n ? n : null;
}
function se(e) {
	if (e.kind === "tool_call") {
		let t = oe(e, "callId");
		if (t) return `tool:${JSON.stringify([
			e.runId,
			e.nativeRef.scopeId || e.nativeRef.scope_id || "",
			t
		])}`;
	}
	if (e.kind === "approval") {
		let t = oe(e, "interactionId");
		if (t) return `approval:${t}`;
	}
	if (e.kind === "a2ui") {
		let t = oe(e, "surfaceId");
		if (t) return `a2ui:${t}`;
	}
	return `item:${e.itemId}`;
}
function ce(e, t) {
	let n = D(e) && !D(t);
	return {
		...e,
		...t,
		itemId: e.itemId,
		parentItemId: e.parentItemId,
		sourceEventIds: [...new Set([...e.sourceEventIds, ...t.sourceEventIds])],
		payload: {
			...e.payload,
			...t.payload,
			...e.payload.sourceKind === "tool_result" && t.payload.sourceKind === "tool_call" ? {
				executionStatus: e.payload.executionStatus,
				sourceKind: "tool_result"
			} : {}
		},
		nativeRef: {
			...e.nativeRef,
			...t.nativeRef
		},
		...n ? {
			lifecycle: e.lifecycle,
			operation: e.operation
		} : {}
	};
}
function le(e) {
	let t = [], n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = se(r), i = n.get(e);
		if (i === void 0) {
			n.set(e, t.length), t.push({
				key: e,
				item: r,
				sourceItemIds: [r.itemId]
			});
			continue;
		}
		let a = t[i];
		t[i] = {
			key: e,
			item: ce(a.item, r),
			sourceItemIds: [...new Set([...a.sourceItemIds, r.itemId])]
		};
	}
	return t.map((t) => t.item.kind === "tool_call" ? {
		...t,
		item: {
			...t.item,
			payload: {
				...t.item.payload,
				...t.item.payload.sourceKind === "tool_result" ? { orphan: !e.some((e) => t.sourceItemIds.includes(e.itemId) && e.payload.sourceKind === "tool_call") } : {}
			}
		}
	} : t);
}
function ue(e, t) {
	let n = e.payload.trigger_ref;
	return n ? t.filter((t) => t.kind === "tool_call" && t.runId === e.runId && (t.nativeRef.scopeId || t.nativeRef.scope_id) === n.scope_id && (t.payload.callId === n.call_id || t.itemId === e.parentItemId)) : [];
}
function de(e) {
	let t = e.filter((e) => e.kind === "agent"), n = (e) => String(e.nativeRef.scopeId || e.nativeRef.scope_id || ""), r = (e) => t.find((t) => t.runId === e.runId && t.itemId !== e.itemId && (e.parentItemId === t.itemId || (e.kind === "agent" ? e.payload.parent_scope_id === t.payload.scope_id : n(e) && n(e) === String(t.payload.scope_id)))), i = new Set(t.flatMap((t) => ue(t, e).map((e) => e.itemId))), a = e.filter((e) => !r(e) && !i.has(e.itemId));
	return a.sort((t, n) => {
		let r = (t) => t.kind === "agent" && t.parentItemId && e.some((e) => e.itemId === t.parentItemId) ? e.findIndex((e) => e.itemId === t.parentItemId) : e.indexOf(t);
		return r(t) - r(n);
	}), le(a).map((t) => {
		if (t.item.kind !== "agent") return t;
		let n = le(e.filter((e) => r(e) === t.item && !i.has(e.itemId)));
		return {
			...t,
			sourceItemIds: [...new Set([...ue(t.item, e).map((e) => e.itemId), ...t.sourceItemIds])],
			children: n
		};
	});
}
function fe(e, t = {}) {
	let n = e.items.filter((e) => e.visibility === "public" || t.includeInternal === !0 && e.visibility === "internal");
	if (t.profile === "flat-v1" && n.some((e) => e.kind === "agent")) {
		let e = n.filter((e) => e.kind === "agent"), t = new Set(e.flatMap((e) => ue(e, n).map((e) => e.itemId))), r = (t) => e.some((e) => e.runId === t.runId && (t.parentItemId === e.itemId || typeof e.payload.scope_id == "string" && e.payload.scope_id.length > 0 && e.payload.scope_id === (t.nativeRef.scopeId || t.nativeRef.scope_id))), i = n.find((e) => O(e)), a = n.filter((e) => e.kind !== "agent" && (e.kind === "error" || !r(e) && !t.has(e.itemId))), o = i?.payload.outputRefs || i?.payload.output_refs;
		Array.isArray(o) && o.length && (a = a.filter((e) => e.kind !== "assistant_text" || o.some((t) => e.nativeRef.scopeId === t.scope_id && e.nativeRef.runtimeItemId === t.item_id)));
		let s = a.filter((e) => e.kind === "assistant_text");
		if (i && !s.some((e) => e.payload.text) && Array.isArray(o)) {
			let e = o.flatMap((e) => n.filter((t) => t.runId === i.runId && t.nativeRef.scopeId === e.scope_id && t.nativeRef.runtimeItemId === e.item_id && t.kind === "assistant_text"));
			e.length && a.push({
				...e[0],
				itemId: `${i.runId}:delegated-final`,
				parentItemId: null,
				nativeRef: {},
				payload: { text: e.map((e) => e.payload.text).join("") },
				lifecycle: "completed"
			});
		}
		n = a.filter((e) => e.kind !== "assistant_text" || !!i);
	}
	let r = n.filter(ne), i = n.filter((e) => !ne(e)), a = new Set([
		"user_message",
		"assistant_text",
		"reasoning"
	]), o = r.filter((e) => a.has(e.kind)).map(ie), s = (e) => e.nativeRef.parentScopeId || e.nativeRef.parent_scope_id || r.some((t) => t.kind === "agent" && (e.parentItemId === t.itemId || t.runId === e.runId && t.payload.scope_id === (e.nativeRef.scopeId || e.nativeRef.scope_id))), c = (e) => r.filter((t) => t.kind === e && !s(t)).map((e) => typeof e.payload.text == "string" ? e.payload.text : "").join(""), l = [...r.filter((e) => e.kind === "unknown"), ...i], u = r.filter((e) => e.kind === "error"), d = [...r].reverse().find((e) => O(e) !== void 0);
	return {
		timeline: de(r.filter((e) => e.kind !== "progress" || b(e) || te(e) !== void 0)),
		output: c("assistant_text"),
		reasoning: c("reasoning"),
		textItems: o,
		toolItems: r.filter((e) => e.kind === "tool_call"),
		approvalItems: r.filter((e) => e.kind === "approval"),
		structuredInputItems: r.filter((e) => e.kind === "progress" && e.payloadSchemaRef === "conversation.item.structured-input/v1"),
		a2uiItems: r.filter((e) => e.kind === "a2ui"),
		artifacts: r.filter((e) => e.kind === "artifact").map(ae),
		fallbacks: [...l.map((e) => ({
			id: e.itemId,
			title: "Unsupported content",
			detail: String(e.payload.summary || e.payload.originalKind || e.payloadSchemaRef),
			failed: e.lifecycle === "failed"
		})), ...u.map((e) => ({
			id: e.itemId,
			title: "Run failed",
			detail: String(e.payload.error || "The agent run failed."),
			failed: !0
		}))],
		runId: n.at(-1)?.runId || "",
		terminalStatus: d ? O(d) : void 0
	};
}
//#endregion
//#region src/core/conversation/client.ts
var k = 8;
function A(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function j(e) {
	if (e?.aborted) throw new s("conversation_aborted", "Conversation request was aborted.");
}
function pe(e, t) {
	return t?.aborted === !0 || e instanceof Error && e.name === "AbortError";
}
function me(e) {
	let t = e.trim().replace(/\/+$/, "");
	if (!t) return "";
	if (!t.includes("://")) return t.startsWith("/") ? t : `/${t}`;
	try {
		let e = new URL(t);
		if (e.protocol !== "http:" && e.protocol !== "https:" || e.username || e.password) throw Error("unsafe URL");
		return e.toString().replace(/\/$/, "");
	} catch (e) {
		throw new s("conversation_contract_mismatch", "Conversation base URL must be an HTTP(S) URL without embedded credentials.", { cause: e });
	}
}
function he(e) {
	return Math.min(200 * 2 ** Math.max(0, e - 1), 2e3);
}
function ge(e) {
	return new Promise((t) => {
		setTimeout(t, e);
	});
}
async function _e(e, t, n) {
	if (j(n), !n) {
		await e(t);
		return;
	}
	await new Promise((r, i) => {
		let a = () => i(new s("conversation_aborted", "Conversation request was aborted."));
		n.addEventListener("abort", a, { once: !0 }), e(t).then(r, i).finally(() => {
			n.removeEventListener("abort", a);
		});
	});
}
function ve(e, t, n, r, i) {
	let a = i ? i.snapshot() : e.snapshot();
	return {
		cursor: t,
		runId: n,
		state: a,
		presentation: fe(a, { profile: r })
	};
}
function ye(e, t) {
	let n, r = [];
	for (let t of e.split(/\r?\n/)) {
		let e = t.endsWith("\r") ? t.slice(0, -1) : t;
		if (!e || e.startsWith(":")) continue;
		let i = e.indexOf(":"), a = i < 0 ? e : e.slice(0, i), o = i < 0 ? "" : e.slice(i + 1), c = o.startsWith(" ") ? o.slice(1) : o;
		if (a === "id") {
			if (!/^\d+$/.test(c) || !Number.isSafeInteger(Number(c))) throw new s("conversation_stream_error", "Conversation stream contains an invalid replay cursor.");
			n = Number(c);
		} else a === "data" && r.push(c);
	}
	if (r.length === 0) return;
	let i = r.join("\n");
	if (!i || i === "[DONE]") return;
	let o;
	try {
		o = JSON.parse(i);
	} catch (e) {
		throw new s("conversation_contract_mismatch", "Conversation stream contains invalid JSON.", { cause: e });
	}
	let c = A(o), l = A(c?.runtimeEvent) || A(c?.runtime_event) || (c?.schema_version === 2 ? c : null);
	if (!c || c.conversationItem === void 0 && !l) {
		n !== void 0 && (t.cursor = Math.max(t.cursor, n));
		return;
	}
	if (n === void 0) throw new s("conversation_stream_error", "Canonical conversation items require an SSE replay cursor.");
	let u = c.conversationItem === void 0 ? "runtime" : "native";
	if (t.lane && t.lane !== u) {
		t.cursor = Math.max(t.cursor, n);
		return;
	}
	let d;
	try {
		d = u === "native" ? a(c.conversationItem) : t.runtime.apply(l);
	} catch (e) {
		throw new s("conversation_contract_mismatch", "Runtime conversation identity or lifecycle invariant failed.", { cause: e });
	}
	if (u === "runtime" && !d) {
		t.cursor = Math.max(t.cursor, n);
		return;
	}
	if (!d) throw new s("conversation_contract_mismatch", "Conversation stream item does not match conversation.ksadk.io/v1.");
	if (t.runId && t.runId !== d.runId) throw new s("conversation_contract_mismatch", "Conversation stream changed canonical run identity.", {
		runId: t.runId,
		cursor: t.cursor
	});
	t.runId = d.runId;
	let f;
	try {
		f = u === "runtime" ? !0 : t.reducer.apply(d);
	} catch (e) {
		throw new s("conversation_contract_mismatch", "Conversation identity or lifecycle invariant failed.", { cause: e });
	}
	t.cursor = Math.max(t.cursor, n), f && !(t.profile === "flat-v1" && d.nativeRef.parentScopeId) && t.options.onItem?.(d), t.options.onUpdate?.(ve(t.reducer, t.cursor, t.runId, t.profile, t.lane === "runtime" ? t.runtime : void 0));
}
async function be(e, t) {
	if (!e.body) throw new s("conversation_stream_error", "Conversation response has no event stream body.");
	let n = e.body.getReader(), r = new TextDecoder(), i = "";
	try {
		for (;;) {
			j(t.options.signal);
			let { value: e, done: a } = await n.read();
			if (a) break;
			i += r.decode(e, { stream: !0 });
			let o = /\r?\n\r?\n/.exec(i);
			for (; o?.index !== void 0;) {
				let e = o.index, n = o[0].length;
				ye(i.slice(0, e), t), i = i.slice(e + n), o = /\r?\n\r?\n/.exec(i);
			}
		}
		i += r.decode(), i.trim() && ye(i, t);
	} catch (e) {
		throw e instanceof s ? e : (pe(e, t.options.signal) && j(t.options.signal), new s("conversation_stream_error", "Conversation event stream was interrupted.", {
			cause: e,
			runId: t.runId || void 0,
			cursor: t.cursor
		}));
	} finally {
		n.releaseLock();
	}
}
function xe(e) {
	return e.state.items.some((e) => O(e) !== void 0);
}
var Se = class {
	fetcher;
	ingressLane;
	rendererCatalog;
	baseUrl;
	maxReconnects;
	sleep;
	retryDelayMs;
	constructor(e = {}) {
		if (!Number.isInteger(e.maxReconnects ?? k) || (e.maxReconnects ?? k) < 0 || (e.maxReconnects ?? k) > 32) throw new s("conversation_contract_mismatch", "Conversation reconnect limit must be an integer from 0 to 32.");
		this.fetcher = e.fetch, this.rendererCatalog = e.rendererCatalog, this.ingressLane = e.ingressLane, this.baseUrl = me(e.baseUrl || ""), this.maxReconnects = e.maxReconnects ?? k, this.sleep = e.sleep || ge, this.retryDelayMs = e.retryDelayMs || he;
	}
	fetch() {
		if (this.fetcher) return this.fetcher;
		if (typeof globalThis.fetch == "function") return globalThis.fetch.bind(globalThis);
		throw new s("conversation_http_error", "No fetch implementation is available for the conversation client.");
	}
	url(e) {
		return `${this.baseUrl}${e}`;
	}
	async request(e, t, n, r = "conversation_stream_error") {
		j(n);
		try {
			return await this.fetch()(e, t);
		} catch (e) {
			throw e instanceof s ? e : (pe(e, n) && j(n), new s(r, "Conversation network request failed.", { cause: e }));
		}
	}
	assertOk(e) {
		if (!e.ok) throw new s("conversation_http_error", `Conversation endpoint returned HTTP ${e.status}.`, { status: e.status });
	}
	async getSurface(e, t, n = {}) {
		if (!e || !t) throw new s("conversation_contract_mismatch", "Agent and session identities are required to get a conversation surface.");
		let r = n.signal ? { signal: n.signal } : void 0, i = await this.request(this.url(`/api/v1/agents/${encodeURIComponent(e)}/conversation-surface?sessionId=${encodeURIComponent(t)}`), r, n.signal, "conversation_http_error");
		this.assertOk(i);
		let a;
		try {
			a = await i.json();
		} catch (e) {
			throw new s("conversation_contract_mismatch", "Conversation surface response is not valid JSON.", { cause: e });
		}
		let o = A(a), c = l(o?.surface);
		if (!o || typeof o.buildId != "string" || !o.buildId || !c) throw new s("conversation_contract_mismatch", "Conversation surface response does not match conversation.ksadk.io/v1.");
		return {
			buildId: o.buildId,
			surface: c
		};
	}
	async streamTurn(e) {
		j(e.signal);
		let t = i(e.bootstrap.surface, this.rendererCatalog), n = {
			...e.input,
			...t === "agent-block-v1" || e.input.extensions?.["ksadk.presentation"] ? { extensions: {
				...e.input.extensions,
				"ksadk.presentation": { profile: t }
			} } : {}
		};
		r(e.bootstrap.surface, n);
		let a = e.bootstrap.surface.outputs.find((e) => e.name === "agent.block"), o = a?.mode === "native" ? "native" : a?.mode === "translated" ? "runtime" : void 0;
		if (o && this.ingressLane && o !== this.ingressLane) throw new s("conversation_contract_mismatch", "Configured ingress lane disagrees with the conversation surface.");
		let l = o || this.ingressLane || "native", u = new c(), d = {
			profile: t,
			lane: l,
			runtime: new T(n.sessionId, u, t),
			cursor: 0,
			runId: "",
			reducer: u,
			options: e
		}, f = {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Idempotency-Key": e.input.idempotencyKey
			},
			body: JSON.stringify({ input: n }),
			...e.signal ? { signal: e.signal } : {}
		}, p = await this.request(this.url(`/api/v1/builds/${encodeURIComponent(e.bootstrap.buildId)}/conversation:stream`), f, e.signal);
		this.assertOk(p);
		try {
			await be(p, d);
		} catch (e) {
			if (!(e instanceof s) || e.code !== "conversation_stream_error" || !d.runId) throw e;
		}
		let m = ve(d.reducer, d.cursor, d.runId, d.profile, d.lane === "runtime" ? d.runtime : void 0);
		if (xe(m)) return m;
		if (!d.runId) throw new s("conversation_run_identity_missing", "The stream ended before a canonical item supplied its run identity.", { cursor: d.cursor });
		for (let t = 1; t <= this.maxReconnects; t += 1) {
			await _e(this.sleep, this.retryDelayMs(t), e.signal), j(e.signal);
			let n;
			try {
				n = await this.request(this.url(`/api/v1/runs/${encodeURIComponent(d.runId)}/events?after=${d.cursor}${d.profile === "agent-block-v1" ? "&presentationProfile=agent-block-v1" : ""}`), {
					method: "GET",
					headers: { "Last-Event-ID": String(d.cursor) },
					...e.signal ? { signal: e.signal } : {}
				}, e.signal), this.assertOk(n), await be(n, d);
			} catch (e) {
				if (e instanceof s && e.code === "conversation_aborted" || e instanceof s && e.code === "conversation_contract_mismatch" || e instanceof s && e.code === "conversation_http_error" && e.status !== void 0 && e.status < 500) throw e;
				continue;
			}
			if (m = ve(d.reducer, d.cursor, d.runId, d.profile, d.lane === "runtime" ? d.runtime : void 0), xe(m)) return m;
		}
		throw new s("conversation_reconnect_exhausted", "Conversation replay stopped after the configured reconnect limit.", {
			runId: d.runId,
			cursor: d.cursor
		});
	}
};
//#endregion
//#region src/core/conversation/renderer-registry.ts
function Ce(e, t) {
	if (!e.trim()) throw Error(`trusted conversation renderer ${t} must not be empty`);
}
function we(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (Ce(n.id, "id"), Ce(n.schemaRef, "schemaRef"), !n.kinds.length) throw Error("trusted conversation renderer kinds must not be empty");
		if (t.has(n.schemaRef)) throw Error(`duplicate trusted conversation renderer schemaRef: ${n.schemaRef}`);
		t.set(n.schemaRef, Object.freeze({
			...n,
			kinds: Object.freeze([...n.kinds])
		}));
	}
	let n = Object.freeze([...t.values()]);
	return Object.freeze({
		resolve(e) {
			let n = t.get(e.payloadSchemaRef);
			return n?.kinds.includes(e.kind) ? n : void 0;
		},
		entries() {
			return n;
		}
	});
}
var Te = we([{
	id: "ksadk.agent-block",
	schemaRef: "conversation.item.agent/v1",
	kinds: ["agent"]
}]), Ee = "conversation_item_v1";
function De(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function M(e) {
	return typeof e == "string" && e.trim() ? e : null;
}
function N(e) {
	if (typeof e == "string") return e;
	if (e == null) return "";
	try {
		return JSON.stringify(e, null, 2);
	} catch {
		return String(e);
	}
}
function P(e) {
	return {
		id: `conversation:${e.runId}:${e.itemId}`,
		timestamp: 0,
		eventType: Ee,
		eventId: e.sourceEventIds.at(-1),
		runId: e.runId,
		itemId: e.itemId,
		status: e.lifecycle === "failed" ? "failed" : e.lifecycle === "completed" ? "completed" : "running"
	};
}
function Oe(e) {
	return e.lifecycle === "failed" ? "error" : e.lifecycle === "completed" ? "done" : "streaming";
}
function ke(e) {
	let t = typeof e.payload.text == "string" ? e.payload.text : "";
	if (e.kind === "user_message") return {
		...P(e),
		role: "user",
		content: t,
		eventType: "user_message"
	};
	let n = e.kind === "reasoning" ? {
		id: `conversation-block:${e.itemId}`,
		type: "thinking",
		content: t,
		status: Oe(e),
		source: e.payload.presentationSource === "public_summary" ? "public_summary" : e.payload.presentationSource === "provider_reasoning" ? "provider_reasoning" : "reasoning"
	} : {
		id: `conversation-block:${e.itemId}`,
		type: "text",
		content: t,
		status: Oe(e)
	};
	return {
		...P(e),
		role: "model",
		content: e.kind === "assistant_text" ? t : "",
		reasoning: e.kind === "reasoning" ? t : void 0,
		blocks: [n]
	};
}
function Ae(e) {
	let t = M(e.payload.tool) || (e.payload.sourceKind === "tool_result" ? "Tool result" : "Tool"), r = M(e.payload.callId), i = n(e.payload.toolDisplay), a = N(_(e.payload.args)), o = Object.prototype.hasOwnProperty.call(e.payload, "output") ? N(_(e.payload.output)) : void 0, s = {
		failed: "error",
		completed: "completed",
		running: "running",
		unknown: "unknown"
	}, c = e.payload.executionStatus, l = typeof c == "string" && Object.hasOwn(s, c) ? s[c] : e.lifecycle === "failed" || e.payload.isError === !0 ? "error" : e.lifecycle === "completed" ? "completed" : "running";
	return {
		...P(e),
		role: "model",
		content: "",
		blocks: [{
			id: `conversation-block:${e.itemId}`,
			type: "tool",
			toolName: t,
			args: a,
			output: o,
			status: l,
			...r || i ? { extra: {
				...r ? { callId: r } : {},
				...i ? { toolDisplay: i } : {}
			} } : {}
		}],
		tools: { [t]: {
			name: t,
			...r ? { callId: r } : {},
			...i ? { toolDisplay: i } : {},
			args: a,
			output: o,
			status: l
		} }
	};
}
function je(e) {
	return e === "structured_input" ? "structured_input" : e === "plan_review" ? "plan_review" : e === "custom" ? "custom" : "approval";
}
function Me(e) {
	let t = M(e.payload.interactionId), n = e.payload.revision;
	if (!t || !Number.isInteger(n) || Number(n) < 1) return null;
	let r = N(e.payload.detail), i = M(e.payload.prompt) || r, a = je(e.payload.interactionKind), o = e.lifecycle === "completed";
	return {
		interactionId: t,
		sessionId: e.sessionId,
		runId: e.runId,
		kind: a,
		title: M(e.payload.title) || (a === "approval" ? `审批：${M(e.payload.kind) || "操作"}` : "需要补充信息"),
		message: i || "运行需要人工确认。",
		requestSchema: De(e.payload.inputSchema),
		presentation: null,
		status: o ? "resolved" : "pending",
		revision: Number(n),
		createdAt: M(e.payload.createdAt) || "",
		expiresAt: M(e.payload.expiresAt),
		resolvedAt: o ? M(e.payload.resolvedAt) : null,
		actor: o ? M(e.payload.actor) : null,
		outcome: o && [
			"approved",
			"rejected",
			"submitted",
			"cancelled",
			"expired"
		].includes(String(e.payload.outcome || "")) ? e.payload.outcome : null,
		responseSummary: o ? M(e.payload.responseSummary) : null,
		source: "interaction_v1",
		extensions: {
			conversation_item_id: e.itemId,
			...M(e.payload.callId) ? { call_id: M(e.payload.callId) } : {}
		}
	};
}
function Ne(e, t) {
	let n = M(e.payload.kind) || "approval", r = N(e.payload.detail), i = t.status === "resolved" ? t.outcome === "rejected" ? "rejected" : t.outcome === "cancelled" || t.outcome === "expired" ? "cancelled" : "approved" : "pending", a = t.status === "pending" ? "paused" : "completed", o = {
		approvalRequestId: t.interactionId,
		approvalStatus: i,
		approvalMessage: t.message
	};
	return {
		...P(e),
		role: "model",
		content: "",
		blocks: [{
			id: `conversation-block:${e.itemId}`,
			type: "tool",
			toolName: n,
			args: r,
			status: a,
			extra: o
		}],
		tools: { [n]: {
			name: n,
			args: r,
			status: a,
			approvalRequestId: t.interactionId,
			approvalStatus: i,
			approvalMessage: t.message
		} }
	};
}
function Pe(e) {
	for (let t of [
		"createSurface",
		"updateComponents",
		"updateDataModel",
		"deleteSurface"
	]) {
		let n = M(De(e[t])?.surfaceId);
		if (n) return n;
	}
	return null;
}
function Fe(e) {
	let t = Array.isArray(e.payload.data) ? e.payload.data : Array.isArray(e.payload.operations) ? e.payload.operations : null;
	if (!t) return null;
	let n = t.map(De);
	if (n.some((e) => e === null)) return null;
	let r = n, i = M(e.payload.surfaceId) || r.map(Pe).find((e) => e !== null) || null;
	return i ? {
		...P(e),
		role: "a2ui",
		content: "",
		aguiActivity: {
			surfaceId: i,
			messages: r
		}
	} : null;
}
function F(e, t, n, r = !1) {
	return {
		...P(e),
		role: "system",
		content: n ? `${t}: ${n}` : t,
		status: r ? "failed" : P(e).status
	};
}
function Ie(e) {
	for (let { item: t } of [...e].reverse()) {
		if (t.visibility !== "public" || t.kind !== "assistant_text" || t.payloadSchemaRef !== "conversation.item.assistant_text/v1" || typeof t.payload.text != "string") continue;
		let e = _(t.payload.text);
		if (typeof e != "string" || e === "[redacted]") continue;
		let n = e.replace(/\s+/g, " ").trim();
		if (!n) continue;
		let r = Array.from(n);
		return r.length > 160 ? `${r.slice(0, 160).join("")}…` : n;
	}
}
function Le(e) {
	let t = te(e);
	if (!t || ["canceled", "cancelled"].includes(String(e.payload.status))) return null;
	let n = {
		verified: "要求的验证已通过。",
		unverified: "执行已结束，要求的验证尚未完成。",
		partial: "任务仅完成了一部分。",
		blocked: "任务遇到阻断，无法继续。"
	}[t.outcome], r = t.status === "failed";
	return {
		...F(e, r ? "运行失败" : "任务验收结果", r && typeof e.payload.error == "string" && e.payload.error ? e.payload.error : n, r),
		runOutcome: t
	};
}
function I(e) {
	let t = e.presentation, n = new Map(t.textItems.map((e) => [e.id, e])), r = new Set(t.toolItems.map((e) => e.itemId)), i = new Set(t.approvalItems.map((e) => e.itemId)), a = new Set(t.structuredInputItems.map((e) => e.itemId)), o = new Set(t.a2uiItems.map((e) => e.itemId)), s = new Map(t.artifacts.map((e) => [e.id, e])), c = new Map(t.fallbacks.map((e) => [e.id, e])), l = [], u = [];
	for (let d of t.timeline) {
		let { item: f } = d;
		if (b(f)) {
			let e = Object.hasOwn(y, String(f.payload.contextStatus)) ? f.payload.contextStatus : "unknown";
			l.push({
				...P(f),
				role: "system",
				content: y[e],
				contextActivity: {
					status: e,
					...typeof f.payload.durationMs == "number" && f.payload.durationMs >= 0 ? {
						durationMs: f.payload.durationMs,
						durationSource: "studio_observed"
					} : {}
				}
			});
			continue;
		}
		if (f.kind === "agent") {
			if (!d.children) {
				l.push(F(f, "Remote agent", String(f.payload.status || "submitted")));
				continue;
			}
			let n = I({
				...e,
				presentation: {
					...t,
					timeline: d.children || []
				}
			});
			l.push({
				...P(f),
				role: "model",
				content: "",
				agentBlock: {
					item: f,
					messages: n.messages,
					summary: Ie(d.children || [])
				},
				status: f.payload.status === "cancelled" ? "cancelled" : P(f).status
			}), u.push(...n.interactions);
			continue;
		}
		let p = te(f);
		if (f.kind === "progress" && p) {
			let e = Le(f);
			e && l.push(e);
			continue;
		}
		if (n.has(f.itemId)) {
			l.push(ke(f));
			continue;
		}
		if (r.has(f.itemId)) {
			l.push(Ae(f));
			continue;
		}
		if (i.has(f.itemId) || a.has(f.itemId)) {
			let e = Me(f);
			e ? (u.push(e), l.push(Ne(f, e))) : l.push(F(f, "Interaction unavailable", "The server did not provide a durable interaction revision; this card is read-only."));
			continue;
		}
		if (o.has(f.itemId)) {
			let e = Fe(f);
			l.push(e || F(f, "Unsupported content", "A2UI payload is not a valid passive operation list."));
			continue;
		}
		let m = s.get(f.itemId);
		if (m) {
			l.push(m.status === "pending" ? {
				...P(f),
				role: "model",
				content: m.name,
				attachments: [{
					name: m.name,
					type: m.mimeType,
					url: "",
					artifactId: m.artifactId,
					itemId: m.itemId,
					runId: m.runId,
					sizeBytes: m.sizeBytes,
					status: "pending"
				}]
			} : m.status === "ready" && m.uri ? {
				...P(f),
				role: "model",
				content: m.name,
				attachments: [{
					name: m.name,
					type: m.mimeType,
					url: m.uri,
					artifactId: m.artifactId,
					itemId: m.itemId,
					runId: m.runId,
					sizeBytes: m.sizeBytes,
					status: m.status
				}]
			} : F(f, "Artifact unavailable", m.status === "failed" ? "The artifact failed to generate or its URI is not a safe HTTP(S) link." : "The artifact URI is not a safe HTTP(S) link."));
			continue;
		}
		let h = c.get(f.itemId);
		if (h) {
			if (f.kind === "error" && ["cancelled", "canceled"].includes(String(f.payload.status || "").toLowerCase())) continue;
			l.push({
				...F(f, h.title, h.detail, h.failed),
				...p ? { runOutcome: p } : {}
			});
		}
	}
	return {
		messages: l,
		interactions: u
	};
}
function Re(e, t, n) {
	let r = I(t).messages;
	if (!r.length) return e;
	let i = e.filter((e) => e.eventType !== "optimistic_assistant_placeholder"), a = (e) => e.runId === t.runId || e.invocationId === t.runId, o = i.findIndex(a), s = n ? i.findIndex((e) => e.id === n) : o < 0 ? i.findLastIndex((e) => e.role === "user" && e.eventType === "optimistic_user_message") : i.findIndex((e) => e.role === "user" && a(e)), c = i[s], l = i.filter((e, t) => t !== s && !a(e)), u = [s, o].filter((e) => e >= 0), d = u.length ? Math.min(...u) : l.length, f = c && !r.some((e) => e.role === "user") ? [{
		...c,
		invocationId: t.runId,
		eventType: void 0
	}] : [];
	return [
		...l.slice(0, d),
		...f,
		...r,
		...l.slice(d)
	];
}
//#endregion
//#region src/core/run/blocks.ts
var ze = 0;
function L(e) {
	return ze += 1, `${e}-${ze}`;
}
function R(e) {
	return e.map((e) => e.type === "thinking" && e.status === "streaming" ? {
		...e,
		status: "done"
	} : e);
}
function Be(e, t, n) {
	let r = [...e ?? []];
	if (n?.itemId) {
		let e = r.findIndex((e) => e.id === n.itemId && e.type === "thinking");
		if (e >= 0) {
			let n = r[e];
			return n.status === "streaming" && (r[e] = {
				...n,
				content: n.content + t
			}), r;
		}
	}
	let i = r[r.length - 1];
	return !n?.itemId && i?.type === "thinking" && i.status === "streaming" ? (r[r.length - 1] = {
		...i,
		content: i.content + t
	}, r) : [...r, {
		id: n?.itemId || L("thinking"),
		type: "thinking",
		content: t,
		status: "streaming",
		...n?.source ? { source: n.source } : {}
	}];
}
function Ve(e, t, n) {
	return (e || []).map((e) => e.type === "thinking" && (!t || e.id === t) ? {
		...e,
		content: n ?? e.content,
		status: "done"
	} : e);
}
function He(e, t) {
	let n = [...R(e ?? [])], r = n[n.length - 1];
	return r?.type === "text" && r.status === "streaming" ? (n[n.length - 1] = {
		...r,
		content: r.content + t
	}, n) : [...n, {
		id: L("text"),
		type: "text",
		content: t,
		status: "streaming"
	}];
}
function Ue(e, t) {
	let n = R(e ?? []);
	if (n.filter((e) => e.type === "text").map((e) => e.content).join("") === t) return n.map((e) => e.type === "text" && e.status === "streaming" ? {
		...e,
		status: "done"
	} : e);
	let r = [...n], i = r.map((e) => e.type).lastIndexOf("text");
	return i >= 0 && r[i].type === "text" ? (r[i] = {
		...r[i],
		content: t,
		status: "done"
	}, r) : [...r, {
		id: L("text"),
		type: "text",
		content: t,
		status: "done"
	}];
}
function We(e, t) {
	if (!t) return [...e ?? []];
	let n = [...e ?? []], r = n[n.length - 1];
	if (r?.type !== "thinking" || !r.content.endsWith(t)) return n;
	let i = r.content.slice(0, -t.length);
	return i ? (n[n.length - 1] = {
		...r,
		content: i
	}, n) : (n.pop(), n);
}
function Ge(e, t, n) {
	let r = [...R(e ?? [])], i = n.extra?.callId || n.extra?.call_id, a = r.findIndex((e) => e.type === "tool" && (i ? (e.extra?.callId || e.extra?.call_id) === i : e.toolName === t && !e.extra?.callId && !e.extra?.call_id));
	if (a >= 0 && r[a].type === "tool") {
		let e = r[a], t = e.status === "error" || e.status === "completed", i = n.output !== void 0, o = n.extra && (n.extra.approvalRequestId || n.extra.approvalStatus);
		if (t && !i && !o) return r;
		let s = {
			...e.extra,
			...n.extra
		};
		return r[a] = {
			...e,
			...n,
			extra: s
		}, r;
	}
	return [...r, {
		id: typeof i == "string" && i ? i : L("tool"),
		type: "tool",
		toolName: t,
		args: n.args ?? "",
		output: n.output,
		status: n.status ?? "running",
		extra: n.extra
	}];
}
function Ke(e) {
	return R(e ?? []);
}
function qe(e) {
	let t = [];
	if (e.reasoning && e.reasoning.trim() && t.push({
		id: L("thinking"),
		type: "thinking",
		content: e.reasoning,
		status: "done",
		...e.reasoningSource ? { source: e.reasoningSource } : {}
	}), e.tools) for (let n of Object.values(e.tools)) t.push({
		id: L("tool"),
		type: "tool",
		toolName: n.name,
		args: n.args ?? "",
		output: n.output,
		status: n.status ?? "completed",
		...n.callId || n.toolDisplay ? { extra: {
			...n.callId ? { callId: n.callId } : {},
			...n.toolDisplay ? { toolDisplay: n.toolDisplay } : {}
		} } : {}
	});
	return e.content && e.content.trim() && t.push({
		id: L("text"),
		type: "text",
		content: e.content,
		status: "done"
	}), t;
}
//#endregion
//#region src/core/stream/kernel-events.ts
var Je = {
	"run.started": "in_progress",
	"run.progress": "in_progress",
	"run.completed": "completed",
	"run.failed": "failed",
	"run.canceled": "cancelled",
	"run.interrupted": "interrupted"
}, Ye = new Set([
	"completed",
	"failed",
	"cancelled",
	"canceled"
]);
function z(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function Xe(e) {
	let t = z(e.source), n = t ? z(t.metadata) : null;
	return String(n?.native_item_kind || "");
}
function B(e, t) {
	let n = z(e[t]);
	if (!n) return [];
	let r = n?.parts;
	return Array.isArray(r) ? r : t === "update" ? [n] : [];
}
function Ze(e) {
	let t = z(e);
	if (!t) return "";
	if (typeof t.text == "string") return t.text;
	let n = z(t.data);
	if (n) {
		let e = n.content;
		if (Array.isArray(e)) return e.map((e) => String(z(e)?.text || "")).join("");
		for (let e of [
			"text",
			"output",
			"stdout",
			"stderr"
		]) if (n[e] != null) return String(n[e]);
	}
	return "";
}
function V(e) {
	return e.map(Ze).join("");
}
function Qe(e) {
	return e.some((e) => z(z(e)?.data)?.type === "userMessage");
}
function H(e) {
	if (e.length === 1) {
		let t = z(z(e[0])?.data);
		if (t) return t;
	}
	return V(e) || null;
}
function $e(e) {
	let t = z(e);
	return t ? z(t.data) || t : null;
}
function et(e) {
	let t = $e(e);
	return String(t?.content_type || t?.type || "").trim().toLowerCase();
}
function tt(e) {
	for (let t of e) {
		let e = $e(t);
		if (!e || et(t) !== "tool_call") continue;
		let n = String(e.call_id || "").trim(), r = String(e.name || e.tool_name || "").trim();
		if (!(!n && !r)) return {
			callId: n,
			name: r,
			arguments: e.arguments ?? e.args ?? {}
		};
	}
	return null;
}
function nt(e) {
	for (let t of e) {
		let e = $e(t);
		if (!e || et(t) !== "tool_result") continue;
		let n = String(e.call_id || e.tool_call_id || "").trim(), r = e.is_error === !0 || e.error != null;
		return {
			callId: n,
			result: e.result ?? e.output ?? e.error ?? null,
			isError: r
		};
	}
	return null;
}
function U(e, t, r, i) {
	let a = String(e.item_id || ""), o = String(i || a), s = z(z(e.source)?.metadata), c = n(s?.tool_display);
	return {
		...c ? { tool_display: c } : {},
		presentation_source: s?.public_summary === !0 ? "public_summary" : s?.provider_reasoning === !0 ? "provider_reasoning" : "reasoning",
		RuntimeItem: {
			RunId: String(e.run_id || ""),
			ScopeId: String(e.scope_id || e.run_id || ""),
			ItemId: o,
			...r ? { PartId: r } : {},
			Operation: t,
			SourceEventId: String(e.event_id || ""),
			...a && a !== o ? { SourceItemId: a } : {}
		}
	};
}
var rt = class {
	textByPart = /* @__PURE__ */ new Map();
	toolNameByCallId = /* @__PURE__ */ new Map();
	toolCallByItemId = /* @__PURE__ */ new Map();
	toolResultByItemId = /* @__PURE__ */ new Map();
	sessionId;
	constructor(e) {
		this.sessionId = e;
	}
	translate(e) {
		if (!z(e)) return null;
		let t = Number(e.seq);
		if (!Number.isFinite(t) || t <= 0) return null;
		let n = String(e.family || ""), r = String(e.event_type || ""), i = String(e.run_id || ""), a = () => ({
			EventId: e.event_id ? String(e.event_id) : `kernel-${t}`,
			SessionId: this.sessionId,
			InvocationId: i || void 0,
			SeqId: t
		});
		if (n === "interaction") return {
			...a(),
			EventType: r,
			payload: e
		};
		if (n === "control") {
			if (r === "control.command_rejected") return {
				...a(),
				EventType: r,
				Content: e
			};
			if (r === "control.run_transition") {
				let t = String(e.state || "").toLowerCase();
				if (Ye.has(t)) return {
					...a(),
					EventType: "run_status",
					Content: { status: t }
				};
			}
			return null;
		}
		if (n !== "runtime") return null;
		let o = Je[r];
		if (o) return {
			...a(),
			EventType: "run_status",
			Content: { status: o }
		};
		let s = Xe(e);
		if (r === "item.started") {
			let t = B(e, "initial");
			if (e.item_kind === "tool_call") {
				let n = tt(t), r = n?.callId || String(e.item_id || ""), o = n?.name || "tool";
				return r && this.toolNameByCallId.set(r, o), e.item_id && this.toolCallByItemId.set(String(e.item_id), {
					callId: r,
					name: o
				}), {
					...a(),
					EventType: "tool_call",
					Metadata: {
						...U(e, "replace", void 0, r),
						call_id: r,
						tool_name: o,
						run_id: i,
						tool_args: n?.arguments ?? H(t)
					}
				};
			}
			return e.item_kind === "tool_result" || s === "userMessage" || Qe(t) || s === "reasoning" || e.item_kind === "reasoning" ? null : s === "agentMessage" || !s && e.item_kind === "message" ? {
				...a(),
				EventType: "assistant_stream_snapshot",
				Content: { parts: [{ text: "" }] },
				Metadata: U(e, "replace")
			} : s && s !== "notification" ? {
				...a(),
				EventType: "tool_call",
				Metadata: {
					...U(e, "replace"),
					call_id: String(e.item_id || ""),
					tool_name: s,
					run_id: i,
					tool_args: H(t)
				}
			} : null;
		}
		if (r === "item.updated") {
			let n = B(e, "update");
			if (e.item_kind === "tool_call") {
				let t = nt(n);
				if (!t) return null;
				let r = this.toolCallByItemId.get(String(e.item_id || "")), o = t.callId || r?.callId || String(e.item_id || ""), s = r?.name || this.toolNameByCallId.get(o) || "tool", c = t.isError ? { error: t.result } : t.result;
				return e.item_id && this.toolResultByItemId.set(String(e.item_id), c), {
					...a(),
					EventType: "tool_result",
					Metadata: {
						...U(e, "completed", void 0, o),
						call_id: o,
						tool_name: s,
						run_id: i,
						tool_output: c
					}
				};
			}
			let r = z(n[0]), o = String(r?.part_id || e.item_id || t), c = String(e.op || "replace"), l = V(n), u = this.textByPart.get(o) || "", d = c === "append" ? u + l : l;
			return this.textByPart.set(o, d), s === "agentMessage" || !s && e.item_kind === "message" ? {
				...a(),
				EventType: "assistant_stream_snapshot",
				Content: { parts: [{ text: d }] },
				Metadata: U(e, "replace", o)
			} : s === "reasoning" || e.item_kind === "reasoning" ? {
				...a(),
				EventType: "reasoning",
				Content: { parts: [{ text: l }] },
				Metadata: U(e, c === "append" ? "append" : "replace", o)
			} : null;
		}
		if (r === "item.snapshot_replaced") {
			let n = B(e, "snapshot"), r = String(z(n[0])?.part_id || e.item_id || t), i = V(n);
			return this.textByPart.set(r, i), s === "agentMessage" || !s && e.item_kind === "message" ? {
				...a(),
				EventType: "assistant_stream_snapshot",
				Content: { parts: [{ text: i }] },
				Metadata: U(e, "replace", r)
			} : s === "reasoning" || e.item_kind === "reasoning" ? {
				...a(),
				EventType: "reasoning",
				Content: { parts: [{ text: i }] },
				Metadata: U(e, "replace", r)
			} : null;
		}
		if (r === "item.completed") {
			let n = B(e, "snapshot");
			if (e.item_kind === "tool_call") {
				let t = tt(n), r = nt(n), o = this.toolCallByItemId.get(String(e.item_id || "")), s = r?.callId || t?.callId || o?.callId || String(e.item_id || ""), c = t?.name || o?.name || this.toolNameByCallId.get(s) || "tool";
				if (s && this.toolNameByCallId.set(s, c), r) {
					let t = r.isError ? { error: r.result } : r.result;
					return {
						...a(),
						EventType: "tool_result",
						Metadata: {
							...U(e, "completed", void 0, s),
							call_id: s,
							tool_name: c,
							run_id: i,
							tool_output: t
						}
					};
				}
				return {
					...a(),
					EventType: "tool_call",
					Metadata: {
						...U(e, "replace", void 0, s),
						call_id: s,
						tool_name: c,
						run_id: i,
						tool_args: t?.arguments ?? H(n)
					}
				};
			}
			if (e.item_kind === "tool_result") {
				let t = nt(n), r = t?.callId || String(e.item_id || ""), o = this.toolNameByCallId.get(r) || s || "tool", c = t?.isError ? { error: t.result } : t?.result ?? H(n);
				return {
					...a(),
					EventType: "tool_result",
					Metadata: {
						...U(e, "completed", void 0, r),
						call_id: r,
						tool_name: o,
						run_id: i,
						tool_output: c
					}
				};
			}
			if (s === "userMessage" || Qe(n)) return {
				...a(),
				EventType: "user_message",
				Content: { parts: [{ text: V(n) }] }
			};
			if (s === "agentMessage" || !s && e.item_kind === "message") {
				let r = V(n), i = String(z(n[0])?.part_id || e.item_id || t);
				return this.textByPart.set(i, r), {
					...a(),
					EventType: "assistant_message",
					Content: { parts: [{ text: r }] },
					Metadata: U(e, "completed", i)
				};
			}
			if (s === "reasoning" || e.item_kind === "reasoning") {
				let r = String(z(n[0])?.part_id || e.item_id || t);
				return {
					...a(),
					EventType: "reasoning",
					Content: { parts: [{ text: V(n) }] },
					Metadata: U(e, "completed", r)
				};
			}
			return s && s !== "notification" ? {
				...a(),
				EventType: "tool_result",
				Metadata: {
					...U(e, "completed"),
					call_id: String(e.item_id || ""),
					tool_name: s,
					run_id: i,
					tool_output: H(n)
				}
			} : null;
		}
		if (r === "item.failed") {
			if (e.item_kind === "tool_call") {
				let t = this.toolCallByItemId.get(String(e.item_id || "")), n = t?.callId || String(e.item_id || ""), r = t?.name || this.toolNameByCallId.get(n) || "tool", o = this.toolResultByItemId.get(String(e.item_id || ""));
				return {
					...a(),
					EventType: "tool_result",
					Metadata: {
						...U(e, "completed", void 0, n),
						call_id: n,
						tool_name: r,
						run_id: i,
						tool_output: o ?? { error: z(e.error) || e.error || "item failed" }
					}
				};
			}
			return s && s !== "notification" && s !== "agentMessage" && s !== "reasoning" ? {
				...a(),
				EventType: "tool_result",
				Metadata: {
					...U(e, "completed"),
					call_id: String(e.item_id || ""),
					tool_name: s,
					run_id: i,
					tool_output: { error: z(e.error) || e.error || "item failed" }
				}
			} : null;
		}
		return null;
	}
};
async function it(e) {
	let t = e.getReader(), n = new TextDecoder(), r = "", i = null, a = !1, o = (e) => e.includes("data:") || e.includes("event:") || e.includes(":");
	try {
		for (;;) {
			let { value: e, done: s } = await t.read();
			if (e && (r += n.decode(e, { stream: !0 })), s) {
				a = !0;
				break;
			}
			if (r.trimStart().startsWith("{")) {
				if (at(r)) {
					i = ot(r);
					break;
				}
			} else if (o(r)) break;
		}
	} catch (e) {
		throw t.releaseLock(), e;
	}
	let s = new TextEncoder().encode(r), c = new ReadableStream({
		start(e) {
			if (s.length > 0 && e.enqueue(s), a || i) {
				e.close();
				return;
			}
			let n = () => t.read().then(({ value: t, done: r }) => {
				if (t && e.enqueue(t), r) {
					e.close();
					return;
				}
				return n();
			}).catch((t) => {
				try {
					e.error(t);
				} catch {}
			});
			n();
		},
		cancel() {
			t.cancel().catch(() => {});
		}
	});
	return {
		receipt: i,
		stream: c
	};
}
function at(e) {
	let t = e.trim();
	if (!t.endsWith("}")) return !1;
	let n = 0, r = !1, i = !1;
	for (let e of t) {
		if (i) {
			i = !1;
			continue;
		}
		if (e === "\\") {
			i = !0;
			continue;
		}
		e === "\"" && (r = !r), !r && ((e === "{" || e === "[") && (n += 1), (e === "}" || e === "]") && --n);
	}
	return n === 0;
}
function ot(e) {
	try {
		let t = z(JSON.parse(e).Data), n = String(t?.ReceiptStatus || "");
		if (!n) return null;
		let r = z(t?.Error);
		return {
			status: n,
			presentationProfile: t?.PresentationProfile === "agent-block-v1" ? "agent-block-v1" : "flat-v1",
			commandId: t?.CommandId ?? null,
			messageId: t?.MessageId ?? null,
			runId: t?.RunId ?? null,
			acceptedSeq: t?.AcceptedSeq ?? null,
			error: r ? {
				code: String(r.code || ""),
				message: String(r.message || "")
			} : null
		};
	} catch {
		return null;
	}
}
//#endregion
//#region src/utils/responses-stream.js
function st() {
	return {
		toolNames: /* @__PURE__ */ new Map(),
		toolArguments: /* @__PURE__ */ new Map(),
		callIds: /* @__PURE__ */ new Map(),
		currentResponseId: "",
		sawTextDelta: !1,
		sawReasoningDelta: !1,
		seenEvents: /* @__PURE__ */ new Set(),
		itemCallIds: /* @__PURE__ */ new Map()
	};
}
function ct(e) {
	return typeof e == "string" ? e : Array.isArray(e) ? e.map((e) => typeof e == "string" ? e : e && typeof e == "object" && typeof e.text == "string" ? e.text : "").join("") : e && typeof e == "object" && typeof e.text == "string" ? e.text : "";
}
function W(e) {
	return e == null ? "" : typeof e == "string" ? e : typeof e == "object" ? JSON.stringify(e, null, 2) : String(e);
}
function G(...e) {
	for (let t of e) {
		let e = ct(t);
		if (e) return e;
	}
	return "";
}
function lt(e, t) {
	return String(e?.id || e?.item_id || e?.call_id || t?.item_id || t?.call_id || t?.output_index || "");
}
function ut(e, t, n, r, i) {
	t && (e.toolNames.set(t, r), e.toolArguments.set(t, i));
	let a = String(n?.call_id || "");
	t && a && e.itemCallIds.set(t, a), a && (e.callIds.set(a, t || r), e.toolNames.set(a, r), e.toolArguments.set(a, i));
}
function K(e, t, n, r = "tool") {
	let i = String(n?.call_id || "");
	return String(n?.name || n?.tool_name || (t ? e.toolNames.get(t) : "") || (i ? e.toolNames.get(i) : "") || r);
}
function dt(e) {
	if (!e || typeof e != "object") return "";
	let t = ct(e.content);
	return G(e.output_text, e.text, e.summary_text, e.summary, e.delta, t);
}
function ft(e) {
	let t = e?.response && typeof e.response == "object" ? e.response : e, n = G(t?.output_text, t?.text);
	if (n) return n;
	let r = Array.isArray(t?.output) ? t.output : [];
	for (let e of r) {
		let t = dt(e);
		if (t) return t;
	}
	return "";
}
function pt(e) {
	let t = e?.response && typeof e.response == "object" ? e.response : e;
	return Array.isArray(t?.output) ? t.output : [];
}
function mt(e) {
	let t = e;
	if (typeof t == "string") try {
		t = JSON.parse(t);
	} catch {
		return {};
	}
	return Array.isArray(t) && (t = t[0] || {}), !t || typeof t != "object" ? {} : t.value && typeof t.value == "object" && !Array.isArray(t.value) ? {
		...t.value,
		approval_request_id: t.value.approval_request_id || t.value.id || t.id
	} : t;
}
function ht({ data: e, state: t, status: n }) {
	let r = e?.item || e?.output_item || e || {}, i = String(r.type || "").trim(), a = lt(r, e);
	if (i === "function_call" || i === "shell_call") {
		let e = K(t, a, r, i === "shell_call" ? "codex.command" : "tool"), o = W(r.arguments ?? r.args ?? r.input ?? r.action);
		ut(t, a, r, e, o);
		let s = String(r.call_id || t.itemCallIds.get(a) || a);
		return [{
			type: "tool_upsert",
			name: e,
			args: o,
			status: [
				"failed",
				"error",
				"uncertain"
			].includes(r.status) ? "error" : n,
			extra: {
				...s ? { callId: s } : {},
				...r.tool_display ? { toolDisplay: r.tool_display } : {}
			}
		}];
	}
	if (i === "function_call_output") return [{
		type: "tool_result",
		name: K(t, a, r),
		output: W(r.output ?? r.result ?? r.content),
		callId: String(r.call_id || t.itemCallIds.get(a) || a)
	}];
	if (i === "mcp_approval_request") {
		let n = String(r.name || "approval"), i = W(r.arguments ?? r.args), a = String(r.id || r.approval_request_id || ""), o = String(r.run_id || r.runId || e?.run_id || e?.runId || "");
		return [{
			type: "tool_upsert",
			name: n,
			args: i,
			status: "paused",
			approvalRequestId: a,
			previousResponseId: String(e?.response_id || t.currentResponseId || ""),
			serverLabel: String(r.server_label || "")
		}, {
			type: "approval_request",
			approvalRequestId: a,
			previousResponseId: String(e?.response_id || t.currentResponseId || ""),
			...o ? { runId: o } : {},
			name: n,
			args: i
		}];
	}
	if (i === "reasoning" || i === "reasoning_summary" || i === "reasoning_summary_text") {
		let t = dt(r), i = q({
			...e,
			...r,
			item_id: r.id || e?.item_id
		});
		return [...t ? [{
			type: "reasoning_delta",
			text: t,
			...i
		}] : [], ...n === "completed" ? [{
			type: "reasoning_done",
			text: t,
			...i
		}] : []];
	}
	if (i === "message") {
		let e = dt(r);
		return e ? [{
			type: n === "completed" ? "text_final" : "text_delta",
			text: e
		}] : [];
	}
	return [];
}
function gt({ eventName: e, data: t, state: n }) {
	let r = String(t?.type || e || "").trim();
	if (t?.event_id) {
		if (n.seenEvents.has(t.event_id)) return [];
		n.seenEvents.add(t.event_id);
	}
	let i = String(t?.id || t?.response?.id || t?.response_id || "");
	if (i.startsWith("resp_") && (n.currentResponseId = i), r === "response.tool_call") return [{
		type: "tool_upsert",
		name: String(t?.name || t?.tool_name || "tool"),
		args: W(t?.args ?? t?.arguments),
		status: "running",
		extra: { callId: String(t?.call_id || t?.item_id || "") }
	}];
	if (r === "response.tool_result" || r === "response.ksadk.tool_result") return [{
		type: "tool_result",
		name: String(t?.name || t?.tool_name || "tool"),
		callId: String(t?.call_id || t?.item_id || ""),
		output: W(t?.output ?? t?.result)
	}];
	if (r === "response.output_item.added") return ht({
		data: t,
		state: n,
		status: "running"
	});
	if (r === "response.output_item.done") return ht({
		data: t,
		state: n,
		status: "completed"
	});
	if (r === "response.function_call_arguments.delta") {
		let e = String(t?.item_id || t?.call_id || ""), r = K(n, e, t), i = `${n.toolArguments.get(e) || ""}${String(t?.delta || "")}`;
		return n.toolArguments.set(e, i), [{
			type: "tool_upsert",
			name: r,
			args: i,
			status: "running",
			extra: { callId: String(t?.call_id || n.itemCallIds.get(e) || e) }
		}];
	}
	if (r === "response.function_call_arguments.done") {
		let e = String(t?.item_id || t?.call_id || ""), r = K(n, e, t), i = W(t?.arguments ?? n.toolArguments.get(e));
		return n.toolArguments.set(e, i), [{
			type: "tool_upsert",
			name: r,
			args: i,
			status: "running",
			extra: { callId: String(t?.call_id || n.itemCallIds.get(e) || e) }
		}];
	}
	if (r === "response.reasoning.delta" || r === "response.reasoning_text.delta" || r === "response.reasoning_summary.delta" || r === "response.reasoning_summary_text.delta") {
		let e = G(t?.delta, t?.text);
		return e && (n.sawReasoningDelta = !0), e ? [{
			type: "reasoning_delta",
			text: e,
			...q(t)
		}] : [];
	}
	if (r === "response.reasoning_summary_text.done") return [{
		type: "reasoning_done",
		text: G(t?.text),
		...q(t)
	}];
	if (r === "response.output_text.delta") {
		let e = G(t?.delta, t?.text);
		return e && (n.sawTextDelta = !0), e ? [{
			type: "text_delta",
			text: e
		}] : [];
	}
	if (r === "response.output_text.done") {
		let e = G(t?.text, t?.delta);
		return e ? [{
			type: "text_final",
			text: e
		}] : [];
	}
	if (r === "response.content_part.delta") {
		let e = String(t?.part?.type || t?.delta?.type || t?.content_type || ""), r = G(t?.delta?.text, t?.delta, t?.text);
		return r ? e.includes("reasoning") ? (n.sawReasoningDelta = !0, [{
			type: "reasoning_delta",
			text: r,
			...q(t)
		}]) : (n.sawTextDelta = !0, [{
			type: "text_delta",
			text: r
		}]) : [];
	}
	if (r === "response.completed") {
		let e = ft(t), r = pt(t).flatMap((e) => ht({
			data: {
				...t,
				item: e
			},
			state: n,
			status: "completed"
		})).filter((e) => !(n.sawTextDelta && e.type === "text_final") && !(n.sawReasoningDelta && e.type === "reasoning_delta")), i = r.some((e) => e.type === "text_final");
		return [
			...r,
			...e && !n.sawTextDelta && !i ? [{
				type: "text_final",
				text: e
			}] : [],
			{
				type: "terminal",
				status: "completed"
			}
		];
	}
	if (r === "response.failed") return [{
		type: "failed",
		message: t?.error?.message || "Agent 运行失败"
	}, {
		type: "terminal",
		status: "failed"
	}];
	if (r === "response.incomplete") return [{ type: "incomplete" }, {
		type: "terminal",
		status: "incomplete"
	}];
	if (r === "response.cancelled") return [{
		type: "terminal",
		status: "cancelled"
	}];
	if (r === "response.approval_request" || r === "response.ksadk.approval_request") {
		let e = mt(t?.interrupt_info), r = String(e.approval_request_id || e.id || ""), i = String(t?.response_id || n.currentResponseId || ""), a = String(t?.run_id || t?.runId || ""), o = e.approval_requests && typeof e.approval_requests == "object" ? e.approval_requests : e, s = Array.isArray(o.action_requests) ? o.action_requests : [];
		if (s.length > 0) {
			let e = s.map((e) => ({
				type: "tool_upsert",
				name: String(e?.name || "tool"),
				args: JSON.stringify(e?.args ?? {}),
				status: "paused",
				approvalRequestId: r,
				previousResponseId: i
			})), t = s[0] || {};
			return [...e, {
				type: "approval_request",
				approvalRequestId: r,
				previousResponseId: i,
				...a ? { runId: a } : {},
				name: String(t?.name || "人工确认"),
				args: JSON.stringify(t?.args ?? {})
			}];
		}
		return [{
			type: "approval_request",
			approvalRequestId: r,
			previousResponseId: i,
			...a ? { runId: a } : {}
		}];
	}
	if (r === "response.approval_resolved" || r === "response.ksadk.approval_resolved") {
		let e = String(t?.decision || t?.outcome || "").toLowerCase(), n = e === "reject" || e === "rejected" || e === "denied" ? "rejected" : e === "cancel" || e === "cancelled" || e === "canceled" ? "cancelled" : "approved";
		return [{
			type: "approval_resolved",
			approvalRequestId: String(t?.approval_request_id || t?.approvalRequestId || t?.approval_id || t?.approvalId || ""),
			decision: n,
			revision: Number(t?.revision || 2)
		}];
	}
	if (new Set([
		"response.ksadk.a2ui_surface_begin",
		"a2ui.surface.begin",
		"response.a2ui.createSurface",
		"a2ui.createSurface",
		"createSurface"
	]).has(r)) {
		let e = t?.surface && typeof t.surface == "object" ? t.surface : {};
		return [{
			type: "a2ui_surface_begin",
			surfaceId: String(t?.surface_id || t?.surfaceId || e.surface_id || e.surfaceId || ""),
			surface: e
		}];
	}
	if (new Set([
		"response.ksadk.a2ui_surface_update",
		"a2ui.surface.update",
		"response.a2ui.updateComponents",
		"a2ui.updateComponents",
		"updateComponents"
	]).has(r)) {
		let e = t?.surface && typeof t.surface == "object" ? t.surface : {};
		return [{
			type: "a2ui_surface_update",
			surfaceId: String(t?.surface_id || t?.surfaceId || e.surface_id || e.surfaceId || ""),
			surface: e
		}];
	}
	if (new Set([
		"response.ksadk.a2ui_surface_end",
		"a2ui.surface.end",
		"response.a2ui.deleteSurface",
		"a2ui.deleteSurface",
		"deleteSurface"
	]).has(r)) return [{
		type: "a2ui_surface_end",
		surfaceId: String(t?.surface_id || t?.surfaceId || "")
	}];
	if (new Set(["response.ksadk.a2ui_interaction", "a2ui.interaction"]).has(r)) return [{
		type: "a2ui_interaction",
		surfaceId: String(t?.surface_id || t?.surfaceId || ""),
		interactionId: String(t?.interaction_id || t?.interactionId || ""),
		kind: String(t?.kind || "input"),
		inputSchema: t?.input_schema && typeof t.input_schema == "object" ? t.input_schema : {}
	}];
	let a = t?.content?.parts?.[0]?.text;
	return a && !t?.actions?.finishReason ? [{
		type: "text_delta",
		text: String(a)
	}] : [];
}
function q(e) {
	return {
		...e?.item_id ? { itemId: String(e.item_id) } : {},
		source: e?.public_summary === !0 ? "public_summary" : e?.presentation_source === "provider_reasoning" ? "provider_reasoning" : e?.presentation_source === "runtime_progress" ? "runtime_progress" : "reasoning"
	};
}
//#endregion
//#region src/utils/session-events.js
var _t = new Set([
	"completed",
	"failed",
	"error",
	"cancelled",
	"canceled",
	"aborted",
	"interrupted",
	"resume_failed"
]), vt = new Set([
	"tool_call",
	"tool_result",
	"stage_tool_call",
	"stage_tool_result"
]), yt = {
	"run.started": "in_progress",
	"run.progress": "in_progress",
	"run.interrupted": "interrupted",
	"run.completed": "completed",
	"run.failed": "failed",
	"run.canceled": "cancelled"
};
function J(e) {
	let t = e?.Content?.payload;
	return t && typeof t == "object" ? t : {};
}
function bt(e, t) {
	let n = String(e || ""), r = String(t || "");
	return n ? !r || n.endsWith(r) ? n : r.startsWith(n) ? r : `${n}${r}` : r;
}
function xt(e) {
	let t = String(e?.EventType || ""), n = J(e);
	return yt[t] ? {
		...e,
		EventType: "run_status",
		Content: {
			status: String(n.status || yt[t]),
			...n.detail ? { detail: String(n.detail) } : {}
		}
	} : t === "reasoning.delta" || t === "reasoning.completed" ? {
		...e,
		EventType: "reasoning",
		Content: {
			role: "model",
			parts: [{ text: String(n.text || "") }]
		}
	} : t === "tool.call.begin" ? {
		...e,
		EventType: "tool_call",
		Metadata: {
			...e.Metadata || {},
			tool_name: n.name,
			tool_args: n.args,
			tool_call_id: n.call_id
		},
		Content: {
			role: "model",
			parts: []
		}
	} : t === "tool.call.end" ? {
		...e,
		EventType: "tool_result",
		Metadata: {
			...e.Metadata || {},
			tool_name: n.name,
			tool_output: n.error || n.result,
			tool_call_id: n.call_id
		},
		Content: {
			role: "model",
			parts: []
		}
	} : e;
}
function St(e) {
	let t = [], n = /* @__PURE__ */ new Map();
	for (let r of Array.isArray(e) ? e : []) {
		let e = String(r?.EventType || "");
		if (e === "text.delta" || e === "text.completed" || e === "message.delta") {
			let e = String(r?.InvocationId || "").trim();
			if (!e) continue;
			let t = n.get(e);
			n.set(e, {
				event: r,
				text: bt(t?.text, J(r).text || r?.Content?.text)
			});
			continue;
		}
		t.push(xt(r));
	}
	for (let { event: e, text: r } of n.values()) t.push({
		...e,
		EventType: "assistant_stream_snapshot",
		Content: {
			role: "model",
			parts: [{ text: r }]
		},
		Metadata: {
			...e.Metadata || {},
			stream_snapshot: !0
		}
	});
	for (let n of Array.isArray(e) ? e : []) String(n?.EventType || "") === "message.completed" && t.push({
		...n,
		EventType: "assistant_message",
		Content: {
			role: "model",
			parts: [{ text: String(J(n).text || n?.Content?.text || "") }]
		}
	});
	return t.sort((e, t) => X(e) - X(t));
}
function Ct(e) {
	let t = String(e?.EventType || "").trim();
	if (t !== "run_status" && !t.startsWith("run.")) return "";
	let n = J(e);
	return String(e?.Content?.status || n.status || yt[t] || "").trim().toLowerCase();
}
function wt(e) {
	return typeof e == "string" ? e : Array.isArray(e) ? e.map((e) => typeof e == "string" ? e : e && typeof e == "object" && typeof e.text == "string" ? e.text : "").join("") : "";
}
function Tt(e) {
	let t = String(e || "").trim();
	return t ? `/agentengine/api/v1/AttachmentContent?FileUri=${encodeURIComponent(t)}` : "";
}
function Et(e) {
	return String(e || "").match(/^data:([^;,]+)/)?.[1] || "";
}
function Dt(e, t) {
	let n = String(e || "").trim(), r = String(t || "").trim();
	return !n || !r || n === r ? !0 : n.endsWith("/*") ? r.startsWith(n.slice(0, -1)) : r.endsWith("/*") ? n.startsWith(r.slice(0, -1)) : !1;
}
function Y(e) {
	let t = e?.Content?.parts || [], n = [], r = /* @__PURE__ */ new Map(), i = (e) => {
		let t = `${e.fileUri || e.url || e.name}|${e.type}`;
		r.has(t) || r.set(t, e);
	};
	for (let e of t) {
		if (e?.type === "input_text" || e?.text) {
			n.push(e.text || "");
			continue;
		}
		if (e?.type === "input_file" && e.inlineData) {
			i({
				name: e.inlineData.displayName || "attachment",
				url: `data:${e.inlineData.mimeType || "application/octet-stream"};base64,${e.inlineData.data}`,
				type: e.inlineData.mimeType || "application/octet-stream"
			});
			continue;
		}
		if (e?.type === "input_file" && typeof e.file_data == "string" && e.file_data) {
			i({
				name: e.filename || e.displayName || e.display_name || "attachment",
				url: `data:${e.mime_type || e.mimeType || "application/octet-stream"};base64,${e.file_data}`,
				type: e.mime_type || e.mimeType || "application/octet-stream"
			});
			continue;
		}
		if (e?.type === "input_file" && typeof e.file_url == "string" && e.file_url.trim()) {
			let t = e.file_url.trim();
			i({
				name: e.filename || e.displayName || e.display_name || "attachment",
				url: Tt(t),
				type: e.mime_type || e.mimeType || "application/octet-stream",
				fileUri: t
			});
			continue;
		}
		if (e?.type === "input_image" || e?.type === "image_url") {
			let t = typeof e.image_url == "string" ? e.image_url : e.image_url?.url;
			t && i({
				name: e.filename || e.displayName || e.display_name || "uploaded_image",
				url: t,
				type: e.mime_type || e.mimeType || Et(t) || "image/*"
			});
			continue;
		}
		if (e?.type === "input_file" && e.fileData) {
			let t = String(e.fileData.fileUri || "").trim();
			i({
				name: e.fileData.displayName || "attachment",
				url: Tt(t),
				type: e.fileData.mimeType || "application/octet-stream",
				fileUri: t
			});
		}
	}
	let a = Array.isArray(e?.Metadata?.attachments) ? e.Metadata.attachments : [];
	for (let e of a) {
		let t = String(e.file_uri || "").trim(), n = {
			name: e.display_name || "attachment",
			url: Tt(t),
			type: e.mime_type || "application/octet-stream",
			fileUri: t
		};
		!n.url && !n.fileUri && Array.from(r.values()).some((e) => e.name === n.name && Dt(e.type, n.type) && (e.url || e.fileUri)) || i(n);
	}
	let o = Array.from(r.values());
	return {
		text: n.join(""),
		attachments: o.length > 0 ? o : void 0
	};
}
function Ot(e) {
	let n = e?.Metadata?.responses_output;
	if (!Array.isArray(n)) return {};
	let r = st(), i = gt({
		eventName: "response.completed",
		data: { response: {
			id: String(e.Metadata?.response_id || ""),
			output: n
		} },
		state: r
	}), a = "", o = {};
	for (let e of i) {
		if (e.type === "reasoning_delta") {
			a += e.text;
			continue;
		}
		if (e.type === "tool_upsert") {
			o[e.name] = {
				...o[e.name] || {
					name: e.name,
					args: ""
				},
				name: e.name,
				args: e.args,
				status: e.status,
				...e.approvalRequestId ? { approvalRequestId: e.approvalRequestId } : {},
				...e.previousResponseId ? { previousResponseId: e.previousResponseId } : {},
				...e.serverLabel ? { serverLabel: e.serverLabel } : {},
				...e.approvalRequestId ? { approvalStatus: "pending" } : {}
			};
			continue;
		}
		e.type === "tool_result" && (o[e.name] = {
			...o[e.name] || {
				name: e.name,
				args: ""
			},
			name: e.name,
			output: e.output,
			status: t(e.output) ? "error" : "completed"
		});
	}
	return {
		...a ? { reasoning: a } : {},
		...Object.keys(o).length > 0 ? { tools: o } : {}
	};
}
function kt(e, t, n) {
	return t === "running" ? e === "prompt_too_long" ? "检测到上下文过长，正在自动压缩历史后重试" : "正在自动压缩上下文" : n ? e === "prompt_too_long" ? "上下文过长，系统已自动压缩历史并重试" : "系统已自动压缩较早的对话上下文" : t === "failed" ? "自动压缩上下文未完成" : e === "prompt_too_long" ? "已完成上下文压缩，并继续当前回复" : "已完成上下文压缩";
}
function At(e, t) {
	return t?.itemId ? [
		"runtime-item",
		t.runId || e,
		t.scopeId || e,
		t.itemId
	].join("\0") : [
		e,
		t.content || "",
		t.reasoning || ""
	].join("\0");
}
function jt(e) {
	let t = String(e?.InvocationId || "").trim(), n = e?.Metadata?.RuntimeItem;
	return n?.ItemId ? [
		"runtime-item",
		n.RunId || t,
		n.ScopeId || t,
		n.ItemId
	].join("\0") : t;
}
function Mt(e) {
	let t = e?.Metadata?.RuntimeItem;
	return t?.ItemId ? {
		id: `runtime:${t.RunId || e.InvocationId || "run"}:${t.ScopeId || e.InvocationId || "scope"}:${t.ItemId}`,
		runId: String(t.RunId || e.InvocationId || ""),
		scopeId: String(t.ScopeId || e.InvocationId || ""),
		itemId: String(t.ItemId),
		partId: t.PartId ? String(t.PartId) : void 0
	} : null;
}
function Nt(e) {
	return e?.Metadata?.responses_mirror === !0 || String(e?.Metadata?.responses_mirror || "").trim().toLowerCase() === "true";
}
function Pt(e) {
	if (e?.EventType !== "user_message") return "";
	let t = Y(e), n = (t.attachments || []).map((e) => [
		e.name || "",
		e.fileUri || "",
		e.url || "",
		e.type || ""
	].join("")).sort().join("");
	return [String(t.text || "").trim(), n].join("\0");
}
function Ft(e) {
	return e?.EventType === "assistant_stream_snapshot";
}
function X(e) {
	let t = Number(e?.SeqId || 0);
	if (Number.isFinite(t) && t > 0) return t;
	let n = Number(e?.Timestamp || 0);
	return Number.isFinite(n) ? n : 0;
}
function It(e) {
	if (typeof e == "string") return e;
	if (e == null) return "";
	try {
		return JSON.stringify(e, null, 2);
	} catch {
		return String(e);
	}
}
function Lt(e) {
	let r = String(e?.EventType || "");
	if (!vt.has(r)) return null;
	let i = String(e.Metadata?.tool_name || e.Metadata?.name || e.Metadata?.function_name || wt(e.Content?.parts) || "tool").trim() || "tool", a = String(e.Metadata?.call_id || e.Metadata?.callId || e.Metadata?.RuntimeItem?.ToolCallId || "").trim(), o = {
		name: i,
		...a ? { callId: a } : {},
		...n(e.Metadata?.tool_display) ? { toolDisplay: n(e.Metadata.tool_display) } : {},
		args: "",
		status: "running"
	}, s = r === "tool_result" || r === "stage_tool_result" ? (() => {
		let n = It(e.Metadata?.tool_output ?? e.Metadata?.output ?? e.Metadata?.result ?? wt(e.Content?.parts));
		return {
			...o,
			output: n,
			status: t(n) ? "error" : "completed"
		};
	})() : {
		...o,
		args: It(e.Metadata?.tool_args ?? e.Metadata?.arguments ?? e.Metadata?.args ?? {})
	}, c = Mt(e);
	return {
		id: c?.id || e.EventId || String(Date.now() + Math.random()),
		role: "model",
		content: "",
		timestamp: e.Timestamp || Date.now(),
		eventType: r,
		...c || {},
		tools: { [i]: s }
	};
}
function Rt(e = {}, t = {}) {
	let n = { ...e || {} };
	for (let [e, r] of Object.entries(t || {})) n[e] = {
		...n[e] || {},
		...r || {},
		name: e,
		args: r?.args || n[e]?.args || ""
	};
	return n;
}
function zt(e = {}, t = "") {
	let n = String(t || "").trim().toLowerCase(), r = n === "completed" ? "completed" : _t.has(n) ? "error" : "";
	if (!r) return e;
	let i = !1, a = {};
	for (let [t, n] of Object.entries(e || {})) n?.status === "running" ? (i = !0, a[t] = {
		...n,
		status: r
	}) : a[t] = n;
	return i ? a : e;
}
function Bt(e, t) {
	return {
		...e,
		reasoning: Vt(e.reasoning, t.reasoning),
		tools: Rt(e.tools, t.tools),
		eventId: t.eventId || e.eventId,
		responseId: t.responseId || e.responseId,
		traceId: t.traceId || e.traceId,
		rootSpanId: t.rootSpanId || e.rootSpanId,
		timestamp: Math.max(Number(e.timestamp || 0), Number(t.timestamp || 0)) || t.timestamp || e.timestamp,
		id: t.responseId || t.reasoning || t.tools ? t.id : e.id
	};
}
function Vt(e = "", t = "") {
	let n = String(e || ""), r = String(t || "");
	return n ? !r || n.endsWith(r) ? n : r.startsWith(n) ? r : `${n}${r}` : r;
}
function Ht(e) {
	return {
		id: e.id,
		role: "system",
		eventType: "context_checkpoint",
		status: e.status,
		trigger: e.trigger,
		compactedUntilSeqId: e.compactedUntilSeqId,
		summary: e.summary,
		historical: e.historical,
		timestamp: e.timestamp,
		content: kt(e.trigger, e.status, e.historical)
	};
}
function Ut(e) {
	let t = e?.EventType || "", n = Mt(e);
	if (t === "run_status") return e.Content?.status === "failed" ? {
		id: e.EventId || String(Date.now() + Math.random()),
		role: "system",
		content: e.Content?.detail || "本轮运行失败。",
		eventType: t,
		status: "failed",
		timestamp: e.Timestamp || Date.now()
	} : e.Content?.status === "cancelled" ? {
		id: e.EventId || String(Date.now() + Math.random()),
		role: "system",
		content: e.Content?.detail || "本轮输出已停止。",
		eventType: t,
		status: "cancelled",
		timestamp: e.Timestamp || Date.now()
	} : null;
	if (t === "context_checkpoint") {
		let t = Y(e);
		return Ht({
			id: e.EventId || String(Date.now() + Math.random()),
			timestamp: e.Timestamp || Date.now(),
			status: "completed",
			trigger: String(e.Metadata?.trigger || "auto"),
			compactedUntilSeqId: Number(e.Metadata?.compacted_until_seq_id || 0) || void 0,
			summary: t.text || void 0,
			historical: !0
		});
	}
	if (t === "reasoning") {
		let r = Y(e).text || wt(e.Metadata?.reasoning);
		return r ? {
			id: n?.id || e.EventId || String(Date.now() + Math.random()),
			role: "model",
			content: "",
			reasoning: r,
			reasoningSource: e.Metadata?.presentation_source === "public_summary" ? "public_summary" : e.Metadata?.presentation_source === "provider_reasoning" ? "provider_reasoning" : "reasoning",
			timestamp: e.Timestamp || Date.now(),
			eventType: t,
			...n || {}
		} : null;
	}
	if (vt.has(t)) return Lt(e);
	if (t !== "user_message" && t !== "assistant_message" && t !== "assistant_stream_snapshot") return null;
	let r = Y(e), i = t === "assistant_message" ? Ot(e) : {};
	if (!r.text && !r.attachments?.length && !i.reasoning && !i.tools) return null;
	let a = String(e.Metadata?.response_id || e.Metadata?.ResponseId || "").trim(), o = String(e.Metadata?.trace_id || e.Metadata?.TraceId || "").trim(), s = String(e.Metadata?.root_span_id || e.Metadata?.rootSpanId || e.Metadata?.RootSpanId || "").trim();
	return {
		id: n?.id || e.EventId || String(Date.now() + Math.random()),
		role: t === "user_message" ? "user" : "model",
		content: r.text,
		timestamp: e.Timestamp || Date.now(),
		eventType: t,
		eventId: e.EventId || void 0,
		responseId: a || void 0,
		traceId: o || void 0,
		rootSpanId: s || void 0,
		attachments: r.attachments,
		...n || {},
		...i
	};
}
function Wt(e = []) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set(), s = St(e), c = [];
	for (let e of s) {
		let t = String(e?.EventId || "").trim();
		if (t) {
			if (o.has(t)) continue;
			o.add(t);
		}
		c.push(e);
	}
	let l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Map();
	for (let e of c) {
		if (e?.EventType !== "user_message" || Nt(e)) {
			if (e?.EventType === "assistant_message") {
				let t = jt(e);
				t && u.add(t);
			}
			if (Ft(e)) {
				let t = jt(e);
				if (t) {
					let n = d.get(t);
					(!n || X(e) >= X(n)) && d.set(t, e);
				}
			}
			continue;
		}
		let t = Pt(e);
		t && l.add(t);
	}
	let f = c.filter((e) => {
		if (Ft(e)) {
			let t = jt(e);
			return t ? u.has(t) ? !1 : d.get(t) === e : !0;
		}
		if (e?.EventType !== "user_message" || !Nt(e)) return !0;
		let t = Pt(e);
		return !t || !l.has(t);
	});
	for (let e of f) {
		let a = String(e.InvocationId || "").trim();
		a && e.EventType === "user_message" && i.add(a), a && [
			"assistant_message",
			"assistant_stream_snapshot",
			"reasoning",
			"tool_call",
			"tool_result",
			"stage_tool_call",
			"stage_tool_result"
		].includes(String(e.EventType || "")) && r.add(a), e.EventType === "run_status" && a && (t.set(a, String(e.Content?.status || "").trim()), n.set(a, e));
	}
	let p = [], m = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Map(), g = null, _ = /* @__PURE__ */ new Map(), v = (e) => {
		let t = e?.itemId ? `${e.runId || e.invocationId || ""}\u0000${e.scopeId || e.invocationId || ""}\u0000${e.itemId}` : "", n = t ? h.get(t) : void 0;
		if (n !== void 0) {
			p[n] = Bt(p[n], e);
			return;
		}
		let r = String(e?.responseId || "").trim(), i = r ? m.get(r) : void 0;
		if (i !== void 0) {
			p[i] = Bt(p[i], e);
			return;
		}
		r && m.set(r, p.length), t && h.set(t, p.length), p.push(e);
	}, y = () => {
		g &&= (v(g), null);
	}, b = (e, n = "") => {
		let r = String(e || "").trim();
		if (!r) return {};
		let i = _.get(r);
		return i ? (_.delete(r), { tools: zt(i.tools, t.get(r) || n) }) : {};
	};
	for (let e of f) {
		if (e.EventType === "run_status") continue;
		let t = Ut(e);
		if (!t) continue;
		let n = String(e.InvocationId || "").trim();
		if (n && (t.invocationId = n), vt.has(t.eventType)) {
			let n = String(e.InvocationId || "").trim();
			if (t.itemId) {
				y(), v(t);
				continue;
			}
			if (!n) {
				y(), v(t);
				continue;
			}
			let r = _.get(n);
			_.set(n, {
				...r || {
					id: t.id,
					role: "model",
					content: "",
					timestamp: t.timestamp,
					invocationId: n
				},
				timestamp: Math.max(Number(r?.timestamp || 0), Number(t.timestamp || 0)),
				tools: Rt(r?.tools, t.tools)
			});
			continue;
		}
		if (t.eventType === "reasoning") {
			let n = String(e.InvocationId || "").trim(), r = String(e.Metadata?.RuntimeItem?.Operation || "").toLowerCase(), i = !!(t.itemId && g?.itemId === t.itemId && g?.runId === t.runId && g?.scopeId === t.scopeId), a = !!(!t.itemId && !g?.itemId && n && g?.invocationId === n);
			if (g && (i || a)) {
				g.reasoning = r === "replace" || r === "completed" ? t.reasoning : `${g.reasoning || ""}${t.reasoning || ""}`, g.timestamp = t.timestamp;
				continue;
			}
			y(), g = {
				...t,
				...n ? { invocationId: n } : {}
			};
			continue;
		}
		let r = t.eventType === "assistant_message" || t.eventType === "assistant_stream_snapshot";
		if (r && g) {
			let n = String(e.InvocationId || "").trim(), r = At(n, t);
			if (t.eventType === "assistant_message" && n && a.has(r)) {
				g = null;
				continue;
			}
			t.eventType === "assistant_message" && n && a.add(r), v({
				...t,
				...b(n, t.eventType === "assistant_message" ? "completed" : ""),
				reasoning: Vt(g.reasoning, t.reasoning)
			}), g = null;
			continue;
		}
		if (y(), r) {
			let n = String(e.InvocationId || "").trim(), r = At(n, t);
			if (t.eventType === "assistant_message" && n && a.has(r)) continue;
			t.eventType === "assistant_message" && n && a.add(r), v({
				...t,
				...b(n, t.eventType === "assistant_message" ? "completed" : "")
			});
			continue;
		}
		v(t);
	}
	y();
	for (let [e, n] of _.entries()) v({
		...n,
		tools: zt(n.tools, t.get(e))
	});
	for (let [e, a] of t.entries()) {
		if (a !== "in_progress" || r.has(e) || !i.has(e)) continue;
		let t = n.get(e) || {};
		v({
			id: `run-placeholder-${e}`,
			role: "model",
			content: "",
			status: "running",
			eventType: "run_status",
			timestamp: t.Timestamp || Date.now()
		});
	}
	return p;
}
function Gt(e = [], t = []) {
	let n = [], r = /* @__PURE__ */ new Set();
	for (let i of [...Array.isArray(e) ? e : [], ...Array.isArray(t) ? t : []]) {
		let e = String(i?.EventId || "").trim();
		if (e) {
			if (r.has(e)) continue;
			r.add(e);
		}
		n.push(i);
	}
	return n.sort((e, t) => {
		let n = Number(e?.SeqId || 0), r = Number(t?.SeqId || 0);
		return Number.isFinite(n) && Number.isFinite(r) && n !== r ? n - r : Number(e?.Timestamp || 0) - Number(t?.Timestamp || 0);
	});
}
function Kt(e = []) {
	return (Array.isArray(e) ? e : []).reduce((e, t) => {
		let n = Number(t.SeqId || 0);
		return Number.isFinite(n) ? Math.max(e, n) : e;
	}, 0);
}
function qt(e) {
	return _t.has(Ct(e));
}
//#endregion
//#region src/utils/persisted-session-history.ts
function Z(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : null;
}
function Q(e) {
	if (typeof e == "number" && Number.isFinite(e)) return e > 0 && e < 1e11 ? e * 1e3 : e;
	if (typeof e == "string" && e.trim()) {
		let t = Number(e.trim());
		if (Number.isFinite(t)) return t > 0 && t < 1e11 ? t * 1e3 : t;
	}
	let t = Date.parse(String(e || ""));
	return Number.isFinite(t) ? t : Date.now();
}
function $(e) {
	let t = Z(e?.Content?.runtime_event || e?.Content?.runtimeEvent);
	if (t && String(t.event_type || "")) return {
		...t,
		family: "runtime",
		seq: Number(e.SeqId || t.seq || 0),
		timestamp: e.Timestamp || t.timestamp
	};
	let n = Z(e?.Content?.session_event || e?.Content?.sessionEvent);
	if (!n || String(n.family || "") !== "runtime") return null;
	let r = Z(n.payload);
	return !r || !String(r.event_type || n.event_type || "") ? null : {
		...r,
		family: "runtime",
		event_type: r.event_type || n.event_type,
		run_id: r.run_id || n.run_id,
		seq: Number(e.SeqId || n.seq || r.seq || 0),
		timestamp: e.Timestamp || n.timestamp || r.timestamp
	};
}
function Jt(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let e of t) {
		if (e.EventType !== "run_status" || $(e)) continue;
		let t = String(e.InvocationId || e.Metadata?.run_id || "").trim();
		t && !n.has(t) && r.set(t, e);
	}
	let i = e;
	for (let [e, t] of r) {
		let n = Ut({
			...t,
			EventId: t.EventId || `legacy-terminal:${e}:${t.SeqId || 0}`,
			Timestamp: Q(t.Timestamp)
		});
		if (!n) continue;
		let r = (t) => (t.invocationId || t.runId) === e;
		i = i.filter((e) => !(r(e) && e.role === "system" && e.eventType === "run_status")).map((e) => {
			if (!r(e) || e.role !== "model") return e;
			let t = (e) => e === "running" || e === "paused", i = "运行已结束，未记录此工具的最终结果。";
			return {
				...e,
				tools: e.tools && Object.fromEntries(Object.entries(e.tools).map(([e, n]) => [e, t(n.status) ? {
					...n,
					status: "unknown",
					summary: n.summary || i
				} : n])),
				blocks: e.blocks?.map((e) => e.type === "thinking" && e.status === "streaming" ? {
					...e,
					status: "done"
				} : e.type !== "tool" || !t(e.status) ? e : {
					...e,
					status: "unknown",
					summary: e.summary || i,
					extra: {
						...e.extra,
						persistedToolStatus: e.status,
						terminalRunStatus: n.status
					}
				})
			};
		}), i.push({
			...n,
			invocationId: e,
			eventId: t.EventId
		});
	}
	return i === e ? e : [...i].sort((e, t) => Number(e.timestamp || 0) - Number(t.timestamp || 0));
}
function Yt(e) {
	return e.role === "model" ? {
		...e,
		blocks: e.blocks?.length ? e.blocks : qe({
			content: e.content,
			reasoning: e.reasoning,
			reasoningSource: e.reasoningSource,
			tools: e.tools
		})
	} : e;
}
function Xt(e, t) {
	let n = t.find((e) => e.role === "user"), r = e.some((e) => e.role === "user"), i = t.filter((e) => e.role === "model"), a = e.filter((e) => e.role === "model").at(-1), o = i.at(-1), s = e.map((e) => e.role === "user" && n ? {
		...e,
		...n,
		invocationId: e.invocationId || n.invocationId
	} : Yt(e === a && o ? {
		...e,
		responseId: o.responseId || e.responseId,
		traceId: o.traceId || e.traceId,
		rootSpanId: o.rootSpanId || e.rootSpanId
	} : e));
	return n && !r ? [n, ...s] : s;
}
function Zt(e, t) {
	let n = t.filter((e) => e.role === "model"), r = n.reduce((e, t) => ({
		...e,
		...t.tools || {}
	}), {}), i = n.map((e) => String(e.reasoning || "").trim()).filter(Boolean).join("\n\n"), a = [...e].reverse().find((e) => e.role === "model");
	return !a || Object.keys(r).length === 0 && !i ? e : e.map((e) => e === a ? Yt({
		...e,
		reasoning: e.reasoning || i || void 0,
		tools: Object.keys(r).length > 0 ? {
			...e.tools || {},
			...r
		} : e.tools
	}) : e);
}
function Qt(e) {
	return new Set(e.filter((e) => e.role === "model" && e.eventType === "assistant_message" && !!String(e.content || "").trim() && !!e.invocationId).map((e) => String(e.invocationId)));
}
var $t = new Set([
	"approval.resolved",
	"interaction.resolved",
	"interaction.cancelled",
	"interaction.canceled",
	"a2ui.action"
]);
function en(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) {
		let e = Z(n.Content) || {}, r = Z(e.runtime_event || e.runtimeEvent) || {}, i = Z(e.payload) || Z(r.payload) || {}, a = String(n.EventType || e.event_type || e.eventType || r.event_type || "").toLowerCase();
		if (!$t.has(a)) continue;
		let o = String(e.outcome || e.action || e.name || e.status || i.outcome || i.action || i.name || i.status || "").toLowerCase();
		if (![
			"cancel",
			"cancelled",
			"canceled"
		].includes(o)) continue;
		let s = String(n.InvocationId || e.runId || e.run_id || i.runId || i.run_id || r.run_id || "").trim();
		s && t.add(s);
	}
	return t;
}
function tn(e, t, n, r = "flat-v1") {
	let i = new rt(n), o = [], s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Map(), d = [...t || []].sort((e, t) => Number(e.SeqId || 0) - Number(t.SeqId || 0)), f = Number(d[0]?.SeqId || 0) <= 1;
	for (let e of d) {
		let t = Z(e.Content?.conversationItem);
		if (t && (t.kind === "progress" || t.kind === "error") && typeof Z(t.payload)?.outcome == "string") {
			let n = a(t), r = n ? Le(n) : null;
			r && u.set(r.id, {
				...r,
				invocationId: r.runId,
				timestamp: Q(e.Timestamp)
			});
		}
		let n = $(e);
		if (!n) continue;
		let r = String(n.run_id || "").trim();
		if (r) {
			s.add(r), !n.parent_scope_id && [
				"run.completed",
				"run.failed",
				"run.cancelled",
				"run.canceled"
			].includes(String(n.event_type)) && c.add(r);
			let e = Z(Z(n.source)?.metadata), t = String(n.event_type || "") === "run.started", i = e?.native_item_kind === "userMessage";
			(f || t || i) && l.add(r);
		}
		let d = i.translate(n);
		d && o.push({
			...d,
			SeqId: Number(e.SeqId || d.SeqId || 0),
			Timestamp: Q(e.Timestamp || d.Timestamp)
		});
	}
	let p = Wt(o).filter((e) => e.invocationId && s.has(e.invocationId)), m = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = String(t.invocationId || "");
		e && m.set(e, [...m.get(e) || [], t]);
	}
	let h = new Set([...Qt(p)].filter((e) => l.has(e))), g = /* @__PURE__ */ new Map();
	for (let e of d) {
		let t = $(e);
		if (t?.schema_version !== 2 || !t.run_id) continue;
		let n = String(t.run_id), r = g.get(n) || [];
		r.push(t), g.set(n, r);
	}
	let _ = (e) => [
		Z(e.initial),
		Z(e.snapshot),
		Z(e.update)
	].some((e) => Z(e?.data)?.schema === "execution.scope/v1" || Array.isArray(e?.parts) && e.parts.some((e) => Z(Z(e)?.data)?.schema === "execution.scope/v1")), v = new Set([...g].filter(([, e]) => e.some(_)).map(([e]) => e)), y = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Set();
	for (let [e, t] of g) {
		if (!v.has(e) && !h.has(e) && !t.some((e) => ["item.failed", "run.failed"].includes(String(e.event_type)))) continue;
		let i = t.some((e) => e.event_type === "run.started" && !e.parent_scope_id), a = /* @__PURE__ */ new Set(), o = t.every((e) => {
			let t = JSON.stringify([e.scope_id, e.item_id]);
			return e.event_type === "item.started" && a.add(t), !_(e) || a.has(t);
		});
		if (!(!i || !o)) try {
			let i = new T(n, void 0, r);
			t.forEach((e) => i.apply(e));
			let a = i.snapshot(), o = fe(a, { profile: r }), s = Q(t[0].timestamp);
			y.set(e, I({
				state: a,
				presentation: o,
				runId: e,
				cursor: Math.max(...t.map((e) => Number(e.seq || 0)))
			}).messages.map((t, n) => ({
				...t,
				invocationId: e,
				timestamp: s + n
			})));
		} catch (t) {
			b.add(e), console.warn(`[SessionHistory] strict replay skipped for run ${e}:`, t instanceof Error ? t.message : "invalid runtime history");
		}
	}
	for (let e of new Set([...v, ...b])) y.has(e) || h.delete(e);
	let x = en(d), S = [...h].flatMap((e) => Xt(p.filter((t) => t.invocationId === e), m.get(e) || [])), C = /* @__PURE__ */ new Map(), w = [];
	for (let [e, t] of m) {
		if (h.has(e) || !s.has(e)) continue;
		let n = p.filter((t) => t.invocationId === e);
		C.set(e, Zt(t, n)), t.some((e) => e.role === "model" && String(e.content || "").trim()) || w.push(...n.map(Yt));
	}
	for (let e of s) h.has(e) || m.has(e) || w.push(...p.filter((t) => t.invocationId === e).map(Yt));
	let E = new Map([...C.values()].flat().map((e) => [e.id, e])), D = [
		...e.filter((e) => !(e.role === "model" && e.invocationId && x.has(e.invocationId)) && (e.role === "a2ui" || !e.invocationId || !h.has(e.invocationId))).map((e) => E.get(e.id) || e),
		...S,
		...w,
		...u.values()
	].sort((e, t) => Number(e.timestamp || 0) - Number(t.timestamp || 0));
	for (let [e, t] of y) {
		if (!t.length) continue;
		let n = (t) => t.invocationId === e || t.runId === e, r = D.findIndex(n), i = D.filter(n), a = i.find((e) => e.role === "user"), o = v.has(e) ? a && !t.some((e) => e.role === "user") ? [a, ...t] : t : Xt(t, i), s = D.filter((e) => !n(e)), c = r < 0 ? s.length : r;
		D = [
			...s.slice(0, c),
			...o,
			...s.slice(c)
		], h.add(e);
	}
	return {
		messages: Jt(D, d, c),
		canonicalRunIds: [...h],
		translatedEvents: o
	};
}
//#endregion
export { Te as C, T as D, fe as E, w as O, I as S, Se as T, Ue as _, qt as a, Ge as b, Ct as c, rt as d, it as f, Ve as g, qe as h, Wt as i, st as l, Be as m, tn as n, Kt as o, He as p, Ht as r, Gt as s, $ as t, gt as u, Ke as v, we as w, Re as x, We as y };
