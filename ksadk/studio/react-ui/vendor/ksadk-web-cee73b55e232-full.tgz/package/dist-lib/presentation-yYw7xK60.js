//#region src/core/teams/presentation.ts
var e = {
	draft: "计划中",
	ready: "待开始",
	blocked: "等待依赖",
	planning: "规划中",
	running: "进行中",
	waiting: "等待中",
	needs_attention: "需要处理",
	awaiting_acceptance: "待验收",
	succeeded: "已验收",
	failed: "失败",
	cancel_requested: "正在请求停止",
	cancelled: "已取消"
}, t = (e) => ![
	"succeeded",
	"failed",
	"cancelled"
].includes(e);
function n(e) {
	return e.teamRuns.find((e) => t(e.status)) ?? e.teamRuns.at(-1) ?? null;
}
function r(e) {
	return ["failed", "awaiting_acceptance"].includes(e.status) ? "attention" : ["running", "cancel_requested"].includes(e.status) ? "running" : ["succeeded", "cancelled"].includes(e.status) ? "done" : "waiting";
}
function i(e) {
	if (!(e.reason === "等待人工审批" && ["awaiting_acceptance", "succeeded"].includes(e.status))) return e.reason ?? void 0;
}
function a(e) {
	if (!e) return null;
	try {
		let t = new URL(e);
		return ["https:", "http:"].includes(t.protocol) && !t.username && !t.password ? t.href : null;
	} catch {
		return null;
	}
}
function o(e) {
	let t = new Set(e.map((e) => e.taskId)), n = new Map(e.map((e) => [e.taskId, e])), r = /* @__PURE__ */ new Set(), i = [];
	for (; n.size;) {
		let e = [...n.values()].filter((e) => e.dependencies.every((e) => t.has(e) && r.has(e)));
		if (!e.length) break;
		i.push(e), e.forEach((e) => {
			r.add(e.taskId), n.delete(e.taskId);
		});
	}
	return {
		levels: i,
		invalidIds: [...n.keys()]
	};
}
//#endregion
export { o as a, a as i, n, i as o, t as r, r as s, e as t };
