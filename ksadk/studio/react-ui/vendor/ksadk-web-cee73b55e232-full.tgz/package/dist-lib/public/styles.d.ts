import '../embed.css';
//# sourceMappingURL=styles.d.ts.map