//#region src/core/conversation/errors.ts
var e = class extends Error {
	code;
	status;
	capability;
	runId;
	cursor;
	cause;
	constructor(e, t, n = {}) {
		super(t), this.name = "ConversationClientError", this.code = e, this.status = n.status, this.capability = n.capability, this.runId = n.runId, this.cursor = n.cursor, this.cause = n.cause;
	}
}, t = "conversation.ksadk.io/v1", n = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/, r = new Set([
	"native",
	"translated",
	"degraded",
	"unavailable"
]), i = new Set([
	"user_message",
	"assistant_text",
	"reasoning",
	"agent",
	"tool_call",
	"approval",
	"progress",
	"plan",
	"goal",
	"artifact",
	"a2ui",
	"error",
	"unknown"
]), a = new Set([
	"append",
	"replace",
	"completed"
]), o = new Set([
	"pending",
	"streaming",
	"completed",
	"failed"
]), s = new Set([
	"public",
	"internal",
	"hidden"
]), c = new Set([
	"apiVersion",
	"kind",
	"inputId",
	"sessionId",
	"idempotencyKey",
	"parts",
	"modelRef",
	"reasoning",
	"extensions"
]), l = new Set(["kind", "text"]), u = new Set([
	"kind",
	"attachmentRef",
	"mediaType",
	"name"
]), d = "ksadk.approval", f = "ksadk.collaboration", p = "ksadk.goal";
function m(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function h(e, t) {
	return typeof e == "string" && e.length > 0 && e.length <= t;
}
function g(e, t, n = !1) {
	return e == null || typeof e == "string" && e.length <= t && (n || e.length > 0);
}
function _(e, t) {
	return Object.keys(e).every((e) => t.has(e));
}
function v(e) {
	let t = m(e);
	return !t || typeof t.kind != "string" ? null : t.kind === "text" ? !_(t, l) || !h(t.text, 131072) ? null : {
		kind: "text",
		text: t.text
	} : t.kind === "attachment" ? !_(t, u) || !h(t.attachmentRef, 2048) || !h(t.mediaType, 256) || !g(t.name, 1024, !0) ? null : {
		kind: "attachment",
		attachmentRef: t.attachmentRef,
		mediaType: t.mediaType,
		...t.name === void 0 ? {} : { name: t.name }
	} : null;
}
function y(e) {
	if (e === void 0) return {};
	let t = m(e);
	if (!t || Object.keys(t).some((e) => !n.test(e) || !e.includes("."))) return null;
	let r = t["ksadk.presentation"];
	if (r !== void 0) {
		let e = m(r);
		if (!e || Object.keys(e).some((e) => e !== "profile") || !["agent-block-v1", "flat-v1"].includes(String(e.profile))) return null;
	}
	let i = t[d], a = t[f], o = t[p];
	return i !== void 0 && ![
		"ask",
		"risk",
		"full"
	].includes(String(i)) || a !== void 0 && !["default", "plan"].includes(String(a)) || o !== void 0 && !h(o, 4096) ? null : { ...t };
}
function b(e) {
	let n = m(e);
	if (!n || !_(n, c) || n.apiVersion !== t || n.kind !== "ConversationInput" || !h(n.inputId, 256) || !h(n.sessionId, 256) || !h(n.idempotencyKey, 512) || !Array.isArray(n.parts) || n.parts.length === 0 || !g(n.modelRef, 256) || !g(n.reasoning, 64)) return null;
	let r = n.parts.map(v), i = y(n.extensions);
	return r.some((e) => e === null) || i === null ? null : {
		apiVersion: t,
		kind: "ConversationInput",
		inputId: n.inputId,
		sessionId: n.sessionId,
		idempotencyKey: n.idempotencyKey,
		parts: r,
		...n.modelRef === void 0 ? {} : { modelRef: n.modelRef },
		...n.reasoning === void 0 ? {} : { reasoning: n.reasoning },
		...n.extensions === void 0 ? {} : { extensions: i }
	};
}
function x(n) {
	let r = b({
		...n,
		apiVersion: n.apiVersion || t,
		kind: n.kind || "ConversationInput"
	});
	if (!r) throw new e("conversation_contract_mismatch", "Conversation input does not match conversation.ksadk.io/v1.");
	return r;
}
function S(e) {
	let t = e.parts.map((e) => e.kind === "text" ? "text" : e.mediaType.toLowerCase().startsWith("image/") ? "attachment.image" : "attachment.file");
	e.modelRef && t.push("model.select"), e.reasoning && t.push("reasoning.effort");
	for (let n of Object.keys(e.extensions || {})) n === d ? t.push("approval") : n === f ? e.extensions?.[n] === "plan" && t.push("plan") : n === p ? t.push("goal") : t.push(n);
	return [...new Set(t)];
}
function C(t, n) {
	if (t.sessionId !== n.sessionId) throw new e("conversation_session_mismatch", "Conversation input session does not match the active surface.");
	for (let r of S(n)) if (!O(t, r)) throw new e("conversation_input_unsupported", "Conversation input is not declared by the active surface.", { capability: r });
	return n;
}
function w(e) {
	let t = m(e);
	return !t || !h(t.name, 128) || !n.test(t.name) || !r.has(t.mode) || !g(t.reason, 512, !0) || (t.mode === "degraded" || t.mode === "unavailable") && !h(t.reason, 512) ? null : {
		name: t.name,
		mode: t.mode,
		...t.reason === void 0 ? {} : { reason: t.reason }
	};
}
function T(e) {
	if (e === void 0) return [];
	if (!Array.isArray(e)) return null;
	let t = e.map(w);
	if (t.some((e) => e === null)) return null;
	let n = t;
	return new Set(n.map((e) => e.name)).size === n.length ? n : null;
}
function E(e) {
	let n = m(e);
	if (!n || n.apiVersion !== t || n.kind !== "ConversationSurface" || !h(n.surfaceId, 256) || !h(n.sessionId, 256) || !h(n.providerRef, 256)) return null;
	let r = T(n.inputs), i = T(n.outputs);
	return !r || !i ? null : {
		apiVersion: t,
		kind: "ConversationSurface",
		surfaceId: n.surfaceId,
		sessionId: n.sessionId,
		providerRef: n.providerRef,
		inputs: r,
		outputs: i
	};
}
function D(e) {
	let n = m(e);
	if (!n || n.apiVersion !== t || n.kindVersion !== 1 || !h(n.itemId, 512) || !g(n.parentItemId, 512) || !Array.isArray(n.sourceEventIds) || n.sourceEventIds.length === 0 || n.sourceEventIds.some((e) => typeof e != "string" || e.length === 0) || new Set(n.sourceEventIds).size !== n.sourceEventIds.length || !h(n.sessionId, 256) || !h(n.runId, 256) || !h(n.kind, 128) || !a.has(n.operation) || !o.has(n.lifecycle) || n.visibility !== void 0 && !s.has(n.visibility) || !h(n.payloadSchemaRef, 256) || !g(n.capabilityRef, 256, !0)) return null;
	let r = n.operation, c = n.lifecycle;
	if (r === "completed" && c !== "completed" && c !== "failed") return null;
	let l = n.payload === void 0 ? {} : m(n.payload), u = n.nativeRef === void 0 ? {} : m(n.nativeRef);
	if (!l || !u) return null;
	let d = String(n.kind || "unknown"), f = i.has(d) ? d : "unknown";
	return {
		apiVersion: t,
		kindVersion: 1,
		itemId: n.itemId,
		...n.parentItemId === void 0 ? {} : { parentItemId: n.parentItemId },
		sourceEventIds: [...n.sourceEventIds],
		sessionId: n.sessionId,
		runId: n.runId,
		kind: f,
		operation: r,
		lifecycle: c,
		visibility: f === "unknown" && d !== "unknown" ? "hidden" : n.visibility || "public",
		payloadSchemaRef: n.payloadSchemaRef,
		payload: f === "unknown" && d !== "unknown" ? {
			originalKind: d,
			summary: "This content type is not supported by the current renderer."
		} : { ...l },
		...n.capabilityRef === void 0 ? {} : { capabilityRef: n.capabilityRef },
		nativeRef: { ...u }
	};
}
function O(e, ...t) {
	return e.inputs.some((e) => t.includes(e.name) && (e.mode === "native" || e.mode === "translated"));
}
//#endregion
//#region src/core/conversation/agent.ts
function k(e, t) {
	let n = E(e);
	return n ? A(n, t) : "flat-v1";
}
function A(e, t) {
	let n = (e, t) => t.some((t) => t.name === e && ["native", "translated"].includes(t.mode));
	return n("ksadk.presentation", e.inputs) && n("agent.block", e.outputs) && t?.entries().some((e) => e.schemaRef === "conversation.item.agent/v1" && e.kinds.includes("agent")) ? "agent-block-v1" : "flat-v1";
}
var j = (e) => [
	"completed",
	"failed",
	"cancelled"
].includes(String(e)), M = (e) => typeof e == "string" && e.trim().length > 0;
function N(e, t) {
	if (e.kind !== "agent" || e.payloadSchemaRef !== "conversation.item.agent/v1") return;
	let n = e.payload, r = n.trigger_ref, i = n.cancel, a = n.agent;
	if (n.schema !== "execution.scope/v1" || !M(n.scope_id) || !M(n.parent_scope_id) || !M(n.binding_id) || !M(r?.item_id) || !M(r?.call_id) || r?.scope_id !== n.parent_scope_id || !a || [
		"id",
		"name",
		"version_id",
		"protocol"
	].some((e) => !M(a[e])) || ![
		"submitted",
		"working",
		"input_required",
		"completed",
		"failed",
		"cancelled"
	].includes(String(n.status)) || !Number.isFinite(n.started_at) || (j(n.status) ? !Number.isFinite(n.ended_at) : n.ended_at !== null) || !Array.isArray(n.output_refs)) throw Error("Invalid agent scope descriptor");
	if (!i || ![
		"supported",
		"unsupported",
		"unknown"
	].includes(String(i.capability)) || ![
		"none",
		"cancel_requested",
		"unsupported",
		"unknown",
		"confirmed",
		"local_confirmed"
	].includes(String(i.request_state))) throw Error("Invalid agent cancel state");
	if (i.request_state === "confirmed" && i.capability !== "supported") throw Error("Unsupported remote cancel confirmation");
	if (i.request_state === "local_confirmed" && n.status !== "cancelled") throw Error("Local cancellation must be terminal");
	if (t) {
		for (let e of [
			"scope_id",
			"parent_scope_id",
			"trigger_ref",
			"binding_id",
			"agent"
		]) if (JSON.stringify(t.payload[e]) !== JSON.stringify(n[e])) throw Error("Agent descriptor identity changed");
		let e = String(t.payload.status);
		if (j(e) && JSON.stringify(t.payload) !== JSON.stringify(n)) throw Error("Agent terminal conflict");
		if (["working", "input_required"].includes(e) && n.status === "submitted") throw Error("Agent status regression");
		if (i.request_state === "local_confirmed" && e !== "submitted" && e !== "cancelled") throw Error("Local cancellation after send");
	}
}
//#endregion
//#region src/core/conversation/reducer.ts
function P() {
	return {
		items: [],
		appliedSources: []
	};
}
function F(e) {
	return e.lifecycle === "completed" || e.lifecycle === "failed";
}
function I(e, t) {
	let n = {
		...e,
		...t
	};
	typeof e.text == "string" && typeof t.text == "string" && (n.text = e.text + t.text);
	for (let r of ["data", "operations"]) Array.isArray(e[r]) && Array.isArray(t[r]) && (n[r] = [...e[r], ...t[r]]);
	return n;
}
function L(e, t) {
	let n = t.sourceEventIds.map((e) => JSON.stringify([t.itemId, e])), r = new Set(e.appliedSources);
	if (n.every((e) => r.has(e))) return e;
	n.forEach((e) => r.add(e));
	let i = e.items.findIndex((e) => e.itemId === t.itemId), a = i >= 0 ? e.items[i] : void 0;
	if (N(t, a), a && (a.runId !== t.runId || a.parentItemId !== t.parentItemId)) throw Error("Conversation item locator changed");
	if (a && (a.nativeRef.scopeId || a.nativeRef.scope_id) !== (t.nativeRef.scopeId || t.nativeRef.scope_id)) throw Error("Conversation item scope changed");
	if (a?.payload.callId && t.payload.callId && a.payload.callId !== t.payload.callId) throw Error("Conversation call identity changed");
	if (a && F(a) && !F(t)) return {
		...e,
		appliedSources: [...r]
	};
	let o = [...e.items];
	if (!a) o.push(t);
	else {
		let e = [...new Set([...a.sourceEventIds, ...t.sourceEventIds])];
		a.kind === t.kind ? t.operation === "append" ? o[i] = {
			...t,
			payload: I(a.payload, t.payload),
			sourceEventIds: e
		} : o[i] = {
			...t,
			sourceEventIds: e
		} : o[i] = {
			...t,
			kind: "unknown",
			operation: "replace",
			payloadSchemaRef: "conversation.item.unknown/v1",
			payload: { summary: "The content type changed for the same item and was safely degraded." },
			sourceEventIds: e
		};
	}
	return {
		items: o,
		appliedSources: [...r]
	};
}
var R = class {
	state = P();
	apply(e) {
		let t = L(this.state, e);
		if (t === this.state) return !1;
		let n = t.items !== this.state.items;
		return this.state = t, n;
	}
	applyAll(e) {
		for (let t of e) this.apply(t);
	}
	snapshot() {
		return {
			items: this.state.items.map((e) => ({
				...e,
				sourceEventIds: [...e.sourceEventIds],
				payload: { ...e.payload },
				nativeRef: { ...e.nativeRef }
			})),
			appliedSources: [...this.state.appliedSources]
		};
	}
};
//#endregion
export { k as a, b as c, C as d, O as f, A as i, D as l, P as n, N as o, e as p, L as r, x as s, R as t, E as u };
