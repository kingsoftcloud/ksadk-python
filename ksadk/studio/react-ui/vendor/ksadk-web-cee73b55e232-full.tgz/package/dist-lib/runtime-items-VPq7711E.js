//#region src/core/stream/runtime-items.ts
function e(e, t) {
	return `${e}\u0000${t}`;
}
function t(e) {
	return { ...e };
}
var n = class {
	runId = null;
	status = null;
	items = /* @__PURE__ */ new Map();
	seenEventIds = /* @__PURE__ */ new Set();
	apply(e) {
		if (e.eventId) {
			if (this.seenEventIds.has(e.eventId)) return;
			this.seenEventIds.add(e.eventId);
		}
		switch (e.type) {
			case "run_started":
				this.runId = e.runId, this.status = "running";
				return;
			case "run_interrupted":
				this.status = "interrupted";
				return;
			case "run_completed":
				this.status = "completed";
				return;
			case "run_failed":
				this.status = "failed";
				return;
			case "run_canceled":
				this.status = "canceled";
				return;
			case "item_started":
				this.startItem(e);
				return;
			case "item_updated":
				this.updateItem(e);
				return;
			case "item_snapshot_replaced":
				this.replaceSnapshot(e);
				return;
			case "item_completed":
			case "item_failed":
				this.closeItem(e);
				return;
		}
	}
	applyAll(e) {
		for (let t of e) this.apply(t);
	}
	snapshot() {
		return {
			runId: this.runId,
			status: this.status,
			items: Array.from(this.items.values()).map((e) => ({
				...e,
				parts: e.parts.map(t)
			}))
		};
	}
	ensureItem(t) {
		this.runId === null && (this.runId = t.runId);
		let n = e(t.scopeId, t.itemId), r = this.items.get(n);
		return r || (r = {
			runId: t.runId,
			scopeId: t.scopeId,
			itemId: t.itemId,
			itemKind: t.itemKind || "message",
			status: "open",
			parts: []
		}, this.items.set(n, r)), r;
	}
	startItem(n) {
		let r = e(n.scopeId, n.itemId), i = this.items.get(r);
		if (i) {
			n.phase !== void 0 && (i.phase = n.phase);
			return;
		}
		let a = this.ensureItem(n);
		a.phase = n.phase, n.initialParts && (a.parts = n.initialParts.map(t));
	}
	updateItem(e) {
		let n = this.ensureItem(e), r = n.parts.findIndex((t) => t.partId === e.partId);
		if (r < 0) {
			n.parts.push(t(e.part));
			return;
		}
		let i = n.parts[r];
		if (e.op === "replace") {
			n.parts[r] = t(e.part);
			return;
		}
		n.parts[r] = {
			...i,
			text: `${i.text || ""}${e.part.text || ""}`
		};
	}
	replaceSnapshot(e) {
		let n = this.ensureItem(e);
		n.parts = e.parts.map(t);
	}
	closeItem(e) {
		let n = this.ensureItem(e);
		e.parts && (n.parts = e.parts.map(t)), n.status = e.type === "item_completed" ? "completed" : "failed";
	}
};
function r(e, t) {
	return {
		partId: e,
		contentType: "text",
		text: t
	};
}
var i = "text-0";
function a(e, t) {
	return String(e?.id || e?.item_id || t?.item_id || t?.output_index || "");
}
function o(e) {
	let t = e?.content;
	return Array.isArray(t) ? t.map((e) => typeof e == "string" ? e : String(e?.text || "")).join("") : String(e?.output_text || e?.text || "");
}
function s(e, t, n, s) {
	let c = String(t?.type || e || "").trim(), l = t?.id ? String(t.id) : void 0, u = t?.item || t?.output_item || {}, d = a(u, t), f = String(u?.type || ""), p = f.includes("reasoning") ? "reasoning" : "message";
	if (c === "response.output_item.added") return !d || f !== "message" && !f.includes("reasoning") ? [] : [{
		type: "item_started",
		runId: n,
		scopeId: s,
		itemId: d,
		itemKind: p,
		phase: "final_answer",
		eventId: l
	}];
	if (c === "response.output_text.delta" || c === "response.content_part.delta") {
		if (!d) return [];
		let e = String(t?.delta || t?.text || "");
		return e ? [{
			type: "item_updated",
			runId: n,
			scopeId: s,
			itemId: d,
			itemKind: p,
			partId: i,
			op: t?.replace === !0 ? "replace" : "append",
			part: r(i, e),
			eventId: l
		}] : [];
	}
	return c === "response.output_item.done" || c === "response.output_text.done" ? d ? [{
		type: "item_completed",
		runId: n,
		scopeId: s,
		itemId: d,
		itemKind: p,
		parts: [r(i, o(u) || String(t?.text || ""))],
		eventId: l
	}] : [] : c === "response.completed" ? [{
		type: "run_completed",
		runId: n,
		scopeId: s,
		eventId: l
	}] : [];
}
//#endregion
export { s as n, n as t };
