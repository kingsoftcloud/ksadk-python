import { t as e } from "./capabilities-CXle1R-K.js";
import { a as t, c as n, d as r, g as i, h as a, l as o, m as s } from "./a2ui-B1x5yNaJ.js";
import { t as c } from "./utils-CX-Pz5p6.js";
import { t as l } from "./ConnectedComposer-BkZNPn4n.js";
import { n as u } from "./permission-BWNFYYw-.js";
import { u as d } from "./feedback-CuC5jRi_.js";
import { r as f, t as p } from "./ConnectedMessageList-DSvFUAhq.js";
import { a as m, c as h, d as g, f as _, i as v, l as ee, n as y, o as te, r as ne, s as re, t as ie, u as b } from "./WorkspacePanelContainer-DLUNPZLb.js";
import { f as x, l as S, n as ae, r as oe, t as C, u as se } from "./reducer-mbYiX0wz.js";
import { E as w } from "./persisted-session-history-ChW9k7v9.js";
import { A as T, C as ce, D as E, E as D, M as le, N as O, O as k, S as ue, T as A, _ as de, a as fe, b as j, c as pe, d as me, f as he, g as ge, h as _e, i as M, j as N, k as ve, l as P, m as F, n as ye, o as be, p as xe, r as Se, s as Ce, t as we, u as I, v as Te, w as L, x as Ee, y as De } from "./useSessionLifecycle-hKAAD9mt.js";
import { t as Oe } from "./artifact-BfFsPe5A.js";
import ke, { Suspense as Ae, useCallback as je, useEffect as R, useMemo as Me, useRef as z, useState as Ne } from "react";
import { Fragment as Pe, jsx as B, jsxs as V } from "react/jsx-runtime";
//#region src/core/conversation/scoped-cancel.ts
var H = (e, t) => JSON.stringify([
	e,
	t.sessionId,
	t.runId,
	t.scopeId,
	t.parentItemId
]);
async function U(e, t) {
	let n = new TextEncoder().encode(H(e, t)), r = await crypto.subtle.digest("SHA-256", n);
	return "scope-cancel-" + [...new Uint8Array(r)].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function Fe(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = (t) => {
		let n = e.getContext();
		if (!n.supported) return "unsupported";
		if (!t.sessionId || t.sessionId !== n.sessionId || !t.runId || !t.scopeId || !t.parentItemId) return "unknown";
		let r = n.items.find((e) => e.kind === "agent" && e.sessionId === t.sessionId && e.runId === t.runId && e.payload.scope_id === t.scopeId && e.parentItemId === t.parentItemId);
		return r ? r.payload.cancel?.capability === "supported" ? [
			"submitted",
			"working",
			"input_required"
		].includes(String(r.payload.status)) ? null : "unknown" : "unsupported" : "unknown";
	};
	return {
		getCancelRequestState: (t) => n.get(H(e.agentId, t)) || "none",
		cancel: (i) => {
			let a = H(e.agentId, i), o = r(i);
			if (o) return Promise.resolve(o);
			let s = t.get(a);
			if (s) return s;
			if (n.get(a) === "processing" || n.get(a) === "unsupported") return Promise.resolve(n.get(a));
			n.set(a, "processing");
			let c = (async () => {
				try {
					let t = await U(e.agentId, i), n = r(i);
					if (n) return n;
					let a = await e.api.cancelRun(e.agentId, i.sessionId, i.runId, {
						scopeId: i.scopeId,
						clientToken: t
					});
					return a?.ScopeId === i.scopeId ? a.CancelRequestState === "unsupported" ? "unsupported" : a.CancelRequestState === "cancel_requested" ? "processing" : "unknown" : "unknown";
				} catch {
					return "unknown";
				}
			})().then((e) => (n.set(a, e), t.delete(a), e));
			return t.set(a, c), c;
		}
	};
}
//#endregion
//#region src/utils/native-platform.js
var W = new Map([["openclaw", "OpenClaw"], ["hermes", "Hermes"]]);
function G(e) {
	return String(e || "").trim().toLowerCase();
}
function K(e) {
	return String(e || "").trim().toLowerCase();
}
function q(e) {
	try {
		return new URL("/", e).toString();
	} catch {
		return "/";
	}
}
function Ie({ capability: e, agentFramework: t, accessMode: n, origin: r }) {
	let i = G(n);
	if (i !== "owner" && i !== "private" || !e?.Enabled) return null;
	let a = W.get(K(t)) || "运行时";
	return {
		href: typeof e.Href == "string" && e.Href ? new URL(e.Href, q(r)).toString() : q(r),
		label: typeof e.Label == "string" && e.Label ? e.Label : "管理平台",
		title: `打开 ${a} 原生管理平台`
	};
}
//#endregion
//#region src/components/chat/ConnectedSidebar.tsx
function Le({ uiCapabilities: t, createNewSession: n, deleteSession: a, loadSession: o, loadMoreSessions: s }) {
	let l = r((e) => e.sessions), u = r((e) => e.currentSessionId), d = r((e) => e.pinnedSessionIds), p = r((e) => e.isLoadingSessions), g = r((e) => e.hasMoreSessions), _ = i((e) => e.sidebarOpen), v = i((e) => e.mobileSidebarOpen), { isMobile: y } = he(), te = e(t), { desktopSidebarVisible: ne } = F({
		isMobile: y,
		desktopSidebarOpen: _,
		mobileSidebarOpen: v
	});
	return te ? y ? /* @__PURE__ */ B(re, {
		open: v,
		onOpenChange: (e) => i.getState().setMobileSidebarOpen(e),
		children: /* @__PURE__ */ V(h, {
			side: "left",
			className: "w-[88vw] max-w-sm border-slate-200 bg-slate-50 p-0 dark:border-slate-800 dark:bg-slate-950",
			children: [
				/* @__PURE__ */ B(b, {
					className: "sr-only",
					children: "历史记录"
				}),
				/* @__PURE__ */ B(ee, {
					className: "sr-only",
					children: "查看和切换历史对话。"
				}),
				/* @__PURE__ */ B(m, {
					sessions: l,
					currentSessionId: u,
					onCreateNewSession: n,
					onSelectSession: o,
					onDeleteSession: (e, t) => {
						t.stopPropagation(), a(e);
					},
					onTogglePinSession: (e, t) => {
						t.stopPropagation(), r.getState().togglePinnedSession(e);
					},
					onLoadMoreSessions: s,
					sessionTitle: f,
					pinnedSessionIds: d,
					hasMoreSessions: g,
					isLoadingSessions: p
				})
			]
		})
	}) : /* @__PURE__ */ B("aside", {
		className: c("flex-shrink-0 overflow-hidden border-r border-slate-200 transition-[width] duration-300 ease-in-out dark:border-slate-800", ne ? "w-[280px]" : "w-0 border-r-0"),
		children: /* @__PURE__ */ B(m, {
			sessions: l,
			currentSessionId: u,
			onCreateNewSession: n,
			onSelectSession: o,
			onDeleteSession: (e, t) => {
				t.stopPropagation(), a(e);
			},
			onTogglePinSession: (e, t) => {
				t.stopPropagation(), r.getState().togglePinnedSession(e);
			},
			onLoadMoreSessions: s,
			sessionTitle: f,
			pinnedSessionIds: d,
			hasMoreSessions: g,
			isLoadingSessions: p
		})
	}) : null;
}
//#endregion
//#region src/App.tsx
var Re = new A(), ze = ke.lazy(() => import("./ArtifactsPanel-DByDntRi.js").then((e) => ({ default: e.ArtifactsPanel }))), Be = ke.lazy(() => import("./NativeTerminalPanel-beSt6mii.js").then((e) => e.n).then((e) => ({ default: e.NativeTerminalPanel })));
function J(e = {}) {
	let t = e.apiAdapter || Re, [n, r] = Ne(null);
	if (R(() => {
		let e = new AbortController();
		return t.getAgentUiBootstrap(void 0, { signal: e.signal }).then((n) => {
			e.signal.aborted || r({
				api: t,
				data: n
			});
		}).catch(() => {
			e.signal.aborted || r({
				api: t,
				data: void 0
			});
		}), () => e.abort();
	}, [t]), !n || n.api !== t) return /* @__PURE__ */ B(_, {});
	let i = n.data?.AuthorizationScopeKey;
	return /* @__PURE__ */ B(g, {
		authorizationScopeKey: e.authorizationScopeKey ?? (typeof i == "string" && i ? i : void 0),
		children: /* @__PURE__ */ B(Y, {
			...e,
			bootstrapData: n.data
		})
	});
}
function Y({ apiAdapter: t, initialSurface: n = "chat", routeShell: o, bootstrapData: c }) {
	let f = t || Re, m = L((e) => e.agentId), h = r((e) => e.currentSessionId), g = a((e) => e.isStreaming), _ = i((e) => e.sidebarOpen), ee = i((e) => e.mobileSidebarOpen), re = i((e) => e.mobileActionsOpen), b = L((e) => e.agentName), x = s((e) => e.selectedModel), S = s((e) => e.availableModels), ae = s((e) => e.modelSource), oe = s((e) => e.modelCatalogLoaded), C = s((e) => e.thinkingMode), se = u((e) => e.permissionMode), w = L((e) => e.agentFramework), T = L((e) => e.workspaceFiles), E = L((e) => e.accessMode), D = L((e) => e.status), le = L((e) => e.errorMessage), O = i((e) => e.workspacePanelOpen), k = i((e) => e.workspacePanelWidth), A = i((e) => e.workspacePanelFullscreen), de = L((e) => e.apiFormats), j = L((e) => e.capabilities), me = Oe((e) => e.visible && !!e.content), ge = z([]), M = z(null), { isMobile: N, viewportHeight: ve } = he(), P = xe({
		isMobile: N,
		viewportHeight: ve
	}), { fetchSessions: F, loadMoreSessions: ye, loadSession: be, followAcceptedInteraction: Se, loadOlderSessionMessages: I, createNewSession: Te, adoptCreatedSession: De, waitForPendingSessionCreation: ke, deleteSession: H, currentSessionIdRef: U, agentIdRef: W, runSubscriptionAbortRef: G } = we({
		agentId: m,
		currentSessionId: h,
		isMobile: N,
		uiCapabilities: j,
		api: f,
		resetCompaction: () => {},
		disconnectRun: () => M.current?.()
	}), K = je((e) => {
		if (!e) return;
		let t = () => {
			r.getState().clearSessionMessageHistory(e), F(W.current, e);
		};
		queueMicrotask(t), window.setTimeout(t, 1800), window.setTimeout(t, 5e3);
	}, [W, F]), q = S.find((e) => e.id === x) || null, { submitDraft: J, stopGeneration: Y, disconnectRun: X, resumeCheckpoint: Ve, submitAguiAction: He, respondToAguiApproval: Z } = fe({
		agentId: m,
		currentSessionId: h,
		agentFramework: w,
		apiFormats: de,
		selectedModel: x,
		selectedModelMetadata: q,
		thinkingMode: C,
		permissionMode: se,
		uiCapabilities: j,
		isMobile: N,
		api: f,
		currentSessionIdRef: U,
		agentIdRef: W,
		queuedDraftRef: ge,
		onRunSettled: K,
		onSessionCreated: (e) => De(e, !0),
		waitForPendingSessionCreation: ke
	});
	R(() => {
		M.current = X;
	}, [X]);
	let Ue = je(() => {
		let e = U.current;
		G.current?.abort(), a.getState().stopActivity(), a.getState().stopSessionActivity(e), Y();
	}, [
		U,
		G,
		Y
	]), We = Me(() => Fe({
		api: f,
		agentId: m,
		getContext: () => ({
			sessionId: r.getState().currentSessionId || "",
			supported: L.getState().capabilities.scoped_cancel?.supported === !0,
			items: d.getState().messages.flatMap((e) => e.agentBlock ? [e.agentBlock.item] : [])
		})
	}), [f, m]), Ge = je(async () => {
		let e = U.current, t = a.getState(), n = t.getSessionActivity(e)?.runId || t.currentRunId || "";
		if (e && n) try {
			await f.cancelRun(m, e, n), a.getState().stopSessionActivity(e, "取消请求已发送，后台运行会停在最近 checkpoint。");
		} catch (t) {
			console.warn("[App] cancelRun failed:", t), a.getState().updateActivity({
				sessionId: e,
				status: "failed",
				phase: "取消请求失败",
				detail: t instanceof Error ? t.message : String(t),
				countEvent: !1
			});
		}
		K(e);
	}, [
		f,
		m,
		U,
		K
	]), { submitResponseFeedback: Ke, deleteResponseFeedback: qe, respondToApproval: Q } = Ee({
		agentId: m,
		currentSessionId: h,
		isStreaming: g,
		api: f,
		submitDraft: J
	}), Je = z(Q), Ye = z(Z);
	R(() => {
		Je.current = Q, Ye.current = Z;
	}, [Q, Z]);
	let { pending: Xe, records: Ze, respond: Qe, localCatalog: $e } = _e({
		agentId: m,
		getAgentId: () => W.current,
		currentSessionId: h,
		api: f,
		interactionV1Enabled: !!j.InteractionV1,
		onAcceptedInteraction: Se,
		legacyResponsesApproval: (e, t) => Je.current({
			approvalRequestId: e,
			approve: t
		}),
		legacyAguiResume: (e, t, n) => Ye.current({
			interruptId: e,
			approve: t === "resolved"
		})
	});
	ue({ fetchSessions: F }, void 0, f, c), R(() => {
		W.current = m, ce(m, h);
	}, [
		m,
		h,
		W
	]), R(() => {
		N ? i.getState().setWorkspacePanelFullscreen(!1) : (i.getState().setMobileSidebarOpen(!1), i.getState().setMobileActionsOpen(!1));
	}, [N]), R(() => {
		O || i.getState().setWorkspacePanelFullscreen(!1);
	}, [O]), R(() => () => {
		G.current?.abort();
	}, [G]);
	let et = e(j), tt = !!j.Thinking, $ = y({
		workspaceFiles: T,
		accessMode: E
	}), nt = ne({ isMobile: N }), rt = Ie({
		capability: j.NativeDashboard,
		agentFramework: w,
		accessMode: E,
		origin: window.location.origin
	}), it = !et, at = w === "openclaw" ? "OpenClaw" : w === "hermes" ? "Hermes" : "原生运行时", ot = q?.display_name || x || "", st = !N && _ && et, ct = z(!1), [lt, ut] = Ne(n === "tui"), dt = lt && !!j.NativeTerminal?.Enabled;
	R(() => {
		ct.current || n !== "workspace" || !$ || (ct.current = !0, i.getState().setWorkspacePanelOpen(!0), i.getState().setWorkspacePanelFullscreen(!0));
	}, [n, $]);
	let ft = () => {
		i.getState().setWorkspacePanelFullscreen(!1), i.getState().setWorkspacePanelOpen(!1);
	};
	if (D !== "ready") {
		let e = D === "auth-required", t = /* @__PURE__ */ B("div", {
			className: "ksadk-web",
			children: /* @__PURE__ */ B("div", {
				className: "fixed inset-0 flex h-[var(--app-height)] min-h-[var(--app-height)] items-center justify-center bg-slate-50 px-6 font-sans text-slate-800 dark:bg-slate-950 dark:text-slate-100",
				children: /* @__PURE__ */ V("div", {
					className: "w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900",
					children: [
						/* @__PURE__ */ B("div", {
							className: "mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-50 text-xl text-blue-600 dark:bg-blue-950/50",
							children: D === "loading" ? "…" : "↗"
						}),
						/* @__PURE__ */ B("h1", {
							className: "text-xl font-semibold",
							children: D === "loading" ? "正在连接 Agent" : e ? "需要有效的访问链接" : "Agent 暂时无法连接"
						}),
						D === "loading" ? null : /* @__PURE__ */ V(Pe, { children: [/* @__PURE__ */ V("p", {
							className: "mt-3 text-sm leading-6 text-slate-500 dark:text-slate-400",
							children: [le, e ? " 请从 AgentEngine 控制台重新打开 Dashboard，或使用 agentengine dashboard open 获取临时链接。" : ""]
						}), /* @__PURE__ */ B("button", {
							type: "button",
							className: "mt-6 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-500",
							onClick: () => window.location.reload(),
							children: "重新加载"
						})] })
					]
				})
			})
		});
		return o ? /* @__PURE__ */ B(o, { children: t }) : t;
	}
	let pt = /* @__PURE__ */ B("div", {
		className: "ksadk-web",
		children: /* @__PURE__ */ V("div", {
			className: "fixed inset-0 flex h-[var(--app-height)] min-h-[var(--app-height)] overflow-hidden bg-white font-sans text-slate-800 dark:bg-slate-900 dark:text-slate-200",
			children: [
				/* @__PURE__ */ B(Le, {
					uiCapabilities: j,
					createNewSession: Te,
					deleteSession: H,
					loadSession: be,
					loadMoreSessions: ye
				}),
				/* @__PURE__ */ V("main", {
					className: "relative flex min-w-0 flex-1 flex-col bg-white dark:bg-slate-900",
					children: [/* @__PURE__ */ B(te, {
						agentName: b,
						currentSessionId: h,
						nativeLauncherMode: it,
						isMobile: N,
						sidebarOpen: _,
						mobileSidebarOpen: ee,
						onToggleSidebar: () => {
							N ? i.getState().toggleMobileSidebar() : i.getState().toggleSidebar();
						},
						availableModels: S,
						selectedModel: x,
						onSelectModel: (e) => {
							s.getState().setSelectedModel(e), N && i.getState().setMobileActionsOpen(!1);
						},
						selectedModelLabel: ot,
						modelCatalogLoaded: oe,
						modelSource: ae,
						thinkingEnabled: tt,
						thinkingMode: C,
						onSelectThinkingMode: (e) => s.getState().setThinkingMode(pe(e)),
						mobileActionsOpen: re,
						onMobileActionsOpenChange: (e) => i.getState().setMobileActionsOpen(e),
						workspaceEnabled: $,
						onOpenWorkspace: () => i.getState().setWorkspacePanelOpen(!0),
						nativeManagementLink: rt,
						nativeTerminal: j.NativeTerminal
					}), it ? /* @__PURE__ */ B(v, {
						productLabel: at,
						nativeManagementLink: rt,
						nativeTerminal: j.NativeTerminal,
						workspaceEnabled: $,
						onOpenWorkspace: () => i.getState().setWorkspacePanelOpen(!0)
					}) : /* @__PURE__ */ V(Pe, { children: [/* @__PURE__ */ B(p, {
						agentName: b,
						isMobile: N,
						onDeleteFeedback: qe,
						onSubmitFeedback: Ke,
						onRespondToApproval: Q,
						onRespondToAguiApproval: Z,
						onSubmitAguiAction: He,
						onStopGeneration: Ue,
						onCancelRemote: j.StopRun ? Ge : void 0,
						agentBlockActions: j.scoped_cancel?.supported === !0 ? We : void 0,
						checkpointResumeEnabled: j.RunLifecycle.Enabled && j.RunLifecycle.Checkpoints && j.RunLifecycle.CheckpointResume,
						onResumeCheckpoint: Ve,
						onLoadOlderSessionMessages: I,
						interactionRecords: Ze
					}), /* @__PURE__ */ B(l, {
						onCompactContext: j.ContextCompaction && f.compactSession ? async () => {
							if (!(!h || !f.compactSession)) {
								if ((await f.compactSession(m, h)).Status !== "completed") throw Error("运行时尚未确认压缩完成");
								await F(m, h);
							}
						} : void 0,
						composerMaxHeight: P,
						submitDraft: J,
						stopGeneration: Ue,
						cancelRemote: j.StopRun ? Ge : void 0,
						isMobile: N,
						attachmentsEnabled: j.Attachments !== !1,
						approvalEnabled: !!j.Approval && j.ApprovalPolicy?.RuntimeOverride !== !1,
						approvalPolicy: j.ApprovalPolicy,
						thinkingEnabled: tt,
						runtimeCapabilityMatrix: j.RuntimeCapabilityMatrix,
						pendingInteractions: Xe,
						onRespondInteraction: (e) => {
							Qe(e);
						},
						localCatalog: $e
					})] })]
				}),
				/* @__PURE__ */ B(ie, {
					agentId: m,
					capability: T,
					workspacePanelOpen: O,
					workspacePanelWidth: k,
					workspacePanelFullscreen: A,
					isMobile: N,
					workspaceEnabled: $,
					workspaceFiles: T,
					workspacePanelPresentation: nt,
					closeWorkspacePanel: ft,
					handleWorkspacePanelResizeStart: (e) => {
						if (A || N) return;
						e.preventDefault();
						let t = e.clientX, n = k, r = et && st ? 280 : 0, a = document.body.style.cursor, o = document.body.style.userSelect;
						document.body.style.cursor = "col-resize", document.body.style.userSelect = "none";
						let s = (e) => {
							let a = n + t - e.clientX;
							i.getState().setWorkspacePanelWidth(Ce(a, window.innerWidth, r));
						}, c = () => {
							document.body.style.cursor = a, document.body.style.userSelect = o, window.removeEventListener("pointermove", s), window.removeEventListener("pointerup", c), window.removeEventListener("pointercancel", c);
						};
						window.addEventListener("pointermove", s), window.addEventListener("pointerup", c), window.addEventListener("pointercancel", c);
					},
					api: f
				}),
				me && /* @__PURE__ */ B(Ae, {
					fallback: null,
					children: /* @__PURE__ */ B(ze, {})
				}),
				dt ? /* @__PURE__ */ B(Ae, {
					fallback: null,
					children: /* @__PURE__ */ B(Be, {
						capability: j.NativeTerminal,
						open: !0,
						sessionId: h,
						onClose: () => ut(!1)
					})
				}) : null
			]
		})
	});
	return o ? /* @__PURE__ */ B(o, { children: pt }) : pt;
}
//#endregion
//#region src/core/transport/sse-transport.ts
function X(e, t) {
	if (e.eventName === "__ping__") {
		a.getState().updateActivity({ countEvent: !1 });
		return;
	}
	t.onEvent(e);
}
var Ve = class {
	protocol = "sse-post";
	async connect(e, t) {
		let n = (await le(e.action, e.body || {}, { signal: e.signal })).getReader(), r = new TextDecoder(), i = "", a = !1;
		return (async () => {
			try {
				for (; !a;) {
					let { value: e, done: a } = await n.read();
					if (a) break;
					i += r.decode(e, { stream: !0 });
					let { chunks: o, remainder: s } = I(i);
					i = s;
					for (let e of o) {
						if (!e.trim()) continue;
						let n = P(e);
						for (let e of n) {
							if (e.eventName === "__done__") {
								t.onComplete();
								return;
							}
							X(e, t);
						}
					}
				}
				t.onComplete();
			} catch (e) {
				a || t.onError(e instanceof Error ? e : Error(String(e)));
			}
		})(), () => {
			a = !0, n.cancel().catch(() => {});
		};
	}
}, He = class {
	protocol = "sse-get";
	async connect(e, t) {
		let n = (await O(e.action, e.params || {}, { signal: e.signal })).getReader(), r = new TextDecoder(), i = "", a = !1;
		return (async () => {
			try {
				for (; !a;) {
					let { value: e, done: a } = await n.read();
					if (a) break;
					i += r.decode(e, { stream: !0 });
					let { chunks: o, remainder: s } = I(i);
					i = s;
					for (let e of o) {
						if (!e.trim()) continue;
						let n = P(e);
						for (let e of n) {
							if (e.eventName === "__done__") {
								t.onComplete();
								return;
							}
							X(e, t);
						}
					}
				}
				t.onComplete();
			} catch (e) {
				a || t.onError(e instanceof Error ? e : Error(String(e)));
			}
		})(), () => {
			a = !0, n.cancel().catch(() => {});
		};
	}
};
//#endregion
export { n as A2UI_WIRE_VERSION, g as AgentAuthorizationBoundary, N as AgentEngineClient, J as AgentWorkbench, A as ApiFacadeImpl, D as ContractMismatchError, C as ConversationItemReducer, De as InteractionClientImpl, j as InteractionStore, be as RunEngineImpl, ye as SessionEventConflictError, Se as SessionEventCursor, He as SseGetTransport, Ve as SsePostTransport, ae as createConversationItemState, me as createProtocol, M as createSessionEventCursor, E as decodeAgentStatusSnapshot, k as decodeCapabilityMatrix, S as decodeConversationItem, se as decodeConversationSurface, ve as decodeReceipt, T as decodeSessionEventEnvelope, ge as interactionFromAguiInterrupt, de as interactionFromResponsesApproval, Te as interactionFromSessionEvent, t as interactionIdempotencyKey, w as projectConversationItems, oe as reduceConversationItem, x as surfacePermitsInput, o as validateA2uiPresentation };
