import { useEffect as e, useRef as t } from "react";
//#region src/utils/sandbox.ts
function n(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function r(e) {
	let t = e.endsWith("/") ? e : `${e}/`;
	if (typeof window > "u") return "'self'";
	try {
		return new URL(t, window.location.origin).toString();
	} catch {
		return "'self'";
	}
}
function i(...e) {
	return Array.from(new Set(e.filter((e) => !!e))).join(" ");
}
function a(e) {
	let t = e ? r(e) : void 0, n = i("'unsafe-inline'", "'unsafe-eval'", "'self'", "https:", t), a = i("'self'", "https:", t);
	return [
		"default-src 'none'",
		`script-src ${n}`,
		`style-src 'unsafe-inline' data: ${a}`,
		`img-src data: blob: ${a}`,
		`font-src data: ${a}`,
		`media-src data: blob: ${a}`,
		"worker-src blob:",
		"connect-src 'none'",
		"form-action 'none'",
		"base-uri 'self'"
	].join("; ");
}
function o(e) {
	try {
		let t = new URL(e, window.location.href);
		return [
			"http:",
			"https:",
			"mailto:"
		].includes(t.protocol);
	} catch {
		return !1;
	}
}
function s(e, t = {}) {
	let { channelId: r, basePath: i } = typeof t == "string" ? { channelId: t } : t, o = a(i), s = `<script>
function ksadkScrollToHash(rawHref) {
  if (!rawHref || rawHref === '#') return;
  var rawId = rawHref.slice(1);
  var id = rawId;
  try {
    id = decodeURIComponent(rawId);
  } catch (_) {}
  var target = document.getElementById(id) || document.getElementsByName(id)[0];
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
document.addEventListener('click', function(event) {
  var target = event.target && event.target.closest ? event.target.closest('a') : null;
  if (!target) return;
  var rawHref = target.getAttribute('href') || '';
  if (rawHref.charAt(0) === '#') {
    event.preventDefault();
    ksadkScrollToHash(rawHref);
    return;
  }
  if (target.href) {
    event.preventDefault();
    window.parent.postMessage({
      type: 'ksadk:linkClick',
      channelId: ${JSON.stringify(r || "")},
      href: target.href,
      target: target.target || '_self'
    }, '*');
  }
}, true);
<\/script>`, c = `${`<meta http-equiv="Content-Security-Policy" content="${n(o)}">`}${i ? `<base href="${n(i)}">` : ""}${s}`;
	return /<head[^>]*>/i.test(e) ? e.replace(/<head[^>]*>/i, `$&${c}`) : `${c}${e}`;
}
function c(n, r) {
	let i = t(null);
	e(() => (i.current = (e) => {
		if (e.source !== n.current?.contentWindow || e.data?.type !== "ksadk:linkClick" || r && e.data?.channelId !== r) return;
		let t = e.data?.href;
		typeof t == "string" && t && o(t) && window.open(t, "_blank", "noopener,noreferrer");
	}, window.addEventListener("message", i.current), () => {
		i.current && window.removeEventListener("message", i.current);
	}), [n, r]);
}
//#endregion
export { c as n, s as t };
