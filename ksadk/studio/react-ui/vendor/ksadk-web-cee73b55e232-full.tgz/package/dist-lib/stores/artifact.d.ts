export type ArtifactState = {
    content: string | null;
    type: string;
    visible: boolean;
};
export type ArtifactActions = {
    show: (content: string, type?: string) => void;
    hide: () => void;
    setContent: (content: string | null, type?: string) => void;
};
export type ArtifactStore = ArtifactState & ArtifactActions;
export declare const useArtifactStore: import("zustand").UseBoundStore<import("zustand").StoreApi<ArtifactStore>>;
//# sourceMappingURL=artifact.d.ts.map