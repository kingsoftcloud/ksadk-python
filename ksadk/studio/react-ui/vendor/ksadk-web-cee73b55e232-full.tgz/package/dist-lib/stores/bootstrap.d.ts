import type { RuntimeApiFormat } from '../types/api.js';
import type { UiCapabilities } from '../types/capabilities.js';
export type BootstrapStatus = 'loading' | 'ready' | 'auth-required' | 'error';
export type BootstrapState = {
    agentId: string;
    agentName: string;
    agentFramework: string;
    capabilities: UiCapabilities;
    apiFormats: RuntimeApiFormat[];
    accessMode: string;
    workspaceFiles: Record<string, unknown> | null;
    status: BootstrapStatus;
    errorMessage: string;
};
export type BootstrapActions = {
    setAgentId: (id: string) => void;
    setAgentName: (name: string) => void;
    setAgentFramework: (framework: string) => void;
    setCapabilities: (caps: UiCapabilities) => void;
    setApiFormats: (formats: RuntimeApiFormat[]) => void;
    setAccessMode: (mode: string) => void;
    setWorkspaceFiles: (files: Record<string, unknown> | null) => void;
    setStatus: (status: BootstrapStatus, errorMessage?: string) => void;
};
export type BootstrapStore = BootstrapState & BootstrapActions;
export declare const useBootstrapStore: import("zustand").UseBoundStore<import("zustand").StoreApi<BootstrapStore>>;
//# sourceMappingURL=bootstrap.d.ts.map