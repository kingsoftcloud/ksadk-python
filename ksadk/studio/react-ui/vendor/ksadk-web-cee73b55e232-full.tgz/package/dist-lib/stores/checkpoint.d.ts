export type SessionCheckpoint = {
    checkpointId: string;
    runId: string;
    sessionId?: string;
    invocationId?: string;
    seqId?: number;
    timestamp?: string | number;
    framework?: string;
    frameworkRef?: Record<string, unknown>;
    phase?: string;
    stage?: string;
    summary?: string;
    nextAction?: string;
    status?: string;
    metadata?: Record<string, unknown>;
};
export type ToolReceipt = {
    receiptId: string;
    idempotencyKey: string;
    toolName: string;
    toolCallId?: string;
    runId?: string;
    checkpointId?: string;
    sessionId?: string;
    invocationId?: string;
    seqId?: number;
    timestamp?: string | number;
    status?: string;
    replayed?: boolean;
    metadata?: Record<string, unknown>;
};
type CheckpointState = {
    checkpointsBySessionId: Record<string, SessionCheckpoint[]>;
    toolReceiptsBySessionId: Record<string, ToolReceipt[]>;
};
type CheckpointActions = {
    setSessionCheckpoints: (sessionId: string, checkpoints: unknown[]) => void;
    upsertSessionCheckpoint: (sessionId: string, checkpoint: unknown) => void;
    getSessionCheckpoints: (sessionId: string | null | undefined) => SessionCheckpoint[];
    setSessionToolReceipts: (sessionId: string, receipts: unknown[]) => void;
    getSessionToolReceipts: (sessionId: string | null | undefined) => ToolReceipt[];
    clearSessionCheckpoints: (sessionId?: string | null) => void;
};
export declare function normalizeSessionCheckpoint(value: unknown): SessionCheckpoint | null;
export declare function normalizeToolReceipt(value: unknown): ToolReceipt | null;
export declare const useCheckpointStore: import("zustand").UseBoundStore<import("zustand").StoreApi<CheckpointState & CheckpointActions>>;
export {};
//# sourceMappingURL=checkpoint.d.ts.map