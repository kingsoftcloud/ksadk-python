import type { Message } from '../components/chat/types.js';
type MessageState = {
    messages: Message[];
};
type MessageActions = {
    setMessages: (messages: Message[]) => void;
    patchMessages: (updater: (prev: Message[]) => Message[]) => void;
};
export declare const useMessageStore: import("zustand").UseBoundStore<import("zustand").StoreApi<MessageState & MessageActions>>;
export {};
//# sourceMappingURL=message.d.ts.map