import type { ModelCatalogItem } from '../components/chat/types';
export type ThinkingMode = 'auto' | 'enabled' | 'disabled';
export type ModelState = {
    availableModels: ModelCatalogItem[];
    selectedModel: string;
    modelSource: string;
    modelCatalogLoaded: boolean;
    thinkingMode: ThinkingMode;
};
export type ModelActions = {
    upsertModels: (incoming: ModelCatalogItem[]) => void;
    setSelectedModel: (id: string) => void;
    setModelSource: (source: string) => void;
    setModelCatalogLoaded: (loaded: boolean) => void;
    setThinkingMode: (mode: ThinkingMode) => void;
    resetCatalog: () => void;
};
export type ModelStore = ModelState & ModelActions;
export declare const useModelStore: import("zustand").UseBoundStore<import("zustand").StoreApi<ModelStore>>;
//# sourceMappingURL=model.d.ts.map