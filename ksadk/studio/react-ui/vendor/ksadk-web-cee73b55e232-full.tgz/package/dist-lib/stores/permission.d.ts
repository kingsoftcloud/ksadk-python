import type { PermissionMode } from '../core/run/types.js';
export declare function readPermissionMode(): PermissionMode;
export type PermissionStore = {
    permissionMode: PermissionMode;
    setPermissionMode: (mode: PermissionMode) => void;
};
/**
 * A conversation-level default. The backend remains authoritative and may
 * impose a stricter tool policy for a deployment or tenant.
 */
export declare const usePermissionStore: import("zustand").UseBoundStore<import("zustand").StoreApi<PermissionStore>>;
//# sourceMappingURL=permission.d.ts.map