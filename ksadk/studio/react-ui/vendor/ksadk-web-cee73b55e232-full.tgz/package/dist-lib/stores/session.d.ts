import type { Session } from '../components/chat/types.js';
export type SessionState = {
    sessions: Session[];
    currentSessionId: string | null;
    sessionsAgentId: string;
    /** Invalidates list requests across resets, including returning to the same Agent. */
    sessionsGeneration: number;
    sessionsTotal: number;
    sessionsPage: number;
    sessionsPageSize: number;
    loadedPages: Set<number>;
    hasMoreSessions: boolean;
    isLoadingSessions: boolean;
    pinnedSessionIds: string[];
    messageHistory: Record<string, {
        nextCursor: number | null;
        hasMore: boolean;
        isLoadingInitial: boolean;
        isLoadingOlder: boolean;
    }>;
};
export type SessionActions = {
    setSessions: (sessions: Session[]) => void;
    setCurrentSessionId: (id: string | null) => void;
    upsertSessions: (incoming: Session[], meta?: {
        agentId?: string;
        total?: number;
        page?: number;
        pageSize?: number;
        replace?: boolean;
    }) => void;
    removeSession: (id: string) => void;
    setLoadingSessions: (loading: boolean) => void;
    resetSessionPagination: (agentId: string) => void;
    togglePinnedSession: (id: string) => void;
    setSessionMessageHistory: (sessionId: string, history: {
        nextCursor: number | null;
        hasMore: boolean;
        isLoadingOlder?: boolean;
    }) => void;
    setSessionInitialMessageHistoryLoading: (sessionId: string, loading: boolean) => void;
    setSessionMessageHistoryLoading: (sessionId: string, loading: boolean) => void;
    clearSessionMessageHistory: (sessionId?: string) => void;
};
export declare function readPinnedSessionIds(): string[];
export type SessionStore = SessionState & SessionActions;
export declare const useSessionStore: import("zustand").UseBoundStore<import("zustand").StoreApi<SessionStore>>;
//# sourceMappingURL=session.d.ts.map