import { type RuntimeItemOperation, type RuntimeItemSnapshot } from '../core/stream/runtime-items.js';
export type RunActivityStatus = 'connecting' | 'running' | 'waiting' | 'stopped' | 'completed' | 'failed';
export type StatusBannerKind = 'rate_limited' | 'network' | 'error';
export type StatusBanner = {
    kind: StatusBannerKind;
    message: string;
    retryAfterSec?: number;
    sessionId?: string | null;
    createdAt?: number;
};
export type RunActivity = {
    runId?: string;
    source: 'run' | 'restore';
    status: RunActivityStatus;
    phase: string;
    detail?: string;
    startedAt: number;
    lastEventAt: number;
    eventCount: number;
};
export type StreamingState = {
    isStreaming: boolean;
    currentRunId: string;
    stopRequested: boolean;
    activity: RunActivity | null;
    sessionActivities: Record<string, RunActivity>;
    sessionStreaming: Record<string, true>;
    banner: StatusBanner | null;
    /** 当前 run 的最后事件 seq_id,用于网络断线后 afterSeqId 续订重连。 */
    lastSeqId: number;
    /** 当前 run 的 invocationId(afterSeqId 续订需要)。 */
    activeInvocationId: string;
    /** 当前 run 的 identity-aware item 投影(schema v2),替代 v1 启发式去重。 */
    runtimeItems: RuntimeItemSnapshot;
};
export type StreamingActions = {
    setStreaming: (streaming: boolean) => void;
    setSessionStreaming: (sessionId: string | null | undefined, streaming: boolean) => void;
    isSessionStreaming: (sessionId: string | null | undefined) => boolean;
    getSessionActivity: (sessionId: string | null | undefined) => RunActivity | null;
    setCurrentRunId: (runId: string) => void;
    requestStop: () => void;
    setBanner: (banner: StatusBanner | null) => void;
    setLastSeqId: (seqId: number) => void;
    setActiveInvocationId: (invocationId: string) => void;
    beginActivity: (activity: {
        runId?: string;
        source?: RunActivity['source'];
        status?: RunActivityStatus;
        phase: string;
        detail?: string;
    }) => void;
    updateActivity: (activity: {
        runId?: string;
        visible?: boolean;
        sessionId?: string | null;
        source?: RunActivity['source'];
        status?: RunActivityStatus;
        phase?: string;
        detail?: string;
        countEvent?: boolean;
    }) => void;
    stopActivity: (detail?: string) => void;
    stopSessionActivity: (sessionId?: string | null, detail?: string, visible?: boolean) => void;
    clearActivity: () => void;
    clearSessionActivity: (sessionId?: string | null) => void;
    /**
     * 应用 identity-aware item 操作到当前 run 的 RuntimeItemReducer。
     * 操作按 runId/scopeId/itemId/partId 归并;eventId 重放是幂等 no-op。
     */
    applyRuntimeItemOperations: (operations: RuntimeItemOperation[]) => void;
    resetRun: () => void;
};
export type StreamingStore = StreamingState & StreamingActions;
export declare const useStreamingStore: import("zustand").UseBoundStore<import("zustand").StoreApi<StreamingStore>>;
//# sourceMappingURL=streaming.d.ts.map