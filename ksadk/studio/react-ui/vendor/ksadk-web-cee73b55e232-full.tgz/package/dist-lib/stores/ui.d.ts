import type { MessageAttachment, PreviewImageSize } from '../components/chat/types.js';
import type { RuntimeExecutionMode } from '../core/run/types.js';
type QueuedDraft = {
    text: string;
    attachments: File[];
    executionMode?: RuntimeExecutionMode;
};
type ToastEntry = {
    id: string;
    message: string;
    variant: 'error' | 'info';
    createdAt: number;
};
export type UIState = {
    sidebarOpen: boolean;
    mobileSidebarOpen: boolean;
    mobileActionsOpen: boolean;
    workspacePanelOpen: boolean;
    workspacePanelWidth: number;
    workspacePanelFullscreen: boolean;
    input: string;
    attachments: File[];
    previewAttachment: MessageAttachment | null;
    previewImageSize: PreviewImageSize | null;
    queuedDrafts: QueuedDraft[];
    toasts: ToastEntry[];
};
export type UIActions = {
    toggleSidebar: () => void;
    setSidebarOpen: (open: boolean) => void;
    toggleMobileSidebar: () => void;
    setMobileSidebarOpen: (open: boolean) => void;
    toggleMobileActions: () => void;
    setMobileActionsOpen: (open: boolean) => void;
    setWorkspacePanelOpen: (open: boolean) => void;
    setWorkspacePanelWidth: (width: number) => void;
    setWorkspacePanelFullscreen: (fullscreen: boolean) => void;
    setInput: (input: string) => void;
    setAttachments: (updater: File[] | ((prev: File[]) => File[])) => void;
    setPreviewAttachment: (attachment: MessageAttachment | null) => void;
    setPreviewImageSize: (size: PreviewImageSize | null) => void;
    setQueuedDrafts: (updater: QueuedDraft[] | ((prev: QueuedDraft[]) => QueuedDraft[])) => void;
    pushToast: (message: string, variant?: 'error' | 'info') => void;
    dismissToast: (id: string) => void;
};
export type UIStore = UIState & UIActions;
export declare const useUIStore: import("zustand").UseBoundStore<import("zustand").StoreApi<UIStore>>;
export {};
//# sourceMappingURL=ui.d.ts.map