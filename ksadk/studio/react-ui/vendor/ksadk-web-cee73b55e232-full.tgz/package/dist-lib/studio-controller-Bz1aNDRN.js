//#region src/core/conversation/studio-controller.ts
var e = class {
	entries = /* @__PURE__ */ new Map();
	storageKey;
	maxEntries;
	listeners = /* @__PURE__ */ new Set();
	runtimeAttachments = /* @__PURE__ */ new Map();
	constructor(e = "ksadk.conversation-outbox", t = 128) {
		this.storageKey = e, this.maxEntries = Math.max(1, t), this.restore();
	}
	enqueue(e) {
		let n = e.requestId || `request_${Date.now().toString(36)}_${(++t).toString(36)}`, r = this.entries.get(n);
		if (r) return r;
		let i = Date.now(), a = {
			...e,
			requestId: n,
			attachments: e.attachments.map((e) => ({ ...e })),
			status: "pending",
			attempt: 0,
			createdAt: i,
			updatedAt: i
		};
		return this.entries.set(n, a), this.evict(), this.persist(), a;
	}
	get(e) {
		return this.entries.get(e);
	}
	setRuntimeAttachments(e, t) {
		this.entries.has(e) && this.runtimeAttachments.set(e, [...t]);
	}
	getRuntimeAttachments(e) {
		return [...this.runtimeAttachments.get(e) || []];
	}
	subscribe(e) {
		return this.listeners.add(e), () => this.listeners.delete(e);
	}
	list(e) {
		return [...this.entries.values()].filter((t) => !e || t.conversationId === e).sort((e, t) => e.createdAt - t.createdAt);
	}
	listUnresolved(e) {
		return this.list(e).filter((e) => e.status === "pending" || e.status === "sending" || e.status === "unknown" || e.status === "failed");
	}
	update(e, t) {
		let n = this.entries.get(e);
		if (!n) return;
		let r = {
			...n,
			...t,
			updatedAt: Date.now()
		};
		return this.entries.set(e, r), this.persist(), r;
	}
	markSending(e) {
		let t = this.entries.get(e);
		return t ? this.update(e, {
			status: "sending",
			attempt: t.attempt + 1,
			error: void 0
		}) : void 0;
	}
	requeue(e) {
		let t = this.entries.get(e);
		return !t || ![
			"pending",
			"failed",
			"unknown"
		].includes(t.status) ? t : this.update(e, {
			status: "pending",
			error: void 0
		});
	}
	remove(e) {
		this.entries.delete(e), this.runtimeAttachments.delete(e), this.persist();
	}
	clear() {
		this.entries.clear(), this.runtimeAttachments.clear(), this.persist();
	}
	evict() {
		for (; this.entries.size > this.maxEntries;) {
			let e = [...this.entries.values()].find((e) => [
				"delivered",
				"completed",
				"cancelled",
				"failed"
			].includes(e.status));
			if (!e) return;
			this.entries.delete(e.requestId), this.runtimeAttachments.delete(e.requestId);
		}
	}
	restore() {
		try {
			let e = globalThis.localStorage?.getItem(this.storageKey);
			if (!e) return;
			let t = JSON.parse(e);
			if (!Array.isArray(t)) return;
			for (let e of t) {
				let t = e;
				if (!t.requestId || !t.conversationId || !t.agentId || typeof t.text != "string") continue;
				let n = t.status;
				if (!n || ![
					"pending",
					"sending",
					"unknown",
					"failed",
					"delivered",
					"completed",
					"cancelled"
				].includes(n)) continue;
				let r = n === "sending" ? "unknown" : n;
				this.entries.set(t.requestId, {
					requestId: t.requestId,
					conversationId: t.conversationId,
					agentId: t.agentId,
					text: t.text,
					attachments: Array.isArray(t.attachments) ? t.attachments.map((e) => ({
						name: String(e.name || ""),
						type: String(e.type || ""),
						size: Number(e.size || 0)
					})) : [],
					executionMode: t.executionMode,
					nativeSessionId: t.nativeSessionId,
					invocationId: t.invocationId,
					status: r,
					attempt: Number(t.attempt || 0),
					createdAt: Number(t.createdAt || Date.now()),
					updatedAt: Number(t.updatedAt || Date.now()),
					error: r === "unknown" && n === "sending" ? t.error || "应用重启后投递状态待确认。" : t.error
				});
			}
			this.evict();
		} catch {}
	}
	persist() {
		try {
			globalThis.localStorage?.setItem(this.storageKey, JSON.stringify([...this.entries.values()]));
		} catch {}
		for (let e of this.listeners) e();
	}
}, t = 0;
function n(e = Math.random) {
	return `conversation_${`${Date.now().toString(36)}_${(++r).toString(36)}_${Math.floor(e() * 4294967296).toString(36)}`}`;
}
var r = 0, i = 128;
function a() {
	let e = 0;
	return {
		get current() {
			return e;
		},
		next: () => ++e
	};
}
var o = class {
	drafts = /* @__PURE__ */ new Map();
	conflicts = /* @__PURE__ */ new Map();
	listeners = /* @__PURE__ */ new Set();
	storageKey;
	maxEntries;
	storageListener;
	constructor(e = "ksadk.conversation-drafts", t = 128) {
		this.storageKey = e, this.maxEntries = Math.max(1, t), this.restore(), typeof window < "u" && typeof window.addEventListener == "function" && (this.storageListener = (e) => {
			e.key === this.storageKey && this.applyExternal(e.newValue);
		}, window.addEventListener("storage", this.storageListener));
	}
	get(e) {
		let t = this.drafts.get(e);
		return t || (t = {
			conversationId: e,
			text: "",
			revision: 0,
			updatedAt: Date.now(),
			attachments: []
		}, this.drafts.set(e, t), this.evict(e) && this.persist()), t;
	}
	set(e, t, n) {
		let r = this.get(e), i = n ?? r.attachments, a = r.attachments.length === i.length && r.attachments.every((e, t) => e === i[t]);
		if (r.text === t && a) return r;
		let o = {
			conversationId: e,
			text: t,
			attachments: i,
			revision: r.revision + 1,
			updatedAt: Date.now()
		};
		return this.drafts.set(e, o), this.conflicts.delete(e), this.evict(e), this.persist(), o;
	}
	delete(e) {
		this.drafts.delete(e), this.conflicts.delete(e), this.persist();
	}
	clear() {
		this.drafts.clear(), this.conflicts.clear(), this.persist();
	}
	size() {
		return this.drafts.size;
	}
	subscribe(e) {
		return this.listeners.add(e), () => this.listeners.delete(e);
	}
	getConflict(e) {
		let t = this.conflicts.get(e);
		return t ? {
			...t,
			local: {
				...t.local,
				attachments: [...t.local.attachments]
			}
		} : void 0;
	}
	resolveConflict(e, t) {
		let n = this.conflicts.get(e);
		if (!n) return this.drafts.get(e);
		if (t === "remote") {
			if (!n.remote) {
				this.drafts.delete(e), this.conflicts.delete(e), this.persist();
				return;
			}
			let t = {
				conversationId: e,
				text: n.remote.text,
				revision: n.remote.revision,
				updatedAt: n.remote.updatedAt,
				attachments: []
			};
			return this.drafts.set(e, t), this.conflicts.delete(e), this.persist(), t;
		}
		let r = this.drafts.get(e);
		if (!r) return;
		let i = {
			...r,
			revision: Math.max(r.revision, n.remote?.revision || 0) + 1,
			updatedAt: Date.now()
		};
		return this.drafts.set(e, i), this.conflicts.delete(e), this.persist(), i;
	}
	dispose() {
		this.storageListener && typeof window < "u" && window.removeEventListener("storage", this.storageListener), this.listeners.clear();
	}
	restore() {
		try {
			let e = globalThis.localStorage?.getItem(this.storageKey);
			if (!e) return;
			let t = JSON.parse(e);
			for (let [e, n] of Object.entries(t)) {
				let t = n;
				!e.startsWith("conversation_") || typeof t.text != "string" || this.drafts.set(e, {
					conversationId: e,
					text: t.text,
					revision: Number.isFinite(t.revision) ? Number(t.revision) : 0,
					updatedAt: Number.isFinite(t.updatedAt) ? Number(t.updatedAt) : Date.now(),
					attachments: []
				});
			}
			this.evict() && this.persist();
		} catch {}
	}
	evict(e) {
		let t = !1;
		for (; this.drafts.size > this.maxEntries;) {
			let n = [...this.drafts.values()].filter((t) => t.conversationId !== e).sort((e, t) => e.updatedAt - t.updatedAt)[0];
			if (!n) break;
			this.drafts.delete(n.conversationId), t = !0;
		}
		return t;
	}
	persist() {
		try {
			if (!globalThis.localStorage) return;
			let e = {};
			for (let [t, n] of this.drafts) n.text && (e[t] = {
				text: n.text,
				revision: n.revision,
				updatedAt: n.updatedAt
			});
			globalThis.localStorage.setItem(this.storageKey, JSON.stringify(e));
		} catch {}
		this.notify();
	}
	notify() {
		for (let e of this.listeners) e();
	}
	applyExternal(e) {
		let t = {};
		try {
			let n = e ? JSON.parse(e) : {};
			n && typeof n == "object" && !Array.isArray(n) && (t = n);
		} catch {
			return;
		}
		let n = new Set([...this.drafts.keys(), ...Object.keys(t).filter((e) => e.startsWith("conversation_"))]), r = !1;
		for (let e of n) {
			let n = this.drafts.get(e), i = t[e], a = i && typeof i.text == "string" ? {
				text: i.text,
				revision: Number(i.revision || 0),
				updatedAt: Number(i.updatedAt || 0)
			} : null;
			if (!n && a) {
				this.drafts.set(e, {
					conversationId: e,
					...a,
					attachments: []
				}), r = !0;
				continue;
			}
			if (!n) continue;
			let o = a && a.revision === n.revision && (a.text !== n.text || a.updatedAt !== n.updatedAt), s = a && a.revision > n.revision, c = !a && n.text;
			o || c ? (this.conflicts.set(e, {
				conversationId: e,
				local: {
					...n,
					attachments: [...n.attachments]
				},
				remote: a,
				detectedAt: Date.now()
			}), r = !0) : s && (this.drafts.set(e, {
				conversationId: e,
				...a,
				attachments: n.attachments
			}), this.conflicts.delete(e), r = !0);
		}
		r && this.notify();
	}
}, s = class {
	drafts;
	outbox;
	storageKey;
	ids = /* @__PURE__ */ new Map();
	bindings = /* @__PURE__ */ new Map();
	unboundDrafts = /* @__PURE__ */ new Map();
	epoch = a();
	constructor(t = "ksadk.conversation-bindings") {
		this.storageKey = t, this.drafts = new o(`${t}:drafts`), this.outbox = new e(`${t}:outbox`), this.restoreIds();
	}
	navigate() {
		return this.epoch.next();
	}
	get navigationEpoch() {
		return this.epoch.current;
	}
	getOrCreate(e, t, r) {
		let i = this.key(e, t, r), a = this.ids.get(i);
		if (a) return this.bindings.has(a) || this.bindings.set(a, {
			conversationId: a,
			agentId: e,
			targetId: r,
			nativeSessionId: t || void 0
		}), t || this.unboundDrafts.set(a, !0), a;
		let o = n();
		return this.ids.set(i, o), this.bindings.set(o, {
			conversationId: o,
			agentId: e,
			targetId: r,
			nativeSessionId: t || void 0
		}), t || (this.unboundDrafts.set(o, !0), this.pruneUnboundDrafts()), this.persistIds(), o;
	}
	bindNative(e, t) {
		let n = this.bindings.get(e);
		if (!n) throw Error(`Unknown conversation: ${e}`);
		if (!t) throw Error("Native session identity is required");
		if (n.nativeSessionId && n.nativeSessionId !== t) throw Error("An executed conversation cannot change native sessions");
		let r = this.key(n.agentId, t, n.targetId), i = this.ids.get(r);
		if (i && i !== e) throw Error("Native session is already bound");
		let a = {
			...n,
			nativeSessionId: t
		};
		this.bindings.set(e, a), this.unboundDrafts.delete(e), this.ids.set(r, e);
		let o = this.key(n.agentId, null, n.targetId);
		return this.ids.get(o) === e && this.ids.delete(o), this.persistIds(), a;
	}
	createDraft(e, t) {
		return this.ids.delete(this.key(e, null, t)), this.getOrCreate(e, null, t);
	}
	clear() {
		this.navigate(), this.ids.clear(), this.bindings.clear(), this.unboundDrafts.clear(), this.drafts.clear(), this.outbox.clear(), this.persistIds();
	}
	restoreIds() {
		try {
			let e = globalThis.localStorage?.getItem(this.storageKey);
			if (!e) return;
			let t = JSON.parse(e);
			for (let [e, n] of Object.entries(t)) {
				if (typeof n != "string" || !n.startsWith("conversation_")) continue;
				let t = n;
				this.ids.set(e, t);
				try {
					let n = JSON.parse(e);
					Array.isArray(n) && n[2] === null && this.unboundDrafts.set(t, !0);
				} catch {}
			}
			this.pruneUnboundDrafts();
		} catch {}
	}
	persistIds() {
		try {
			globalThis.localStorage?.setItem(this.storageKey, JSON.stringify(Object.fromEntries(this.ids)));
		} catch {}
	}
	pruneUnboundDrafts() {
		let e = !1;
		for (; this.unboundDrafts.size > i;) {
			let t = [...this.unboundDrafts.keys()].find((e) => !this.bindings.get(e)?.nativeSessionId && this.outbox.listUnresolved(e).length === 0);
			if (!t) break;
			this.unboundDrafts.delete(t), this.bindings.delete(t);
			for (let [e, n] of this.ids) n === t && this.ids.delete(e);
			this.drafts.delete(t), e = !0;
		}
		e && this.persistIds();
	}
	key(e, t, n) {
		return JSON.stringify([
			e,
			n ?? null,
			t
		]);
	}
	binding(e) {
		return this.bindings.get(e);
	}
};
function c(e, t) {
	return e === t;
}
//#endregion
export { a, n as i, o as n, c as o, e as r, s as t };
