import { n as e, r as t, t as n } from "./InteractionSchemaForm-ChYkHPop.js";
import { t as r } from "./MessageMarkdown-Lj01l-_B.js";
import { Et as i, Ot as a, S as o, i as s, o as c, qt as l, s as u, t as d, v as f } from "./cloudMaterials-D75jTrkQ.js";
import { i as p, n as m, o as h, r as g, s as _, t as v } from "./presentation-yYw7xK60.js";
import { Suspense as y, lazy as b, useCallback as x, useEffect as S, useId as C, useLayoutEffect as w, useMemo as T, useRef as E, useState as D, useSyncExternalStore as O } from "react";
import { Fragment as k, jsx as A, jsxs as j } from "react/jsx-runtime";
//#region src/components/teams/InteractionMessage.tsx
function M({ message: e }) {
	let t = null;
	try {
		let n = JSON.parse(e);
		n && typeof n == "object" && "arguments" in n && n.arguments && typeof n.arguments == "object" && !Array.isArray(n.arguments) && (t = n);
	} catch {}
	if (!t) return /* @__PURE__ */ A("p", { children: e });
	let n = {
		path: "文件位置",
		command: "命令",
		cwd: "执行目录"
	}, r = {
		low: "低",
		medium: "中",
		high: "高"
	}, i = (e) => typeof e == "string" ? e : JSON.stringify(e, null, 2);
	return /* @__PURE__ */ j("div", {
		className: "team-approval-details",
		children: [
			/* @__PURE__ */ A("dl", { children: Object.entries(t.arguments).filter(([e]) => e !== "content").map(([e, t]) => /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: n[e] || e }), /* @__PURE__ */ A("dd", { children: /* @__PURE__ */ A("code", { children: i(t) }) })] }, e)) }),
			"content" in t.arguments && /* @__PURE__ */ j("details", {
				className: "team-approval-preview",
				children: [/* @__PURE__ */ A("summary", { children: "查看待写入的文件内容" }), /* @__PURE__ */ A("pre", { children: i(t.arguments.content) })]
			}),
			typeof t.risk == "string" && /* @__PURE__ */ j("p", {
				className: "team-approval-risk",
				children: ["风险级别：", r[t.risk] || t.risk]
			})
		]
	});
}
//#endregion
//#region src/components/teams/TeamReconciliation.tsx
function N({ run: e, onLoadReconciliation: t, onReconcile: n }) {
	let [r, i] = D(null), [a, o] = D({}), [s, c] = D(!1), [l, u] = D("");
	if (!t || !n || e.leaderStandby?.reason !== "execution_uncertain_fenced") return null;
	async function d() {
		c(!0), u("");
		try {
			i(await t(e));
		} catch (e) {
			u(e instanceof Error ? e.message : "暂时无法读取原单。");
		} finally {
			c(!1);
		}
	}
	async function f(r, s) {
		c(!0), u("");
		try {
			await n(r, s, (a[r.commandId] || "").trim()), i(await t(e)), o((e) => ({
				...e,
				[r.commandId]: ""
			}));
		} catch (e) {
			u(e instanceof Error ? e.message : "核查状态已改变，请刷新。");
		} finally {
			c(!1);
		}
	}
	return /* @__PURE__ */ j("section", {
		className: "team-run-budget",
		"aria-label": "原执行核查",
		children: [
			/* @__PURE__ */ A("h4", { children: "旧执行结果需要核查" }),
			/* @__PURE__ */ A("p", { children: "云端已接管，相关分支会等待原单确认。请先核对外部操作和交付物，再决定是否采用结果。" }),
			/* @__PURE__ */ A("button", {
				type: "button",
				className: "team-button",
				disabled: s,
				onClick: () => void d(),
				children: s ? "正在核对…" : "查看原单证据"
			}),
			r?.filter((e) => !e.reconciled).map((e) => {
				let t = e.quarantinedReceipt, n = a[e.commandId] || "", r = !!e.receiptDigest && [
					"succeeded",
					"failed",
					"cancelled",
					"interrupted"
				].includes(t?.run_status || "");
				return /* @__PURE__ */ j("article", {
					className: "team-observer-item",
					children: [
						/* @__PURE__ */ j("p", { children: [
							e.taskId ? "成员执行" : "原 Leader 执行",
							" · ",
							r ? "已返回结束回执" : "原节点尚未返回结束回执"
						] }),
						t?.output && /* @__PURE__ */ A("pre", {
							className: "team-observer-details",
							children: t.output.slice(0, 1e4)
						}),
						/* @__PURE__ */ j("details", { children: [/* @__PURE__ */ A("summary", { children: "执行引用" }), /* @__PURE__ */ A("code", { children: t?.run_id || e.nativeRunId || e.commandId })] }),
						r && /* @__PURE__ */ j(k, { children: [
							/* @__PURE__ */ j("label", {
								className: "team-field",
								children: ["核查说明", /* @__PURE__ */ A("textarea", {
									value: n,
									onChange: (t) => o((n) => ({
										...n,
										[e.commandId]: t.target.value
									})),
									maxLength: 2e3,
									placeholder: "说明已检查哪些原单或外部结果"
								})]
							}),
							/* @__PURE__ */ A("button", {
								type: "button",
								className: "team-button",
								disabled: s || !n.trim(),
								onClick: () => void f(e, "confirm_ended"),
								children: "确认已结束"
							}),
							e.taskId && t?.run_status === "succeeded" && /* @__PURE__ */ A("button", {
								type: "button",
								className: "team-button",
								disabled: s || !n.trim(),
								onClick: () => void f(e, "use_result"),
								children: "采用已验证成果"
							}),
							/* @__PURE__ */ A("p", {
								className: "team-muted",
								children: "确认结束不会自动重新执行；必要时再对相应子任务提出重试。"
							})
						] })
					]
				}, e.commandId);
			}),
			l && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: l
			})
		]
	});
}
//#endregion
//#region src/components/teams/TeamWorkspace.tsx
var P = b(() => import("./ExecutionTree-v3HexvPo.js").then((e) => e.n).then((e) => ({ default: e.ExecutionTree }))), F = () => `team-${globalThis.crypto.randomUUID()}`, I = {
	owner: "群主",
	leader: "Leader",
	member: "成员",
	system: "系统"
}, L = {
	idle: "空闲",
	queued: "待执行",
	running: "进行中",
	waiting: "等待中",
	needs_attention: "需要处理",
	unavailable: "不可用"
}, R = {
	connecting: "正在连接",
	connected: "已连接",
	reconnecting: "正在重连 · 任务继续执行",
	offline: "连接中断 · 显示最后状态",
	closed: "未连接"
};
function z({ name: e }) {
	return /* @__PURE__ */ A("span", {
		className: "team-avatar",
		"aria-hidden": "true",
		children: Array.from(e.trim())[0] || "A"
	});
}
function B({ status: e }) {
	return /* @__PURE__ */ A("span", {
		className: "team-status",
		"data-status": e,
		children: v[e] ?? e
	});
}
function V({ goal: e }) {
	return e.length <= 100 ? /* @__PURE__ */ A("h3", { children: e }) : /* @__PURE__ */ j("details", {
		className: "team-run-goal",
		children: [/* @__PURE__ */ j("summary", { children: [/* @__PURE__ */ A("h3", { children: e }), /* @__PURE__ */ A("span", { children: "完整目标" })] }), /* @__PURE__ */ A("p", { children: e })]
	});
}
function H({ snapshot: e, connection: t, onMembers: n, onManage: r }) {
	let i = e.members.filter((e) => e.status !== "removed");
	return /* @__PURE__ */ j("header", {
		className: "team-header",
		children: [/* @__PURE__ */ j("div", {
			className: "team-header-identity",
			children: [/* @__PURE__ */ A("div", {
				className: "team-avatar-stack",
				"aria-hidden": "true",
				children: i.slice(0, 3).map((e) => /* @__PURE__ */ A(z, { name: e.name }, e.memberId))
			}), /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("h1", { children: e.group.name }), /* @__PURE__ */ j("button", {
				type: "button",
				className: "team-text-button team-muted",
				onClick: n,
				children: [
					i.length,
					" 位成员 · ",
					i.find((t) => t.memberId === e.group.leaderMemberId)?.name || "Leader"
				]
			})] })]
		}), /* @__PURE__ */ j("div", {
			className: "team-header-actions",
			children: [t !== "connected" && /* @__PURE__ */ A("span", {
				className: "team-connection",
				role: "status",
				children: R[t]
			}), r && /* @__PURE__ */ A("button", {
				type: "button",
				className: "team-button",
				onClick: r,
				children: "设置"
			})]
		})]
	});
}
function U({ messages: e, children: t, emptyState: n, focusFinalDelivery: i }) {
	let a = E(null), o = E(!0), [s, c] = D(100), l = e.filter((e) => e.visibility === "public");
	w(() => {
		let e = a.current;
		if (!o.current || !e) return;
		let t = i ? e.querySelector(".team-final-delivery") : null;
		t ? e.scrollTop += t.getBoundingClientRect().top - e.getBoundingClientRect().top - 12 : e.scrollTop = e.scrollHeight;
	}, [l.map((e) => `${e.messageId}:${e.revision}`).join("|"), i]);
	function u() {
		let e = a.current;
		if (!e) return;
		let t = e.scrollHeight;
		c((e) => e + 100), requestAnimationFrame(() => {
			e.scrollTop += e.scrollHeight - t;
		});
	}
	return /* @__PURE__ */ A("div", {
		className: "team-timeline",
		ref: a,
		onScroll: () => {
			let e = a.current;
			e && (o.current = e.scrollHeight - e.scrollTop - e.clientHeight < 80);
		},
		"aria-label": "群聊消息",
		tabIndex: 0,
		children: /* @__PURE__ */ j("div", {
			className: "team-timeline-inner",
			children: [
				l.length > s && /* @__PURE__ */ A("button", {
					className: "team-button team-history-more",
					type: "button",
					onClick: u,
					children: "查看更早的消息"
				}),
				!l.length && (n ?? /* @__PURE__ */ j("div", {
					className: "team-empty",
					children: [
						/* @__PURE__ */ A("span", {
							className: "team-eyebrow",
							children: "一起完成一个目标"
						}),
						/* @__PURE__ */ A("h2", { children: "团队已就绪" }),
						/* @__PURE__ */ j("p", { children: [
							"描述你想得到的成果，Leader 会组织成员分工。",
							/* @__PURE__ */ A("br", {}),
							"也可以 @成员，指定由谁参与。"
						] })
					]
				})),
				l.slice(-s).map((e) => /* @__PURE__ */ j("article", {
					className: "team-message",
					"data-role": e.groupRole,
					"data-message-id": e.messageId,
					children: [e.groupRole !== "owner" && /* @__PURE__ */ A(z, { name: e.senderName }), /* @__PURE__ */ j("div", {
						className: "team-message-main",
						children: [/* @__PURE__ */ j("header", { children: [
							/* @__PURE__ */ A("strong", { children: e.senderName }),
							/* @__PURE__ */ A("span", { children: I[e.groupRole] }),
							/* @__PURE__ */ A("time", {
								dateTime: e.createdAt,
								children: new Date(e.createdAt).toLocaleTimeString([], {
									hour: "2-digit",
									minute: "2-digit"
								})
							}),
							e.intent === "note" && /* @__PURE__ */ A("span", { children: "仅留言" })
						] }), /* @__PURE__ */ A("div", {
							className: "team-message-body",
							children: e.parts.map((e, t) => e.kind === "text" ? /* @__PURE__ */ A(r, { content: e.text }, t) : /* @__PURE__ */ j("span", {
								className: "team-attachment",
								children: [
									e.name || "附件",
									" ",
									/* @__PURE__ */ A("span", { children: e.mediaType })
								]
							}, e.attachmentRef))
						})]
					})]
				}, e.messageId)),
				t
			]
		})
	});
}
function ee({ run: e, tasks: t, pendingCount: n, onOpen: r, compact: i = !1 }) {
	let a = t.filter((e) => e.status === "succeeded").length, o = g(e.status);
	return /* @__PURE__ */ j("button", {
		type: "button",
		className: "team-progress-card",
		"data-active": o || void 0,
		onClick: r,
		"aria-label": `查看协作：${e.goal}`,
		children: [
			/* @__PURE__ */ j("span", {
				className: "team-progress-heading",
				children: [/* @__PURE__ */ A("span", {
					className: "team-eyebrow",
					children: "本轮协作"
				}), /* @__PURE__ */ j("span", {
					className: "team-progress-status",
					children: [/* @__PURE__ */ A(B, { status: e.status }), o && /* @__PURE__ */ j("span", {
						className: "team-progress-live",
						role: "status",
						children: ["实时处理中", /* @__PURE__ */ j("span", {
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ A("i", {}),
								/* @__PURE__ */ A("i", {}),
								/* @__PURE__ */ A("i", {})
							]
						})]
					})]
				})]
			}),
			!i && /* @__PURE__ */ A("strong", { children: e.goal }),
			/* @__PURE__ */ j("span", {
				className: "team-progress-caption",
				children: [
					t.length ? `${a} / ${t.length} 项任务已验收` : "正在整理目标与分工",
					n > 0 ? ` · ${n} 项需要处理` : "",
					/* @__PURE__ */ j("span", { children: ["查看协作 ", /* @__PURE__ */ A("span", {
						"aria-hidden": "true",
						children: "→"
					})] })
				]
			}),
			e.reason && /* @__PURE__ */ A("span", {
				className: "team-progress-reason",
				children: e.reason
			})
		]
	});
}
function te({ members: e, activeRun: n, value: r, onChange: i, onSend: a, disabled: o = !1, recipientMemberId: s, onRecipientChange: c, focusRequest: l = 0, artifacts: u = [], referenceArtifacts: d = [], serverAuthority: f = !1 }) {
	let p = C(), m = C(), h = C(), _ = n?.teamRunId || "", v = {
		attachmentIds: [],
		note: !1,
		sourcePath: "",
		baseRef: "",
		inputs: "",
		mode: "auto"
	}, [y, b] = D({}), x = y[_] || v, T = (e) => b((t) => ({
		...t,
		[_]: {
			...t[_] || v,
			...e
		}
	})), { attachmentIds: O, note: M } = x, N = (e) => b((t) => {
		let n = t[_] || v;
		return {
			...t,
			[_]: {
				...n,
				attachmentIds: typeof e == "function" ? e(n.attachmentIds) : e
			}
		};
	}), P = (e) => T({ note: e }), I = [...new Map([...u, ...d].map((e) => [e.artifactId, e])).values()], L = I.filter((e) => O.includes(e.artifactId)), [R, B] = D(""), V = s ?? R, H = (e) => {
		B(e), c?.(e);
	}, U = E(null);
	w(() => {
		let e = U.current;
		e && (e.style.height = "auto", e.style.height = `${Math.min(e.scrollHeight, 176)}px`);
	}, [r]), S(() => {
		l && U.current?.focus();
	}, [l]);
	let [ee, te] = D(0), ne = E(_);
	ne.current = _, S(() => {
		G("");
	}, [_]);
	let [W, re] = D(!1), ie = !!(n && g(n.status)), ae = (!!(n && !ie) || n?.status === "cancel_requested") && !M, [oe, G] = D(""), se = t(), K = E(/* @__PURE__ */ new Map()), ce = E(!0);
	S(() => (ce.current = !0, () => {
		ce.current = !1;
	}), []);
	let le = /@([^\s@]*)$/u.exec(r)?.[1], q = le === void 0 ? [] : e.filter((e) => e.status === "active" && e.name.toLowerCase().includes(le.toLowerCase()));
	async function J() {
		if (o || W || !r.trim() && !L.length) return;
		if (ae) {
			G("这个任务已结束，请新建任务继续协作。");
			return;
		}
		let e = r.trim(), t = M ? "note" : n ? V === "" ? "followup" : "directed" : "start_goal";
		if (t === "start_goal" && !e) {
			G("请补充这轮希望团队完成的目标，或选择仅留言。");
			return;
		}
		let s = V === "" ? [] : [V], c = [...e ? [{
			kind: "text",
			text: e
		}] : [], ...L.map((e) => ({
			kind: "attachment",
			attachmentRef: e.artifactId,
			mediaType: e.mediaType,
			name: e.name
		}))], l = n?.teamRunId, u = _;
		if (t === "start_goal" && !x.sourcePath.trim() && (x.baseRef.trim() || x.inputs.trim())) {
			G("请先填写执行节点上的工作目录。");
			return;
		}
		let d = t === "start_goal" && x.sourcePath.trim() ? {
			sourcePath: x.sourcePath.trim(),
			mode: x.mode,
			...x.mode === "auto" && x.baseRef.trim() ? { baseRef: x.baseRef.trim() } : {},
			inputs: x.inputs.split(/\r?\n/).map((e) => e.trim()).filter(Boolean)
		} : void 0;
		if (d && f && d.mode === "auto" && !/^(?:[a-fA-F0-9]{40}|[a-fA-F0-9]{64})$/.test(x.baseRef.trim())) {
			G("云端协作的 Git 基线需要完整的 40 或 64 位 commit，请在工作目录设置中填写。");
			return;
		}
		if (d && d.inputs.length > 32) {
			G("每次任务最多引用 32 个输入文件。");
			return;
		}
		let p = JSON.stringify([
			c,
			t,
			s,
			l,
			d
		]);
		K.current.get(_)?.digest !== p && K.current.set(_, {
			digest: p,
			idempotencyKey: F()
		});
		let m = K.current.get(_);
		re(!0), G("");
		try {
			let e = await a({
				parts: c,
				mentions: s,
				intent: t,
				...l ? { teamRunId: l } : {},
				...d ? { workspace: d } : {},
				idempotencyKey: m.idempotencyKey
			});
			if (!ce.current) return;
			if (e?.status === "rejected" || e?.status === "uncertain") throw Error(e.reason || (e.status === "uncertain" ? "消息接收结果尚未确认。再次提交将使用相同标识核对。" : "消息未被接收。"));
			ne.current === u && (i(""), N([])), K.current.delete(u), t === "start_goal" && b((e) => {
				let t = { ...e };
				return delete t[u], t;
			});
		} catch (e) {
			G(e instanceof Error ? e.message : "消息发送失败，请重试。");
		} finally {
			re(!1);
		}
	}
	function Y(e) {
		H(e.memberId), i(r.replace(/@([^\s@]*)$/u, `@${e.name} `)), te(0), U.current?.focus();
	}
	return /* @__PURE__ */ j("form", {
		className: "team-composer-wrap",
		onSubmit: (e) => {
			e.preventDefault(), J();
		},
		children: [
			oe && /* @__PURE__ */ A("p", {
				className: "team-inline-error",
				role: "alert",
				children: oe
			}),
			!!q.length && /* @__PURE__ */ A("div", {
				className: "team-mention-options",
				role: "listbox",
				"aria-label": "选择要提及的成员",
				children: q.map((e, t) => /* @__PURE__ */ j("button", {
					type: "button",
					role: "option",
					"aria-selected": t === ee,
					onClick: () => Y(e),
					children: [
						/* @__PURE__ */ A(z, { name: e.name }),
						/* @__PURE__ */ A("span", { children: e.name }),
						/* @__PURE__ */ A("small", { children: e.role === "leader" ? "Leader" : "成员" })
					]
				}, e.memberId))
			}),
			!!L.length && /* @__PURE__ */ A("div", {
				className: "team-selected-artifacts",
				"aria-label": "已选择的交付物",
				children: L.map((e) => /* @__PURE__ */ j("span", {
					className: "team-attachment",
					children: [e.name, /* @__PURE__ */ A("button", {
						type: "button",
						className: "team-text-button",
						"aria-label": `移除引用 ${e.name}`,
						disabled: W,
						onClick: () => N((t) => t.filter((t) => t !== e.artifactId)),
						children: "×"
					})]
				}, e.artifactId))
			}),
			/* @__PURE__ */ j("div", {
				className: "team-composer",
				children: [
					/* @__PURE__ */ A("label", {
						className: "team-sr-only",
						htmlFor: p,
						children: "给团队的消息"
					}),
					/* @__PURE__ */ A("textarea", {
						ref: U,
						id: p,
						value: r,
						rows: 2,
						onChange: (e) => {
							i(e.target.value), te(0);
						},
						placeholder: M ? "留下一条消息，不启动任务…" : V === "" ? "描述目标、交付物或需要团队解决的问题…" : "向选中的成员提问或分派工作…",
						disabled: o || W,
						onKeyDown: (e) => {
							if (q.length && !se(e) && [
								"ArrowDown",
								"ArrowUp",
								"Enter"
							].includes(e.key)) {
								e.preventDefault(), e.key === "Enter" ? Y(q[ee % q.length]) : te((t) => (t + (e.key === "ArrowDown" ? 1 : -1) + q.length) % q.length);
								return;
							}
							e.key === "Enter" && !e.shiftKey && !se(e) && (e.preventDefault(), J());
						}
					}),
					/* @__PURE__ */ j("div", {
						className: "team-composer-toolbar",
						children: [/* @__PURE__ */ j("div", { children: [
							/* @__PURE__ */ A("label", {
								className: "team-sr-only",
								htmlFor: m,
								children: "接收成员"
							}),
							/* @__PURE__ */ j("select", {
								id: m,
								value: V,
								onChange: (e) => H(e.target.value),
								disabled: o || W,
								children: [/* @__PURE__ */ A("option", {
									value: "",
									children: "发给 Leader"
								}), e.filter((e) => e.status === "active").map((e) => /* @__PURE__ */ j("option", {
									value: e.memberId,
									children: ["@", e.name]
								}, e.memberId))]
							}),
							/* @__PURE__ */ j("details", {
								className: "team-composer-more",
								children: [/* @__PURE__ */ A("summary", {
									"aria-label": "更多消息选项",
									children: "···"
								}), /* @__PURE__ */ j("div", {
									className: "team-composer-menu",
									children: [/* @__PURE__ */ j("label", {
										className: "team-note-toggle",
										children: [/* @__PURE__ */ A("input", {
											type: "checkbox",
											checked: M,
											onChange: (e) => P(e.target.checked),
											disabled: o || W
										}), "仅留言，不启动执行"]
									}), !n && /* @__PURE__ */ j("details", {
										className: "team-workspace-options",
										children: [
											/* @__PURE__ */ j("summary", { children: ["工作目录", x.sourcePath ? " · 已选择" : " · 可选"] }),
											/* @__PURE__ */ j("label", {
												className: "team-field",
												children: ["工作目录", /* @__PURE__ */ A("input", {
													value: x.sourcePath,
													maxLength: 4096,
													onChange: (e) => T({ sourcePath: e.target.value }),
													placeholder: "执行节点上的目录路径",
													disabled: W
												})]
											}),
											/* @__PURE__ */ j("label", {
												className: "team-field",
												children: ["目录类型", /* @__PURE__ */ j("select", {
													value: x.mode,
													onChange: (e) => T({ mode: e.target.value }),
													children: [/* @__PURE__ */ A("option", {
														value: "auto",
														children: f ? "Git 仓库" : "自动识别 Git"
													}), /* @__PURE__ */ A("option", {
														value: "directory",
														children: "普通目录，仅复制输入文件"
													})]
												})]
											}),
											x.mode === "auto" && /* @__PURE__ */ j("label", {
												className: "team-field",
												children: ["Git 基线", /* @__PURE__ */ A("input", {
													value: x.baseRef,
													maxLength: 256,
													onChange: (e) => T({ baseRef: e.target.value }),
													placeholder: f ? "完整 commit（40 或 64 位）" : "HEAD",
													disabled: W
												})]
											}),
											/* @__PURE__ */ j("label", {
												className: "team-field",
												children: ["输入文件", /* @__PURE__ */ A("textarea", {
													rows: 2,
													value: x.inputs,
													onChange: (e) => T({ inputs: e.target.value }),
													placeholder: "每行一个相对路径（非 Git 目录）",
													disabled: W
												})]
											}),
											/* @__PURE__ */ j("p", { children: ["路径须在执行节点可访问。Git 使用提交版本，不带入未提交修改；普通目录只复制列出的输入文件。", f && "云端协作需填写固定 commit，并确保节点可访问相同版本。"] })
										]
									})]
								})]
							}),
							!!I.length && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("label", {
								className: "team-sr-only",
								htmlFor: h,
								children: "引用本群交付物"
							}), /* @__PURE__ */ j("select", {
								id: h,
								value: "",
								disabled: o || W || L.length >= 8,
								onChange: (e) => {
									let t = e.target.value;
									t && N((e) => e.includes(t) ? e : [...e, t]);
								},
								children: [
									/* @__PURE__ */ A("option", {
										value: "",
										children: "引用交付物"
									}),
									/* @__PURE__ */ A("optgroup", {
										label: "当前任务",
										children: u.filter((e) => !O.includes(e.artifactId)).map((e) => /* @__PURE__ */ A("option", {
											value: e.artifactId,
											children: e.name
										}, e.artifactId))
									}),
									/* @__PURE__ */ A("optgroup", {
										label: "其他任务（显式引用）",
										children: d.filter((e) => !u.some((t) => t.artifactId === e.artifactId) && !O.includes(e.artifactId)).map((e) => /* @__PURE__ */ A("option", {
											value: e.artifactId,
											children: e.name
										}, e.artifactId))
									})
								]
							})] })
						] }), /* @__PURE__ */ A("button", {
							className: "team-button team-primary",
							type: "submit",
							disabled: o || W || ae || !r.trim() && !L.length,
							children: W ? "正在发送" : "发送"
						})]
					})
				]
			}),
			/* @__PURE__ */ A("p", {
				className: "team-composer-help",
				children: ae ? n?.status === "cancel_requested" ? "正在停止任务 · 等待执行端确认" : "任务已结束 · 新建任务以继续协作" : /* @__PURE__ */ j(k, { children: ["Enter 发送 · Shift + Enter 换行", M ? " · 留言不会唤醒成员" : ""] })
			})
		]
	});
}
function ne({ tasks: e, members: t, selectedTaskId: n, onSelect: r }) {
	return e.length ? /* @__PURE__ */ A("div", {
		className: "team-task-board",
		children: [
			["attention", "需处理"],
			["running", "进行中"],
			["waiting", "等待"],
			["done", "已完成"]
		].map(([i, a]) => {
			let o = e.filter((e) => _(e) === i);
			return o.length ? /* @__PURE__ */ j("section", { children: [/* @__PURE__ */ j("h3", { children: [a, /* @__PURE__ */ A("span", { children: o.length })] }), o.map((e) => /* @__PURE__ */ j("button", {
				className: "team-task-row",
				type: "button",
				onClick: () => r(e),
				"aria-pressed": n === e.taskId,
				children: [/* @__PURE__ */ j("span", {
					className: "team-task-row-main",
					children: [/* @__PURE__ */ A("strong", { children: e.title }), /* @__PURE__ */ A(B, { status: e.status })]
				}), /* @__PURE__ */ j("span", {
					className: "team-muted",
					children: [t.find((t) => t.memberId === e.ownerMemberId)?.name || "待分派", h(e) ? ` · ${h(e)}` : e.dependencies.length && e.status === "blocked" ? " · 等待前置任务验收" : ""]
				})]
			}, e.taskId))] }, i) : null;
		})
	}) : /* @__PURE__ */ j("div", {
		className: "team-panel-empty",
		children: [/* @__PURE__ */ A("h3", { children: "尚未分派任务" }), /* @__PURE__ */ A("p", { children: "Leader 建立任务后，负责人、依赖与验收进度会出现在这里。" })]
	});
}
function W({ artifact: e, onOpen: t }) {
	let n = p(e.uri);
	return /* @__PURE__ */ j("div", {
		className: "team-artifact",
		children: [t ? /* @__PURE__ */ A("button", {
			className: "team-text-button",
			type: "button",
			onClick: () => t(e),
			children: e.name
		}) : n ? /* @__PURE__ */ A("a", {
			href: n,
			target: "_blank",
			rel: "noopener noreferrer",
			children: e.name
		}) : /* @__PURE__ */ A("span", { children: e.name }), /* @__PURE__ */ j("small", { children: [e.mediaType, e.digest ? ` · ${e.digest.slice(0, 12)}` : ""] })]
	});
}
function re({ task: e, members: t, onAction: n, onOpenArtifact: i, onMemberSelect: a }) {
	let [o, s] = D(""), [c, l] = D(!1), [u, d] = D(""), [f, p] = D(!1), [m, g] = D(""), _ = e.attempts.find((e) => e.attemptId === o) ?? e.attempts.at(-1), y = t.find((t) => t.memberId === e.ownerMemberId);
	async function b(t) {
		if (!(!n || c)) {
			if (t === "reject" && !m.trim()) {
				d("请填写需要修改的内容。");
				return;
			}
			l(!0), d("");
			try {
				await n(e, t, t === "reject" ? m.trim() : void 0), p(!1);
			} catch (e) {
				d(e instanceof Error ? e.message : "操作失败。");
			} finally {
				l(!1);
			}
		}
	}
	return /* @__PURE__ */ j("section", {
		className: "team-task-detail",
		children: [
			/* @__PURE__ */ A(B, { status: e.status }),
			/* @__PURE__ */ A("h3", { children: e.title }),
			y && /* @__PURE__ */ j("button", {
				className: "team-member-link",
				type: "button",
				onClick: () => a?.(y),
				disabled: !a,
				children: [
					/* @__PURE__ */ A(z, { name: y.name }),
					y.name,
					/* @__PURE__ */ A("span", { children: "查看执行" })
				]
			}),
			/* @__PURE__ */ A("p", { children: e.description }),
			h(e) && /* @__PURE__ */ A("p", {
				className: "team-detail-reason",
				children: h(e)
			}),
			/* @__PURE__ */ A("h4", { children: "验收要求" }),
			/* @__PURE__ */ A("p", { children: e.acceptanceCriteria || "等待确定验收要求" }),
			e.attempts.length > 1 && /* @__PURE__ */ j("label", {
				className: "team-field",
				children: ["执行记录", /* @__PURE__ */ A("select", {
					value: _?.attemptId,
					onChange: (e) => s(e.target.value),
					children: e.attempts.map((e) => /* @__PURE__ */ j("option", {
						value: e.attemptId,
						children: [
							"第 ",
							e.attemptNumber,
							" 次执行 · ",
							v[e.status]
						]
					}, e.attemptId))
				})]
			}),
			_?.result && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h4", { children: "交付结果" }), /* @__PURE__ */ A(r, { content: _.result })] }),
			_?.artifacts.map((e) => /* @__PURE__ */ A(W, {
				artifact: e,
				onOpen: i
			}, e.artifactId)),
			f && /* @__PURE__ */ j("label", {
				className: "team-field",
				children: [
					"修改意见",
					/* @__PURE__ */ A("textarea", {
						rows: 3,
						maxLength: 2e3,
						value: m,
						onChange: (e) => g(e.target.value)
					}),
					/* @__PURE__ */ A("button", {
						className: "team-button",
						type: "button",
						disabled: c || !m.trim(),
						onClick: () => void b("reject"),
						children: "提交修改意见"
					})
				]
			}),
			n && /* @__PURE__ */ j("div", {
				className: "team-task-actions",
				children: [e.status === "awaiting_acceptance" && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
					className: "team-button team-primary",
					type: "button",
					disabled: c,
					onClick: () => void b("accept"),
					children: "验收通过"
				}), /* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					disabled: c,
					onClick: () => p(!0),
					children: "提出修改"
				})] }), ["failed", "cancelled"].includes(e.status) && /* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					disabled: c,
					onClick: () => void b("retry"),
					children: "重新执行"
				})]
			}),
			u && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: u
			})
		]
	});
}
function ie({ interaction: e, member: t, onRespond: r }) {
	let [i, a] = D({}), [o, s] = D(!1), [c, l] = D(!1), [u, d] = D(""), f = E(null);
	async function p(t, n) {
		if (o || c) return;
		let i = JSON.stringify([
			t,
			n,
			e.revision
		]);
		f.current?.digest !== i && (f.current = {
			digest: i,
			idempotencyKey: F()
		}), s(!0), d("");
		try {
			let i = await r({
				ref: e.ref,
				expectedRevision: e.revision,
				action: t,
				response: n,
				idempotencyKey: f.current.idempotencyKey
			});
			if (i?.status === "rejected" || i?.status === "uncertain") throw Error(i.reason || "审批结果尚未确认，请核对后重试。");
			l(!0);
		} catch (e) {
			d(e instanceof Error ? e.message : "审批提交失败。");
		} finally {
			s(!1);
		}
	}
	return /* @__PURE__ */ j("article", {
		className: "team-interaction-card",
		children: [
			/* @__PURE__ */ j("span", {
				className: "team-eyebrow",
				children: [t?.name || "成员", " · 需要你的确认"]
			}),
			/* @__PURE__ */ A("h3", { children: e.title }),
			/* @__PURE__ */ A(M, { message: e.message }),
			c || e.status === "resolving" ? /* @__PURE__ */ A("p", {
				role: "status",
				children: "已提交，等待执行端确认"
			}) : e.kind === "input" && e.requestSchema ? /* @__PURE__ */ A(n, {
				schema: e.requestSchema,
				values: i,
				onChange: a,
				disabled: o,
				onSubmit: () => void p("submit", i),
				onCancel: () => void p("cancel", {})
			}) : /* @__PURE__ */ j("div", {
				className: "team-task-actions",
				children: [/* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					disabled: o,
					onClick: () => void p("reject", { approved: !1 }),
					children: "拒绝"
				}), /* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button team-primary",
					disabled: o,
					onClick: () => void p("approve", { approved: !0 }),
					children: "同意"
				})]
			}),
			u && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: u
			})
		]
	});
}
function ae({ interactions: e, members: t, onRespond: n }) {
	return /* @__PURE__ */ A("section", {
		className: "team-interactions",
		"aria-label": "团队审批与待处理输入",
		children: e.filter((e) => ["pending", "resolving"].includes(e.status)).map((e) => /* @__PURE__ */ A(ie, {
			interaction: e,
			member: t.find((t) => t.memberId === e.ref.memberId),
			onRespond: n
		}, i(e.ref)))
	});
}
function oe({ members: e, selectedMemberId: t, onSelect: n }) {
	return /* @__PURE__ */ A("div", {
		className: "team-member-list",
		children: e.filter((e) => e.status !== "removed").map((e) => /* @__PURE__ */ j("button", {
			type: "button",
			className: "team-member-row",
			onClick: () => n(e),
			"aria-pressed": t === e.memberId,
			children: [
				/* @__PURE__ */ A(z, { name: e.name }),
				/* @__PURE__ */ j("span", { children: [/* @__PURE__ */ j("strong", { children: [e.name, /* @__PURE__ */ A("small", { children: e.role === "leader" ? "Leader" : "成员" })] }), /* @__PURE__ */ j("span", { children: [L[e.executionStatus], e.binding.kind === "local_build" ? " · 本地" : " · 云端"] })] }),
				/* @__PURE__ */ A("span", {
					"aria-hidden": "true",
					children: "→"
				})
			]
		}, e.memberId))
	});
}
function G({ member: e, observation: t, onDirectedMessage: n, onRetry: i, onCancel: a, cancelPending: o = !1, cancelBusy: s = !1 }) {
	return /* @__PURE__ */ j("section", {
		className: "team-member-inspector",
		children: [
			/* @__PURE__ */ j("div", {
				className: "team-member-heading",
				children: [/* @__PURE__ */ A(z, { name: e.name }), /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("h3", { children: e.name }), /* @__PURE__ */ j("span", {
					className: "team-muted",
					children: [
						e.role === "leader" ? "Leader" : "成员",
						" · ",
						L[e.executionStatus]
					]
				})] })]
			}),
			e.responsibility && /* @__PURE__ */ A("p", {
				className: "team-member-responsibility",
				children: e.responsibility
			}),
			/* @__PURE__ */ j("div", {
				className: "team-member-actions",
				children: [n && /* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					onClick: n,
					children: "在群内 @成员"
				}), a && e.binding.capabilities.cancel && e.activeRunId && /* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					disabled: o || s,
					onClick: a,
					children: s ? "正在提交…" : o ? "已请求停止" : "请求停止此执行"
				})]
			}),
			/* @__PURE__ */ A("p", {
				className: "team-observer-note",
				children: "执行详情只读。关闭面板不会停止成员。"
			}),
			t ? /* @__PURE__ */ j(k, { children: [
				/* @__PURE__ */ A("span", {
					className: "team-connection",
					role: "status",
					children: R[t.connection]
				}),
				t.error && /* @__PURE__ */ A("p", {
					role: "alert",
					className: "team-inline-error",
					children: t.error
				}),
				t.connection === "offline" && i && /* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					onClick: i,
					children: "重新连接"
				}),
				/* @__PURE__ */ A("div", {
					className: "team-member-transcript",
					children: t.items.filter((e) => e.visibility === "public" && !(e.kind === "progress" && Object.keys(e.payload).length === 0)).map((e) => /* @__PURE__ */ j("article", {
						className: "team-observer-item",
						children: [/* @__PURE__ */ A("span", {
							className: "team-eyebrow",
							children: e.kind === "assistant_text" ? "回复" : e.kind === "user_message" ? "输入" : e.kind === "tool_call" ? "工具调用" : e.kind === "reasoning" ? "执行思考" : e.kind
						}), typeof e.payload.text == "string" ? /* @__PURE__ */ A(r, { content: e.payload.text }) : typeof e.payload.error == "string" ? /* @__PURE__ */ A("p", {
							className: "team-inline-error",
							children: e.payload.error
						}) : /* @__PURE__ */ j("details", {
							className: "team-observer-details",
							children: [/* @__PURE__ */ A("summary", { children: String(e.payload.tool || e.payload.summary || e.payload.title || (e.kind === "tool_call" ? "查看工具结果" : "查看事件详情")) }), /* @__PURE__ */ A("pre", { children: JSON.stringify(e.payload, null, 2) })]
						})]
					}, e.itemId))
				}),
				!t.items.length && /* @__PURE__ */ A("p", {
					className: "team-muted",
					children: "尚无可展示的运行事件。"
				})
			] }) : /* @__PURE__ */ A("p", {
				className: "team-muted",
				children: e.activeRunId ? "正在读取执行详情…" : "当前没有进行中的执行。"
			})
		]
	});
}
function se(e) {
	return e.snapshot ? /* @__PURE__ */ A(K, {
		...e,
		snapshot: e.snapshot
	}, `${e.snapshot.group.authorityRef}:${e.snapshot.group.groupId}`) : /* @__PURE__ */ A("section", {
		className: "ksadk-teams team-workspace",
		children: e.loading ? /* @__PURE__ */ j("div", {
			className: "team-loading",
			role: "status",
			"aria-label": "正在加载群组",
			children: [
				/* @__PURE__ */ A("span", {}),
				/* @__PURE__ */ A("span", {}),
				/* @__PURE__ */ A("span", {})
			]
		}) : /* @__PURE__ */ j("div", {
			className: "team-empty",
			children: [
				/* @__PURE__ */ A("h2", { children: e.error ? "群组暂不可用" : "选择一个团队，开始协作" }),
				/* @__PURE__ */ A("p", { children: e.error || "创建群组并选择 Leader，让各有所长的 Agent 共同完成目标。" }),
				e.onRetry && /* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					onClick: e.onRetry,
					children: "重试"
				})
			]
		})
	});
}
function K({ snapshot: e, connection: t = "connected", draft: n, onDraftChange: i, initialDrafts: a, initialSelection: o, onSelectionChange: s, onSend: c, onRetry: l, error: u, onManage: d, serverAuthority: f, standbyCandidates: p, onConfigureStandby: h, onLoadReconciliation: v, onReconcile: b, onControl: x, onAcceptRun: C, onTaskAction: w, onRespondInteraction: T, onOpenArtifact: O, onMemberSelect: M, renderMember: P, onLoadExecution: F }) {
	let [I, L] = D(a?.[o?.teamRunId || m(e)?.teamRunId || ""] || ""), [R, z] = D(""), [ie, se] = D(0), [K, q] = D(null), [J, Y] = D(!1), [ue, de] = D(o?.taskId ?? ""), [X, fe] = D(o?.teamRunId || m(e)?.teamRunId || ""), [pe, me] = D(!1), [he, ge] = D(""), [_e, ve] = D(), [Z, ye] = D(!1), [be, xe] = D(""), [Se, Ce] = D(!1), [we, Te] = D(""), Ee = E(null), De = E(null), Q = E(new Map(Object.entries(a || {}).map(([e, t]) => [e, {
		text: t,
		recipient: ""
	}]))), $ = e.teamRuns.find((e) => e.teamRunId === X) ?? null, Oe = !!(X && !$), ke = e.tasks.filter((e) => e.teamRunId === $?.teamRunId);
	S(() => {
		$ && me(!1);
	}, [$]);
	let Ae = $ ? e.runMembers?.filter((e) => e.teamRunId === $.teamRunId) : void 0, je = $ && e.runMembers ? Ae || [] : e.members.filter((e) => e.status !== "removed"), Me = ke.find((e) => e.taskId === ue), Ne = je.find((e) => e.memberId === he), Pe = [...e.deliveries.filter((e) => e.teamRunId === $?.teamRunId).map((e) => e.runId), ...ke.flatMap((e) => e.attempts.map((e) => e.source?.runId))].filter(Boolean), Fe = !e.runMembers && e.teamRuns.length === 1, Ie = (e) => !!($ && (Pe.includes(e.runId) || Ae?.some((t) => t.sessionId === e.sessionId) || Fe && je.some((t) => t.sessionId === e.sessionId))), Le = e.interactions.filter((e) => Ie(e.ref)), Re = [...new Map([...(e.artifacts || []).filter((e) => Ie(e.source)), ...ke.flatMap((e) => e.attempts.flatMap((e) => e.artifacts))].filter((t) => t.source.groupId === e.group.groupId && t.source.authorityRef === e.group.authorityRef).map((e) => [e.artifactId, e])).values()], ze = Le.filter((e) => e.status === "pending").length + (($?.policy || e.group.policy)?.taskAcceptance === "leader" ? 0 : ke.filter((e) => _(e) === "attention").length), Be = n ?? I;
	function Ve(e) {
		L(e), i?.(e, X), Q.current.set(X, {
			text: e,
			recipient: R
		});
	}
	function He(e) {
		Q.current.set(X, {
			text: Be,
			recipient: R
		});
		let t = Q.current.get(e);
		fe(e), me(!1), de(""), ge(""), ve(void 0), z(t?.recipient || ""), L(t?.text || ""), i?.(t?.text || "", e), xe(""), Ce(!1), Te(""), Y(!1), s?.({
			teamRunId: e,
			taskId: ""
		});
	}
	function Ue(e) {
		de(e), s?.({
			teamRunId: $?.teamRunId ?? "",
			taskId: e
		});
	}
	function We(e) {
		De.current = document.activeElement, q(e), ge("");
	}
	function Ge() {
		q(null), Y(!1), De.current?.focus();
	}
	function Ke(e) {
		z(e.memberId), q(null), Y(!1), se((e) => e + 1);
	}
	function qe(e) {
		ve(void 0), ge(e.memberId), q("members"), M?.(e);
	}
	S(() => {
		K && Ee.current?.focus();
	}, [K]);
	async function Je(e) {
		if (!(!$ || !x || Z)) {
			ye(!0), xe("");
			try {
				await x($, e);
			} catch (e) {
				xe(e instanceof Error ? e.message : "操作失败。");
			} finally {
				ye(!1);
			}
		}
	}
	async function Ye(e) {
		if (!(!$ || !C || Z)) {
			if (!e && !we.trim()) {
				xe("请说明需要修改的内容。");
				return;
			}
			ye(!0), xe("");
			try {
				await C($, e, e ? void 0 : we.trim()), Ce(!1), Te("");
			} catch (e) {
				xe(e instanceof Error ? e.message : "验收提交失败。");
			} finally {
				ye(!1);
			}
		}
	}
	async function Xe(e) {
		let t = await c(e);
		return t?.teamRunId && !e.teamRunId && ["accepted", "duplicate"].includes(t.status) && (Q.current.set("", {
			text: "",
			recipient: ""
		}), fe(t.teamRunId), me(!0), L(""), i?.("", ""), z(""), s?.({
			teamRunId: t.teamRunId,
			taskId: ""
		})), t;
	}
	let Ze = $?.status === "awaiting_acceptance" && C && /* @__PURE__ */ j("section", {
		className: "team-final-delivery",
		"aria-label": "最终验收",
		children: [
			/* @__PURE__ */ A("span", {
				className: "team-eyebrow",
				children: "团队已提交成果"
			}),
			/* @__PURE__ */ A("h3", { children: "请确认这次交付" }),
			$.result && /* @__PURE__ */ A("div", {
				className: "team-final-summary",
				children: /* @__PURE__ */ A(r, { content: $.result })
			}),
			/* @__PURE__ */ A("p", { children: "验收通过后完成任务；提出修改会交给 Leader 继续推进。" }),
			Se && /* @__PURE__ */ j("label", {
				className: "team-field",
				children: ["修改意见", /* @__PURE__ */ A("textarea", {
					value: we,
					onChange: (e) => Te(e.target.value),
					placeholder: "哪些内容需要调整？期望是什么？",
					rows: 3,
					maxLength: 2e3,
					disabled: Z
				})]
			}),
			/* @__PURE__ */ A("div", {
				className: "team-task-actions",
				children: Se ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					disabled: Z,
					onClick: () => Ce(!1),
					children: "取消修改"
				}), /* @__PURE__ */ A("button", {
					className: "team-button team-primary",
					type: "button",
					disabled: Z || !we.trim(),
					onClick: () => void Ye(!1),
					children: "提交修改意见"
				})] }) : /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
					className: "team-button",
					type: "button",
					disabled: Z,
					onClick: () => Ce(!0),
					children: "提出修改"
				}), /* @__PURE__ */ A("button", {
					className: "team-button team-primary",
					type: "button",
					disabled: Z,
					onClick: () => void Ye(!0),
					children: "通过验收"
				})] })
			}),
			be && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: be
			})
		]
	});
	return /* @__PURE__ */ j("section", {
		className: "ksadk-teams team-workspace",
		"data-panel": K || "closed",
		"data-execution": J ? "open" : "closed",
		children: [
			/* @__PURE__ */ A(H, {
				snapshot: e,
				connection: t,
				onProgress: () => We("tasks"),
				onMembers: () => We("members"),
				onManage: d
			}),
			u && /* @__PURE__ */ j("div", {
				className: "team-top-error",
				role: "alert",
				children: [u, l && /* @__PURE__ */ A("button", {
					className: "team-text-button",
					type: "button",
					onClick: l,
					children: "重新连接"
				})]
			}),
			/* @__PURE__ */ j("div", {
				className: "team-body",
				children: [
					/* @__PURE__ */ j("nav", {
						className: "team-run-directory",
						"aria-label": "团队任务",
						children: [/* @__PURE__ */ j("header", { children: [/* @__PURE__ */ A("h2", { children: "任务" }), /* @__PURE__ */ A("button", {
							type: "button",
							className: "team-text-button",
							onClick: () => {
								He(""), se((e) => e + 1);
							},
							children: "＋ 新任务"
						})] }), /* @__PURE__ */ j("div", {
							className: "team-run-list",
							children: [[...e.teamRuns].reverse().map((e) => /* @__PURE__ */ j("button", {
								type: "button",
								className: "team-run-item",
								"aria-current": e.teamRunId === X ? "page" : void 0,
								onClick: () => He(e.teamRunId),
								children: [/* @__PURE__ */ A("strong", { children: e.goal }), /* @__PURE__ */ A(B, { status: e.status })]
							}, e.teamRunId)), !e.teamRuns.length && /* @__PURE__ */ A("p", {
								className: "team-muted",
								children: "每个目标是一个独立任务。"
							})]
						})]
					}),
					/* @__PURE__ */ j("div", {
						className: "team-chat-pane",
						"aria-hidden": J || void 0,
						children: [
							/* @__PURE__ */ j("header", {
								className: "team-task-heading",
								children: [/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("span", {
									className: "team-eyebrow",
									children: $ ? "当前任务" : "新的目标"
								}), /* @__PURE__ */ A("h2", { children: $?.goal || (Oe ? pe ? "正在同步任务…" : "未找到所选任务" : "希望团队完成什么？") })] }), /* @__PURE__ */ A("button", {
									type: "button",
									className: "team-button",
									"aria-label": "查看任务详情",
									onClick: () => We("tasks"),
									children: "详情"
								})]
							}),
							/* @__PURE__ */ j("label", {
								className: "team-mobile-task-picker team-field",
								children: ["切换任务", /* @__PURE__ */ j("select", {
									value: X,
									onChange: (e) => He(e.target.value),
									children: [/* @__PURE__ */ A("option", {
										value: "",
										children: "＋ 新任务"
									}), e.teamRuns.map((e) => /* @__PURE__ */ A("option", {
										value: e.teamRunId,
										children: e.goal
									}, e.teamRunId))]
								})]
							}),
							/* @__PURE__ */ j(U, {
								emptyState: Oe ? /* @__PURE__ */ j("div", {
									className: "team-empty",
									role: "status",
									children: [/* @__PURE__ */ A("p", { children: pe ? "正在读取刚创建的任务，消息已提交。" : "请从任务列表重新选择；当前输入不会发送到其他任务。" }), l && /* @__PURE__ */ A("button", {
										className: "team-button",
										type: "button",
										onClick: l,
										children: "重新读取"
									})]
								}) : void 0,
								focusFinalDelivery: Ze ? $?.teamRunId : void 0,
								messages: e.messages.filter((e) => $ ? e.teamRunId === $.teamRunId || Fe && !e.teamRunId : !1),
								children: [$ && /* @__PURE__ */ A(ee, {
									compact: !0,
									run: $,
									tasks: ke,
									pendingCount: ze,
									onOpen: () => We("tasks")
								}), Ze]
							}, X),
							ze > 0 && /* @__PURE__ */ j("button", {
								type: "button",
								className: "team-attention-banner",
								onClick: () => We("tasks"),
								children: [
									ze,
									" 项需要处理 ",
									/* @__PURE__ */ j("span", { children: ["查看 ", /* @__PURE__ */ A("span", {
										"aria-hidden": "true",
										children: "→"
									})] })
								]
							}),
							/* @__PURE__ */ A(te, {
								serverAuthority: f,
								referenceArtifacts: [...new Map([...e.artifacts || [], ...e.tasks.flatMap((e) => e.attempts.flatMap((e) => e.artifacts))].filter((t) => t.source.groupId === e.group.groupId && t.source.authorityRef === e.group.authorityRef).map((e) => [e.artifactId, e])).values()],
								artifacts: Re,
								recipientMemberId: R,
								onRecipientChange: z,
								focusRequest: ie,
								members: je,
								activeRun: $,
								value: Be,
								onChange: Ve,
								onSend: Xe,
								disabled: e.group.status !== "active" || Oe
							})
						]
					}),
					K && /* @__PURE__ */ j("aside", {
						className: "team-sidepanel",
						ref: Ee,
						tabIndex: -1,
						"aria-label": "任务详情",
						onKeyDown: (e) => {
							e.key === "Escape" && (e.stopPropagation(), Ge());
						},
						children: [
							/* @__PURE__ */ j("header", {
								className: "team-panel-header",
								children: [/* @__PURE__ */ A("nav", {
									className: "team-detail-tabs",
									"aria-label": "任务详情分类",
									children: [
										["tasks", "进度"],
										["members", "成员"],
										["artifacts", "交付物"]
									].map(([e, t]) => /* @__PURE__ */ A("button", {
										type: "button",
										"aria-pressed": K === e,
										onClick: () => We(e),
										children: t
									}, e))
								}), /* @__PURE__ */ A("button", {
									type: "button",
									className: "team-button team-icon-button",
									"aria-label": "关闭详情",
									onClick: Ge,
									children: "×"
								})]
							}),
							/* @__PURE__ */ A("div", {
								className: "team-panel-scroll",
								children: K === "tasks" ? /* @__PURE__ */ j(k, { children: [
									$ && /* @__PURE__ */ j("div", {
										className: "team-run-overview",
										children: [
											/* @__PURE__ */ A(B, { status: $.status }),
											/* @__PURE__ */ A(V, { goal: $.goal }),
											$.reason && /* @__PURE__ */ A("p", { children: $.reason }),
											x && g($.status) && /* @__PURE__ */ j("div", {
												className: "team-run-actions",
												children: [/* @__PURE__ */ A("button", {
													className: "team-text-button",
													type: "button",
													disabled: Z || $.status === "cancel_requested",
													onClick: () => void Je($.dispatchSuspended ? "resume_dispatch" : "suspend_dispatch"),
													children: $.dispatchSuspended ? "继续协作" : "暂停派发"
												}), /* @__PURE__ */ A("button", {
													className: "team-text-button team-danger",
													type: "button",
													disabled: Z || $.status === "cancel_requested",
													onClick: () => void Je("stop"),
													children: "停止任务"
												})]
											}),
											be && !Ze && /* @__PURE__ */ A("p", {
												role: "alert",
												className: "team-inline-error",
												children: be
											}),
											/* @__PURE__ */ A(ce, {
												run: $,
												enabled: f,
												candidates: p || [],
												configure: h
											}),
											/* @__PURE__ */ A(N, {
												run: $,
												onLoadReconciliation: v,
												onReconcile: b
											}, $.teamRunId),
											/* @__PURE__ */ j("details", {
												className: "team-run-budget",
												children: [/* @__PURE__ */ A("summary", { children: "执行限额" }), /* @__PURE__ */ j("dl", { children: [
													/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: "累计启动" }), /* @__PURE__ */ j("dd", { children: [
														$.budget.startsUsed,
														" / ",
														$.budget.maxStarts
													] })] }),
													/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: "同时执行" }), /* @__PURE__ */ j("dd", { children: [
														"最多 ",
														$.budget.maxConcurrent,
														" 个"
													] })] }),
													$.budget.maxTokens && /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: "Token" }), /* @__PURE__ */ j("dd", { children: [
														$.budget.tokensUsed ?? 0,
														" / ",
														$.budget.maxTokens
													] })] }),
													$.budget.maxDurationSeconds && /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: "主动执行时限" }), /* @__PURE__ */ j("dd", { children: [Math.round($.budget.maxDurationSeconds / 60), " 分钟"] })] })
												] })]
											})
										]
									}),
									T && /* @__PURE__ */ A(ae, {
										interactions: Le,
										members: je,
										onRespond: T
									}),
									Me ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
										className: "team-text-button team-back",
										type: "button",
										onClick: () => Ue(""),
										children: "← 所有分工"
									}), /* @__PURE__ */ A(re, {
										task: Me,
										members: je,
										onAction: ($?.policy || e.group.policy)?.taskAcceptance === "leader" ? void 0 : w,
										onOpenArtifact: O,
										onMemberSelect: qe
									}, Me.taskId)] }) : /* @__PURE__ */ A(ne, {
										tasks: ke,
										members: je,
										selectedTaskId: ue,
										onSelect: (e) => Ue(e.taskId)
									})
								] }) : K === "artifacts" ? /* @__PURE__ */ j("section", {
									className: "team-artifact-list",
									children: [/* @__PURE__ */ A("h3", { children: "任务交付物" }), Re.length ? Re.map((e) => /* @__PURE__ */ A(W, {
										artifact: e,
										onOpen: O
									}, e.artifactId)) : /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: "成员发布的成果会保存在这里。"
									})]
								}) : Ne ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
									className: "team-text-button team-back",
									type: "button",
									onClick: () => ge(""),
									children: "← 所有成员"
								}), P?.(Ne, {
									directedMessage: () => Ke(Ne),
									teamRunId: $?.teamRunId
								}, _e) ?? /* @__PURE__ */ A(G, {
									member: Ne,
									onDirectedMessage: () => Ke(Ne)
								})] }) : /* @__PURE__ */ A(oe, {
									members: je,
									selectedMemberId: he,
									onSelect: qe
								})
							}),
							K === "tasks" && (ke.length > 0 || !!(F && $)) && /* @__PURE__ */ A("footer", {
								className: "team-panel-footer",
								children: /* @__PURE__ */ j("button", {
									className: "team-button team-expand",
									type: "button",
									onClick: () => Y(!0),
									children: ["查看执行详情 ", /* @__PURE__ */ A("span", {
										"aria-hidden": "true",
										children: "↗"
									})]
								})
							})
						]
					}),
					J && /* @__PURE__ */ j("section", {
						className: "team-execution-workspace",
						"aria-label": "执行工作台",
						children: [/* @__PURE__ */ j("header", {
							className: "team-panel-header",
							children: [/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("span", {
								className: "team-eyebrow",
								children: "执行详情"
							}), /* @__PURE__ */ A("h2", { children: $?.goal })] }), /* @__PURE__ */ A("button", {
								className: "team-button",
								type: "button",
								onClick: () => Y(!1),
								children: "返回聊天"
							})]
						}), /* @__PURE__ */ A(y, {
							fallback: /* @__PURE__ */ j("div", {
								className: "team-loading",
								role: "status",
								"aria-label": "正在加载执行视图",
								children: [/* @__PURE__ */ A("span", {}), /* @__PURE__ */ A("span", {})]
							}),
							children: /* @__PURE__ */ A(le, {
								authorityRef: e.group.authorityRef,
								groupId: e.group.groupId,
								teamRunId: $?.teamRunId || "",
								watermark: e.watermark,
								load: F,
								tasks: ke,
								members: je,
								selectedTaskId: ue,
								onSelect: (e) => {
									Ue(e.taskId), Y(!1), q("tasks");
								},
								onSelectNode: (e) => {
									e.kind === "task" && e.taskId ? (Ue(e.taskId), q("tasks"), Y(!1)) : e.source && (ge(e.source.memberId), ve(e.source), q("members"), Y(!1));
								}
							}, `${e.group.groupId}:${$?.teamRunId || ""}`)
						})]
					})
				]
			})
		]
	});
}
function ce({ run: e, enabled: t, candidates: n, configure: r }) {
	let [i, a] = D(e.leaderStandby?.standbyBindingRef || ""), [o, s] = D(!1), [c, l] = D(""), [u, d] = D(e.leaderStandby), f = n.filter((e) => e.kind !== "local_build" && ["ready", "unchecked"].includes(e.availability?.state || "") && e.capabilities.leader && e.capabilities.enqueue);
	if (S(() => {
		a(e.leaderStandby?.standbyBindingRef || ""), l(""), d(e.leaderStandby);
	}, [e.teamRunId, e.leaderStandby]), !t || !r || !f.length && !u) return null;
	async function p() {
		if (!(!i || o || !r)) {
			s(!0), l("");
			try {
				d(await r(e, i));
			} catch (e) {
				l(e instanceof Error ? e.message : "备用配置失败。");
			} finally {
				s(!1);
			}
		}
	}
	return /* @__PURE__ */ j("details", {
		className: "team-run-budget team-standby",
		children: [
			/* @__PURE__ */ j("summary", { children: ["云端接管设置", u?.state === "active" ? " · 已接管" : u?.state === "blocked" ? " · 等待恢复" : ""] }),
			u && /* @__PURE__ */ A("p", {
				role: "status",
				children: u.state === "active" ? "云端 Leader 已接管当前任务。" : u.state === "armed" ? "兼容的备用节点已配置；接管前会保存进度并核对原执行。" : {
					standby_offline: "云端备用节点离线，正在等待恢复。",
					checkpoint_required: "正在等待 Leader 保存可恢复的任务进度。",
					execution_uncertain: "正在核对原执行结果，避免重复执行。"
				}[u.reason || ""] || "暂时无法接管，请检查执行状态。"
			}),
			g(e.status) && !!f.length && /* @__PURE__ */ j(k, { children: [
				/* @__PURE__ */ j("label", {
					className: "team-field",
					children: ["Leader 备用节点", /* @__PURE__ */ j("select", {
						value: i,
						onChange: (e) => a(e.target.value),
						disabled: o,
						children: [/* @__PURE__ */ A("option", {
							value: "",
							children: "选择云端节点，保存时检查"
						}), f.map((e) => /* @__PURE__ */ A("option", {
							value: e.bindingRef,
							children: e.name || e.agentId
						}, e.bindingRef))]
					})]
				}),
				/* @__PURE__ */ A("p", { children: "本地 Leader 失联后由备用节点继续。新任务沿用此配置；本地恢复时不抢回当前任务。" }),
				/* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					disabled: o || !i,
					onClick: () => void p(),
					children: o ? "正在校验…" : "配置备用节点"
				})
			] }),
			c && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: c
			})
		]
	});
}
function le({ authorityRef: e, groupId: t, teamRunId: n, watermark: r, load: i, ...a }) {
	let o = E(i), s = !!i;
	S(() => {
		o.current = i;
	}, [i]);
	let [c, l] = D(null), [u, d] = D(""), [f, p] = D(!!i), [m, h] = D(0);
	return S(() => {
		if (!o.current || !n) return;
		let r = new AbortController();
		return o.current(n, r.signal).then((i) => {
			if (!r.signal.aborted) {
				if (i.groupId !== t || i.teamRunId !== n || i.nodes.some((t) => t.source && t.source.authorityRef !== e)) throw Error("执行视图不属于当前协作轮次。");
				l(i), d("");
			}
		}).catch((e) => {
			r.signal.aborted || d(e instanceof Error ? e.message : "执行视图加载失败。");
		}).finally(() => {
			r.signal.aborted || p(!1);
		}), () => r.abort();
	}, [
		e,
		t,
		n,
		r,
		m,
		s
	]), /* @__PURE__ */ A(P, {
		...a,
		execution: c,
		executionLoading: f,
		executionError: u,
		onRetryExecution: i ? () => {
			d(""), p(!0), h((e) => e + 1);
		} : void 0
	});
}
//#endregion
//#region src/core/teams/grouping.ts
var q = (e) => `${e.binding.kind}:${e.binding.agentId}`, J = (e) => e.binding.capabilities.enqueue && e.binding.availability?.state !== "unavailable";
function Y(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(q(n), [...t.get(q(n)) || [], n]);
	return [...t.values()].map((e) => e.sort((e, t) => Number(J(t)) - Number(J(e)) || (t.binding.createdAt || "").localeCompare(e.binding.createdAt || "")));
}
//#endregion
//#region src/components/teams/CreateGroupDialog.tsx
function ue({ open: e, candidates: t, serverAuthority: n, loading: r, error: i, onRefresh: a, hasMore: o, onLoadMore: s, onClose: c, onCreate: u }) {
	let d = E(null), f = C(), [p, m] = D(""), [h, g] = D(""), [_, v] = D([]), [y, b] = D(""), [x, w] = D(""), [T, O] = D(!1), [k, M] = D(""), N = E(null), P = (e) => !!(n && e.binding.availability?.state === "unchecked"), F = (e) => J(e) || P(e), I = (e) => F(e) && (e.binding.capabilities.leader || P(e)), L = _.map((e) => {
		let n = t.find((t) => t.binding.bindingRef === e.binding.bindingRef);
		return n ? {
			...n,
			memberId: e.memberId,
			responsibility: e.responsibility
		} : e;
	}), R = L.filter(I), z = R.some((e) => e.memberId === y) ? y : R[0]?.memberId ?? "", B = L.find((e) => e.memberId === z)?.binding.kind === "local_build", V = t.filter((e) => e.binding.kind === "cloud" && I(e)), H = V.some((e) => e.binding.bindingRef === x) ? x : "", U = Y(t).map((e) => e.sort((e, t) => Number(F(t)) - Number(F(e)))).filter((e) => e.some((e) => `${e.name} ${e.description || ""} ${e.binding.agentId}`.toLowerCase().includes(h.toLowerCase())));
	S(() => {
		let t = d.current;
		if (!t) return;
		let n = document.activeElement;
		return e && !t.open && t.showModal(), !e && t.open && t.close(), () => {
			t.open && t.close(), n?.focus();
		};
	}, [e]);
	function ee(e, t) {
		v((n) => t ? [...n, e] : n.filter((t) => q(t) !== q(e)));
	}
	async function te() {
		if (T || r) return;
		M("");
		let e = {
			name: p.trim(),
			members: L.map((e) => ({
				memberId: e.memberId,
				name: e.name,
				bindingRef: e.binding.bindingRef,
				...e.responsibility?.trim() ? { responsibility: e.responsibility.trim() } : {}
			})),
			leaderMemberId: z,
			...n && B && H ? { leaderStandbyBindingRef: H } : {}
		};
		try {
			if (l(e), L.length < 2) throw Error("请选择至少 2 位成员，一起组成团队。");
			if (L.some((e) => !t.some((t) => t.binding.bindingRef === e.binding.bindingRef && F(t)))) throw Error("已选成员中有 Agent 暂不可用，请更换版本或移除后重试。");
			if (!z) throw Error("所选成员中至少需要一位支持 Leader 的 Agent。");
		} catch (e) {
			M(e instanceof Error ? e.message : "团队配置无效。");
			return;
		}
		let i = JSON.stringify(e);
		N.current?.digest !== i && (N.current = {
			digest: i,
			idempotencyKey: `group-${globalThis.crypto.randomUUID()}`
		}), O(!0);
		try {
			await u({
				...e,
				idempotencyKey: N.current.idempotencyKey
			}), m(""), g(""), v([]), b(""), w(""), N.current = null, c();
		} catch (e) {
			M(e instanceof Error ? e.message : "创建团队失败，已保留你的选择。");
		} finally {
			O(!1);
		}
	}
	return /* @__PURE__ */ A("dialog", {
		ref: d,
		className: "ksadk-teams team-create-dialog",
		"aria-labelledby": f,
		onCancel: (e) => {
			e.preventDefault(), T || c();
		},
		children: /* @__PURE__ */ j("form", {
			onSubmit: (e) => {
				e.preventDefault(), te();
			},
			children: [
				/* @__PURE__ */ j("header", { children: [/* @__PURE__ */ j("div", { children: [
					/* @__PURE__ */ A("span", {
						className: "team-eyebrow",
						children: "新的协作空间"
					}),
					/* @__PURE__ */ A("h2", {
						id: f,
						children: "组建团队"
					}),
					/* @__PURE__ */ A("p", { children: "选择搭档，让 Leader 组织分工与复核。" })
				] }), /* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button team-icon-button",
					"aria-label": "关闭创建团队",
					onClick: c,
					disabled: T,
					children: "×"
				})] }),
				/* @__PURE__ */ j("div", {
					className: "team-create-body",
					children: [
						/* @__PURE__ */ j("label", {
							className: "team-field",
							children: ["团队名称", /* @__PURE__ */ A("input", {
								value: p,
								onChange: (e) => m(e.target.value),
								placeholder: "例如：产品交付团队",
								maxLength: 100,
								disabled: T,
								required: !0
							})]
						}),
						/* @__PURE__ */ j("fieldset", {
							disabled: T,
							children: [
								/* @__PURE__ */ j("legend", { children: ["选择成员 ", /* @__PURE__ */ j("span", { children: [_.length, " / 8"] })] }),
								/* @__PURE__ */ j("div", {
									className: "team-directory-search",
									children: [/* @__PURE__ */ A("input", {
										"aria-label": "搜索 Agent",
										value: h,
										onChange: (e) => g(e.target.value),
										placeholder: "搜索名称或职责"
									}), a && /* @__PURE__ */ A("button", {
										type: "button",
										className: "team-text-button",
										disabled: r,
										onClick: a,
										children: "刷新"
									})]
								}),
								r && /* @__PURE__ */ A("p", {
									role: "status",
									className: "team-muted",
									children: "正在读取 Agent…"
								}),
								i && /* @__PURE__ */ A("p", {
									role: "alert",
									className: "team-inline-error",
									children: i
								}),
								!r && !t.length ? /* @__PURE__ */ A("p", {
									className: "team-muted",
									children: "还没有 Agent。先创建 Agent 并完成构建，再回来组队。"
								}) : /* @__PURE__ */ j("div", {
									className: "team-candidate-list",
									children: [U.map((e) => {
										let t = L.find((t) => q(t) === q(e[0])), n = t || e[0], i = n.binding.kind === "local_build" ? "本地" : "云端", a = P(n) ? "创建时验证执行能力" : n.description || n.binding.description || (n.binding.capabilities.leader ? "可担任 Leader" : "任务成员");
										return /* @__PURE__ */ j("div", {
											className: "team-candidate-group",
											children: [/* @__PURE__ */ j("label", {
												className: "team-candidate",
												"data-selected": !!t,
												children: [
													/* @__PURE__ */ A("input", {
														type: "checkbox",
														checked: !!t,
														disabled: r || !t && (!F(n) || _.length >= 8),
														onChange: (e) => ee(n, e.target.checked)
													}),
													/* @__PURE__ */ A("span", {
														className: "team-avatar",
														"aria-hidden": "true",
														children: Array.from(n.name)[0]
													}),
													/* @__PURE__ */ j("span", { children: [
														/* @__PURE__ */ A("strong", {
															title: n.name,
															children: n.name
														}),
														/* @__PURE__ */ A("small", {
															className: "team-candidate-description",
															title: a,
															children: a
														}),
														!F(n) && /* @__PURE__ */ A("small", {
															className: "team-candidate-reason",
															children: n.binding.availability?.reason || "当前不支持团队执行"
														})
													] }),
													/* @__PURE__ */ A("span", {
														className: "team-source",
														"data-available": F(n),
														"data-state": n.binding.availability?.state,
														title: n.binding.availability?.reason || (n.binding.availability?.state === "unchecked" ? "创建时检查执行环境" : void 0),
														children: i
													})
												]
											}), t && /* @__PURE__ */ j("details", {
												className: "team-version-choice",
												children: [
													/* @__PURE__ */ A("summary", { children: "职责与版本" }),
													/* @__PURE__ */ j("label", {
														className: "team-field",
														children: ["工作职责", /* @__PURE__ */ A("textarea", {
															"aria-label": `${n.name} 的工作职责`,
															rows: 2,
															maxLength: 2e3,
															value: n.responsibility || "",
															onChange: (e) => {
																let t = e.target.value;
																v((e) => e.map((e) => q(e) === q(n) ? {
																	...e,
																	responsibility: t
																} : e));
															},
															placeholder: "例如：核对实现边界，补充测试证据"
														})]
													}),
													/* @__PURE__ */ j("p", { children: ["模型：", n.binding.modelName || "沿用固定版本配置"] }),
													/* @__PURE__ */ j("label", {
														className: "team-field",
														children: ["执行版本", /* @__PURE__ */ A("select", {
															"aria-label": `${n.name} 的执行版本`,
															value: n.binding.bindingRef,
															onChange: (t) => {
																let r = e.find((e) => e.binding.bindingRef === t.target.value);
																v((e) => e.map((e) => q(e) === q(n) ? {
																	...r,
																	memberId: e.memberId,
																	responsibility: e.responsibility
																} : e));
															},
															children: e.map((e) => /* @__PURE__ */ j("option", {
																value: e.binding.bindingRef,
																disabled: !F(e),
																children: [e.binding.version || e.binding.buildId || e.binding.bindingRef, F(e) ? "" : " · 不可用"]
															}, e.binding.bindingRef))
														})]
													})
												]
											})]
										}, q(n));
									}), !U.length && !!t.length && /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: "没有匹配的 Agent。"
									})]
								}),
								o && s && /* @__PURE__ */ A("button", {
									type: "button",
									className: "team-button",
									disabled: r || T,
									onClick: s,
									children: "加载更多成员"
								}),
								_.filter((e) => !t.some((t) => t.binding.bindingRef === e.binding.bindingRef)).map((e) => /* @__PURE__ */ j("p", {
									className: "team-inline-error",
									children: [
										e.name,
										" · 当前目录中不可用 ",
										/* @__PURE__ */ A("button", {
											type: "button",
											className: "team-text-button",
											onClick: () => ee(e, !1),
											children: "移除"
										})
									]
								}, e.memberId))
							]
						}),
						/* @__PURE__ */ j("label", {
							className: "team-field",
							children: [
								"指定 Leader",
								/* @__PURE__ */ j("select", {
									value: z,
									onChange: (e) => b(e.target.value),
									disabled: T || !R.length,
									children: [/* @__PURE__ */ A("option", {
										value: "",
										disabled: !0,
										children: "从已选成员中指定"
									}), R.map((e) => /* @__PURE__ */ j("option", {
										value: e.memberId,
										children: [e.name, P(e) ? " · 创建时验证" : ""]
									}, e.memberId))]
								}),
								/* @__PURE__ */ j("small", { children: ["Leader 审核成员成果，你处理工具审批和最终验收。", R.some(P) && " 待检查候选需通过服务端能力验证后才能担任 Leader。"] })
							]
						}),
						n && B && /* @__PURE__ */ j("details", {
							className: "team-version-choice",
							children: [
								/* @__PURE__ */ A("summary", { children: "本地离线时继续协作" }),
								/* @__PURE__ */ j("label", {
									className: "team-field",
									children: ["Leader 云端备用", /* @__PURE__ */ j("select", {
										value: H,
										onChange: (e) => w(e.target.value),
										disabled: T || r,
										children: [/* @__PURE__ */ A("option", {
											value: "",
											children: "暂不配置"
										}), V.map((e) => /* @__PURE__ */ j("option", {
											value: e.binding.bindingRef,
											children: [
												e.name,
												" · ",
												P(e) ? "创建时验证" : e.binding.version || e.binding.buildId || "固定版本"
											]
										}, e.binding.bindingRef))]
									})]
								}),
								/* @__PURE__ */ A("p", {
									className: "team-muted",
									children: "服务端验证同一发布及实际执行能力后，备用才可启用。云端模型、工具和任务资料需预先准备；本地凭据不会复制到云端。"
								}),
								!V.length && /* @__PURE__ */ A("p", {
									className: "team-muted",
									children: "还没有可用的云端 Leader 候选。可以先创建团队，接入节点后再配置。"
								})
							]
						}),
						/* @__PURE__ */ A("p", {
							className: "team-create-footnote",
							children: "创建时检查选中成员的执行环境；配置失败会保留草稿。"
						}),
						k && /* @__PURE__ */ A("p", {
							role: "alert",
							className: "team-inline-error",
							children: k
						})
					]
				}),
				/* @__PURE__ */ j("footer", { children: [/* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					onClick: c,
					disabled: T,
					children: "稍后继续"
				}), /* @__PURE__ */ A("button", {
					type: "submit",
					className: "team-button team-primary",
					disabled: T || r || L.length < 2,
					children: T ? "正在检查并创建…" : "创建团队"
				})] })
			]
		})
	});
}
//#endregion
//#region src/hooks/useTeamChat.ts
var de = class {
	value = {
		snapshot: null,
		connection: "closed",
		error: null,
		draft: ""
	};
	listeners = /* @__PURE__ */ new Set();
	abort;
	generation = 0;
	client;
	groupId;
	authorityRef;
	constructor(e, t, n) {
		this.client = e, this.groupId = t, this.authorityRef = n;
	}
	getSnapshot = () => this.value;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	update(e) {
		this.value = {
			...this.value,
			...e
		}, this.listeners.forEach((e) => e());
	}
	setDraft = (e) => this.update({ draft: e });
	start = () => {
		this.disconnect();
		let e = ++this.generation, t = new AbortController();
		this.abort = t;
		let n = () => e === this.generation && !t.signal.aborted;
		this.update({
			error: null,
			connection: "connecting"
		}), this.client.watch(this.groupId, {
			signal: t.signal,
			onSnapshot: (e) => {
				if (n()) {
					if (e.group.authorityRef !== this.authorityRef) throw new a("scope_mismatch", "群授权域发生变化，请重新打开。");
					this.update({ snapshot: e });
				}
			},
			onConnection: (e) => {
				n() && this.update({ connection: e });
			},
			onError: (e) => {
				n() && this.update({ error: e.message });
			}
		}).catch((e) => {
			n() && this.update({
				connection: "offline",
				error: e instanceof Error ? e.message : "群连接失败。"
			});
		});
	};
	disconnect = () => {
		this.generation++, this.abort?.abort(), this.abort = void 0;
	};
	send = (e) => this.client.send(this.groupId, e);
};
function X(e) {
	let t = T(() => new de(e.client, e.groupId, e.authorityRef), [
		e.client,
		e.groupId,
		e.authorityRef
	]), n = O(t.subscribe, t.getSnapshot, t.getSnapshot);
	return S(() => (t.start(), t.disconnect), [t]), {
		...n,
		loading: !n.snapshot && n.connection === "connecting",
		setDraft: t.setDraft,
		send: t.send,
		reconnect: t.start
	};
}
//#endregion
//#region src/components/teams/CloudEffectsPanel.tsx
function fe({ scope: e, teamRunId: t, product: n, canWrite: r, refreshKey: i, pendingEffectKeys: a, command: o }) {
	let [s, c] = D([]), [l, u] = D(null), [d, p] = D(!1), [m, h] = D(!1), [g, _] = D(""), [v, y] = D(null), [b, w] = D(""), [T, O] = D(!1), [k, M] = D(!1), [N, P] = D(""), F = E(null), I = E(0), L = E(null), R = f(e), z = C(), B = x(async (r = 0) => {
		F.current?.abort();
		let i = new AbortController();
		F.current = i;
		let a = ++I.current;
		p(!0), _("");
		try {
			let o = await n.effects(e, t, i.signal, r);
			if (i.signal.aborted || a !== I.current) return;
			c((e) => r ? [...e.filter((e) => !o.items.some((t) => t.effectKey === e.effectKey)), ...o.items] : o.items), u(o.nextCursor), h(!0);
		} catch {
			!i.signal.aborted && a === I.current && _("执行记录读取失败，请重试。当前不能据此判断外部操作是否完成。");
		} finally {
			!i.signal.aborted && a === I.current && p(!1);
		}
	}, [
		R,
		t,
		n
	]);
	S(() => (B(), () => F.current?.abort()), [B, i]), S(() => {
		v && L.current?.scrollIntoView?.({ block: "nearest" });
	}, [v?.effect.effectKey]);
	let V = v ? s.find((e) => e.effectKey === v.effect.effectKey) : void 0, H = !!(v && m && (!V || V.revision !== v.effect.revision || V.evidenceDigest !== v.effect.evidenceDigest)), U = !!(v && a.includes(v.effect.effectKey));
	async function ee() {
		if (!(!v || !r || g || d || k || H || U || !T || !b.trim())) {
			M(!0), P("");
			try {
				await o(`effects/${v.effect.effectKey}/reconcile`, {
					expectedRevision: v.effect.revision,
					expectedEvidenceDigest: v.effect.evidenceDigest,
					decision: "accept_risk",
					evidenceRef: v.evidenceRef,
					reason: b.trim()
				}), y(null), w(""), O(!1), B();
			} catch (e) {
				P(e instanceof Error ? e.message : "核查决定尚未确认，请核对原单。"), B();
			} finally {
				M(!1);
			}
		}
	}
	return /* @__PURE__ */ j("section", {
		className: "team-effect-review",
		"aria-label": "外部操作核查",
		children: [
			/* @__PURE__ */ j("header", {
				className: "team-effect-review-header",
				children: [/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("h3", { children: "外部操作核查" }), /* @__PURE__ */ A("p", {
					className: "team-muted",
					children: "结果未确认的操作需要核查后再继续。核查决定会保留记录。"
				})] }), /* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					disabled: d,
					onClick: () => void B(),
					children: "刷新记录"
				})]
			}),
			g && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: g
			}),
			d && /* @__PURE__ */ A("p", {
				role: "status",
				className: "team-muted",
				children: "正在读取原执行记录…"
			}),
			m && !d && !g && !s.length && /* @__PURE__ */ A("p", {
				className: "team-muted",
				children: l ? "这一页没有待核查操作，请继续读取后续记录。" : "当前任务没有待核查的外部操作。"
			}),
			s.map((e) => /* @__PURE__ */ j("article", {
				className: "team-effect-card",
				children: [
					/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("strong", { children: e.toolName }), /* @__PURE__ */ A("span", {
						className: "team-effect-state",
						children: e.resolutionConflict ? "核查后收到不同证据" : e.phase === "prepared" ? "执行结果待核对" : "外部结果未确认"
					})] }),
					/* @__PURE__ */ A("p", {
						className: "team-muted",
						children: e.resolutionConflict ? "新证据与已有核查决定不一致，后续处理保持暂停。请重新核对原记录，并记录新的决定。" : "系统保留了原操作，不会因断线或重启自动重复发送。请先查看外部系统。"
					}),
					e.outcome?.evidence_ref && /* @__PURE__ */ j("p", {
						className: "team-muted",
						children: ["原执行证据：", e.outcome.evidence_ref]
					}),
					/* @__PURE__ */ A("button", {
						type: "button",
						className: "team-button",
						disabled: !r || !!g || k || a.includes(e.effectKey),
						onClick: () => {
							y({
								effect: e,
								evidenceRef: `manual-review:${crypto.randomUUID()}`
							}), w(""), O(!1), P("");
						},
						children: a.includes(e.effectKey) ? "等待核对原单" : "记录核查决定"
					})
				]
			}, e.effectKey)),
			l !== null && /* @__PURE__ */ A("button", {
				className: "team-button team-history-more",
				type: "button",
				disabled: d,
				onClick: () => void B(l),
				children: "更多执行记录"
			}),
			v && /* @__PURE__ */ j("form", {
				ref: L,
				className: "team-effect-form",
				onSubmit: (e) => {
					e.preventDefault(), ee();
				},
				children: [
					/* @__PURE__ */ j("h3", { children: ["核查 ", v.effect.toolName] }),
					/* @__PURE__ */ A("p", {
						className: "team-muted",
						children: "此操作记录你接受剩余不确定性的决定，不会重新调用外部工具，也不会将原执行标记为成功。"
					}),
					/* @__PURE__ */ j("label", {
						className: "team-field",
						htmlFor: z,
						children: ["核查说明", /* @__PURE__ */ A("textarea", {
							id: z,
							value: b,
							maxLength: 1e3,
							rows: 3,
							disabled: k || U,
							onChange: (e) => w(e.target.value),
							placeholder: "说明查验了什么、得到什么结果，以及继续处理的依据。"
						})]
					}),
					/* @__PURE__ */ j("label", {
						className: "team-effect-consent",
						children: [/* @__PURE__ */ A("input", {
							type: "checkbox",
							checked: T,
							disabled: k || U,
							onChange: (e) => O(e.target.checked)
						}), /* @__PURE__ */ A("span", { children: "我已核对外部记录，接受剩余不确定性并允许后续处理。" })]
					}),
					H && /* @__PURE__ */ j("p", {
						role: "alert",
						children: ["记录已更新，核查说明已保留。", V && /* @__PURE__ */ A("button", {
							type: "button",
							className: "team-text-button",
							onClick: () => {
								y({
									...v,
									effect: V
								}), O(!1);
							},
							children: "读取最新证据后重新核对"
						})]
					}),
					U && /* @__PURE__ */ A("p", {
						role: "status",
						children: "决定已保存在本地，服务端接收结果仍待确认。请在操作记录中核对原单。"
					}),
					N && /* @__PURE__ */ A("p", {
						role: "alert",
						className: "team-inline-error",
						children: N
					}),
					/* @__PURE__ */ j("div", {
						className: "team-task-actions",
						children: [/* @__PURE__ */ A("button", {
							type: "button",
							className: "team-button",
							disabled: k,
							onClick: () => y(null),
							children: "收起"
						}), /* @__PURE__ */ A("button", {
							type: "submit",
							className: "team-button team-primary",
							disabled: !r || !!g || d || k || H || U || !T || !b.trim(),
							children: k ? "正在记录…" : "记录核查决定"
						})]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/teams/CloudTeamWorkspace.tsx
var pe = {
	operations: [],
	recovering: !1,
	errorCode: null
}, me = () => () => {}, he = () => pe, ge = (e) => e.endsWith("/messages") ? "团队消息" : e.endsWith("/control") ? "任务控制" : e.endsWith("/interactions") ? "审批回复" : e.endsWith("/acceptance") ? "任务验收" : e.endsWith("/actions") ? "子任务操作" : e.endsWith("/reconcile") ? "执行核查决定" : "创建团队", _e = {
	queued: "等待提交",
	sending: "正在核对原单",
	confirmed: "服务端已接收",
	rejected: "请求被拒绝",
	uncertain: "接收结果未确认"
}, ve = {
	connecting: "正在读取工作区",
	connected: "实时连接",
	reconnecting: "正在恢复连接 · 执行状态待同步",
	offline: "连接中断 · 显示最后同步状态",
	closed: "尚未连接"
}, Z = {
	idle: "空闲",
	queued: "排队中",
	running: "执行中",
	waiting: "等待中",
	needs_attention: "需要处理",
	unavailable: "不可用"
}, ye = (e) => e === "execution_preparation_expired" ? "准备时间过长，执行授权已过期。尚未开始执行，可重新提交请求或重试任务。" : e, be = {
	armed: {
		label: "已配置备用 Leader",
		description: "已配置备用执行端，当前仍由原 Leader 负责。"
	},
	fencing_old: {
		label: "正在停止原 Leader",
		description: "正在撤销原执行授权，确认后再启动备用 Leader。"
	},
	waiting_old_grant: {
		label: "等待原授权失效",
		description: "原执行授权尚未确认结束，备用 Leader 暂不执行。"
	},
	activating: {
		label: "正在启动备用 Leader",
		description: "原授权已隔离，正在恢复本轮任务上下文。"
	},
	active: {
		label: "备用 Leader 已接管",
		description: "当前由备用 Leader 继续处理本轮任务。"
	},
	blocked: {
		label: "Leader 接管暂时受阻",
		description: "接管条件尚未满足，需要先处理以下原因。"
	}
}, xe = {
	effect_reconciliation_required: "存在结果未确认的外部操作，核对后才能继续接管。",
	release_verification_required: "尚未确认备用执行端与原 Leader 使用相同的发布内容。",
	standby_probe_unavailable: "暂时无法确认备用执行端的可用状态。",
	standby_capability_unavailable: "备用执行端暂不具备本轮任务所需的能力。",
	binding_revision_mismatch: "执行端配置已变化，需要重新验证。",
	standby_binding_mismatch: "备用执行端与本轮任务的预设配置不一致。",
	original_context_unavailable: "原执行上下文暂不可用。",
	grant_lookup_uncertain: "原执行授权的状态尚未确认。",
	material_not_ready: "任务材料尚未准备就绪。",
	leader_takeover_conflict: "本轮任务状态已变化，暂时不能接管。"
};
function Se({ value: e }) {
	let t = be[e.state];
	return /* @__PURE__ */ j("section", {
		className: "team-cloud-standby",
		"aria-label": "Leader 接管状态",
		"data-state": e.state,
		role: "status",
		children: [
			/* @__PURE__ */ A("strong", { children: t.label }),
			/* @__PURE__ */ A("p", { children: t.description }),
			e.reason && /* @__PURE__ */ A("p", {
				className: "team-cloud-standby-reason",
				children: xe[e.reason] || `服务端原因：${e.reason}`
			})
		]
	});
}
function Ce(e) {
	let [t, n] = D(null), [r, i] = D(""), a = f(e.scope);
	return S(() => {
		let t, r = !0, a = new u(e.scope, e.transport);
		return (async () => {
			try {
				t = new c({ scope: e.scope }, e.product), t.setWritable(!1), await t.refresh(), r && (n({
					observer: a,
					operations: t
				}), i(""));
			} catch {
				t?.dispose(), r && (i("当前浏览器无法打开持久操作存储，工作区仅供查看。"), n({
					observer: a,
					operations: null
				}));
			}
		})(), a.observe(e.initialRunId), () => {
			r = !1, a.dispose(), t?.dispose();
		};
	}, [
		a,
		e.transport,
		e.product
	]), !t || f(t.observer.scope) !== a ? /* @__PURE__ */ A("section", {
		className: "ksadk-teams team-workspace",
		children: /* @__PURE__ */ A("p", {
			role: r ? "alert" : "status",
			className: "team-cloud-notice",
			children: r || "正在准备团队工作区…"
		})
	}) : /* @__PURE__ */ A(we, {
		...e,
		readOnlyReason: r || e.readOnlyReason,
		resources: t
	});
}
function we({ resources: e, ...t }) {
	let { observer: n, operations: r } = e, { onSelectionChange: i, onChanged: a } = t, s = O(n.subscribe, n.getSnapshot, n.getSnapshot), c = O(r?.subscribe ?? me, r?.getSnapshot ?? he, r?.getSnapshot ?? he), [l, u] = D(""), [d, p] = D(!1), [m, h] = D(""), [g, _] = D(null), v = E(0), [y, b] = D(() => typeof navigator > "u" || navigator.onLine);
	S(() => {
		let e = () => b(navigator.onLine);
		return window.addEventListener("online", e), window.addEventListener("offline", e), () => {
			window.removeEventListener("online", e), window.removeEventListener("offline", e);
		};
	}, []);
	let x = s.projection?.snapshot.group.status === "archived", C = !!r && y && !x && t.canWrite && s.connection === "connected";
	S(() => {
		r && (r.setWritable(C), C ? r.recover() : r.refresh());
	}, [r, C]), S(() => {
		if (!r) return;
		let e = () => {
			r.refresh(), document.visibilityState === "visible" && navigator.onLine && C && r.recover();
		};
		window.addEventListener("online", e), window.addEventListener("focus", e);
		let t = window.setInterval(e, 15e3);
		return () => {
			window.removeEventListener("online", e), window.removeEventListener("focus", e), clearInterval(t);
		};
	}, [r, C]);
	async function w(e, i) {
		if (!C || !r) throw Error("当前为只读状态，请恢复连接后重试。");
		u("");
		let a = await r.submit({
			operation: `groups/${t.scope.groupId}/${e}`,
			payload: i
		});
		if (e === "messages" && !["confirmed", "rejected"].includes(a.status) && _(a.operationId), a.status !== "confirmed") throw Error(a.status === "rejected" ? `请求未被接受（${a.errorCode || "operation_rejected"}）。` : "已保存操作，接收结果尚未确认。请在操作记录中核对原单，不要重复创建目标。");
		return t.onChanged?.(), n.refresh(), a;
	}
	S(() => {
		if (!(!r || !g)) return r.subscribe(() => {
			let e = r.getSnapshot().operations.find((e) => e.operationId === g);
			if (!e || !["confirmed", "rejected"].includes(e.status) || (_(null), e.status === "rejected")) return;
			u("");
			let t = n.getSnapshot(), o = e.payload.parts, s = Array.isArray(o) ? o.filter((e) => e && typeof e == "object" && !Array.isArray(e) && e.kind === "text").map((e) => e.text).join("") : "", c = e.payload.intent === "start_goal", l = c ? m.trim() === s : t.selectedRunId === e.payload.teamRunId && t.draft.trim() === s;
			c && l && (h(""), p(!1)), !c && typeof e.payload.teamRunId == "string" && n.acknowledgeDraft(e.payload.teamRunId, s);
			let f = e.receipt?.teamRunId;
			typeof f == "string" && l && (!c || d) ? (n.observe(f), i?.(f)) : n.refresh(), a?.();
		});
	}, [
		r,
		n,
		g,
		m,
		d,
		i,
		a
	]);
	let T = c.operations.some((e) => e.operation.endsWith("/messages") && !["confirmed", "rejected"].includes(e.status) && (d ? e.payload.intent === "start_goal" : e.payload.teamRunId === s.selectedRunId || !s.selectedRunId && e.payload.intent === "start_goal")), k = (e) => {
		v.current++, p(!1), u(""), n.observe(e), t.onSelectionChange?.(e);
	};
	return /* @__PURE__ */ A(Te, {
		observation: s,
		canWrite: C,
		readOnlyReason: y ? x ? "团队已归档，历史记录仍可查看。" : t.readOnlyReason : "浏览器已离线，草稿与待确认操作会保留。",
		onRetry: () => n.refresh(),
		onLoadMore: (e) => {
			n.loadMore(e).catch(() => u("分页读取失败。可重试；快照过期时会自动重新同步。"));
		},
		onChooseRun: k,
		onNewGoal: () => {
			v.current++, p(!0);
		},
		newGoal: d,
		composer: /* @__PURE__ */ A(Ee, {
			scope: t.scope,
			product: t.product,
			observation: s,
			newGoal: d,
			pendingMessage: T,
			canWrite: C,
			value: d ? m : s.draft,
			onChange: (e) => d ? h(e) : n.setDraft(e),
			onCancelNew: () => {
				v.current++, p(!1);
			},
			onSubmit: async (e) => {
				let t = v.current, r = Array.isArray(e.parts) ? e.parts.map((e) => e && typeof e == "object" && !Array.isArray(e) && e.kind === "text" ? e.text : "").join("") : "", i = await w("messages", e);
				if (typeof e.teamRunId == "string" && n.acknowledgeDraft(e.teamRunId, r), v.current !== t) return;
				d && h((e) => e.trim() === r ? "" : e);
				let a = i.receipt?.teamRunId;
				typeof a == "string" && k(a);
			}
		}, d ? "new" : s.selectedRunId ?? "empty"),
		operations: /* @__PURE__ */ j("section", {
			className: "team-cloud-operations",
			"aria-label": "操作记录",
			children: [
				/* @__PURE__ */ j("header", { children: [/* @__PURE__ */ A("strong", { children: "操作记录" }), /* @__PURE__ */ A("button", {
					className: "team-text-button",
					type: "button",
					disabled: !C || c.recovering,
					onClick: () => void r?.recover(),
					children: c.recovering ? "正在核对…" : "核对待确认操作"
				})] }),
				c.errorCode && /* @__PURE__ */ j("p", {
					role: "alert",
					children: [
						"持久操作存储暂不可用（",
						c.errorCode,
						"）。"
					]
				}),
				c.operations.slice(-8).reverse().map((e) => /* @__PURE__ */ j("p", {
					"data-status": e.status,
					children: [/* @__PURE__ */ A("span", { children: ge(e.operation) }), /* @__PURE__ */ A("span", { children: _e[e.status] })]
				}, e.operationId)),
				!c.operations.length && /* @__PURE__ */ A("p", {
					className: "team-muted",
					children: "操作在发送前保存；刷新后继续核对。"
				})
			]
		}),
		error: l,
		renderTasks: (e) => /* @__PURE__ */ A(De, {
			task: e,
			scope: t.scope,
			product: t.product,
			canWrite: C,
			command: w
		}, `${e.taskId}:${e.revision}`),
		effects: t.effectsEnabled && s.selectedRunId ? /* @__PURE__ */ A(fe, {
			scope: t.scope,
			teamRunId: s.selectedRunId,
			product: t.product,
			canWrite: C,
			command: w,
			refreshKey: `${s.projection?.snapshot.watermark ?? 0}:${c.operations.map((e) => `${e.operationId}:${e.status}`).join("|")}`,
			pendingEffectKeys: c.operations.filter((e) => !["confirmed", "rejected"].includes(e.status)).map((e) => /^groups\/[^/]+\/effects\/([^/]+)\/reconcile$/.exec(e.operation)?.[1]).filter((e) => !!e)
		}, `${f(t.scope)}:${s.selectedRunId}`) : void 0,
		renderInteraction: (e) => /* @__PURE__ */ A($, {
			summary: e,
			scope: t.scope,
			product: t.product,
			canWrite: C,
			command: w
		}, `${o(e)}:${e.revision}`),
		artifactUrl: (e, n) => t.product.artifactUrl(t.scope, e, n),
		onControl: (e) => {
			let t = s.projection?.snapshot.selectedRun;
			t && w(`team-runs/${t.teamRunId}/control`, {
				action: e,
				expectedRevision: t.revision
			}).catch((e) => u(e instanceof Error ? e.message : "操作失败。"));
		},
		onAcceptance: (e, t) => {
			let n = s.projection?.snapshot.selectedRun;
			n && w(`team-runs/${n.teamRunId}/acceptance`, {
				action: e,
				expectedRevision: n.revision,
				...t ? { reason: t } : {}
			}).catch((e) => u(e instanceof Error ? e.message : "操作失败。"));
		}
	});
}
function Te(e) {
	let { observation: t, canWrite: n, onLoadMore: i } = e, a = t.projection?.snapshot, [s, c] = D("messages"), [l, u] = D(""), d = C(), f = E(null), p = E(null), m = `${a?.selectedRun?.teamRunId ?? ""}:${s}:${!!e.newGoal}`, h = () => {
		let e = f.current;
		if (!e || s !== "messages") return;
		let t = e.getBoundingClientRect().top, n = Array.from(e.querySelectorAll("[data-message-id]")).find((e) => e.getBoundingClientRect().bottom > t);
		p.current = {
			context: m,
			bottom: e.scrollHeight - e.clientHeight - e.scrollTop < 48,
			anchorId: n?.dataset.messageId,
			anchorOffset: n ? n.getBoundingClientRect().top - t : void 0
		};
	};
	w(() => {
		let e = f.current;
		if (!e || s !== "messages") {
			p.current = null;
			return;
		}
		let t = p.current;
		if (!t || t.context !== m || t.bottom) e.scrollTop = e.scrollHeight;
		else if (t.anchorId && t.anchorOffset !== void 0) {
			let n = Array.from(e.querySelectorAll("[data-message-id]")).find((e) => e.dataset.messageId === t.anchorId);
			n && (e.scrollTop += n.getBoundingClientRect().top - e.getBoundingClientRect().top - t.anchorOffset);
		}
		h();
	}, [m, a?.recentMessages]);
	let _ = (e, n = "加载更多") => a?.cursors[e] && /* @__PURE__ */ A("button", {
		className: "team-button team-history-more",
		type: "button",
		disabled: t.loadingPages.includes(e) || t.connection !== "connected",
		onClick: () => i(e),
		children: t.loadingPages.includes(e) ? "正在读取…" : n
	});
	if (!a) return /* @__PURE__ */ A("section", {
		className: "ksadk-teams team-workspace",
		children: /* @__PURE__ */ j("div", {
			className: "team-empty",
			children: [
				/* @__PURE__ */ A("h2", { children: t.connection === "offline" ? "暂时无法读取团队" : "正在打开工作区" }),
				/* @__PURE__ */ A("p", {
					role: "status",
					children: ve[t.connection]
				}),
				t.errorCode && /* @__PURE__ */ A("p", {
					role: "alert",
					children: t.errorCode
				}),
				/* @__PURE__ */ A("button", {
					type: "button",
					className: "team-button",
					onClick: e.onRetry,
					children: "重新连接"
				})
			]
		})
	});
	let v = a.selectedRun, y = v ? a.selectedRunMembers : a.members;
	return /* @__PURE__ */ j("section", {
		className: "ksadk-teams team-workspace team-cloud-workspace",
		"aria-label": "云端团队工作区",
		children: [
			/* @__PURE__ */ j("header", {
				className: "team-header",
				children: [/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("span", {
					className: "team-eyebrow",
					children: "云端协作空间"
				}), /* @__PURE__ */ A("h1", { children: a.group.name })] }), /* @__PURE__ */ j("div", {
					className: "team-header-actions",
					children: [/* @__PURE__ */ A("span", {
						className: "team-connection",
						role: "status",
						children: ve[t.connection]
					}), /* @__PURE__ */ A("button", {
						type: "button",
						className: "team-button",
						onClick: e.onRetry,
						children: "刷新"
					})]
				})]
			}),
			!n && /* @__PURE__ */ j("p", {
				className: "team-cloud-notice",
				role: "status",
				children: ["只读 · ", e.readOnlyReason || (t.connection === "connected" ? "服务暂未开放写入，已有历史仍可查看。" : "等待连接恢复后再提交操作。")]
			}),
			e.error && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error team-cloud-notice",
				children: e.error
			}),
			/* @__PURE__ */ j("div", {
				className: "team-cloud-layout",
				children: [/* @__PURE__ */ j("aside", {
					className: "team-cloud-runs",
					"aria-label": "团队任务",
					children: [
						/* @__PURE__ */ j("header", { children: [/* @__PURE__ */ A("h2", { children: "团队任务" }), /* @__PURE__ */ A("button", {
							className: "team-text-button",
							type: "button",
							disabled: !n,
							onClick: e.onNewGoal,
							children: "新任务"
						})] }),
						a.runSummaries.map((t) => /* @__PURE__ */ j("button", {
							type: "button",
							className: "team-cloud-run",
							"aria-current": !e.newGoal && v?.teamRunId === t.teamRunId ? "page" : void 0,
							onClick: () => e.onChooseRun(t.teamRunId),
							children: [
								/* @__PURE__ */ A("strong", { children: t.goal }),
								/* @__PURE__ */ j("span", { children: [
									/* @__PURE__ */ A(B, { status: t.status }),
									" · ",
									t.taskCount,
									" 项任务"
								] }),
								t.pendingCount > 0 && /* @__PURE__ */ j("small", { children: [t.pendingCount, " 项待处理"] })
							]
						}, t.teamRunId)),
						!a.runSummaries.length && /* @__PURE__ */ A("p", {
							className: "team-muted",
							children: "还没有协作任务。从一个目标开始。"
						}),
						_("runSummaries", "更多团队任务"),
						e.operations
					]
				}), /* @__PURE__ */ j("div", {
					className: "team-cloud-main",
					children: [e.newGoal ? /* @__PURE__ */ j("div", {
						className: "team-cloud-goal",
						children: [
							/* @__PURE__ */ A("span", {
								className: "team-eyebrow",
								children: "新的协作任务"
							}),
							/* @__PURE__ */ A("h2", { children: "这次需要团队完成什么？" }),
							/* @__PURE__ */ A("p", { children: "描述目标和交付要求。任务记录与其他协作独立保存。" })
						]
					}) : /* @__PURE__ */ j(k, { children: [
						v && /* @__PURE__ */ j("header", {
							className: "team-cloud-run-header",
							children: [
								/* @__PURE__ */ A("h2", { children: v.goal }),
								/* @__PURE__ */ j("div", {
									className: "team-task-actions",
									children: [
										/* @__PURE__ */ A(B, { status: v.status }),
										v.dispatchSuspended && /* @__PURE__ */ A("span", { children: "已暂停派发" }),
										g(v.status) && v.status !== "cancel_requested" && e.onControl && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("button", {
											className: "team-button",
											type: "button",
											disabled: !n,
											onClick: () => e.onControl?.(v.dispatchSuspended ? "resume_dispatch" : "suspend_dispatch"),
											children: v.dispatchSuspended ? "恢复派发" : "暂停派发"
										}), /* @__PURE__ */ A("button", {
											className: "team-button team-danger",
											type: "button",
											disabled: !n,
											onClick: () => e.onControl?.("stop"),
											children: "停止任务"
										})] })
									]
								}),
								v.reason && /* @__PURE__ */ A("p", {
									className: "team-muted",
									children: ye(v.reason)
								}),
								v.status === "awaiting_acceptance" && e.onAcceptance && /* @__PURE__ */ j("div", {
									className: "team-cloud-acceptance",
									children: [
										/* @__PURE__ */ A("p", { children: "请查看成果后验收。" }),
										/* @__PURE__ */ j("label", {
											className: "team-field",
											children: ["修改意见", /* @__PURE__ */ A("textarea", {
												rows: 2,
												value: l,
												maxLength: 2e3,
												onChange: (e) => u(e.target.value),
												disabled: !n
											})]
										}),
										/* @__PURE__ */ A("button", {
											className: "team-button",
											disabled: !n || !l.trim(),
											onClick: () => e.onAcceptance?.("request_changes", l.trim()),
											children: "提出修改"
										}),
										/* @__PURE__ */ A("button", {
											className: "team-button team-primary",
											disabled: !n,
											onClick: () => e.onAcceptance?.("accept"),
											children: "验收通过"
										})
									]
								}),
								v.leaderStandby && /* @__PURE__ */ A(Se, { value: v.leaderStandby })
							]
						}),
						/* @__PURE__ */ A("div", {
							className: "team-cloud-tabs",
							role: "tablist",
							"aria-label": "任务工作区",
							children: [
								"messages",
								"tasks",
								"artifacts",
								"approvals",
								"members",
								"effects"
							].filter((t) => t !== "effects" || e.effects).map((e) => /* @__PURE__ */ j("button", {
								type: "button",
								role: "tab",
								id: `${d}-${e}`,
								"aria-controls": `${d}-panel`,
								"aria-selected": s === e,
								onClick: () => c(e),
								children: [{
									messages: "消息",
									tasks: "任务",
									artifacts: "交付物",
									approvals: "待处理",
									members: "成员",
									effects: "执行核查"
								}[e], e === "approvals" && v?.pendingCount ? ` (${v.pendingCount})` : ""]
							}, e))
						}),
						/* @__PURE__ */ j("div", {
							ref: f,
							onScroll: h,
							className: "team-cloud-panel",
							role: "tabpanel",
							id: `${d}-panel`,
							"aria-labelledby": `${d}-${s}`,
							tabIndex: 0,
							children: [
								s === "effects" && e.effects,
								s === "messages" && /* @__PURE__ */ j(k, { children: [
									_("recentMessages", "查看更早的消息"),
									a.recentMessages.filter((e) => e.visibility === "public").map((e) => /* @__PURE__ */ A("article", {
										className: "team-message",
										"data-message-id": e.messageId,
										"data-role": e.groupRole,
										children: /* @__PURE__ */ j("div", {
											className: "team-message-main",
											children: [/* @__PURE__ */ j("header", { children: [/* @__PURE__ */ A("strong", { children: e.senderName }), /* @__PURE__ */ A("time", {
												dateTime: e.createdAt,
												children: new Date(e.createdAt).toLocaleTimeString([], {
													hour: "2-digit",
													minute: "2-digit"
												})
											})] }), /* @__PURE__ */ A("div", {
												className: "team-message-body",
												children: e.parts.map((e, t) => e.kind === "text" ? /* @__PURE__ */ A(r, { content: e.text }, t) : /* @__PURE__ */ A("span", {
													className: "team-attachment",
													children: e.name || "附件"
												}, t))
											})]
										})
									}, e.messageId)),
									!a.recentMessages.length && /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: v ? "这项协作还没有公开消息。" : "选择任务查看消息，或新建协作目标。"
									})
								] }),
								s === "tasks" && /* @__PURE__ */ j(k, { children: [
									a.taskSummaries.map((t) => e.renderTasks?.(t) ?? /* @__PURE__ */ j("article", { children: [/* @__PURE__ */ A("h3", { children: t.title }), /* @__PURE__ */ A(B, { status: t.status })] }, t.taskId)),
									!a.taskSummaries.length && /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: "尚无分工任务。"
									}),
									_("taskSummaries")
								] }),
								s === "approvals" && /* @__PURE__ */ j(k, { children: [
									a.pendingInteractions.map((t) => e.renderInteraction?.(t) ?? /* @__PURE__ */ A("p", { children: t.title }, o(t))),
									!a.pendingInteractions.length && /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: "当前任务没有待处理事项。"
									}),
									_("pendingInteractions")
								] }),
								s === "artifacts" && /* @__PURE__ */ j(k, { children: [
									a.artifactSummaries.map((t) => /* @__PURE__ */ j("article", {
										className: "team-cloud-artifact",
										children: [/* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("strong", { children: t.name }), /* @__PURE__ */ j("p", {
											className: "team-muted",
											children: [
												t.mediaType,
												" · ",
												t.sizeBytes.toLocaleString(),
												" 字节 · ",
												t.state === "ready" ? "已就绪" : t.state === "failed" ? "准备失败" : "准备中"
											]
										})] }), t.state === "ready" && e.artifactUrl && /* @__PURE__ */ A("a", {
											href: e.artifactUrl(t.artifactId, t.teamRunId),
											download: t.name,
											children: "下载"
										})]
									}, t.artifactId)),
									!a.artifactSummaries.length && /* @__PURE__ */ A("p", {
										className: "team-muted",
										children: "交付物准备好后会显示在这里。"
									}),
									_("artifactSummaries")
								] }),
								s === "members" && /* @__PURE__ */ j(k, { children: [y.map((e) => /* @__PURE__ */ A("article", {
									className: "team-cloud-member",
									children: /* @__PURE__ */ j("div", { children: [
										/* @__PURE__ */ A("strong", { children: e.name }),
										/* @__PURE__ */ j("span", {
											className: "team-muted",
											children: [
												" ",
												e.role === "leader" ? "Leader" : "成员",
												" · ",
												e.binding.kind === "local_build" ? "本地节点" : "云端节点"
											]
										}),
										/* @__PURE__ */ A("p", { children: e.responsibility }),
										/* @__PURE__ */ j("p", {
											className: "team-muted",
											children: [
												e.binding.availability.state === "ready" ? "执行环境就绪" : e.binding.availability.state === "unchecked" ? "执行环境待检查" : "执行环境不可用",
												" · ",
												Z[e.executionStatus]
											]
										}),
										(e.reason || e.binding.availability.reason) && /* @__PURE__ */ A("p", {
											role: "status",
											children: e.reason || e.binding.availability.reason
										})
									] })
								}, e.memberId)), /* @__PURE__ */ A("p", {
									className: "team-muted",
									children: "节点环境与执行状态来自最近同步；离开页面只停止观察。"
								})] })
							]
						})
					] }), e.composer]
				})]
			})
		]
	});
}
function Ee({ scope: e, product: n, observation: r, newGoal: i, pendingMessage: a, value: o, onChange: c, canWrite: l, onSubmit: u, onCancelNew: f }) {
	let p = C(), m = E(null), h = t(), [_] = D(() => new d(n, e)), v = O(_.subscribe, _.getSnapshot, _.getSnapshot);
	S(() => () => _.dispose(), [_]), S(() => {
		l || _.cancel();
	}, [l, _]);
	let [y, b] = D(""), [x, w] = D(!1), [T, M] = D(""), N = r.projection?.snapshot, P = i ? null : N?.selectedRun, F = i || !P, I = l && !a && (F || g(P.status) && P.status !== "cancel_requested"), L = !F || v.files.length === 0 || v.state === "ready", R = s(v.state);
	async function z() {
		if (!(!I || x || !o.trim() || !L)) {
			w(!0), M("");
			try {
				await u({
					parts: [{
						kind: "text",
						text: o.trim()
					}],
					mentions: F || !y ? [] : [y],
					intent: F ? "start_goal" : y ? "directed" : "followup",
					...F ? {} : { teamRunId: P.teamRunId },
					...F && v.material?.state === "ready" ? { materialManifestRef: v.material.materialId } : {}
				});
			} catch (e) {
				M(e instanceof Error ? e.message : "提交未完成，草稿已保留。");
			} finally {
				w(!1);
			}
		}
	}
	return /* @__PURE__ */ j("form", {
		className: "team-composer-wrap",
		onSubmit: (e) => {
			e.preventDefault(), z();
		},
		children: [
			a && /* @__PURE__ */ A("p", {
				className: "team-cloud-notice",
				role: "status",
				children: "上一条消息的接收结果未确认，请先在操作记录中核对原单。"
			}),
			T && /* @__PURE__ */ A("p", {
				className: "team-inline-error",
				role: "alert",
				children: T
			}),
			/* @__PURE__ */ j("div", {
				className: "team-composer",
				children: [
					/* @__PURE__ */ A("label", {
						className: "team-sr-only",
						htmlFor: p,
						children: F ? "团队协作目标" : "给团队的消息"
					}),
					/* @__PURE__ */ A("textarea", {
						id: p,
						rows: 3,
						value: o,
						onChange: (e) => c(e.target.value),
						disabled: x,
						placeholder: F ? "描述目标、预期成果和约束…" : P && !g(P.status) ? "此任务已结束，可新建任务继续协作" : l ? "补充要求，或向成员提问…" : "可先整理草稿，恢复连接后再发送…",
						onKeyDown: (e) => {
							e.key === "Enter" && !e.shiftKey && !h(e) && (e.preventDefault(), z());
						}
					}),
					F && v.files.length > 0 && /* @__PURE__ */ j("section", {
						className: "team-cloud-materials",
						"aria-label": "任务材料",
						children: [
							/* @__PURE__ */ j("div", {
								className: "team-cloud-material-status",
								children: [/* @__PURE__ */ j("span", {
									role: "status",
									children: [{
										idle: "",
										hashing: "正在校验文件",
										creating: "正在准备上传",
										uploading: "正在上传",
										verifying: "服务端正在校验",
										ready: "材料已就绪",
										failed: "上传未完成",
										cancelled: "上传已取消"
									}[v.state], R ? ` · ${v.completed}/${v.files.length}` : ""]
								}), /* @__PURE__ */ j("span", { children: [v.files.length, " 个文件"] })]
							}),
							/* @__PURE__ */ A("ul", { children: v.files.map((e, t) => /* @__PURE__ */ j("li", { children: [/* @__PURE__ */ A("span", { children: e.name }), /* @__PURE__ */ j("span", { children: [e.size.toLocaleString(), " 字节"] })] }, `${t}:${e.name}`)) }),
							v.error && /* @__PURE__ */ A("p", {
								className: "team-inline-error",
								role: "alert",
								children: v.error
							}),
							/* @__PURE__ */ j("div", {
								className: "team-task-actions",
								children: [
									R && /* @__PURE__ */ A("button", {
										type: "button",
										className: "team-text-button",
										onClick: () => _.cancel(),
										children: "取消上传"
									}),
									["failed", "cancelled"].includes(v.state) && /* @__PURE__ */ A("button", {
										type: "button",
										className: "team-text-button",
										disabled: !I || x,
										onClick: () => void _.retry(),
										children: "重试上传"
									}),
									/* @__PURE__ */ A("button", {
										type: "button",
										className: "team-text-button",
										disabled: x || a,
										onClick: () => _.clear(),
										children: "移除材料"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ j("div", {
						className: "team-composer-toolbar",
						children: [/* @__PURE__ */ j("div", { children: [
							!F && /* @__PURE__ */ j("select", {
								"aria-label": "接收成员",
								value: y,
								onChange: (e) => b(e.target.value),
								disabled: x || !I,
								children: [/* @__PURE__ */ A("option", {
									value: "",
									children: "发给 Leader"
								}), N?.selectedRunMembers.filter((e) => e.status === "active").map((e) => /* @__PURE__ */ j("option", {
									value: e.memberId,
									children: ["@", e.name]
								}, e.memberId))]
							}),
							F && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("input", {
								ref: m,
								type: "file",
								multiple: !0,
								hidden: !0,
								"aria-label": "选择任务材料",
								onChange: (e) => {
									let t = Array.from(e.target.files ?? []);
									e.target.value = "", I && !x && t.length && _.select(t);
								}
							}), /* @__PURE__ */ A("button", {
								className: "team-text-button",
								type: "button",
								disabled: !I || x || R,
								onClick: () => m.current?.click(),
								children: v.files.length ? "重新选择材料" : "添加材料"
							})] }),
							i && /* @__PURE__ */ A("button", {
								className: "team-text-button",
								type: "button",
								disabled: x || a,
								onClick: f,
								children: "返回任务"
							})
						] }), /* @__PURE__ */ A("button", {
							className: "team-button team-primary",
							type: "submit",
							disabled: !I || x || !o.trim() || !L,
							children: x ? "正在核对" : F ? "开始协作" : "发送"
						})]
					})
				]
			}),
			/* @__PURE__ */ j("p", {
				className: "team-composer-help",
				children: ["Enter 发送 · Shift + Enter 换行", F ? " · 单个材料 ≤20 MiB，总计 ≤64 MiB" : " · 接收回执不代表执行完成"]
			})
		]
	});
}
function De({ task: e, scope: t, product: n, canWrite: r, command: i }) {
	let [a, o] = D(!1), [s, c] = D(null), [l, u] = D("");
	return S(() => {
		if (!a) return;
		let r = new AbortController();
		return n.task(t, e.taskId, e.teamRunId, r.signal).then((t) => {
			if (!r.signal.aborted) {
				if (t.taskId !== e.taskId || t.revision !== e.revision) throw Error("任务已更新，请刷新后重试。");
				c(t);
			}
		}).catch(() => {
			r.signal.aborted || u("任务详情读取失败，请关闭后重新打开。");
		}), () => r.abort();
	}, [
		a,
		n,
		t,
		e
	]), /* @__PURE__ */ j("article", {
		className: "team-cloud-task",
		children: [
			/* @__PURE__ */ j("button", {
				className: "team-cloud-task-title",
				type: "button",
				"aria-expanded": a,
				onClick: () => {
					o(!a), u("");
				},
				children: [/* @__PURE__ */ A("strong", { children: e.title }), /* @__PURE__ */ A(B, { status: e.status })]
			}),
			e.reason && /* @__PURE__ */ A("p", {
				className: "team-muted",
				children: ye(e.reason)
			}),
			a && (s ? /* @__PURE__ */ A(re, {
				task: s,
				members: [],
				onAction: r ? (t, n, r) => i(`tasks/${e.taskId}/actions`, {
					action: n,
					expectedRevision: e.revision,
					...r ? { reason: r } : {}
				}) : void 0
			}) : /* @__PURE__ */ A("p", {
				role: l ? "alert" : "status",
				children: l || "正在读取任务详情…"
			}))
		]
	});
}
function Q(e) {
	if (!e || typeof e != "object") return !1;
	if (Array.isArray(e)) return e.some(Q);
	let t = e;
	return t.secret === !0 || t.writeOnly === !0 || t.format === "password" || Object.values(t).some(Q);
}
function $({ summary: t, scope: r, product: i, canWrite: a, command: o }) {
	let [s, c] = D(null), [l, u] = D(!1), [d, f] = D({}), [p, m] = D(""), [h, g] = D(!1), [_, v] = D(!1);
	S(() => {
		if (!l) return;
		let e = new AbortController();
		return i.interaction(r, t, e.signal).then((t) => {
			e.signal.aborted || c(t);
		}).catch(() => {
			e.signal.aborted || m("审批详情读取失败，请关闭后重试或刷新。");
		}), () => e.abort();
	}, [
		l,
		r,
		i,
		t
	]);
	async function y(e, t) {
		if (!(!a || !s || s.status !== "pending" || h || _ || Q(s.requestSchema))) {
			g(!0), m("");
			try {
				await o("interactions", {
					ref: s.ref,
					expectedRevision: s.revision,
					action: e,
					response: t
				}), v(!0);
			} catch (e) {
				m(e instanceof Error ? e.message : "审批提交失败。");
			} finally {
				g(!1);
			}
		}
	}
	return /* @__PURE__ */ j("article", {
		className: "team-interaction-card",
		children: [
			/* @__PURE__ */ A("h3", { children: t.title }),
			/* @__PURE__ */ A("button", {
				className: "team-text-button",
				type: "button",
				"aria-expanded": l,
				onClick: () => {
					u(!l), m("");
				},
				children: l ? "收起详情" : "查看并处理"
			}),
			l && (s ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A(M, { message: s.message }), _ || s.status !== "pending" ? /* @__PURE__ */ A("p", {
				role: "status",
				children: _ || s.status === "resolving" ? "服务端已接收，等待执行端确认。" : s.status === "expired" ? "该事项已过期。" : s.status === "cancelled" ? "该事项已取消。" : "该事项已处理。"
			}) : Q(s.requestSchema) ? /* @__PURE__ */ A("p", {
				role: "status",
				children: "此表单包含敏感字段，无法通过浏览器持久队列提交，请使用安全凭据配置入口。"
			}) : s.kind === "input" ? s.requestSchema && e(s.requestSchema).length > 0 ? /* @__PURE__ */ A(n, {
				schema: s.requestSchema,
				values: d,
				onChange: f,
				disabled: !a || h,
				onSubmit: () => void y("submit", d),
				onCancel: () => void y("cancel", {})
			}) : /* @__PURE__ */ A("p", {
				role: "status",
				children: "缺少输入表单，暂不能提交。"
			}) : /* @__PURE__ */ j("div", {
				className: "team-task-actions",
				children: [/* @__PURE__ */ A("button", {
					className: "team-button",
					disabled: !a || h,
					onClick: () => void y("reject", { approved: !1 }),
					children: "拒绝"
				}), /* @__PURE__ */ A("button", {
					className: "team-button team-primary",
					disabled: !a || h,
					onClick: () => void y("approve", { approved: !0 }),
					children: "同意"
				})]
			})] }) : /* @__PURE__ */ A("p", {
				role: "status",
				children: p || "正在读取审批详情…"
			})),
			p && s && /* @__PURE__ */ A("p", {
				role: "alert",
				className: "team-inline-error",
				children: p
			})
		]
	});
}
//#endregion
export { Ce as CloudTeamWorkspace, Te as CloudTeamWorkspaceView, ue as CreateGroupDialog, te as GroupComposer, H as GroupHeader, U as GroupTimeline, G as MemberInspector, oe as MemberRail, ne as TaskBoard, re as TaskDetail, ae as TeamInteractionTray, ee as TeamProgressCard, B as TeamStatusLabel, se as TeamWorkspace, X as useTeamChat };
