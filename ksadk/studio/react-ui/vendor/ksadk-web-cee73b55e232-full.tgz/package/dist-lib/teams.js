import { l as e, t } from "./reducer-mbYiX0wz.js";
import { $ as n, A as r, At as i, B as a, Bt as o, C as s, Ct as c, D as l, Dt as u, E as d, Et as f, F as ee, Ft as te, G as ne, Gt as re, H as ie, Ht as p, I as ae, It as oe, J as se, Jt as m, K as ce, Kt as le, L as ue, Lt as de, M as h, Mt as fe, N as g, Nt as pe, O as me, Ot as _, P as he, Pt as ge, Q as _e, R as ve, Rt as ye, S as be, St as xe, T as Se, Tt as Ce, U as we, Ut as Te, V as Ee, Vt as De, W as Oe, Wt as ke, X as Ae, Y as v, Z as y, _ as je, _t as Me, a as b, at as Ne, b as Pe, bt as x, c as Fe, ct as Ie, d as Le, dt as Re, et as ze, f as Be, ft as Ve, g as He, gt as Ue, h as We, ht as Ge, it as Ke, j as qe, jt as Je, k as Ye, kt as Xe, l as S, lt as Ze, m as Qe, mt as $e, n as et, nt as tt, o as nt, ot as rt, p as it, pt as at, q as ot, qt as st, r as ct, rt as lt, s as ut, st as dt, tt as ft, u as pt, ut as mt, v as ht, vt as gt, w as _t, wt as C, x as vt, xt as yt, y as bt, yt as w, z as xt, zt as St } from "./cloudMaterials-D75jTrkQ.js";
import { a as Ct, i as wt, n as Tt, o as Et, r as Dt, s as Ot, t as kt } from "./presentation-yYw7xK60.js";
import { z as T } from "zod";
//#region src/core/teams/observer.ts
var At = class {
	ref;
	value;
	reducer = new t();
	listeners = /* @__PURE__ */ new Set();
	abort;
	generation = 0;
	disposed = !1;
	constructor(e) {
		let t = p.safeParse(e);
		if (!t.success) throw new _("invalid_member_ref", "成员观察需要完整的运行引用。");
		this.ref = Object.freeze({ ...t.data }), this.value = {
			ref: this.ref,
			items: [],
			cursor: 0,
			connection: "closed",
			draft: "",
			error: null
		};
	}
	getSnapshot = () => this.value;
	subscribe = (e) => (this.listeners.add(e), () => this.listeners.delete(e));
	update(e) {
		this.disposed || (this.value = {
			...this.value,
			...e
		}, this.listeners.forEach((e) => e()));
	}
	setDraft(e) {
		this.update({ draft: e });
	}
	assertRef(e) {
		if (u(e) !== u(this.ref)) throw new _("scope_mismatch", "成员事件的执行身份不匹配。");
	}
	decode(t) {
		let n = e(t);
		if (!n) throw new _("contract_mismatch", "成员会话内容格式不兼容。");
		if (n.sessionId !== this.ref.sessionId || n.runId !== this.ref.runId) throw new _("scope_mismatch", "成员事件引用了其他会话或运行。");
		return n;
	}
	ingest(e) {
		if (!this.disposed) {
			if (this.assertRef(e.ref), !Number.isSafeInteger(e.cursor) || e.cursor < 0) throw new _("contract_mismatch", "成员事件游标无效。");
			e.cursor <= this.value.cursor || (this.reducer.apply(this.decode(e.item)), this.update({
				items: this.reducer.snapshot().items,
				cursor: e.cursor
			}));
		}
	}
	restore(e) {
		if (this.assertRef(e.ref), !Number.isSafeInteger(e.cursor) || e.cursor < 0) throw new _("contract_mismatch", "成员历史游标无效。");
		if (e.cursor < this.value.cursor) return;
		let n = new t();
		for (let t of e.items) n.apply(this.decode(t));
		this.reducer = n, this.update({
			items: n.snapshot().items,
			cursor: e.cursor
		});
	}
	async observe(e) {
		if (this.disposed) throw new _("scope_disposed", "成员会话已关闭。");
		this.disconnect();
		let t = ++this.generation, n = new AbortController();
		this.abort = n;
		let r = () => !n.signal.aborted && t === this.generation;
		this.update({
			connection: "connecting",
			error: null
		});
		try {
			let t = !0, i = 0;
			for (; r();) try {
				if (t) {
					let i = await e.read(this.ref, n.signal);
					if (!r()) return;
					this.restore(i), t = !1;
				}
				if (this.update({
					connection: "connected",
					error: null
				}), await e.subscribe(this.ref, this.value.cursor, n.signal, (e) => {
					r() && (this.ingest(e), i = 0);
				}), !r()) return;
				throw new _("stream_ended", "成员事件连接已断开。");
			} catch (e) {
				if (!r()) return;
				if (e instanceof _ && (["scope_mismatch", "contract_mismatch"].includes(e.code) || [
					401,
					403,
					404
				].includes(e.status ?? 0)) || i++ >= 6) throw e;
				e instanceof _ && e.code === "reset_required" && (t = !0), this.update({ connection: "reconnecting" }), await new Promise((e) => {
					let t = n.signal, r = () => {
						clearTimeout(a), t.removeEventListener("abort", r), e();
					}, a = setTimeout(() => {
						t.removeEventListener("abort", r), e();
					}, Math.min(500 * 2 ** (i - 1), 1e4));
					t.addEventListener("abort", r, { once: !0 });
				});
			}
		} catch (e) {
			r() && this.update({
				connection: "offline",
				error: e instanceof Error ? e.message : "成员详情加载失败。"
			});
		}
	}
	setConnection(e) {
		this.update({ connection: e });
	}
	disconnect() {
		this.generation++, this.abort?.abort(), this.abort = void 0, this.update({ connection: "closed" });
	}
	dispose() {
		this.disconnect(), this.disposed = !0, this.listeners.clear(), this.reducer = new t(), this.value = {
			...this.value,
			draft: "",
			items: [],
			cursor: 0,
			error: null
		};
	}
};
function jt(e) {
	return new At(e);
}
function Mt(e = {}) {
	let t = e.fetch ?? ((e, t) => globalThis.fetch(e, t)), n = (e.baseUrl ?? "/api/v1/groups").replace(/\/+$/, ""), r = (e, t, r) => {
		let i = new URLSearchParams({
			sessionId: e.sessionId,
			runId: e.runId,
			bindingRef: e.bindingRef
		});
		return r !== void 0 && i.set("after", String(r)), `${n}/${encodeURIComponent(e.groupId)}/members/${encodeURIComponent(e.memberId)}/${t}?${i}`;
	}, i = async (e, n) => {
		let r = await t(e, {
			method: "GET",
			signal: n
		});
		if (!r.ok) {
			let e = await r.json().catch(() => ({}));
			throw new _(e.error?.code ?? "member_observation_failed", e.error?.message ?? `成员详情请求失败（${r.status}）`, r.status);
		}
		return r;
	};
	return {
		async read(e, t) {
			return (await i(r(e, "conversation"), t)).json();
		},
		async subscribe(e, t, n, a) {
			await C(await i(r(e, "conversation/events", t), n), n, (e, t) => {
				if (!(e === "heartbeat" || e === "ping")) {
					if (e === "reset_required") throw new _("reset_required", "成员历史已变化，请重新连接。");
					a(t);
				}
			});
		}
	};
}
//#endregion
//#region src/core/teams/cloudEffects.ts
var E = T.string().min(1).max(256), D = T.number().int().min(1).max(2 ** 53 - 1), O = T.string().regex(/^sha256:[0-9a-f]{64}$/), k = T.strictObject({
	phase: T.enum(["completed", "failed"]),
	external_ref: E.nullable(),
	evidence_ref: E,
	result_digest: O.nullable(),
	definitively_not_applied: T.boolean()
}).refine((e) => e.phase === "failed" === e.definitively_not_applied, "Unproven effect outcome"), Nt = T.strictObject({
	resolutionId: E,
	expectedRevision: D,
	expectedEvidenceDigest: O,
	decision: T.enum([
		"confirmed_applied",
		"confirmed_not_applied",
		"accept_risk"
	]),
	evidenceRef: E,
	reason: T.string().min(1).max(1e3),
	kind: T.enum(["manual_risk_acceptance", "external_evidence"]),
	actorSubject: E,
	ownerScopeRef: E,
	verifiedOutcome: k.nullable()
}).refine((e) => e.decision === "accept_risk" ? e.kind === "manual_risk_acceptance" && e.verifiedOutcome === null : e.kind === "external_evidence" && e.verifiedOutcome?.phase === (e.decision === "confirmed_applied" ? "completed" : "failed"), "Unverified effect resolution"), A = T.strictObject({
	effectKey: E,
	groupId: E,
	teamRunId: E,
	toolName: E,
	effectClass: T.enum(["external_idempotent", "external_reconcilable"]),
	phase: T.enum([
		"prepared",
		"unknown",
		"completed",
		"failed",
		"resolved"
	]),
	revision: D,
	evidenceDigest: O,
	resolution: Nt.nullable(),
	resolutionConflict: T.boolean(),
	outcome: k.nullable()
}).refine((e) => e.phase === "resolved" ? e.resolution !== null : e.resolution === null && !e.resolutionConflict && (["completed", "failed"].includes(e.phase) ? e.outcome?.phase === e.phase : e.outcome === null), "Inconsistent effect projection"), j = T.strictObject({
	scope: g,
	teamRunId: E,
	items: T.array(A).max(100),
	nextCursor: D.nullable()
}).refine((e) => new Set(e.items.map((e) => e.effectKey)).size === e.items.length, "Duplicate effect identity"), Pt = "teams-effects/v1", M = "teams-build/v1", N = "teams-loaded-build/v1", { identifier: P, operationKey: F, digest: I, revision: L, timestamp: R, commandId: Ft, relativePath: It, length: z } = v, Lt = T.enum([
	"prepared",
	"unknown",
	"completed",
	"failed",
	"resolved"
]), Rt = T.enum(["external_idempotent", "external_reconcilable"]), B = T.strictObject({
	ref: y,
	context_ref: P,
	store_incarnation: P,
	journal_incarnation: P,
	native_run_id: P,
	tool_call_id: P,
	effect_index: T.number().int().min(0).max(1023),
	tool_name: P,
	adapter_version: P,
	effect_class: Rt,
	payload_digest: I
}).refine((e) => e.ref.nativeRunId === null || e.ref.nativeRunId === e.native_run_id, "effect_native_run_mismatch"), V = T.strictObject({
	phase: T.enum(["completed", "failed"]),
	external_ref: P.nullable().default(null),
	evidence_ref: P,
	result_digest: I.nullable().default(null),
	definitively_not_applied: T.boolean().default(!1)
}).refine((e) => e.phase === "failed" === e.definitively_not_applied, "effect_outcome_not_proven"), zt = T.strictObject({
	effect_key: P,
	payload_digest: I,
	request_digest: I,
	revision: L,
	phase: Lt
}), H = T.strictObject({
	request: B,
	phase: T.enum([
		"prepared",
		"unknown",
		"completed",
		"failed"
	]),
	revision: L,
	evidence_digest: I,
	outcome: V.nullable().default(null)
}).refine((e) => ["completed", "failed"].includes(e.phase) ? e.outcome?.phase === e.phase : e.outcome === null, "effect_outcome_inconsistent"), Bt = T.strictObject({
	effectKey: P,
	journalRevision: L,
	evidenceDigest: I,
	authorityRevision: L,
	phase: Lt
}), Vt = T.strictObject({
	expectedRevision: L,
	expectedEvidenceDigest: I,
	decision: T.enum([
		"confirmed_applied",
		"confirmed_not_applied",
		"accept_risk"
	]),
	evidenceRef: P,
	reason: z(1, 1e3),
	idempotencyKey: F
}), Ht = V.required(), Ut = T.strictObject({
	resolutionId: P,
	expectedRevision: L,
	expectedEvidenceDigest: I,
	decision: T.enum([
		"confirmed_applied",
		"confirmed_not_applied",
		"accept_risk"
	]),
	evidenceRef: P,
	reason: z(1, 1e3),
	kind: T.enum(["manual_risk_acceptance", "external_evidence"]),
	actorSubject: P,
	ownerScopeRef: P,
	verifiedOutcome: Ht.nullable()
}).refine((e) => e.decision === "accept_risk" ? e.kind === "manual_risk_acceptance" && e.verifiedOutcome === null : e.kind === "external_evidence" && e.verifiedOutcome?.phase === (e.decision === "confirmed_applied" ? "completed" : "failed"), "effect_resolution_not_verified"), U = A.safeExtend({
	effectKey: P,
	groupId: P,
	teamRunId: P,
	toolName: P,
	resolution: Ut.nullable(),
	outcome: Ht.nullable()
}), Wt = j.safeExtend({
	scope: T.strictObject({
		authorityId: z(1, 256),
		ownerScopeRef: z(1, 512),
		groupId: z(1, 256)
	}),
	teamRunId: P,
	items: T.array(U).max(100)
}), Gt = T.strictObject({
	contextRef: P,
	storeIncarnation: P,
	nativeRunId: P,
	journalIncarnation: P,
	items: T.array(H).max(100),
	nextCursor: v.text.nullable().default(null)
}), Kt = new Set([
	"ensure_session",
	"prepare",
	"enqueue",
	"renew_grant",
	"set_grant",
	"set_admission",
	"invoke",
	"respond_interaction"
]), qt = new Set([
	"lookup",
	"get_result",
	"observe",
	"get_grant",
	"revoke",
	"cancel"
]), Jt = T.strictObject({
	schemaVersion: T.literal(1).default(1),
	issuer: P,
	kid: P,
	authorityId: P,
	issuedAt: R,
	expiresAt: R,
	nonce: P,
	signature: z(0, 128).default(""),
	audience: T.literal("agentengine-teams-runtime").default("agentengine-teams-runtime"),
	permitKind: T.enum(["execute", "recovery"]),
	subjectRef: P,
	agentInstanceId: P,
	sessionId: P,
	commandId: Ft,
	allowedOperations: T.array(v.text).min(1).max(16),
	payloadDigest: I,
	policyDigest: I,
	leaderEpoch: L,
	dispatchEpoch: L,
	attemptEpoch: L,
	grantRevision: L
}).refine((e) => {
	let t = Date.parse(e.expiresAt) - Date.parse(e.issuedAt);
	return t > 0 && t <= 6e4;
}, "invalid_permit_lifetime").refine((e) => new Set(e.allowedOperations).size === e.allowedOperations.length && e.allowedOperations.every((t) => (e.permitKind === "execute" ? Kt : qt).has(t)), "invalid_permit_operations"), Yt = T.strictObject({
	contextRef: z(1, 2 ** 53 - 1),
	expectedIncarnation: z(1, 2 ** 53 - 1),
	permit: Jt,
	after: z(0, 256).default(""),
	limit: T.number().int().min(1).max(100).default(100)
}), Xt = {
	agentDefinitionDigest: ".teams/agent-definition.json",
	toolsPolicyDigest: ".teams/tools-policy.json",
	behaviorConfigDigest: ".teams/behavior-config.json",
	dependencyLockDigest: ".teams/dependency.lock"
}, Zt = {
	agentDefinitionDigest: I,
	toolsPolicyDigest: I,
	dependencyLockDigest: I,
	behaviorConfigDigest: I
}, W = T.strictObject({
	schemaVersion: T.literal(M).default(M),
	entrypoint: It,
	...Zt,
	materialContractVersion: T.literal("materials/v1").default("materials/v1"),
	files: T.array(T.strictObject({
		path: It,
		digest: I,
		sizeBytes: T.number().int().min(0).max(20 * 1024 * 1024)
	})).min(1).max(4096)
}).superRefine((e, t) => {
	let n = new Map(e.files.map((e) => [e.path, e])), r = e.files.map((e) => e.path);
	n.size === r.length && !n.has(".teams/build-manifest.json") && r.every((e, t) => t === 0 || x(r[t - 1], e) < 0) && n.has(e.entrypoint) && !e.entrypoint.startsWith(".teams/") && e.files.reduce((e, t) => e + t.sizeBytes, 0) <= 64 * 1024 * 1024 && Object.entries(Xt).every(([t, r]) => n.get(r)?.digest === e[t]) && r.every((e) => e.split("/").every((e, t, r) => t === 0 || !n.has(r.slice(0, t).join("/")))) || t.addIssue({
		code: "custom",
		message: "invalid_build_manifest"
	});
}), Qt = T.strictObject({
	schemaVersion: T.literal(N).default(N),
	codeArtifactDigest: I,
	buildManifestDigest: I,
	...Zt,
	materialContractVersion: T.literal("materials/v1").default("materials/v1"),
	immutableWorkspace: T.literal(!0),
	externalMutableInputs: T.literal(!1)
}), G = T.strictObject({
	buildArtifactRef: P,
	state: T.literal("verified"),
	authorityId: P,
	codeArtifactDigest: I,
	buildManifestDigest: I,
	sizeBytes: T.number().int().min(1).max(20 * 1024 * 1024),
	manifest: W
}), $t = T.strictObject({ idempotencyKey: F }), en = T.union([T.strictObject({ status: T.literal("missing") }), G.extend({ status: T.literal("recorded") })]), K = T.strictObject({
	agentId: P,
	versionId: P,
	instanceId: P,
	codeArtifactDigest: I,
	buildManifestDigest: I,
	bundleDigest: I,
	contractDigest: I,
	deployedAt: v.text
}), tn = T.strictObject({
	buildArtifactRef: P,
	localBindingRef: P,
	cloudBindingRef: P,
	idempotencyKey: F
}), nn = T.strictObject({
	releaseRef: P,
	buildArtifactRef: P,
	localBindingRef: P,
	cloudBindingRef: P,
	evidenceDigest: I,
	verifiedAt: R
}), q = {
	"effect-request": B,
	"effect-outcome": V,
	"effect-prepared-receipt": zt,
	"effect-record": H,
	"effect-report-receipt": Bt,
	"effect-reconcile-input": Vt,
	"effect-projection": U,
	"effect-projection-page": Wt,
	"execution-effects-request": Yt,
	"execution-effects-page": Gt,
	"build-manifest": W,
	"loaded-build-evidence": Qt,
	"build-artifact-receipt": G,
	"build-artifact-lookup-input": $t,
	"build-artifact-lookup-result": en,
	"deployment-artifact-receipt": K,
	"release-verify-input": tn,
	"release-verification-receipt": nn
};
function rn(e, t) {
	if (!Object.hasOwn(q, e)) throw Error("unknown_teams_contract");
	return q[e].parse(t);
}
//#endregion
//#region src/core/teams/cloudScope.ts
function J(e) {
	if (!/^[\x21-\x7e]{1,256}$/.test(e.authorityId) || !/^[\x21-\x7e]{1,512}$/.test(e.ownerScopeRef)) throw new _("scope_mismatch", "云端身份引用无效，请重新连接服务。");
	return {
		"X-Teams-Authority-Id": e.authorityId,
		"X-Teams-Owner-Scope-Ref": e.ownerScopeRef
	};
}
//#endregion
//#region src/core/teams/cloudClient.ts
function Y(e) {
	if (e.aborted) throw new DOMException("Aborted", "AbortError");
}
async function X(e, t, n) {
	let r = e.headers.get("content-length");
	if (r !== null && Number(r) > n) throw await e.body?.cancel().catch(() => void 0), new _("workspace_response_too_large", "工作区响应超过大小限制。");
	if (!e.body) throw new _("workspace_contract_mismatch", "工作区服务未返回数据。");
	let i = e.body.getReader(), a = () => {
		i.cancel().catch(() => void 0);
	};
	t.addEventListener("abort", a, { once: !0 });
	let o = new TextDecoder("utf-8", { fatal: !0 }), s = "", c = 0;
	try {
		for (;;) {
			Y(t);
			let e = await i.read();
			if (Y(t), e.done) {
				s += o.decode();
				break;
			}
			if (c += e.value.byteLength, c > n) throw new _("workspace_response_too_large", "工作区响应超过大小限制。");
			s += o.decode(e.value, { stream: !0 });
		}
		try {
			return JSON.parse(s);
		} catch {
			throw new _("workspace_contract_mismatch", "工作区响应不是有效 JSON。");
		}
	} finally {
		t.removeEventListener("abort", a), await i.cancel().catch(() => void 0), i.releaseLock();
	}
}
var an = class {
	origin;
	base;
	fetcher;
	constructor(e) {
		let t = new URL(e.origin), n = new URL(e.baseUrl ?? "/api/v1/groups", t);
		if (!["https:", "http:"].includes(t.protocol) || t.origin !== e.origin || n.origin !== t.origin || n.search || n.hash || n.username || n.password) throw new _("invalid_workspace_origin", "工作区客户端必须固定到同一服务来源。");
		this.origin = t.origin, this.base = n.href.replace(/\/+$/, ""), this.fetcher = e.fetch ?? ((e, t) => globalThis.fetch(e, t));
	}
	path(e, t) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "工作区来源与客户端不一致。");
		return `${this.base}/${encodeURIComponent(e.groupId)}${t}`;
	}
	async get(e, t, n) {
		Y(t);
		let r = await this.fetcher(e, {
			method: "GET",
			signal: t,
			credentials: "same-origin",
			redirect: "error",
			cache: "no-store",
			headers: {
				...J(n),
				Accept: "application/json, text/event-stream"
			}
		});
		if (Y(t), !r.ok) {
			let e = await X(r, t, 64 * 1024).catch(() => ({})), n = e.error?.code ?? e.code;
			throw new _(typeof n == "string" && /^[a-z][a-z0-9_]{0,99}$/.test(n) ? n : "workspace_http_error", `工作区请求失败（${r.status}）。`, r.status);
		}
		return r;
	}
	async read(e, t) {
		let n = new URLSearchParams({ viewVersion: S });
		t.teamRunId !== void 0 && n.set("teamRunId", t.teamRunId);
		let r = Le(await X(await this.get(this.path(e, `/workspace?${n}`), t.signal, e), t.signal, 2 * 1024 * 1024));
		if (h(e) !== h(r.scope) || t.teamRunId !== void 0 && r.selectedRun?.teamRunId !== t.teamRunId) throw new _("scope_mismatch", "服务返回了其他身份或任务的工作区。");
		return r;
	}
	async page(e, t, n) {
		if (!l.safeParse(t).success) throw new _("invalid_workspace_page", "工作区分页参数无效。");
		if (t.collection !== "runSummaries" && t.teamRunId === null) throw new _("scope_mismatch", "任务分页需要指定协作任务。");
		let r = t.collection === "runSummaries" ? "/team-runs" : `/team-runs/${encodeURIComponent(t.teamRunId)}/${{
			taskSummaries: "tasks",
			pendingInteractions: "interactions",
			recentMessages: "messages",
			artifactSummaries: "artifacts"
		}[t.collection]}`, i = new URLSearchParams({
			viewVersion: S,
			snapshotId: t.snapshotId,
			watermark: String(t.watermark),
			cursor: t.cursor,
			limit: String(t.limit ?? 100)
		}), a = it(await X(await this.get(this.path(e, `${r}?${i}`), n, e), n, 2 * 1024 * 1024));
		if (h(e) !== h(a.scope)) throw new _("scope_mismatch", "服务返回了其他身份的分页。");
		if (a.snapshotId !== t.snapshotId || a.watermark !== t.watermark || a.teamRunId !== t.teamRunId || a.collection !== t.collection || a.cursor !== t.cursor) throw new _("workspace_page_mismatch", "服务分页与请求的只读快照不一致。");
		return a;
	}
	async subscribe(e, t, n, r) {
		if (!Number.isSafeInteger(t) || t < 0) throw new _("invalid_workspace_cursor", "工作区事件水位无效。");
		let i = new URLSearchParams({
			after: String(t),
			viewVersion: S
		}), a = await this.get(this.path(e, `/events?${i}`), n, e);
		try {
			await C(a, n, (t, n) => {
				if (t === "heartbeat" || t === "ping") return;
				if (t === "reset_required" || t === "snapshot_expired") throw new _("reset_required", "工作区历史需要重新同步。");
				if (![
					"workspace.delta",
					"workspace.event",
					"message"
				].includes(t)) throw new _("workspace_contract_mismatch", "未知工作区事件，需要重新读取。");
				let i = Be(n);
				if (h(e) !== h(i.scope)) throw new _("scope_mismatch", "服务事件属于其他授权工作区。");
				r(i);
			});
		} catch (e) {
			throw e instanceof _ && ["contract_mismatch", "event_too_large"].includes(e.code) ? new _("workspace_contract_mismatch", "工作区事件无法验证，需要重新读取。") : e;
		}
	}
}, Z = T.string().min(1).max(256), Q = T.number().int().min(0).max(2 ** 53 - 1), on = T.strictObject({
	apiVersion: T.literal(m),
	scope: g.omit({ groupId: !0 }),
	items: T.array(vt.extend({
		memberCount: Q,
		pendingCount: Q,
		unreadCount: Q,
		lastMessage: T.string().default("")
	})).max(100),
	nextCursor: T.string().min(1).max(4096).nullable()
}).refine((e) => new Set(e.items.map((e) => e.groupId)).size === e.items.length, "Duplicate group identity"), sn = He.extend({
	name: T.string().min(1).max(256),
	revision: Q.min(1),
	authorityRef: Z
}), cn = T.strictObject({
	apiVersion: T.literal(m),
	scope: g.omit({ groupId: !0 }),
	items: T.array(sn).max(100),
	nextCursor: T.string().min(1).max(4096).nullable()
}).refine((e) => new Set(e.items.map((e) => e.bindingRef)).size === e.items.length, "Duplicate binding identity"), ln = s.extend({
	message: T.string(),
	requestSchema: T.record(T.string(), T.unknown()).nullable()
}), un = T.strictObject({
	status: T.enum([
		"accepted",
		"duplicate",
		"rejected",
		"uncertain"
	]),
	groupId: Z.optional(),
	teamRunId: Z.optional(),
	messageId: Z.optional(),
	watermark: Q.optional(),
	reason: T.string().max(2e3).optional(),
	effectKey: Z.optional(),
	phase: T.literal("resolved").optional(),
	revision: Q.min(1).optional(),
	resolutionId: Z.optional(),
	decision: T.enum([
		"confirmed_applied",
		"confirmed_not_applied",
		"accept_risk"
	]).optional(),
	evidenceDigest: T.string().regex(/^sha256:[0-9a-f]{64}$/).optional()
}), dn = T.strictObject({
	status: T.enum([
		"confirmed",
		"rejected",
		"pending",
		"uncertain"
	]),
	operationId: Z,
	payloadDigest: T.string().regex(/^sha256:[0-9a-f]{64}$/),
	receipt: un.nullable(),
	code: T.string().max(100).optional()
}), fn = T.strictObject({ status: T.literal("missing") }), $ = encodeURIComponent, pn = class {
	origin;
	fetcher;
	groupsBase;
	teamsBase;
	constructor(e) {
		if (this.origin = new URL(e.origin).origin, e.origin !== this.origin || !/^https?:/.test(this.origin)) throw new _("invalid_workspace_origin", "团队服务来源无效。");
		let t = (e) => {
			let t = new URL(e, this.origin);
			if (t.origin !== this.origin || t.search || t.hash || t.username || t.password) throw new _("invalid_workspace_origin", "团队接口必须使用同一服务来源。");
			return t.href.replace(/\/+$/, "");
		};
		this.groupsBase = t(e.groupsBase ?? "/api/v1/groups"), this.teamsBase = t(e.teamsBase ?? "/api/v1/teams"), this.fetcher = e.fetch ?? globalThis.fetch.bind(globalThis);
	}
	async json(e, t, n, r, i) {
		if (t.aborted) throw new DOMException("Aborted", "AbortError");
		let a = await this.fetcher(e, {
			method: i ? "PUT" : r === void 0 ? "GET" : "POST",
			signal: t,
			credentials: "same-origin",
			redirect: "error",
			cache: "no-store",
			headers: {
				...J(n),
				Accept: "application/json",
				...i ? { "Content-Type": "application/octet-stream" } : r === void 0 ? {} : { "Content-Type": "application/json" }
			},
			...i ? { body: i } : r === void 0 ? {} : { body: JSON.stringify(r) }
		});
		if (t.aborted) throw new DOMException("Aborted", "AbortError");
		if (Number(a.headers.get("content-length")) > 2 * 1024 * 1024) throw await a.body?.cancel(), new _("cloud_contract_mismatch", "团队响应超过大小限制。");
		let o = a.body?.getReader();
		if (!o) throw new _("cloud_contract_mismatch", "团队服务未返回数据。");
		let s = 0, c = [], l = () => {
			o.cancel();
		};
		t.addEventListener("abort", l, { once: !0 });
		try {
			for (;;) {
				let e = await o.read();
				if (t.aborted) throw new DOMException("Aborted", "AbortError");
				if (e.done) break;
				if (s += e.value.byteLength, s > 2 * 1024 * 1024) throw new _("cloud_contract_mismatch", "团队响应超过大小限制。");
				c.push(e.value);
			}
		} finally {
			t.removeEventListener("abort", l), await o.cancel().catch(() => void 0), o.releaseLock();
		}
		let u = new Uint8Array(s), d = 0;
		for (let e of c) u.set(e, d), d += e.byteLength;
		let f;
		try {
			f = JSON.parse(new TextDecoder("utf-8", { fatal: !0 }).decode(u)), w(f);
		} catch {
			throw new _("cloud_contract_mismatch", "团队响应格式无效。");
		}
		if (!a.ok) {
			let e = f.error?.code;
			throw new _(typeof e == "string" && /^[a-z][a-z0-9_]{0,99}$/.test(e) ? e : "cloud_http_error", `团队请求失败（${a.status}）。`, a.status);
		}
		return f;
	}
	async list(e, t, n) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "团队来源不一致。");
		let r = new URLSearchParams({ limit: "50" });
		n && r.set("cursor", n);
		let i = on.parse(await this.json(`${this.groupsBase}?${r}`, t, e));
		if (i.scope.authorityId !== e.authorityId || i.scope.ownerScopeRef !== e.ownerScopeRef || i.items.some((t) => t.authorityRef !== e.authorityId)) throw new _("scope_mismatch", "团队目录属于其他身份。");
		if (n && i.nextCursor === n) throw new _("cloud_contract_mismatch", "团队目录游标未前进。");
		return i;
	}
	async bindings(e, t, n) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "成员目录来源不一致。");
		let r = new URLSearchParams({ limit: "100" });
		n && r.set("cursor", n);
		let i = cn.parse(await this.json(`${this.groupsBase}/bindings?${r}`, t, e));
		if (i.scope.authorityId !== e.authorityId || i.scope.ownerScopeRef !== e.ownerScopeRef || i.items.some((t) => t.authorityRef !== e.authorityId)) throw new _("scope_mismatch", "成员目录属于其他身份。");
		if (n && i.nextCursor === n) throw new _("cloud_contract_mismatch", "成员目录游标未前进。");
		return i;
	}
	target(e) {
		if (e.scope.origin !== this.origin) throw new _("scope_mismatch", "操作来源不一致。");
		let t = e.scope.groupId;
		if (!t && e.operation === "groups") return {
			path: this.groupsBase,
			targetId: ""
		};
		let n = `groups/${t}/`, r = e.operation.slice(n.length);
		if (!t || !e.operation.startsWith(n) || !/^(messages|interactions|team-runs\/[^/]+\/(control|acceptance)|tasks\/[^/]+\/actions|effects\/[^/]+\/reconcile)$/.test(r)) throw new _("invalid_cloud_operation", "不支持的团队操作。");
		let i = r.split("/");
		return {
			path: `${this.groupsBase}/${$(t)}/${i.map($).join("/")}`,
			targetId: t
		};
	}
	outcome(e, t) {
		let n = dn.parse(e);
		if (n.payloadDigest !== t.payloadDigest || n.receipt?.groupId && t.scope.groupId && n.receipt.groupId !== t.scope.groupId) throw new _("scope_mismatch", "操作回执与原始意图不一致。");
		if (n.status === "confirmed" && (!n.receipt || !["accepted", "duplicate"].includes(n.receipt.status))) throw new _("cloud_contract_mismatch", "操作尚未被事务接受。");
		let r = /^groups\/[^/]+\/team-runs\/([^/]+)\//.exec(t.operation)?.[1], i = typeof t.payload.teamRunId == "string" ? t.payload.teamRunId : r;
		if (n.receipt?.teamRunId && i && n.receipt.teamRunId !== i) throw new _("scope_mismatch", "操作回执属于其他协作任务。");
		if (n.status === "confirmed" && (!n.receipt?.groupId || t.payload.intent === "start_goal" && !n.receipt.teamRunId)) throw new _("cloud_contract_mismatch", "原单缺少已创建的资源标识。");
		let a = /^groups\/[^/]+\/effects\/([^/]+)\/reconcile$/.exec(t.operation)?.[1];
		if (n.status === "confirmed" && a && (n.receipt?.effectKey !== a || n.receipt?.phase !== "resolved" || !n.receipt.resolutionId || !n.receipt.revision || !n.receipt.evidenceDigest || n.receipt.decision !== t.payload.decision)) throw new _("scope_mismatch", "核查回执与原操作不一致。");
		if (n.status === "pending" || n.status === "uncertain") return {
			status: n.status,
			serverOperationId: n.operationId
		};
		let o = n.receipt;
		return n.status === "confirmed" ? {
			status: "confirmed",
			serverOperationId: n.operationId,
			...o ? { receipt: o } : {}
		} : {
			status: "rejected",
			code: n.code ?? "operation_rejected",
			serverOperationId: n.operationId,
			...o ? { receipt: o } : {}
		};
	}
	async lookup(e, t) {
		let { targetId: n } = this.target(e), r = await this.json(`${this.teamsBase}/operations/lookup`, t, e.scope, {
			idempotencyKey: e.idempotencyKey,
			operation: e.operation,
			targetId: n
		});
		return fn.safeParse(r).success ? { status: "missing" } : this.outcome(r, e);
	}
	async send(e, t) {
		let { path: n } = this.target(e);
		return this.outcome(await this.json(n, t, e.scope, {
			...e.payload,
			idempotencyKey: e.idempotencyKey
		}), e);
	}
	async interaction(e, t, n) {
		if (e.origin !== this.origin || t.groupId !== e.groupId) throw new _("scope_mismatch", "审批不属于当前团队。");
		let r = new URLSearchParams({
			teamRunId: t.teamRunId,
			...t.ref
		}), i = await this.json(`${this.groupsBase}/${$(e.groupId)}/interactions/${$(t.ref.interactionId)}?${r}`, n, e), a = ln.parse(i);
		if (w(a.ref) !== w(t.ref) || a.teamRunId !== t.teamRunId || a.groupId !== e.groupId || a.revision !== t.revision) throw new _("stale_interaction", "审批已更新，请刷新后查看。");
		return a;
	}
	async task(e, t, n, r) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "任务来源不一致。");
		let i = re.parse(await this.json(`${this.groupsBase}/${$(e.groupId)}/tasks/${$(t)}?teamRunId=${$(n)}`, r, e));
		if (i.taskId !== t || i.groupId !== e.groupId || i.teamRunId !== n) throw new _("scope_mismatch", "任务详情不属于当前协作。");
		return i;
	}
	async effects(e, t, n, r = 0) {
		if (e.origin !== this.origin || !t || !Number.isSafeInteger(r) || r < 0) throw new _("scope_mismatch", "执行核查不属于当前工作区。");
		let i = new URLSearchParams({
			after: String(r),
			limit: "50"
		}), a = j.parse(await this.json(`${this.groupsBase}/${$(e.groupId)}/team-runs/${$(t)}/effects?${i}`, n, e));
		if (a.scope.authorityId !== e.authorityId || a.scope.ownerScopeRef !== e.ownerScopeRef || a.scope.groupId !== e.groupId || a.teamRunId !== t || a.items.some((n) => n.groupId !== e.groupId || n.teamRunId !== t || n.resolution && n.resolution.ownerScopeRef !== e.ownerScopeRef)) throw new _("scope_mismatch", "执行核查记录属于其他任务或身份。");
		if (a.nextCursor !== null && a.nextCursor <= r) throw new _("cloud_contract_mismatch", "执行核查游标未前进。");
		return a;
	}
	async createMaterial(e, t, n) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "材料来源不一致。");
		let r = lt.parse(t);
		return b(await this.json(`${this.teamsBase}/materials`, n, e, r), e, {
			kind: r.kind,
			entries: r.entries,
			sourceCommit: r.sourceCommit
		});
	}
	async uploadMaterialBlob(e, t, n, r, i) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "材料来源不一致。");
		let a = await b(t, e);
		if (r.size !== n.sizeBytes || !a.manifest.entries.some((e) => w(e) === w(n))) throw new _("material_identity_conflict", "文件与原材料清单不一致。");
		let o = et.parse(await this.json(`${this.teamsBase}/materials/${$(a.materialId)}/blobs/${$(n.digest)}`, i, e, void 0, r));
		if (o.digest !== n.digest || o.sizeBytes !== n.sizeBytes) throw new _("material_identity_conflict", "上传回执与原文件不一致。");
	}
	async finalizeMaterial(e, t, n, r) {
		if (e.origin !== this.origin) throw new _("scope_mismatch", "材料来源不一致。");
		let i = await b(t, e), a = await this.json(`${this.teamsBase}/materials/${$(i.materialId)}/finalize`, r, e, {
			manifestDigest: i.manifestDigest,
			idempotencyKey: n
		}), o = ct.safeParse(a);
		if (o.success) {
			let e = o.data.missingBlobs;
			throw o.data.materialId !== i.materialId || !e.length || new Set(e).size !== e.length || e.some((e) => !i.manifest.entries.some((t) => t.digest === e)) ? new _("material_identity_conflict", "待上传文件与原材料清单不一致。") : Error("服务端尚未确认所有文件，请重试原上传。");
		}
		return b(a, e, i.manifest);
	}
	artifactUrl(e, t, n) {
		if (e.origin !== this.origin || !n) throw new _("scope_mismatch", "交付物来源不一致。");
		J(e);
		let r = new URLSearchParams({
			expectAuthorityId: e.authorityId,
			expectOwnerScopeRef: e.ownerScopeRef,
			teamRunId: n
		});
		return `${this.groupsBase}/${$(e.groupId)}/artifacts/${$(t)}/content?${r}`;
	}
};
//#endregion
export { nt as CloudOperations, Ce as GroupReducer, pn as HttpCloudTeamsProductClient, an as HttpCloudWorkspaceClient, c as HttpTeamsClient, At as MemberChatScope, m as TEAMS_API_VERSION, M as TEAMS_BUILD_VERSION, Pt as TEAMS_EFFECTS_PORT_VERSION, ee as TEAMS_HOST_VERSION, N as TEAMS_LOADED_BUILD_VERSION, ae as TEAMS_NODE_VERSION, S as TEAMS_WORKSPACE_VERSION, kt as TEAM_STATUS_LABELS, gt as TeamsCanonicalJsonError, _ as TeamsError, Ge as TeamsOperationDrainer, Ue as TeamsOperationOutbox, Me as TeamsOperationOutboxError, pt as WORKSPACE_COLLECTIONS, ut as WorkspaceObserver, Fe as WorkspaceReducer, Xe as artifactSchema, w as canonicalTeamsJson, cn as cloudBindingDirectorySchema, sn as cloudDirectoryBindingSchema, on as cloudDirectorySchema, k as cloudEffectOutcomeSchema, j as cloudEffectPageSchema, Nt as cloudEffectResolutionSchema, A as cloudEffectSchema, ln as cloudInteractionDetailSchema, x as compareTeamsMaterialPaths, C as consumeTeamsSse, jt as createChatScope, Mt as createHttpMemberTransport, Tt as currentTeamRun, i as decodeExecutionSnapshot, Je as decodeGroupEvent, fe as decodeGroupSnapshot, Le as decodeTeamWorkspaceSnapshot, ue as decodeTeamsCanonicalEventBatch, ve as decodeTeamsExecutionRef, xt as decodeTeamsExecutionResult, rn as decodeTeamsExtendedContract, a as decodeTeamsHostOperationResult, Ee as decodeTeamsHostReceipt, ie as decodeTeamsMaterialManifest, we as decodeTeamsNodeProbeReport, Oe as decodeTeamsNodeReport, Be as decodeWorkspaceEvent, it as decodeWorkspacePage, pe as deliverySchema, yt as digestTeamsJson, ge as executionNodeSchema, te as executionSnapshotSchema, oe as groupEventSchema, de as groupSchema, ye as groupSnapshotSchema, f as interactionRefKey, St as interactionRefSchema, o as interactionSchema, Dt as isTeamRunActive, xe as isTeamsUnicodeScalarString, De as memberSchema, u as memberStreamKey, p as memberStreamRefSchema, Te as messageSchema, ne as parseTeamsNodeCommand, ce as parseTeamsNodeMessage, ke as runMemberSchema, wt as safeArtifactUri, Ct as taskDependencyLevels, Et as taskDisplayReason, re as taskSchema, Ot as taskSection, le as teamRunSchema, Qe as teamWorkspaceSnapshotSchema, $t as teamsBuildArtifactLookupInputSchema, en as teamsBuildArtifactLookupResultSchema, G as teamsBuildArtifactReceiptSchema, W as teamsBuildManifestSchema, ot as teamsCanonicalEventBatchSchema, se as teamsCanonicalEventSchema, v as teamsCloudScalarSchemas, K as teamsDeploymentArtifactReceiptSchema, V as teamsEffectOutcomeSchema, zt as teamsEffectPreparedReceiptSchema, Wt as teamsEffectProjectionPageSchema, U as teamsEffectProjectionSchema, Vt as teamsEffectReconcileInputSchema, H as teamsEffectRecordSchema, Bt as teamsEffectReportReceiptSchema, B as teamsEffectRequestSchema, Gt as teamsExecutionEffectsPageSchema, Yt as teamsExecutionEffectsRequestSchema, Ae as teamsExecutionGrantSnapshotSchema, y as teamsExecutionRefSchema, _e as teamsExecutionResultSchema, n as teamsExecutionTargetSchema, q as teamsExtendedContractSchemas, ze as teamsGrantMutationReceiptSchema, ft as teamsHostOperationResultSchema, tt as teamsHostReceiptSchema, Qt as teamsLoadedBuildEvidenceSchema, lt as teamsMaterialCreateSchema, Ke as teamsMaterialEntrySchema, Ne as teamsMaterialManifestDigest, rt as teamsMaterialManifestSchema, dt as teamsNodeCommandDigest, Ie as teamsNodeCommandSchema, Ze as teamsNodeProbeCommandSchema, mt as teamsNodeProbeDigest, Re as teamsNodeProbeReportSchema, Ve as teamsNodeProbeResultSchema, at as teamsNodeReportSchema, nn as teamsReleaseVerificationReceiptSchema, tn as teamsReleaseVerifyInputSchema, $e as teamsTerminalEvidenceSchema, st as validateGroupCreate, We as workspaceArtifactSchema, He as workspaceBindingSchema, je as workspaceChangeSchema, ht as workspaceClientScopeKey, bt as workspaceClientScopeSchema, Pe as workspaceEventSchema, vt as workspaceGroupSchema, be as workspaceInteractionKey, s as workspaceInteractionSchema, _t as workspaceLeaderStandbySchema, Se as workspaceMemberSchema, d as workspaceMessageSchema, l as workspacePageRequestSchema, me as workspacePageSchema, Ye as workspaceRowKey, r as workspaceRunMemberSchema, qe as workspaceRunSummarySchema, h as workspaceScopeKey, g as workspaceScopeSchema, he as workspaceTaskSummarySchema };
