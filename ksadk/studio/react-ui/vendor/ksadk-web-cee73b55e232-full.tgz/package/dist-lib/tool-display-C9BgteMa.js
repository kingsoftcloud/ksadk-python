//#region src/utils/tool-display.js
function e(e) {
	return String(e || "").replace(/\\u([0-9a-fA-F]{4})/g, (e, t) => String.fromCharCode(Number.parseInt(t, 16)));
}
function t(t) {
	let r = String(t || "").trim();
	for (let t = 0; t < 3; t += 1) {
		if (!r) return r;
		let t = r[0], i = r[r.length - 1];
		if (!(t === "{" && i === "}" || t === "[" && i === "]" || t === "\"" && i === "\"")) return r.replace(/\\n/g, "\n").replace(/\\"/g, "\"");
		try {
			let e = JSON.parse(r);
			if (typeof e != "string") return n(e);
			r = e.trim();
		} catch {
			return e(r).replace(/\\n/g, "\n").replace(/\\"/g, "\"");
		}
	}
	return r;
}
function n(e) {
	return typeof e == "string" ? t(e) : Array.isArray(e) ? e.map((e) => n(e)) : !e || typeof e != "object" ? e : Object.fromEntries(Object.entries(e).map(([e, t]) => [e, n(t)]));
}
function r(e) {
	return typeof e == "string" ? t(e) : n(e);
}
function i(e) {
	return e === !1 ? !0 : typeof e == "string" ? e.trim().toLowerCase() === "false" : !1;
}
function a(e) {
	return e === !0 ? !0 : typeof e == "string" ? e.trim().toLowerCase() === "true" : !1;
}
function o(e) {
	return e == null || e === !1 ? !1 : typeof e == "string" ? e.trim().length > 0 : typeof e == "object" ? Object.keys(e).length > 0 : !0;
}
function s(e) {
	return String(e?.status || "").trim().toLowerCase() === "accepted_not_extracted";
}
function c(e, n = 0) {
	if (!e || n > 4) return !1;
	if (typeof e == "string") {
		let r = t(e);
		return r !== e && c(r, n + 1);
	}
	if (Array.isArray(e)) return e.some((e) => c(e, n + 1));
	if (typeof e != "object" || s(e)) return !1;
	if (i(e.ok) || i(e.success)) return !0;
	let r = a(e.ok) || a(e.success), l = String(e.status || "").trim().toLowerCase();
	return !r && [
		"error",
		"failed",
		"failure"
	].includes(l) || !r && (o(e.error_type) || o(e.error_message) || o(e.error)) ? !0 : Object.values(e).some((e) => c(e, n + 1));
}
function l(e) {
	return e == null || e === "" ? !1 : c(r(e));
}
function u(e) {
	if (e == null || e === "") return "";
	let t = r(e);
	return typeof t == "string" ? t : JSON.stringify(t, null, 2);
}
function d(e) {
	return e && typeof e == "object" && !Array.isArray(e) && e.version === "tool-display/v1" && [
		"terminal",
		"read",
		"search",
		"edit",
		"todo",
		"tool"
	].includes(e.category) ? e : void 0;
}
//#endregion
export { l as n, d as r, u as t };
