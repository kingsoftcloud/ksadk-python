export declare class ContractMismatchError extends Error {
    constructor(message: string);
}
export type AgentControlCommandType = 'enqueue' | 'steer' | 'inject' | 'interrupt' | 'pause' | 'resume' | 'submit_interaction';
export type AgentControlReceiptStatus = 'accepted' | 'duplicate' | 'rejected' | 'unsupported' | 'queue_full' | 'persistence_uncertain';
export type AgentControlError = {
    code: string;
    message: string;
    retryable: boolean;
    details?: Record<string, unknown>;
    extensions: Record<string, unknown>;
};
export type AgentControlReceipt = {
    schema_version: 1;
    command_id: string;
    status: AgentControlReceiptStatus;
    message_id?: string | null;
    run_id?: string | null;
    accepted_seq?: number | null;
    error?: AgentControlError | null;
    /** Unknown optional fields kept verbatim. */
    extensions: Record<string, unknown>;
};
/** Decode the public Action Data shape, then enforce the canonical contract. */
export declare function decodeActionReceipt(raw: unknown): AgentControlReceipt;
export declare function decodeReceipt(raw: unknown): AgentControlReceipt;
export type RuntimeCapabilityMode = 'native' | 'emulated' | 'unavailable';
export type RuntimeCapability = {
    supported: boolean;
    mode: RuntimeCapabilityMode;
    reason?: string | null;
    extensions: Record<string, unknown>;
};
export type RuntimeCapabilityMatrix = {
    schema_version: 1;
    cancel: RuntimeCapability;
    pause: RuntimeCapability;
    resume: RuntimeCapability;
    submit_interaction: RuntimeCapability;
    attach: RuntimeCapability;
    steer: RuntimeCapability;
    inject: RuntimeCapability;
    checkpoint: RuntimeCapability;
    durable_restore: RuntimeCapability;
    /** Runtime v2 execution modes are additive and absent on legacy runtimes. */
    goal?: RuntimeCapability;
    loop?: RuntimeCapability;
    plan?: RuntimeCapability;
    extensions: Record<string, unknown>;
};
export declare function decodeCapabilityMatrix(raw: unknown): RuntimeCapabilityMatrix;
export type SessionEventFamily = 'control' | 'runtime' | 'workflow' | 'schedule' | 'job' | 'relationship';
export type SessionEventEnvelope = {
    schema_version: 1;
    event_id: string;
    session_id: string;
    seq: number;
    timestamp: string;
    family: string;
    family_version: number;
    event_type: string;
    payload: Record<string, unknown>;
    run_id?: string | null;
    causation_id?: string | null;
    correlation_id?: string | null;
    actor_ref?: string | null;
    extensions: Record<string, unknown>;
};
export type DecodedSessionEventEnvelope = {
    ok: true;
    value: SessionEventEnvelope;
} | {
    ok: false;
    error: ContractMismatchError;
};
/**
 * Decode a session event envelope. Unknown families decode successfully so
 * the cursor can still advance; only structural violations fail.
 */
export declare function decodeSessionEventEnvelope(raw: unknown): DecodedSessionEventEnvelope;
export type AgentStatusSnapshot = {
    schema_version: 1;
    agent_instance_id: string;
    instance_state: 'ready' | 'degraded' | 'unavailable';
    session_id?: string | null;
    active_run_id?: string | null;
    active_run_state?: 'pending' | 'running' | 'paused' | 'waiting' | null;
    inbox_depth: number;
    activation_id?: string | null;
    lease_expires_at?: string | null;
    capability: RuntimeCapabilityMatrix;
    extensions: Record<string, unknown>;
};
export declare function decodeAgentStatusSnapshot(raw: unknown): AgentStatusSnapshot;
//# sourceMappingURL=agent-control.d.ts.map