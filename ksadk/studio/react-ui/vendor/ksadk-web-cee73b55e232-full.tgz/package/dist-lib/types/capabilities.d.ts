import type { HostedChatTransport, HostedChatTransportProtocol, RuntimeApiFormat } from './api.js';
import type { RuntimeCapabilityMatrix } from './agent-control.js';
export type BuiltinToolCapability = {
    name: string;
    group: string;
    description?: string;
    risk_level: string;
    requires_approval: boolean;
    side_effects: string[];
    enabled: boolean;
    backend?: string;
    boundary?: string;
};
export type ApprovalPolicyCapability = {
    Modes: Array<'ask' | 'risk' | 'full'>;
    DefaultMode: 'ask' | 'risk' | 'full';
    RuntimeOverride: boolean;
};
export type UiCapabilities = {
    /** Provider-declared presentation strategy; UI must not branch on engine names. */
    ConversationPresentation?: {
        Timeline?: 'standard' | 'compact';
    };
    /** Host may safely warm a provider binding without starting a run. */
    RuntimePrewarm?: boolean;
    Attachments?: boolean;
    Approval?: boolean;
    ApprovalPolicy?: ApprovalPolicyCapability;
    Thinking?: boolean;
    ContextCompaction?: boolean;
    StopRun?: boolean;
    /** Explicit runtime support; absence never permits falling back to root cancellation. */
    scoped_cancel?: {
        supported: boolean;
    };
    ResumeRun?: boolean;
    MCP?: boolean;
    HostedRuntime?: boolean;
    HostedChat: {
        Enabled: boolean;
        ApiFormats: RuntimeApiFormat[];
        PreferredTransport: HostedChatTransportProtocol;
        Transports: HostedChatTransport[];
    };
    NativeDashboard: {
        Enabled: boolean;
        Href?: string | null;
        Label?: string | null;
    };
    NativeTerminal: {
        Enabled: boolean;
        Mode?: string | null;
        Protocol?: string | null;
        Path?: string | null;
    };
    RunLifecycle: {
        Enabled: boolean;
        Resume: boolean;
        Abort: boolean;
        Checkpoints: boolean;
        CheckpointResume: boolean;
        CheckpointResumePreview: boolean;
    };
    WorkspaceFiles?: boolean;
    BuiltinTools: BuiltinToolCapability[];
    /** agent-kernel/v1 Interaction capability (bootstrap `interaction_v1`). */
    InteractionV1?: boolean;
    KernelSessionEvents?: boolean;
    ConversationSurface?: unknown;
    /** Canonical agent-kernel/v1 projection. Absent means no execution-mode UI. */
    RuntimeCapabilityMatrix?: RuntimeCapabilityMatrix;
};
export type { RuntimeCapability, RuntimeCapabilityMatrix, RuntimeCapabilityMode, } from './agent-control.js';
export { decodeCapabilityMatrix } from './agent-control.js';
//# sourceMappingURL=capabilities.d.ts.map