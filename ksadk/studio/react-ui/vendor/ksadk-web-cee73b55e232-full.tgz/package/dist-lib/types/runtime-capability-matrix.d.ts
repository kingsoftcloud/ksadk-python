/**
 * Decode the runtime-only portion of AgentKernel RuntimeCapabilityMatrix/v1.
 *
 * This module intentionally stays plain JavaScript so both the browser bundle
 * and the repository's pre-build Node compatibility tests execute the same
 * fail-closed decoder. The public TypeScript wrapper supplies the contract
 * type and canonical ContractMismatchError.
 */
export function decodeCapabilityMatrixValue(raw: any): {
    schema_version: number;
    extensions: {
        [k: string]: any;
    };
};
//# sourceMappingURL=runtime-capability-matrix.d.ts.map