import { a as e, i as t, o as n, t as r } from "./capabilities-CXle1R-K.js";
import { a as i, d as a, f as o, g as s, h as c, i as l, m as u, n as d, o as f, p, s as m, t as h } from "./a2ui-B1x5yNaJ.js";
import { n as g } from "./runtime-items-VPq7711E.js";
import { a as _, c as v, i as y, l as b, n as x, o as S, r as C, s as w, t as T, u as E } from "./feedback-CuC5jRi_.js";
import { n as D, r as O } from "./tool-display-C9BgteMa.js";
import { a as ee, d as k, f as A, p as j, s as M } from "./reducer-mbYiX0wz.js";
import { C as te, D as N, E as P, S as F, T as ne, _ as I, a as re, b as L, c as ie, d as ae, f as oe, g as se, h as ce, i as le, l as ue, m as de, n as fe, o as pe, p as me, r as he, s as ge, t as _e, u as ve, v as ye, x as be, y as xe } from "./persisted-session-history-ChW9k7v9.js";
import { useCallback as R, useEffect as z, useMemo as Se, useRef as B, useState as Ce } from "react";
import { create as we } from "zustand";
import { z as V } from "zod";
import { HttpAgent as Te, buildResumeArray as Ee } from "@ag-ui/client";
//#region src/api/client.ts
var H = class extends Error {
	code;
	detail;
	constructor(e, t, n) {
		super(t), this.name = "ApiError", this.code = e, this.detail = n;
	}
}, U = class extends Error {
	constructor(e = "请求已取消") {
		super(e), this.name = "CancelledError";
	}
}, De = "/agentengine/api/v1";
async function Oe(e) {
	let t = await e.text(), n = {};
	try {
		n = t ? JSON.parse(t) : {};
	} catch {
		let n = e.headers.get("content-type")?.toLowerCase() || "";
		if ((e.status === 401 || e.status === 403) && (n.includes("text/html") || t.trimStart().startsWith("<"))) throw new H(e.status, "访问会话已失效，请从 Dashboard 或 Studio 的云端会话重新打开 Agent。");
		if (!e.ok) {
			let n = t.trim();
			throw new H(e.status, n && n.length <= 256 && !n.startsWith("<") ? n : e.statusText || `HTTP ${e.status}`, t);
		}
		throw new H(-2, "响应格式异常");
	}
	if (!e.ok) throw new H(e.status, n?.Message || `HTTP ${e.status}`, n);
	if (n?.Code !== void 0 && n.Code !== 0) throw new H(n.Code, n.Message || "请求失败", n);
	return n.Data;
}
function ke(e) {
	throw e instanceof DOMException && e.name === "AbortError" ? new U() : e;
}
var Ae = class {
	fetcher;
	baseUrl;
	agentId;
	constructor(e = {}) {
		this.fetcher = e.fetch || ((e, t) => globalThis.fetch(e, t)), this.baseUrl = String(e.baseUrl || De).replace(/\/+$/, ""), this.agentId = String(e.agentId || "").trim();
	}
	actionUrl(e) {
		return `${this.baseUrl}/${e}`;
	}
	scopedBody(e) {
		return this.agentId && !e.AgentId ? {
			...e,
			AgentId: this.agentId
		} : e;
	}
	async postJsonAction(e, t, n) {
		let r;
		try {
			r = await this.fetcher(this.actionUrl(e), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(this.scopedBody(t)),
				signal: n?.signal
			});
		} catch (e) {
			throw ke(e);
		}
		return Oe(r);
	}
	async postFormAction(e, t, n) {
		let r;
		this.agentId && !t.has("AgentId") && t.append("AgentId", this.agentId);
		try {
			r = await this.fetcher(this.actionUrl(e), {
				method: "POST",
				body: t,
				signal: n?.signal
			});
		} catch (e) {
			throw ke(e);
		}
		return Oe(r);
	}
	async getResource(e, t, n) {
		let r = this.agentId && !t.AgentId ? {
			AgentId: this.agentId,
			...t
		} : t, i = new URLSearchParams(r).toString(), a = i ? `${this.actionUrl(e)}?${i}` : this.actionUrl(e), o;
		try {
			o = await this.fetcher(a, { signal: n?.signal });
		} catch (e) {
			throw ke(e);
		}
		if (!o.ok) throw new H(o.status, `资源获取失败: ${o.statusText}`);
		try {
			return n?.asText ? await o.text() : await o.blob();
		} catch {
			throw new H(-3, "文件读取失败");
		}
	}
	async streamAction(e, t, n) {
		let r;
		try {
			r = await this.fetcher(this.actionUrl(e), {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "text/event-stream"
				},
				body: JSON.stringify(this.scopedBody(t)),
				signal: n?.signal
			});
		} catch (e) {
			throw ke(e);
		}
		if (!r.ok) throw await Oe(r), new H(r.status, `流式请求失败: ${r.statusText}`);
		if ((r.headers.get("content-type")?.toLowerCase() || "").includes("application/json") && await Oe(r.clone()), !r.body) throw new H(-1, "无法获取响应流");
		return r.body;
	}
	async streamGetAction(e, t, n) {
		let r = this.agentId && !t.AgentId ? {
			AgentId: this.agentId,
			...t
		} : t, i = new URLSearchParams(r).toString(), a = i ? `${this.actionUrl(e)}?${i}` : this.actionUrl(e), o;
		try {
			o = await this.fetcher(a, {
				headers: { Accept: "text/event-stream" },
				signal: n?.signal
			});
		} catch (e) {
			throw ke(e);
		}
		if (!o.ok) throw new H(o.status, `流式订阅失败: ${o.statusText}`);
		if (!o.body) throw new H(-1, "无法获取响应流");
		return o.body;
	}
}, je = new Ae(), Me = (e, t, n) => je.streamAction(e, t, n), Ne = (e, t, n) => je.streamGetAction(e, t, n), W = class extends Error {
	constructor(e) {
		super(e), this.name = "ContractMismatchError";
	}
}, Pe = new Set([
	"schema_version",
	"command_id",
	"status",
	"message_id",
	"run_id",
	"accepted_seq",
	"error"
]), Fe = V.object({
	code: V.string().min(1),
	message: V.string(),
	retryable: V.boolean(),
	details: V.record(V.string(), V.unknown()).optional()
});
function Ie(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return G(e);
	let t = e;
	if ("schema_version" in t || !("SchemaVersion" in t)) return G(e);
	let n = {
		SchemaVersion: "schema_version",
		CommandId: "command_id",
		Status: "status",
		MessageId: "message_id",
		RunId: "run_id",
		AcceptedSeq: "accepted_seq",
		Error: "error"
	};
	return G(Object.fromEntries(Object.entries(t).map(([e, t]) => [n[e] ?? e, t])));
}
function G(e) {
	let t = V.object({
		schema_version: V.literal(1),
		command_id: V.string().min(1),
		status: V.enum([
			"accepted",
			"duplicate",
			"rejected",
			"unsupported",
			"queue_full",
			"persistence_uncertain"
		]),
		message_id: V.string().min(1).nullable().optional(),
		run_id: V.string().min(1).nullable().optional(),
		accepted_seq: V.number().int().min(0).nullable().optional(),
		error: Fe.nullable().optional()
	}).passthrough().safeParse(e);
	if (!t.success) throw new W(`AgentControlReceipt/v1 mismatch: ${t.error.message}`);
	let n = t.data;
	if ((n.status === "rejected" || n.status === "unsupported" || n.status === "queue_full" || n.status === "persistence_uncertain") && !n.error) throw new W(`AgentControlReceipt/v1 mismatch: status ${n.status} requires error`);
	let r = {};
	for (let [e, t] of Object.entries(n)) Pe.has(e) || (r[e] = t);
	let i = n.error ? {
		...n.error,
		extensions: {}
	} : null;
	return {
		schema_version: 1,
		command_id: n.command_id,
		status: n.status,
		message_id: n.message_id ?? null,
		run_id: n.run_id ?? null,
		accepted_seq: n.accepted_seq ?? null,
		error: i,
		extensions: r
	};
}
function Le(e) {
	try {
		return n(e);
	} catch (e) {
		throw new W(`RuntimeCapabilityMatrix/v1 mismatch: ${e instanceof Error ? e.message : String(e)}`);
	}
}
var Re = new Set([
	"schema_version",
	"event_id",
	"session_id",
	"seq",
	"timestamp",
	"family",
	"family_version",
	"event_type",
	"payload",
	"run_id",
	"causation_id",
	"correlation_id",
	"actor_ref"
]), ze = new Map([["control", 1], ["runtime", 2]]), Be = {
	schema_version: ["schemaVersion", "SchemaVersion"],
	event_id: ["eventId", "EventId"],
	session_id: ["sessionId", "SessionId"],
	seq: [
		"seqId",
		"SeqId",
		"Seq"
	],
	timestamp: ["Timestamp"],
	family: ["Family"],
	family_version: ["familyVersion", "FamilyVersion"],
	event_type: ["eventType", "EventType"],
	payload: ["Payload"],
	run_id: ["runId", "RunId"],
	causation_id: ["causationId", "CausationId"],
	correlation_id: ["correlationId", "CorrelationId"],
	actor_ref: ["actorRef", "ActorRef"]
};
function Ve(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return e;
	let t = e, n = { ...t };
	for (let [e, r] of Object.entries(Be)) {
		if (n[e] === void 0) {
			let i = r.find((e) => t[e] !== void 0);
			i && (n[e] = t[i]);
		}
		for (let e of r) delete n[e];
	}
	return n;
}
var He = V.object({
	schema_version: V.literal(1),
	event_id: V.string().min(1),
	session_id: V.string().min(1),
	seq: V.number().int().min(0),
	timestamp: V.string().min(1),
	family: V.string().min(1),
	family_version: V.number().int().min(1),
	event_type: V.string().min(1),
	payload: V.record(V.string(), V.unknown()),
	run_id: V.string().min(1).nullable().optional(),
	causation_id: V.string().min(1).nullable().optional(),
	correlation_id: V.string().min(1).nullable().optional(),
	actor_ref: V.string().min(1).nullable().optional()
}).passthrough();
function Ue(e) {
	let t = He.safeParse(Ve(e));
	if (!t.success) return {
		ok: !1,
		error: new W(`SessionEventEnvelope/v1 mismatch: ${t.error.message}`)
	};
	let n = t.data, r = ze.get(n.family);
	if (r !== void 0 && n.family_version !== r) return {
		ok: !1,
		error: new W(`SessionEventEnvelope/v1 mismatch: family ${n.family} requires family_version ${r}`)
	};
	let i = {};
	for (let [e, t] of Object.entries(n)) Re.has(e) || (i[e] = t);
	return {
		ok: !0,
		value: {
			schema_version: 1,
			event_id: n.event_id,
			session_id: n.session_id,
			seq: n.seq,
			timestamp: n.timestamp,
			family: n.family,
			family_version: n.family_version,
			event_type: n.event_type,
			payload: n.payload,
			run_id: n.run_id ?? null,
			causation_id: n.causation_id ?? null,
			correlation_id: n.correlation_id ?? null,
			actor_ref: n.actor_ref ?? null,
			extensions: i
		}
	};
}
function We(e) {
	let t = V.object({
		schema_version: V.literal(1),
		agent_instance_id: V.string().min(1),
		instance_state: V.enum([
			"ready",
			"degraded",
			"unavailable"
		]),
		session_id: V.string().min(1).nullable().optional(),
		active_run_id: V.string().min(1).nullable().optional(),
		active_run_state: V.enum([
			"pending",
			"running",
			"paused",
			"waiting"
		]).nullable().optional(),
		inbox_depth: V.number().int().min(0),
		activation_id: V.string().min(1).nullable().optional(),
		lease_expires_at: V.string().min(1).nullable().optional(),
		capability: V.unknown()
	}).passthrough().safeParse(e);
	if (!t.success) throw new W(`AgentStatusSnapshot/v1 mismatch: ${t.error.message}`);
	let n = t.data, r = {};
	for (let e of Object.keys(n)) [
		"schema_version",
		"agent_instance_id",
		"instance_state",
		"session_id",
		"active_run_id",
		"active_run_state",
		"inbox_depth",
		"activation_id",
		"lease_expires_at",
		"capability"
	].includes(e) || (r[e] = n[e]);
	return {
		schema_version: 1,
		agent_instance_id: n.agent_instance_id,
		instance_state: n.instance_state,
		session_id: n.session_id ?? null,
		active_run_id: n.active_run_id ?? null,
		active_run_state: n.active_run_state ?? null,
		inbox_depth: n.inbox_depth,
		activation_id: n.activation_id ?? null,
		lease_expires_at: n.lease_expires_at ?? null,
		capability: Le(n.capability),
		extensions: r
	};
}
//#endregion
//#region src/core/api/facade.ts
var Ge = class {
	client;
	constructor(e = {}) {
		this.client = new Ae(e);
	}
	async compactSession(e, t) {
		return this.client.postJsonAction("CompactSession", {
			AgentId: e,
			SessionId: t
		});
	}
	async listSessions(e, t) {
		let n = await this.client.postJsonAction("ListSessions", {
			AgentId: e,
			Page: t?.page,
			PageSize: t?.pageSize
		}, t), r = n.Sessions ?? [];
		return {
			Sessions: r,
			Total: Number.isFinite(Number(n.Total)) ? Number(n.Total) : r.length,
			Page: Number.isFinite(Number(n.Page)) ? Number(n.Page) : t?.page ?? 1,
			PageSize: Number.isFinite(Number(n.PageSize)) ? Number(n.PageSize) : t?.pageSize ?? r.length
		};
	}
	async createSession(e, t) {
		let n = await this.client.postJsonAction("CreateSession", { AgentId: e }, t);
		return { SessionId: String(n.Session?.SessionId || "") };
	}
	async deleteSession(e, t) {
		return this.client.postJsonAction("DeleteSession", { SessionId: e }, t);
	}
	async getSession(e, t) {
		return (await this.client.postJsonAction("GetSession", { SessionId: e }, t)).Session;
	}
	async listSessionEvents(e, t) {
		let n = await this.client.postJsonAction("ListSessionEvents", {
			SessionId: e,
			Offset: t?.offset,
			Limit: t?.limit
		}, t), r = n.Events ?? [];
		return {
			Events: r,
			Total: Number.isFinite(Number(n.Total)) ? Number(n.Total) : r.length,
			Offset: Number.isFinite(Number(n.Offset)) ? Number(n.Offset) : t?.offset ?? 0,
			Limit: Number.isFinite(Number(n.Limit)) ? Number(n.Limit) : t?.limit ?? r.length
		};
	}
	async listSessionMessages(e, t) {
		let n = await this.client.postJsonAction("ListSessionMessages", {
			AgentId: t?.agentId,
			SessionId: e,
			AfterSeqId: t?.afterSeqId,
			BeforeSeqId: t?.beforeSeqId,
			Limit: t?.limit,
			IncludeReasoning: t?.includeReasoning,
			IncludeToolEvents: t?.includeToolEvents,
			IncludeAttachments: t?.includeAttachments
		}, t);
		return {
			Messages: n.Messages ?? [],
			LatestSeqId: Number.isFinite(Number(n.LatestSeqId)) ? Number(n.LatestSeqId) : 0,
			HasMore: !!n.HasMore,
			NextCursor: n.NextCursor === null || n.NextCursor === void 0 ? null : Number.isFinite(Number(n.NextCursor)) ? Number(n.NextCursor) : null
		};
	}
	async listSessionCheckpoints(e, t) {
		return this.client.postJsonAction("ListSessionCheckpoints", {
			AgentId: e.agentId,
			SessionId: e.sessionId,
			...e.runId ? { RunId: e.runId } : {}
		}, t);
	}
	async previewCheckpointResume(e, t) {
		return this.client.postJsonAction("GetCheckpointResumePreview", {
			AgentId: e.agentId,
			SessionId: e.sessionId,
			RunId: e.runId,
			CheckpointId: e.checkpointId
		}, t);
	}
	async listToolReceipts(e, t) {
		return this.client.postJsonAction("ListToolReceipts", {
			AgentId: e.agentId,
			SessionId: e.sessionId,
			...e.runId ? { RunId: e.runId } : {},
			...e.checkpointId ? { CheckpointId: e.checkpointId } : {}
		}, t);
	}
	async runAgent(e, t) {
		return this.client.streamAction("RunAgent", e, t);
	}
	async resumeRun(e, t) {
		return this.client.streamAction("ResumeRun", {
			AgentId: e.agentId,
			SessionId: e.sessionId,
			RunId: e.runId,
			CheckpointId: e.checkpointId,
			Stream: !0,
			...e.resumeAttemptId ? { ResumeAttemptId: e.resumeAttemptId } : {},
			...e.invocationId ? { InvocationId: e.invocationId } : {}
		}, t);
	}
	async subscribeRunEvents(e, t) {
		return this.client.streamGetAction("SubscribeRunEvents", {
			SessionId: e.sessionId,
			InvocationId: e.invocationId,
			AfterSeqId: String(e.afterSeqId)
		}, t);
	}
	async submitControl(e, t) {
		return Ie(await this.client.postJsonAction("SubmitAgentControl", {
			CommandType: e.command_type,
			IdempotencyKey: e.idempotency_key,
			Payload: e.payload
		}, t));
	}
	async submitInteraction(e, t) {
		return Ie(await this.client.postJsonAction("SubmitInteraction", { ...e }, t));
	}
	async getAgentStatus(e) {
		return this.client.postJsonAction("GetAgentStatus", {}, e);
	}
	async subscribeSessionEvents(e, t, n) {
		return this.client.streamGetAction("SubscribeSessionEvents", {
			SessionId: e,
			after_seq: String(t)
		}, n);
	}
	async cancelRun(e, t, n, r) {
		if (r?.scopeId !== void 0 && (!r.scopeId.trim() || !t || !r.clientToken?.trim())) throw Error("Scoped cancellation requires session, scope and client token");
		return this.client.postJsonAction("CancelRun", {
			AgentId: e,
			SessionId: t,
			InvocationId: n,
			...r?.scopeId === void 0 ? {} : { ScopeId: r.scopeId },
			...r?.clientToken ? { ClientToken: r.clientToken } : {}
		}, r);
	}
	async getResponseFeedback(e, t) {
		return this.client.postJsonAction("GetResponseFeedback", e, t);
	}
	async upsertResponseFeedback(e, t) {
		return this.client.postJsonAction("UpsertResponseFeedback", e, t);
	}
	async deleteResponseFeedback(e, t) {
		await this.client.postJsonAction("DeleteResponseFeedback", e, t);
	}
	async listWorkspaceFiles(e, t, n, r) {
		return this.client.postJsonAction("ListWorkspaceFiles", {
			AgentId: e,
			Path: t,
			Recursive: n
		}, r);
	}
	async addWorkspaceFile(e, t) {
		return this.client.postFormAction("AddWorkspaceFile", e, t);
	}
	async deleteWorkspaceFile(e, t, n) {
		await this.client.postJsonAction("DeleteWorkspaceFile", {
			AgentId: e,
			Path: t
		}, n);
	}
	async getWorkspaceFileContent(e, t, n) {
		return this.client.getResource("GetWorkspaceFileContent", {
			AgentId: e,
			FilePath: t
		}, n);
	}
	async listAgentModels(e, t) {
		return this.client.postJsonAction("ListAgentModels", { AgentId: e }, t);
	}
	async getAgentUiBootstrap(e, t) {
		return this.client.postJsonAction("GetAgentUiBootstrap", e ? { AgentId: e } : {}, t);
	}
	async uploadFile(e, t) {
		return this.client.postFormAction("UploadFile", e, t);
	}
}, K = we()((e) => ({
	agentId: "default-agent",
	agentName: "Agent",
	agentFramework: "",
	capabilities: t({}),
	apiFormats: ["responses", "chat_completions"],
	accessMode: "Owner",
	workspaceFiles: null,
	status: "loading",
	errorMessage: "",
	setAgentId: (t) => e({ agentId: t }),
	setAgentName: (t) => e({ agentName: t }),
	setAgentFramework: (t) => e({ agentFramework: t }),
	setCapabilities: (t) => e({ capabilities: t }),
	setApiFormats: (t) => e({ apiFormats: t }),
	setAccessMode: (t) => e({ accessMode: t }),
	setWorkspaceFiles: (t) => e({ workspaceFiles: t }),
	setStatus: (t, n = "") => e({
		status: t,
		errorMessage: n
	})
})), Ke = "ksadk:webui:selected-session:";
function qe(e) {
	return String(e || "").trim() || "default-agent";
}
function Je(e) {
	if (e && typeof e.getItem == "function") return e;
	try {
		if (typeof window < "u" && window.localStorage) return window.localStorage;
	} catch {}
	return null;
}
function Ye(e) {
	return p.key(`${Ke}${qe(e)}`);
}
function Xe(e, t) {
	let n = Je(t);
	if (!n) return null;
	try {
		return String(n.getItem(Ye(e)) || "").trim() || null;
	} catch {
		return null;
	}
}
function Ze(e, t, n) {
	if (!p.writable) return;
	let r = Je(n);
	if (!r) return;
	let i = Ye(e), a = String(t || "").trim();
	try {
		if (a) {
			r.setItem(i, a);
			return;
		}
		r.removeItem(i);
	} catch {}
}
function Qe(e, t) {
	if (!Array.isArray(e) || e.length === 0) return null;
	let n = String(t || "").trim();
	if (n && e.some((e) => String(e?.SessionId || "").trim() === n)) return n;
	for (let t of e) {
		let e = String(t?.SessionId || "").trim();
		if (e) return e;
	}
	return null;
}
function $e(e, t, n) {
	let r = Array.isArray(e) ? e : [], i = Array.isArray(t) ? t : [], a = n instanceof Set ? n : new Set(Array.isArray(n) ? n : []);
	if (a.size === 0) return r;
	let o = new Set(r.map((e) => String(e?.SessionId || "").trim()).filter(Boolean)), s = i.filter((e) => {
		let t = String(e?.SessionId || "").trim();
		return t && a.has(t) && !o.has(t);
	});
	return s.length > 0 ? [...r, ...s] : r;
}
//#endregion
//#region src/hooks/useBootstrap.ts
function et(e) {
	return e instanceof H && (e.code === 401 || e.code === 403) ? "auth-required" : "error";
}
function tt(e) {
	if (!Array.isArray(e)) return ["responses", "chat_completions"];
	let t = e.filter((e) => e === "responses" || e === "chat_completions");
	return t.length > 0 ? t : ["responses", "chat_completions"];
}
var nt = new Ge();
async function rt(e, t = nt) {
	try {
		let n = await t.listAgentModels(e), r = n?.Models;
		Array.isArray(r) && u.getState().upsertModels(r);
		let i = n;
		i?.Current && !u.getState().selectedModel && u.getState().setSelectedModel(String(i.Current)), i?.Source && u.getState().setModelSource(String(i.Source));
	} catch (e) {
		console.error("Failed to fetch models:", e);
	} finally {
		u.getState().setModelCatalogLoaded(!0);
	}
}
function it(e, n, i = nt, a) {
	z(() => {
		let o = new AbortController();
		return (async () => {
			K.getState().setStatus("loading");
			try {
				let c = a ?? await i.getAgentUiBootstrap(n, { signal: o.signal });
				if (o.signal.aborted) return;
				let l = c, d = l?.Agent, f = String(d?.AgentId || "default-agent");
				if (K.getState().setAgentId(f), d?.Name) {
					let e = String(d.Name);
					K.getState().setAgentName(e), document.title = e;
				}
				let p = String(d?.Framework || "").trim().toLowerCase();
				K.getState().setAgentFramework(p);
				let m = t(c);
				K.getState().setCapabilities(m), K.getState().setApiFormats(tt(m.HostedChat.ApiFormats)), K.getState().setAccessMode(String(l?.AccessMode || "Owner"));
				let h = m.WorkspaceFiles && l?.WorkspaceFiles ? l.WorkspaceFiles : null;
				K.getState().setWorkspaceFiles(h), h || s.getState().setWorkspacePanelOpen(!1), r(m) && e.fetchSessions(f, Xe(f));
				let g = l?.Model;
				g?.id && (u.getState().setSelectedModel(g.id), u.getState().upsertModels([g]), u.getState().setModelSource(g.source || "")), rt(f, i), K.getState().setStatus("ready");
			} catch (e) {
				if (o.signal.aborted) return;
				console.error("Failed to fetch bootstrap:", e);
				let t = et(e);
				K.getState().setStatus(t, t === "auth-required" ? "当前访问链接未授权或已过期。" : "无法加载 Agent 配置，请稍后重试。");
			}
		})(), () => o.abort();
	}, [
		i,
		n,
		a
	]);
}
//#endregion
//#region src/hooks/useFeedback.ts
function at(e) {
	let { agentId: t, currentSessionId: n, isStreaming: r, api: i, submitDraft: a } = e;
	return {
		submitResponseFeedback: R(async (e) => {
			if (!n) return;
			let r = null;
			E.getState().patchMessages((t) => {
				let n = T(t, {
					messageId: e.message.id,
					rating: e.rating,
					comment: e.comment || ""
				});
				return r = n.previousFeedback, n.nextMessages;
			});
			try {
				let r = S((await i.upsertResponseFeedback(C({
					agentId: t,
					sessionId: n,
					message: e.message,
					rating: e.rating,
					comment: e.comment || ""
				})))?.Feedback);
				r && E.getState().patchMessages((t) => _(t, {
					messageId: e.message.id,
					feedback: r
				}));
			} catch (t) {
				console.error("Failed to submit response feedback:", t), E.getState().patchMessages((t) => w(t, {
					messageId: e.message.id,
					previousFeedback: r
				}));
			}
		}, [
			t,
			n,
			i
		]),
		deleteResponseFeedback: R(async (e) => {
			if (!n) return;
			let r = e.feedback ? { ...e.feedback } : null;
			E.getState().patchMessages((t) => y(t, { messageId: e.id }));
			try {
				await i.deleteResponseFeedback(x({
					agentId: t,
					sessionId: n,
					message: e
				}));
			} catch (t) {
				console.error("Failed to delete response feedback:", t), E.getState().patchMessages((t) => w(t, {
					messageId: e.id,
					previousFeedback: r
				}));
			}
		}, [
			t,
			n,
			i
		]),
		respondToApproval: R(async (e) => !e.approvalRequestId || r || !await a("", [], [{
			type: "mcp_approval_response",
			approval_request_id: e.approvalRequestId,
			approve: e.approve
		}], e.previousResponseId) ? !1 : (E.getState().patchMessages((t) => t.map((t) => {
			let n = e.approve ? "approved" : "rejected", r = (t) => e.approve && t === "paused" ? "running" : e.approve ? t : "completed";
			return {
				...t,
				tools: t.tools ? Object.fromEntries(Object.entries(t.tools).map(([t, i]) => [t, i.approvalRequestId === e.approvalRequestId && (i.approvalStatus === void 0 || i.approvalStatus === "pending") ? {
					...i,
					status: r(i.status),
					approvalStatus: n
				} : i])) : t.tools,
				blocks: t.blocks?.map((t) => t.type === "tool" && t.extra?.approvalRequestId === e.approvalRequestId && (t.extra.approvalStatus === void 0 || t.extra.approvalStatus === "pending") ? {
					...t,
					status: r(t.status),
					extra: {
						...t.extra,
						approvalStatus: n
					}
				} : t)
			};
		})), !0), [r, a])
	};
}
//#endregion
//#region src/core/interaction/store.ts
var ot = class {
	records = /* @__PURE__ */ new Map();
	terminalRuns = /* @__PURE__ */ new Set();
	rejectedCommands = /* @__PURE__ */ new Map();
	listeners = /* @__PURE__ */ new Set();
	key(e, t) {
		return `${e}\u0000${t}`;
	}
	runKey(e, t) {
		return `${e}\u0000${t}`;
	}
	subscribe(e) {
		return this.listeners.add(e), () => {
			this.listeners.delete(e);
		};
	}
	emit(e) {
		for (let t of this.listeners) t(e);
	}
	get(e, t) {
		return this.records.get(this.key(e, t)) || null;
	}
	listPending(e) {
		return this.listAll(e).filter((e) => e.status === "pending");
	}
	listAll(e) {
		return this.all().filter((t) => t.sessionId === e);
	}
	all() {
		return [...this.records.values()].sort((e, t) => String(e.createdAt).localeCompare(String(t.createdAt)));
	}
	upsert(e) {
		e.runId && !f(e.status) && this.terminalRuns.has(this.runKey(e.sessionId, e.runId)) && (e = {
			...e,
			status: "expired",
			outcome: "expired",
			resolvedAt: e.resolvedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
			responseSummary: e.responseSummary ?? "运行已结束"
		});
		let t = this.get(e.sessionId, e.interactionId), n, r;
		return t ? f(t.status) && !f(e.status) || e.revision < t.revision || e.revision === t.revision && f(t.status) && !f(e.status) || t.status === "failed" && t.extensions.rejected_command_id && e.revision === t.revision && !f(e.status) || t.status === "resolving" && !f(e.status) ? (n = t, r = {
			type: "interaction_updated",
			interaction: n
		}) : f(e.status) ? (n = {
			...t,
			...e,
			title: t.title || e.title,
			kind: t.kind || e.kind,
			message: t.message || e.message,
			runId: e.runId ?? t.runId,
			requestSchema: t.requestSchema ?? e.requestSchema,
			presentation: t.presentation ?? e.presentation,
			actor: e.actor ?? t.actor,
			outcome: e.outcome ?? t.outcome,
			resolvedAt: e.resolvedAt ?? t.resolvedAt,
			responseSummary: e.responseSummary ?? t.responseSummary
		}, r = {
			type: "interaction_resolved",
			interaction: n
		}) : (n = {
			...t,
			...e
		}, r = {
			type: "interaction_updated",
			interaction: n
		}) : (n = e, r = {
			type: "interaction_requested",
			interaction: n
		}), this.records.set(this.key(n.sessionId, n.interactionId), n), this.emit(r), r;
	}
	markResolving(e, t) {
		let n = this.get(e, t);
		if (!n || !["pending", "failed"].includes(n.status)) return;
		let r = { ...n.extensions };
		delete r.submit_error, this.records.set(this.key(e, t), {
			...n,
			status: "resolving",
			extensions: r
		}), this.emit({
			type: "interaction_updated",
			interaction: this.get(e, t)
		});
	}
	resolveLocally(e, t, n) {
		let r = this.get(e, t);
		if (!r) return;
		let i = {
			...r,
			...n,
			resolvedAt: n.resolvedAt ?? r.resolvedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
			revision: n.revision ?? r.revision
		};
		this.records.set(this.key(e, t), i), this.emit({
			type: "interaction_resolved",
			interaction: i
		});
	}
	recordCommand(e, t, n) {
		let r = this.get(e, t);
		if (!r || !n || f(r.status)) return;
		this.records.set(this.key(e, t), {
			...r,
			extensions: {
				...r.extensions,
				submit_command_id: n
			}
		});
		let i = this.rejectedCommands.get(this.key(e, n));
		i && this.rejectCommand(e, n, i);
	}
	rejectCommand(e, t, n) {
		if (!(!e || !t)) {
			this.rejectedCommands.set(this.key(e, t), n);
			for (let r of this.listAll(e)) {
				if (r.extensions.submit_command_id !== t) continue;
				this.markFailed(e, r.interactionId, {
					code: n,
					message: `提交未执行（${n}），请重试`,
					retryable: !0
				});
				let i = this.get(e, r.interactionId);
				i?.status === "failed" && this.records.set(this.key(e, r.interactionId), {
					...i,
					extensions: {
						...i.extensions,
						rejected_command_id: t
					}
				});
			}
		}
	}
	recordIdempotencyKey(e, t, n) {
		let r = this.get(e, t);
		if (!r) return;
		let i = {
			...r,
			extensions: {
				...r.extensions,
				idempotency_key: n
			}
		};
		this.records.set(this.key(e, t), i), this.emit({
			type: "interaction_updated",
			interaction: i
		});
	}
	markFailed(e, t, n) {
		let r = this.get(e, t);
		if (!r || r.status !== "resolving") return;
		let i = {
			...r,
			status: "failed",
			extensions: {
				...r.extensions,
				submit_error: n
			}
		};
		this.records.set(this.key(e, t), i), this.emit({
			type: "interaction_updated",
			interaction: i
		});
	}
	revertToPending(e, t) {
		let n = this.get(e, t);
		if (!n || n.status !== "resolving") return;
		let r = {
			...n,
			status: "pending"
		};
		this.records.set(this.key(e, t), r), this.emit({
			type: "interaction_updated",
			interaction: r
		});
	}
	markRunTerminal(e, t) {
		if (!(!e || !t)) {
			this.terminalRuns.add(this.runKey(e, t));
			for (let n of this.listAll(e)) {
				if (n.runId !== t || f(n.status)) continue;
				let r = {
					...n,
					status: "expired",
					outcome: "expired",
					resolvedAt: n.resolvedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
					responseSummary: n.responseSummary ?? "运行已结束"
				};
				this.records.set(this.key(e, n.interactionId), r), this.emit({
					type: "interaction_resolved",
					interaction: r
				});
			}
		}
	}
	markSessionTerminal(e) {
		if (!e) return;
		let t = new Set(this.listAll(e).filter((e) => !f(e.status)).map((e) => e.runId).filter((e) => !!e));
		for (let n of t) this.markRunTerminal(e, n);
		for (let t of this.listAll(e)) {
			if (t.runId || f(t.status)) continue;
			let n = {
				...t,
				status: "expired",
				outcome: "expired",
				resolvedAt: t.resolvedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
				responseSummary: t.responseSummary ?? "运行已结束"
			};
			this.records.set(this.key(e, t.interactionId), n), this.emit({
				type: "interaction_resolved",
				interaction: n
			});
		}
	}
	remove(e, t) {
		let n = this.key(e, t);
		this.records.has(n) && (this.records.delete(n), this.emit({
			type: "interaction_removed",
			interactionId: t
		}));
	}
	clearSession(e) {
		for (let t of this.listAll(e)) this.remove(e, t.interactionId);
		let t = `${e}\u0000`;
		for (let e of this.rejectedCommands.keys()) e.startsWith(t) && this.rejectedCommands.delete(e);
		for (let e of this.terminalRuns) e.startsWith(t) && this.terminalRuns.delete(e);
	}
}, st = {
	approve: "approved",
	reject: "rejected",
	submit: "submitted",
	cancel: "cancelled"
};
function q(e, t) {
	return {
		schema_version: 1,
		command_id: `local-${t}`,
		status: e,
		message_id: null,
		run_id: null,
		accepted_seq: null,
		error: null,
		extensions: {}
	};
}
var ct = class {
	store;
	deps;
	inFlight = /* @__PURE__ */ new Map();
	constructor(e) {
		this.deps = e, this.store = e.store || new ot();
	}
	listPending(e) {
		return this.store.listPending(e);
	}
	setInteractionV1Enabled(e) {
		this.deps.interactionV1Enabled = e;
	}
	subscribe(e) {
		return this.store.subscribe(e);
	}
	ingest(e) {
		this.store.upsert(e);
	}
	ingestHistory(e) {
		for (let t of e) this.store.upsert(t);
		for (let [e] of this.inFlight) {
			let t = this.findByInteractionId(e);
			t && t.status !== "pending" && t.status !== "resolving" && this.inFlight.delete(e);
		}
	}
	findByInteractionId(e) {
		return this.store.all().find((t) => t.interactionId === e) || null;
	}
	async respond(e) {
		let t = this.findByInteractionId(e.interactionId);
		if (!t) return q("rejected", e.interactionId);
		if (t.status === "resolved" || t.status === "cancelled" || t.status === "expired" || t.status === "resolving") return q("duplicate", e.interactionId);
		let n = e.idempotencyKey || i(e.interactionId, e.expectedRevision), r = t.extensions.rejected_command_id, a = r ? `${n}:retry-${r}` : n, o = this.inFlight.get(e.interactionId);
		if (o) return q(o === a ? "duplicate" : "rejected", e.interactionId);
		this.inFlight.set(e.interactionId, a), this.store.markResolving(t.sessionId, e.interactionId);
		let s = this.deps.interactionV1Enabled || t.source === "interaction_v1";
		try {
			if (!s && t.source === "responses" && this.deps.legacyResponsesApproval) return await this.deps.legacyResponsesApproval(e.interactionId, e.action === "approve") === !1 ? (this.store.markFailed(t.sessionId, e.interactionId, {
				code: "interaction_not_dispatched",
				message: "交互尚未提交，请稍后重试。",
				retryable: !0
			}), q("rejected", e.interactionId)) : (this.resolveLocal(t, e, a), q("accepted", e.interactionId));
			if (!s && t.source === "agui" && this.deps.legacyAguiResume) return this.deps.legacyAguiResume(String(t.extensions.interrupt_id || e.interactionId), e.action === "cancel" ? "cancelled" : "resolved", e.response) ? (this.resolveLocal(t, e, a), q("accepted", e.interactionId)) : (this.store.revertToPending(t.sessionId, e.interactionId), q("rejected", e.interactionId));
			let n = G(await this.deps.submitInteraction({
				AgentId: this.deps.agentId,
				SessionId: t.sessionId,
				RunId: t.runId || "",
				InteractionId: e.interactionId,
				ExpectedRevision: e.expectedRevision,
				Action: e.action,
				Response: e.response,
				IdempotencyKey: a
			}));
			return n.status === "accepted" || n.status === "duplicate" ? (this.store.recordCommand(t.sessionId, e.interactionId, n.command_id), this.store.recordIdempotencyKey(t.sessionId, e.interactionId, a)) : n.status === "queue_full" ? this.store.revertToPending(t.sessionId, e.interactionId) : this.store.markFailed(t.sessionId, e.interactionId, {
				code: n.error?.code ?? String(n.status),
				message: n.error?.message ?? `提交未通过（${n.status}）`,
				retryable: n.error?.retryable ?? !1
			}), n;
		} catch (n) {
			let r = n instanceof Error ? n.message : String(n || "交互提交失败");
			throw this.store.markFailed(t.sessionId, e.interactionId, {
				code: "interaction_submit_failed",
				message: r,
				retryable: !0
			}), n;
		} finally {
			this.inFlight.delete(e.interactionId);
		}
	}
	resolveLocal(e, t, n) {
		let r = this.store.get(e.sessionId, t.interactionId);
		if (!r || f(r.status)) return;
		let i = t.action === "cancel" ? "cancelled" : "resolved";
		this.store.resolveLocally(e.sessionId, t.interactionId, {
			status: i,
			outcome: st[t.action],
			actor: "user",
			responseSummary: m(t.action, t.response),
			revision: t.expectedRevision
		});
		let a = this.store.get(e.sessionId, t.interactionId);
		a && this.store.upsert({
			...a,
			extensions: {
				...a.extensions,
				idempotency_key: n
			}
		});
	}
}, lt = new Set([
	"approval",
	"structured_input",
	"plan_review",
	"custom"
]), ut = new Set([
	"pending",
	"resolving",
	"failed",
	"resolved",
	"cancelled",
	"expired"
]), dt = new Set([
	"approved",
	"rejected",
	"submitted",
	"cancelled",
	"expired"
]);
function ft(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function J(e) {
	return typeof e == "string" && e.length > 0 ? e : null;
}
function pt(e) {
	let t = String(e.kind || "approval"), n = String(e.status || "pending"), r = String(e.outcome || ""), i = ft(e.presentation), a = i ? ft(i.a2ui) : null;
	return {
		interactionId: e.interactionId,
		sessionId: e.sessionId,
		runId: J(e.runId),
		kind: lt.has(t) ? t : "custom",
		title: typeof e.title == "string" && e.title ? e.title : "人工确认",
		message: typeof e.message == "string" && e.message ? e.message : "本次运行需要人工处理后才能继续。",
		requestSchema: ft(e.requestSchema),
		presentation: a ? { a2ui: {
			wireVersion: String(a.wire_version ?? a.wireVersion ?? ""),
			catalogDigest: String(a.catalog_digest ?? a.catalogDigest ?? ""),
			messages: Array.isArray(a.messages) ? a.messages.filter((e) => typeof e == "object") : []
		} } : null,
		status: ut.has(n) ? n : "pending",
		revision: Number.isFinite(Number(e.revision)) && Number(e.revision) > 0 ? Number(e.revision) : 1,
		createdAt: J(e.createdAt) || (/* @__PURE__ */ new Date()).toISOString(),
		expiresAt: J(e.expiresAt),
		resolvedAt: J(e.resolvedAt),
		actor: J(e.actor),
		outcome: dt.has(r) ? r : null,
		responseSummary: J(e.responseSummary),
		source: e.source,
		extensions: e.extensions || {}
	};
}
//#endregion
//#region src/core/interaction/adapters/session-events.ts
var mt = new Set([
	"interaction.requested",
	"interaction_requested",
	"ksadk.interaction/v1.requested",
	"InteractionRequested",
	"approval.requested",
	"a2ui.interaction"
]), ht = new Set([
	"interaction.resolved",
	"interaction_resolved",
	"ksadk.interaction/v1.resolved",
	"InteractionResolved",
	"interaction.cancelled",
	"interaction.cancel",
	"interaction.expired",
	"approval.resolved",
	"a2ui.action"
]);
function Y(e) {
	return typeof e == "object" && e && !Array.isArray(e) ? e : null;
}
function gt(e, t) {
	let n = Y(e);
	if (!n) return null;
	let r = Y(n.Content ?? n.content), i = Y(r?.session_event ?? r?.sessionEvent), a = Y(n.payload), o = i ?? (a?.family === "interaction" ? a : null) ?? (n.family === "interaction" ? n : null);
	if (o && o.family !== "interaction") return null;
	let s = o ?? n, c = String(s.event_type || s.EventType || "").trim();
	if (!c) return null;
	let l = Y(s.payload ?? s.Content) ?? (o || {}), u = Y(l.interaction) || Y(l.Interaction) || Y(l.interaction_request) || l, d = String(u.interaction_id || u.interactionId || u.InteractionId || u.approval_id || u.approvalId || l.interaction_id || l.interactionId || l.InteractionId || l.approval_id || l.approvalId || "");
	if (!d) return null;
	let f = String(s.session_id || s.SessionId || u.session_id || u.sessionId || t || "");
	if (!f) return null;
	if (mt.has(c)) {
		let e = Y(u.request) || {}, t = Y(u.presentation ?? e.presentation), n = {
			...Y(u.extensions) || {},
			...u.detail === void 0 ? {} : { detail: u.detail },
			...(u.call_id ?? u.callId) === void 0 ? {} : { call_id: u.call_id ?? u.callId }
		};
		return pt({
			interactionId: d,
			sessionId: f,
			runId: u.run_id ?? u.runId ?? s.run_id ?? s.InvocationId,
			kind: c === "approval.requested" ? "approval" : u.kind ?? e.kind ?? "approval",
			title: u.title ?? t?.title,
			message: u.message ?? u.description ?? Y(u.detail)?.command ?? t?.description,
			requestSchema: u.request_schema ?? u.requestSchema ?? u.input_schema ?? u.inputSchema ?? u.RequestSchema ?? e.request_schema,
			presentation: t,
			status: "pending",
			revision: u.revision ?? 1,
			createdAt: u.created_at ?? u.createdAt ?? s.timestamp ?? s.Timestamp,
			expiresAt: u.expires_at ?? e.expires_at,
			source: "interaction_v1",
			extensions: n
		});
	}
	if (ht.has(c)) {
		let e = {
			...Y(u.extensions) || {},
			...u.detail === void 0 ? {} : { detail: u.detail },
			...(u.call_id ?? u.callId) === void 0 ? {} : { call_id: u.call_id ?? u.callId }
		}, t = c === "interaction.cancelled" || c === "interaction.cancel" ? "cancelled" : c === "interaction.expired" ? "expired" : "resolved", n = String(l.outcome ?? u.outcome ?? u.status ?? "").toLowerCase(), r = String(l.action ?? u.action ?? l.name ?? u.name ?? "").toLowerCase(), i = n;
		i ||= r === "approve" ? "approved" : r === "reject" ? "rejected" : r === "submit" ? "submitted" : r === "cancel" || t === "cancelled" ? "cancelled" : t === "expired" ? "expired" : "submitted";
		let a = t === "resolved" ? "resolved" : t;
		return pt({
			interactionId: d,
			sessionId: f,
			runId: u.run_id ?? u.runId ?? s.run_id ?? s.InvocationId,
			kind: u.kind,
			title: u.title,
			message: u.message,
			requestSchema: u.request_schema,
			presentation: u.presentation,
			status: a,
			revision: u.revision,
			createdAt: u.created_at ?? s.timestamp,
			expiresAt: u.expires_at,
			resolvedAt: l.resolved_at ?? l.resolvedAt ?? u.resolved_at ?? u.resolvedAt ?? s.timestamp ?? s.Timestamp,
			actor: l.actor ?? u.actor ?? s.actor_ref,
			outcome: i,
			responseSummary: l.response_summary ?? u.response_summary ?? (r ? `${r}` : void 0),
			source: "interaction_v1",
			extensions: e
		});
	}
	return null;
}
//#endregion
//#region src/core/interaction/adapters/responses.ts
function _t(e) {
	return !e.approvalRequestId || !e.sessionId ? null : pt({
		interactionId: e.approvalRequestId,
		sessionId: e.sessionId,
		runId: e.runId ?? null,
		kind: "approval",
		title: e.name ? `审批：${e.name}` : "人工确认",
		message: e.message || "本次运行需要人工审批后才能继续。",
		requestSchema: e.requestSchema ?? null,
		status: "pending",
		revision: 1,
		source: "responses",
		extensions: {
			...e.approvalLevel ? { approval_level: e.approvalLevel } : {},
			...e.args ? { arguments: e.args } : {}
		}
	});
}
//#endregion
//#region src/core/interaction/adapters/agui.ts
function vt(e) {
	return !e.interruptId || !e.sessionId ? null : pt({
		interactionId: e.interruptId,
		sessionId: e.sessionId,
		runId: e.runId ?? null,
		kind: "approval",
		title: e.name ? `确认：${e.name}` : "人工确认",
		message: e.message || "本次运行需要人工确认后才能继续。",
		requestSchema: e.requestSchema ?? null,
		status: "pending",
		revision: 1,
		source: "agui",
		extensions: {
			interrupt_id: e.interruptId,
			...e.toolCallId ? { tool_call_id: e.toolCallId } : {},
			...e.reason ? { reason: e.reason } : {}
		}
	});
}
//#endregion
//#region src/core/interaction/index.ts
var yt = new Set([
	"completed",
	"failed",
	"error",
	"cancelled",
	"canceled",
	"aborted",
	"interrupted",
	"resume_failed"
]), X = new ot();
function bt(e, t) {
	let n = gt(e, t);
	n && X.upsert(n);
	let r = typeof e == "object" && e ? e : null;
	if (r?.EventType === "control.command_rejected") {
		let e = r.Content;
		X.rejectCommand(String(r.SessionId || t || ""), String(e?.command_id || ""), String(e?.reason || "command_rejected"));
	}
	let i = r ? ie(r) : null;
	if (i !== null && yt.has(i)) {
		let e = typeof r?.Content == "object" && r.Content !== null ? r.Content : {}, n = typeof e.payload == "object" && e.payload !== null ? e.payload : {}, i = String(r?.SessionId || r?.session_id || t || ""), a = String(r?.InvocationId || r?.run_id || n.run_id || n.runId || "");
		X.markRunTerminal(i, a);
	}
	return n;
}
function xt(e) {
	let t = e.sessionId || "";
	if (!t || !e.approvalRequestId) return null;
	let n = e.protocol === "ag-ui" ? vt({
		interruptId: e.approvalRequestId,
		sessionId: t,
		name: e.name,
		message: e.message,
		reason: e.approvalLevel
	}) : _t({
		approvalRequestId: e.approvalRequestId,
		sessionId: t,
		runId: e.runId,
		name: e.name,
		message: e.message,
		args: e.args,
		approvalLevel: e.approvalLevel
	});
	return n && X.upsert(n), n;
}
function St(e) {
	let t = e.sessionId || "";
	return !t || !e.approvalRequestId ? null : bt({
		EventType: "approval.resolved",
		Content: {
			approvalId: e.approvalRequestId,
			revision: e.revision || 2,
			outcome: e.decision,
			actor: "user",
			resolvedAt: (/* @__PURE__ */ new Date()).toISOString()
		}
	}, t);
}
//#endregion
//#region src/hooks/useInteractions.ts
function Ct(e) {
	let [t] = Ce(() => new ct({
		agentId: e.agentId,
		store: X,
		submitInteraction: (t) => e.api.submitInteraction({
			...t,
			AgentId: e.getAgentId?.() ?? t.AgentId
		}),
		interactionV1Enabled: e.interactionV1Enabled,
		legacyResponsesApproval: e.legacyResponsesApproval,
		legacyAguiResume: e.legacyAguiResume
	}));
	z(() => {
		t.setInteractionV1Enabled(e.interactionV1Enabled);
	}, [t, e.interactionV1Enabled]);
	let [n, r] = Ce(0);
	z(() => X.subscribe(() => r((e) => e + 1)), []);
	let i = Se(() => e.currentSessionId ? X.listAll(e.currentSessionId).filter((e) => e.status === "pending" || e.status === "resolving" || e.status === "failed") : [], [n, e.currentSessionId]), a = Se(() => e.currentSessionId ? X.listAll(e.currentSessionId) : [], [n, e.currentSessionId]), { currentSessionId: o, interactionV1Enabled: s, onAcceptedInteraction: c } = e;
	return {
		client: t,
		pending: i,
		records: a,
		respond: R((e) => {
			let n = o ? X.get(o, e.interactionId) : null;
			return t.respond(e).then((e) => (s && n && (e.status === "accepted" || e.status === "duplicate") && c?.(n), e));
		}, [
			t,
			o,
			s,
			c
		]),
		localCatalog: d
	};
}
var wt = .28;
function Tt(e, t = 768) {
	return Number(e) <= t;
}
function Et({ isMobile: e, desktopSidebarOpen: t, mobileSidebarOpen: n }) {
	return {
		desktopSidebarVisible: !e && !!t,
		mobileDrawerVisible: !!(e && n)
	};
}
function Dt({ isMobile: e, viewportHeight: t, desktopMaxHeight: n = 160 }) {
	if (!e) return n;
	let r = Number(t);
	if (!Number.isFinite(r) || r <= 0) return n;
	let i = Math.floor(r * wt);
	return Math.max(120, Math.min(n, i));
}
//#endregion
//#region src/hooks/useResponsiveViewport.ts
function Ot() {
	return typeof window > "u" ? 900 : Math.round(window.visualViewport?.height || window.innerHeight || 900);
}
function kt() {
	return typeof window > "u" ? {
		isMobile: !1,
		viewportHeight: 900
	} : {
		isMobile: Tt(window.innerWidth, 768),
		viewportHeight: Ot()
	};
}
function At() {
	let [e, t] = Ce(() => kt());
	return z(() => {
		if (typeof window > "u") return;
		let e = window.matchMedia("(max-width: 768px)"), n = () => {
			t(kt());
		};
		n();
		let r = typeof e.addEventListener == "function" ? (e.addEventListener("change", n), () => e.removeEventListener("change", n)) : (e.addListener(n), () => e.removeListener(n));
		return window.addEventListener("resize", n), window.visualViewport?.addEventListener("resize", n), () => {
			r(), window.removeEventListener("resize", n), window.visualViewport?.removeEventListener("resize", n);
		};
	}, []), e;
}
//#endregion
//#region src/core/stream/responses-protocol.ts
var jt = class {
	id = "responses";
	createState() {
		return ue();
	}
	parseItemOperations(e, t, n) {
		return g(e.eventName, e.data, t, n);
	}
	parse(e, t) {
		let n = e.data;
		if (e.eventName === "interaction.requested" && n?.family === "interaction") {
			let e = n.payload, t = String(e?.interaction_id || "");
			if (t && n.session_id && n.run_id) return [{
				type: "canonical_interaction",
				interactionId: t,
				event: {
					EventType: "interaction.requested",
					SessionId: String(n.session_id),
					InvocationId: String(n.run_id),
					SeqId: Number(n.seq || 0),
					Content: { session_event: n }
				}
			}];
		}
		return ve({
			eventName: e.eventName,
			data: e.data,
			state: t
		}).map((e) => {
			if (e.type === "tool_upsert") {
				let { approvalRequestId: t, previousResponseId: n, serverLabel: r, ...i } = e;
				return {
					...i,
					extra: {
						...i.extra || {},
						...t ? { approvalRequestId: t } : {},
						...n ? { previousResponseId: n } : {},
						...r ? { serverLabel: r } : {},
						...t ? { approvalProtocol: "responses" } : {}
					}
				};
			}
			return e;
		});
	}
};
//#endregion
//#region src/utils/stream-parsing.ts
function Mt(e) {
	return typeof e == "string" ? e : Array.isArray(e) ? e.map((e) => typeof e == "string" ? e : e && typeof e == "object" && "text" in e && typeof e.text == "string" ? e.text : "").join("") : "";
}
function Nt(e) {
	return e && typeof e == "object" ? e : {};
}
function Pt(e) {
	let t = Nt(e).choices, n = Nt(Array.isArray(t) ? t[0] : null), r = Nt(n.delta), i = Nt(n.message);
	return {
		content: Mt(r.content),
		reasoning: Mt(r.reasoning_content),
		finalText: Mt(i.content)
	};
}
//#endregion
//#region src/core/stream/chat-completions-protocol.ts
var Ft = class {
	id = "chat_completions";
	createState() {
		return {};
	}
	parse(e) {
		let t = e.data;
		if (typeof t != "object" || !t) return [];
		let n = Pt(t), r = [];
		return n.reasoning && r.push({
			type: "reasoning_delta",
			text: n.reasoning
		}), n.content && r.push({
			type: "text_delta",
			text: n.content
		}), n.finalText && r.push({
			type: "text_final",
			text: n.finalText
		}), r;
	}
}, It = /* @__PURE__ */ new Map();
It.set("responses", new jt()), It.set("chat_completions", new Ft());
function Lt(e) {
	return It.get(e) || It.get("responses");
}
//#endregion
//#region src/utils/stream-control.js
function Rt(e = []) {
	return e.some((e) => {
		if (e?.type !== "terminal") return !1;
		let t = String(e.status || "").toLowerCase();
		return t === "failed" || t === "incomplete" || t === "cancelled";
	});
}
//#endregion
//#region src/core/transport/sse-parser.ts
function Z(e) {
	let t = [], n = e.trim();
	if (!n) return t;
	let r = n.split("\n");
	if (r.every((e) => e.startsWith(":"))) return t.push({
		eventName: "__ping__",
		data: null
	}), t;
	let i = "message", a = [];
	for (let e of r) e.startsWith(":") || (e.startsWith("event:") ? i = e.substring(6).trim() || "message" : e.startsWith("data:") && a.push(e.substring(5).trim()));
	let o = a.join("\n").trim();
	if (o === "[DONE]") return t.push({
		eventName: "__done__",
		data: null
	}), t;
	if (!o) return t;
	try {
		let e = JSON.parse(o);
		t.push({
			eventName: i,
			data: e
		});
	} catch {
		t.push({
			eventName: i,
			data: o
		});
	}
	return t;
}
function zt(e) {
	let t = e.split("\n\n");
	return {
		chunks: t,
		remainder: t.pop() || ""
	};
}
//#endregion
//#region src/utils/error.ts
function Bt(e) {
	return e instanceof Error ? e.message : String(e);
}
//#endregion
//#region src/utils/model-options.js
var Vt = new Set([
	"auto",
	"enabled",
	"disabled"
]);
function Ht(e) {
	let t = String(e || "").trim().toLowerCase();
	return Vt.has(t) ? t : "auto";
}
function Ut(e) {
	let t = Ht(e);
	if (t === "disabled") return { thinking: { type: "disabled" } };
	if (t === "enabled") return { thinking: { type: "enabled" } };
}
var Wt = 1280;
function Gt(e) {
	let { apiFormats: t } = e;
	return t.includes("responses") ? "responses" : t.includes("chat_completions") ? "chat_completions" : "responses";
}
function Kt(e, t, n) {
	let r = Math.min(Wt, Math.max(420, t - n - 360));
	return Math.min(Math.max(e, 420), r);
}
//#endregion
//#region src/core/run/agui.ts
function qt(e) {
	return String(e.type || "").toUpperCase();
}
function Jt(e, t) {
	return String(e.messageId || t);
}
function Yt(e, t) {
	return String(e.runId || t);
}
function Xt(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : {};
}
function Zt(e) {
	if (Array.isArray(e)) return l(e.filter((e) => !!(e && typeof e == "object")));
	if (e && typeof e == "object") {
		let t = e.a2ui_operations;
		return Array.isArray(t) ? l(t.filter((e) => !!(e && typeof e == "object"))) : [e];
	}
	return [];
}
function Qt(e) {
	return e == null || e === "" ? "" : typeof e == "string" ? e : JSON.stringify(e, null, 2);
}
var $t = class {
	agent;
	onEvent;
	tools = /* @__PURE__ */ new Map();
	runMessageIds = /* @__PURE__ */ new Map();
	pendingByRun = /* @__PURE__ */ new Map();
	activeRunId = "";
	constructor(e) {
		this.agent = new Te({
			url: e.url,
			agentId: e.agentId,
			threadId: e.threadId,
			fetch: e.fetch
		}), this.onEvent = e.onEvent;
	}
	async run(e, t, n) {
		return this.activeRunId = t, this.agent.addMessage({
			id: `${t}:user`,
			role: "user",
			content: e
		}), this.execute({
			runId: t,
			abortController: this.controllerFor(n)
		});
	}
	async resume(e, t) {
		let n = this.agent.pendingInterrupts.length > 0 ? this.agent.pendingInterrupts : this.pendingByRun.get(this.activeRunId) || [], r = Ee(n.length > 0 ? n : [{
			id: t.interruptId,
			reason: "approval"
		}], { [t.interruptId]: t.status === "resolved" ? {
			status: "resolved",
			payload: t.payload
		} : { status: "cancelled" } });
		if (!r.some((e) => e.interruptId === t.interruptId)) throw Error(`AG-UI interrupt ${t.interruptId} is not pending`);
		return this.activeRunId = e, this.execute({
			runId: e,
			resume: r
		});
	}
	abort() {
		this.agent.abortRun();
	}
	controllerFor(e) {
		if (!e) return;
		let t = new AbortController();
		return e.aborted && t.abort(e.reason), e.addEventListener("abort", () => t.abort(e.reason), { once: !0 }), t;
	}
	async execute(e) {
		let t = "completed", n = await this.agent.runAgent({
			runId: e.runId,
			context: [h],
			forwardedProps: { injectA2UITool: !0 },
			resume: e.resume,
			abortController: e.abortController
		}, {
			onEvent: ({ event: n }) => {
				let r = this.project(n, e.runId);
				r.status && (t = r.status), r.events.forEach((e) => this.onEvent(e));
			},
			onRunFinishedEvent: ({ outcome: e }) => {
				t = e === "interrupt" ? "interrupted" : "completed";
			},
			onRunErrorEvent: () => {
				t = "failed";
			}
		}), r = this.agent.pendingInterrupts.slice();
		return r.length > 0 && (this.pendingByRun.set(e.runId, r), t = "interrupted"), {
			status: t,
			result: n
		};
	}
	project(e, t) {
		let n = qt(e), r = Yt(e, t), i = Jt(e, `${r}:assistant`), a = e, o = [];
		if (n === "RUN_STARTED") o.push({
			type: "activity",
			phase: "AG-UI 运行已创建",
			status: "running",
			countEvent: !1
		});
		else if (n === "TEXT_MESSAGE_START") this.runMessageIds.set(r, i), o.push({
			type: "assistant_message_created",
			messageId: i
		});
		else if (n === "TEXT_MESSAGE_CONTENT") o.push({
			type: "text_delta",
			messageId: this.runMessageIds.get(r) || i,
			delta: String(a.delta || "")
		});
		else if (n === "TEXT_MESSAGE_END") o.push({
			type: "activity",
			phase: "生成回复内容",
			status: "running"
		});
		else if (n === "REASONING_MESSAGE_CONTENT") o.push({
			type: "reasoning_delta",
			messageId: this.runMessageIds.get(r) || i,
			delta: String(a.delta || "")
		});
		else if (n === "TOOL_CALL_START") {
			let e = String(a.toolCallId || "tool");
			this.tools.set(e, {
				name: String(a.toolCallName || "tool"),
				args: ""
			}), o.push({
				type: "tool_upsert",
				messageId: this.runMessageIds.get(r) || `${r}:assistant`,
				name: String(a.toolCallName || "tool"),
				args: "",
				status: "running"
			});
		} else if (n === "TOOL_CALL_ARGS") {
			let e = String(a.toolCallId || "tool"), t = this.tools.get(e) || {
				name: "tool",
				args: ""
			};
			t.args += String(a.delta || ""), this.tools.set(e, t), o.push({
				type: "tool_upsert",
				messageId: this.runMessageIds.get(r) || `${r}:assistant`,
				name: t.name,
				args: t.args,
				status: "running"
			});
		} else if (n === "TOOL_CALL_RESULT") {
			let e = String(a.toolCallId || "tool"), t = this.tools.get(e) || {
				name: "tool",
				args: ""
			};
			o.push({
				type: "tool_result",
				messageId: this.runMessageIds.get(r) || `${r}:assistant`,
				name: t.name,
				output: String(a.content || "")
			});
		} else if (n === "ACTIVITY_SNAPSHOT") {
			let e = a.content, t = Xt(e), n = String(t.surfaceId || t.surface_id || a.messageId || "default");
			o.push({
				type: "agui_activity",
				messageId: this.runMessageIds.get(r) || i,
				surfaceId: n,
				messages: Zt(t.content ?? e)
			});
		} else if (n === "RUN_FINISHED") {
			let e = Xt(a.outcome);
			if (String(e.type || "").toLowerCase() === "interrupt") {
				let t = Array.isArray(e.interrupts) ? e.interrupts : [];
				this.pendingByRun.set(r, t);
				for (let e of t) {
					let t = Xt(e.metadata), n = e.toolCallId ? this.tools.get(e.toolCallId) : void 0, i = String(t.tool_name || t.toolName || n?.name || e.reason || "人工确认"), a = Qt(t.arguments ?? t.tool_args ?? t.args ?? n?.args);
					o.push({
						type: "approval_requested",
						messageId: this.runMessageIds.get(r) || `${r}:assistant`,
						approvalRequestId: e.id,
						protocol: "ag-ui",
						name: i,
						args: a,
						...e.message ? { message: e.message } : {},
						...t.approval_level ? { approvalLevel: String(t.approval_level) } : {}
					});
				}
				return o.push({
					type: "activity",
					phase: "等待人工确认",
					status: "waiting"
				}), {
					events: o,
					status: "interrupted"
				};
			}
			o.push({
				type: "terminal",
				status: "completed"
			});
		} else if (n === "RUN_ERROR") return o.push({
			type: "error",
			error: /* @__PURE__ */ Error("AG-UI 运行失败")
		}), {
			events: o,
			status: "failed"
		};
		return { events: o };
	}
}, en = new Set([
	"completed",
	"failed",
	"error",
	"cancelled",
	"canceled",
	"aborted",
	"interrupted",
	"resume_failed"
]);
function tn(e) {
	if (e.EventType !== "run_status") return null;
	let t = String(e.Content?.status || "").trim().toLowerCase();
	return en.has(t) ? t : null;
}
function nn(e, t) {
	let n = String(t?.type || e || "").trim();
	if (n === "response.created") return {
		phase: "运行已创建",
		status: "running"
	};
	if (n === "response.in_progress") return {
		phase: "等待运行时输出",
		status: "waiting"
	};
	if (n === "response.output_item.added") {
		let e = t?.item;
		return e?.type === "function_call" ? {
			phase: `调用工具 ${e.name || "tool"}`,
			status: "running"
		} : String(e?.type || "").includes("reasoning") ? {
			phase: "生成思考过程",
			status: "running"
		} : {
			phase: "生成回复内容",
			status: "running"
		};
	}
	return n.includes("reasoning") ? {
		phase: "生成思考过程",
		status: "running"
	} : n.includes("function_call") || n === "response.tool_call" ? {
		phase: "调用工具",
		status: "running"
	} : n.includes("tool_result") ? {
		phase: "收到工具结果",
		status: "running"
	} : n.includes("output_text") || n.includes("content_part") ? {
		phase: "生成回复内容",
		status: "running"
	} : n === "response.completed" ? {
		phase: "运行完成",
		status: "completed"
	} : n === "response.failed" ? {
		phase: "运行失败",
		status: "failed"
	} : n === "response.incomplete" ? {
		phase: "运行中断",
		status: "failed"
	} : null;
}
function rn() {
	let e = globalThis.crypto;
	return e && typeof e.randomUUID == "function" ? `run_${e.randomUUID()}` : `run_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
var an = {
	idle: [
		"creating-session",
		"uploading-files",
		"connecting",
		"error"
	],
	"creating-session": [
		"uploading-files",
		"connecting",
		"error",
		"idle"
	],
	"uploading-files": [
		"connecting",
		"error",
		"idle"
	],
	connecting: [
		"streaming",
		"error",
		"idle"
	],
	streaming: [
		"completing",
		"stopping",
		"recovering",
		"error"
	],
	stopping: ["cancelled", "idle"],
	completing: ["idle"],
	recovering: [
		"streaming",
		"error",
		"idle"
	],
	error: ["connecting", "idle"],
	cancelled: ["idle"]
}, on = class {
	_stage = "idle";
	listeners = /* @__PURE__ */ new Set();
	abortController = null;
	activeCompactionId = null;
	activeSessionId = null;
	invocationId = "";
	operationEpoch = 0;
	lastSeqId = 0;
	pendingConfig = null;
	projection;
	aguiClient = null;
	aguiThreadSessionId = null;
	api;
	controlStateValue = { phase: "idle" };
	lastControlCommand = null;
	config = {
		agentId: "default-agent",
		apiFormats: ["responses"],
		agentFramework: "",
		selectedModel: "",
		thinkingMode: "auto"
	};
	constructor(e, t = {}) {
		this.api = e, this.projection = t;
	}
	get activeInvocationId() {
		return this.invocationId;
	}
	get streamingKey() {
		return this.activeSessionId || this.projection.draftId || null;
	}
	publishInvocation(e) {
		this.invocationId = e, e && c.getState().updateActivity({
			sessionId: this.streamingKey,
			runId: e,
			countEvent: !1,
			visible: this.projection.isVisible?.()
		}), this.projection.isVisible?.() !== !1 && (c.getState().setCurrentRunId(e), c.getState().setActiveInvocationId(e));
	}
	recordCursor(e) {
		this.lastSeqId = e === 0 ? 0 : Math.max(this.lastSeqId, e), this.projection.isVisible?.() !== !1 && c.getState().setLastSeqId(this.lastSeqId);
	}
	stopActivity(e) {
		let t = c.getState(), n = this.projection.isVisible?.() !== !1;
		this.streamingKey ? t.stopSessionActivity(this.streamingKey, e, n) : n && t.stopActivity(e);
	}
	get stage() {
		return this._stage;
	}
	get controlState() {
		return this.controlStateValue;
	}
	async submitControl(e) {
		this.lastControlCommand = e;
		let t;
		try {
			t = G(await this.api.submitControl(e));
		} catch (e) {
			if (e instanceof W) return this.controlStateValue = {
				phase: "contract_mismatch",
				error: null,
				receipt: null
			}, this.emit({
				type: "system_message",
				content: "【系统提示】控制指令响应不符合 agent-kernel/v1 合同，已停止变更本地状态。"
			}), this.controlStateValue;
			throw e;
		}
		return this.controlStateValue = this.controlStateFor(t, e), t.status === "accepted" || t.status === "duplicate" ? this.emit({
			type: "activity",
			phase: "指令已入队，等待运行时处理",
			status: "waiting",
			countEvent: !1
		}) : t.status === "queue_full" ? this.emit({
			type: "system_message",
			content: "【系统提示】指令队列已满，可点击重试；重试将复用同一幂等键。"
		}) : t.status === "unsupported" ? this.emit({
			type: "system_message",
			content: `【系统提示】运行时不支持该操作：${t.error?.message || ""}`
		}) : t.status === "persistence_uncertain" ? this.emit({
			type: "system_message",
			content: "【系统提示】指令提交结果待确认，正在查询状态…"
		}) : t.status === "rejected" && this.emit({
			type: "system_message",
			content: `【系统提示】指令被拒绝：${t.error?.message || ""}`
		}), this.controlStateValue;
	}
	controlStateFor(e, t) {
		switch (e.status) {
			case "accepted":
			case "duplicate": return {
				phase: "queued",
				receipt: e,
				error: null
			};
			case "queue_full": return {
				phase: "retryable",
				retryKey: t.idempotency_key,
				receipt: e,
				error: e.error
			};
			case "unsupported": return {
				phase: "unsupported",
				receipt: e,
				error: e.error
			};
			case "persistence_uncertain": return {
				phase: "confirming",
				retryKey: t.idempotency_key,
				receipt: e,
				error: e.error
			};
			default: return {
				phase: "rejected",
				receipt: e,
				error: e.error
			};
		}
	}
	async retryControl() {
		let e = this.lastControlCommand;
		if (!e || this.controlStateValue.phase !== "retryable" && this.controlStateValue.phase !== "confirming") return this.controlStateValue;
		if (this.controlStateValue.phase === "confirming") try {
			await this.api.getAgentStatus();
		} catch (e) {
			console.warn("[RunEngine] status query after persistence_uncertain failed:", e);
		}
		return this.submitControl(e);
	}
	updateConfig(e) {
		let t = {
			...e,
			apiFormats: [...e.apiFormats]
		};
		this._stage === "idle" ? this.config = t : this.pendingConfig = t;
	}
	emit(e) {
		e.type === "stream_event" && typeof e.event.SeqId == "number" && this.recordCursor(e.event.SeqId);
		let t = "sessionId" in e ? e : {
			...e,
			sessionId: this.activeSessionId
		};
		for (let e of this.listeners) e(t);
	}
	getAguiClient(e) {
		let t = this.config.hostedChatTransport;
		return t?.Protocol !== "ag-ui" || !t.Endpoint ? null : ((!this.aguiClient || this.aguiThreadSessionId !== e) && (this.aguiClient = new $t({
			url: t.Endpoint,
			agentId: this.config.agentId,
			threadId: e,
			onEvent: (e) => this.emit(e)
		}), this.aguiThreadSessionId = e), this.aguiClient);
	}
	setStage(e) {
		if (this._stage === e) return;
		let t = an[this._stage];
		t && !t.includes(e) && console.warn(`[RunEngine] Invalid transition: ${this._stage} → ${e}`), this._stage = e, e === "idle" && this.pendingConfig && (this.config = this.pendingConfig, this.pendingConfig = null), this.emit({
			type: "stage_changed",
			stage: e
		});
	}
	subscribe(e) {
		return this.listeners.add(e), () => {
			this.listeners.delete(e);
		};
	}
	start(e) {
		if (this._stage !== "idle") return !1;
		let t = ++this.operationEpoch;
		this.abortController = new AbortController(), this.activeSessionId = e.sessionId || null, this.invocationId = "", this.recordCursor(0), this.setStage(this.activeSessionId ? "connecting" : "creating-session");
		let n = e.responsesInput !== void 0, r = !1, i = (t) => {
			r || (r = !0, e.onDispatchResult?.(t));
		};
		return (async () => {
			let r = e.sessionId || null, a = "unknown", o = !1;
			try {
				if (r ||= await this.createSession(e), !r) throw Error("运行时未返回会话身份，请确认创建结果后重试。");
				this.activeSessionId = r;
				let s = rn();
				this.publishInvocation(s), e.onInvocationCreated?.(s), this.recordCursor(0);
				let c = n ? null : await this.getConversationBootstrap(r);
				if (c && this.config.conversationClient) {
					let n = await this.buildCanonicalConversationInput(c, r, s, e);
					this.setStage("connecting"), this.emit({
						type: "activity",
						phase: "连接会话运行时",
						status: "connecting",
						countEvent: !1
					}), this.setStage("streaming"), this.emit({
						type: "activity",
						phase: "等待会话输出",
						status: "waiting",
						countEvent: !1
					});
					let i = await this.config.conversationClient.streamTurn({
						bootstrap: c,
						input: n,
						signal: this.abortController?.signal,
						onUpdate: (t) => {
							t.runId && (this.publishInvocation(t.runId), e.onInvocationCreated?.(t.runId)), this.emit({
								type: "conversation_snapshot",
								result: t,
								sessionId: r,
								optimisticMessageId: e.optimisticMessageId
							});
						}
					});
					if (this.operationEpoch !== t) return;
					if (i.presentation.terminalStatus === "failed") {
						o = !0, a = "failed", this.setStage("error"), this.emit({
							type: "activity",
							phase: "运行失败",
							status: "failed",
							countEvent: !1
						});
						return;
					}
					this.setStage("completing"), a = "completed", this.emit({
						type: "activity",
						phase: "运行完成",
						status: "completed",
						countEvent: !1
					}), this.emit({
						type: "stream_ended",
						sessionId: r,
						runId: i.runId
					});
					return;
				}
				let l = await this.uploadFiles(e, n);
				this.setStage("connecting"), this.emit({
					type: "activity",
					phase: "连接运行时",
					status: "connecting",
					countEvent: !1
				});
				let u = n ? "responses" : Gt({
					agentFramework: this.config.agentFramework,
					apiFormats: this.config.apiFormats
				}), d = Lt(u), f = d.createState(), p = this.config.hostedChatTransport, m = !n && !e.executionMode && e.attachments.length === 0 && p?.Protocol === "ag-ui" ? this.getAguiClient(r) : null;
				if (m && p) {
					this.setStage("streaming"), this.emit({
						type: "activity",
						phase: "等待 AG-UI 输出",
						status: "waiting",
						countEvent: !1
					});
					let t = await m.run(e.text, s, this.abortController?.signal);
					if (t.status === "interrupted") {
						a = "cancelled", this.setStage("completing"), this.emit({ type: "stream_ended" });
						return;
					}
					if (t.status !== "completed") {
						a = "failed", this.setStage("error"), this.emit({
							type: "activity",
							phase: "AG-UI 运行失败",
							status: "failed",
							countEvent: !1
						});
						return;
					}
					this.setStage("completing"), a = "completed", this.emit({
						type: "activity",
						phase: "运行完成",
						status: "completed",
						countEvent: !1
					}), this.emit({ type: "stream_ended" });
					return;
				}
				let h = this.buildRequestBody(r, u, n, e, l, s), g = this.config.kernelSessionEventsEnabled && this.config.presentationProfile === "agent-block-v1" ? "agent-block-v1" : "flat-v1", _ = await this.api.runAgent(h, { signal: this.abortController?.signal });
				if (this.operationEpoch !== t || this.abortController?.signal.aborted) {
					i(!1), await _.cancel();
					return;
				}
				this.config.kernelSessionEventsEnabled || i(!0), this.setStage("streaming"), this.emit({
					type: "activity",
					phase: "等待首个输出",
					status: "waiting",
					countEvent: !1
				});
				let v = `msg-${Date.now()}`, y = await oe(_);
				if (this.operationEpoch !== t || this.abortController?.signal.aborted) {
					i(!1), await y.stream.cancel();
					return;
				}
				this.config.kernelSessionEventsEnabled && i(!y.receipt || y.receipt.status === "accepted" || y.receipt.status === "duplicate");
				let b;
				if (b = y.receipt ? await this.consumeKernelRunEvents(r, y.receipt, e.onInvocationCreated, g) : await this.consumeStream(y.stream, d, f, v, s), this.operationEpoch !== t) return;
				if (b.awaitingInput) {
					a = "awaiting-input", this.setStage("completing"), this.emit({
						type: "activity",
						phase: "等待人工确认",
						status: "waiting",
						countEvent: !1
					}), this.emit({ type: "stream_ended" });
					return;
				}
				if (b.terminalStatus === "cancelled") {
					a = "cancelled", this.setStage("stopping"), this.stopActivity("运行时已取消本次执行。"), this.emit({
						type: "activity",
						phase: "运行已取消",
						status: "stopped",
						countEvent: !1
					}), this.setStage("cancelled");
					return;
				}
				if (b.terminalStatus && b.terminalStatus !== "completed") {
					o = b.submissionAccepted === !0, a = "failed", this.setStage("error"), this.emit({
						type: "activity",
						phase: b.terminalStatus === "incomplete" ? "运行中断" : "运行失败",
						status: "failed",
						countEvent: !1
					});
					return;
				}
				this.setStage("completing"), a = "completed", this.emit({
					type: "activity",
					phase: "运行完成",
					status: "completed",
					countEvent: !1
				}), this.emit({ type: "stream_ended" });
			} catch (e) {
				if (this.failCompaction(), e instanceof DOMException && e.name === "AbortError" || e instanceof j && e.code === "conversation_aborted") a = "cancelled";
				else {
					let t = e instanceof TypeError;
					if (a = t ? "unknown" : "failed", console.error("[RunEngine] start() error:", e), t) {
						this.setStage("recovering"), this.emit({
							type: "activity",
							phase: "网络异常，尝试重连",
							status: "waiting",
							countEvent: !1
						});
						let t = this.lastSeqId, n = this.invocationId;
						if (t > 0 && n && this.activeSessionId) try {
							await this.resumeRun({
								sessionId: this.activeSessionId,
								invocationId: n,
								afterSeqId: t
							});
							return;
						} catch (e) {
							console.warn("[RunEngine] afterSeqId resume failed, fall back to error:", e);
						}
						this.setStage("error"), this.emit({
							type: "error",
							error: e instanceof Error ? e : Error(String(e))
						});
					} else e instanceof H && e.code === 429 ? (this.setStage("error"), this.emit({
						type: "rate_limited",
						message: e.message || "请求过于频繁，请稍后重试",
						sessionId: r
					})) : (this.setStage("error"), this.emit({
						type: "error",
						error: e instanceof Error ? e : Error(String(e))
					}));
				}
			} finally {
				i(!1), this.operationEpoch === t && (c.getState().setSessionStreaming(this.streamingKey, !1), this.setStage("idle"), this.activeCompactionId = null, this.activeSessionId = null, o ? e.onSettled?.(r, a, { accepted: !0 }) : e.onSettled?.(r, a));
			}
		})(), !0;
	}
	stop() {
		if (this._stage === "idle") return;
		this.setStage("stopping");
		let e = this.invocationId;
		e && this.activeSessionId && this.api.cancelRun(this.config.agentId, this.activeSessionId, e).catch((e) => {
			console.warn("[RunEngine] cancelRun on stop failed:", e);
		}), this.abortController?.abort(), this.aguiClient?.abort(), this.stopActivity(e ? "已向运行时发送取消请求；如果当前框架只支持协作式取消，后台可能会在下一个安全点停止。" : void 0), this.publishInvocation(""), this.setStage("cancelled"), this.emit({
			type: "system_message",
			content: e ? "已请求取消本次运行。" : "已停止接收本次输出；如果运行时不支持取消，后台执行可能仍会继续。"
		});
	}
	disconnect() {
		this._stage !== "idle" && (this.operationEpoch += 1, this.abortController?.abort(), this.aguiClient?.abort(), c.getState().setSessionStreaming(this.streamingKey, !1), this.projection.isVisible?.() !== !1 && c.getState().clearActivity(), this._stage = "idle", this.activeCompactionId = null, this.activeSessionId = null);
	}
	async cancelRemote(e) {
		try {
			this.activeSessionId && await this.api.cancelRun(this.config.agentId, this.activeSessionId, e);
		} catch (e) {
			console.warn("[RunEngine] cancelRemote failed:", e);
		}
		this.stop();
	}
	async resumeRun(e) {
		this.abortController?.abort(), this.abortController = new AbortController(), this.activeSessionId = e.sessionId, this.publishInvocation(e.invocationId), this.setStage("connecting"), this.emit({
			type: "activity",
			phase: "恢复运行事件订阅",
			status: "connecting",
			countEvent: !1
		});
		let t = null;
		try {
			let n = await this.api.subscribeRunEvents({
				sessionId: e.sessionId,
				invocationId: e.invocationId,
				afterSeqId: e.afterSeqId
			}, { signal: this.abortController?.signal });
			this.setStage("streaming"), this.emit({
				type: "activity",
				phase: "等待恢复事件",
				status: "waiting",
				countEvent: !1
			});
			let r = n.getReader(), i = new TextDecoder(), a = "";
			for (;;) {
				let { value: e, done: n } = await r.read();
				if (n) break;
				a += i.decode(e, { stream: !0 });
				let { chunks: o, remainder: s } = zt(a);
				a = s;
				for (let e of o) {
					if (!e.trim()) continue;
					let n = Z(e);
					for (let e of n) e.eventName === "__done__" || e.eventName === "__ping__" || (this.emit({
						type: "activity",
						phase: "收到恢复事件",
						status: "running"
					}), this.emit({
						type: "stream_event",
						event: e.data
					}), t = tn(e.data) || t);
				}
			}
			this.setStage("completing"), t === "cancelled" || t === "canceled" || t === "aborted" ? this.emit({
				type: "activity",
				phase: "后台长任务已取消",
				status: "stopped",
				countEvent: !1
			}) : t === "interrupted" ? this.emit({
				type: "activity",
				phase: "后台长任务已中断",
				status: "stopped",
				countEvent: !1
			}) : t === "failed" || t === "error" ? this.emit({
				type: "activity",
				phase: "后台长任务失败",
				status: "failed",
				countEvent: !1
			}) : t === "resume_failed" ? this.emit({
				type: "activity",
				phase: "后台长任务恢复失败",
				status: "failed",
				countEvent: !1
			}) : t ? this.emit({
				type: "activity",
				phase: "后台长任务已完成",
				status: "completed",
				countEvent: !1
			}) : this.emit({
				type: "activity",
				phase: "后台长任务状态待确认",
				status: "waiting",
				detail: "事件流已结束，但运行时尚未提供终态；正在等待会话状态对账。",
				countEvent: !1
			}), t && this.emit({ type: "stream_ended" }), e.onSessionReloadNeeded?.();
		} catch (e) {
			e instanceof DOMException && e.name === "AbortError" || console.error("Failed to subscribe to run events:", e);
		} finally {
			c.getState().setSessionStreaming(e.sessionId, !1), this.publishInvocation(""), this.setStage("idle"), this.activeSessionId = null;
		}
	}
	resumeCheckpoint(e) {
		if (this._stage !== "idle") return !1;
		let t = ++this.operationEpoch;
		this.abortController = new AbortController(), this.activeSessionId = e.sessionId;
		let n = rn();
		return this.publishInvocation(n), (async () => {
			let r = "unknown";
			try {
				if (this.setStage("connecting"), this.emit({
					type: "activity",
					source: "restore",
					phase: "从 checkpoint 恢复运行",
					status: "connecting",
					countEvent: !1
				}), this.config.checkpointResumePreviewEnabled) try {
					let t = (await this.api.previewCheckpointResume({
						agentId: this.config.agentId,
						sessionId: e.sessionId,
						runId: e.runId,
						checkpointId: e.checkpointId
					}, { signal: this.abortController?.signal })).Preview?.Risk?.Level || "unknown";
					this.emit({
						type: "activity",
						source: "restore",
						phase: `恢复预览完成：${String(t)} 风险`,
						status: "waiting",
						countEvent: !1
					});
				} catch (e) {
					console.warn("[RunEngine] checkpoint resume preview failed:", e);
				}
				let t = await this.api.resumeRun({
					agentId: this.config.agentId,
					sessionId: e.sessionId,
					runId: e.runId,
					checkpointId: e.checkpointId,
					resumeAttemptId: e.resumeAttemptId,
					invocationId: n
				}, { signal: this.abortController?.signal }), i = Lt("responses"), a = i.createState();
				this.setStage("streaming"), this.emit({
					type: "activity",
					source: "restore",
					phase: "等待恢复输出",
					status: "waiting",
					countEvent: !1
				});
				let o = `msg-${Date.now()}`, s = await this.consumeStream(t, i, a, o, n);
				if (s.awaitingInput) {
					r = "awaiting-input", this.setStage("completing"), this.emit({
						type: "activity",
						source: "restore",
						phase: "等待人工确认",
						status: "waiting",
						countEvent: !1
					}), this.emit({ type: "stream_ended" });
					return;
				}
				if (s.terminalStatus && s.terminalStatus !== "completed") {
					if (s.terminalStatus === "cancelled") {
						r = "cancelled", this.setStage("stopping"), this.stopActivity("运行时已取消本次恢复。"), this.emit({
							type: "activity",
							source: "restore",
							phase: "恢复已取消",
							status: "stopped",
							countEvent: !1
						}), this.setStage("cancelled");
						return;
					}
					this.setStage("error"), r = "failed", this.emit({
						type: "activity",
						source: "restore",
						phase: s.terminalStatus === "incomplete" ? "恢复中断" : "恢复失败",
						status: "failed",
						countEvent: !1
					});
					return;
				}
				this.setStage("completing"), r = "completed", this.emit({
					type: "activity",
					source: "restore",
					phase: "恢复完成",
					status: "completed",
					countEvent: !1
				}), this.emit({ type: "stream_ended" });
			} catch (e) {
				e instanceof DOMException && e.name === "AbortError" ? r = "cancelled" : (r = "failed", console.error("[RunEngine] resumeCheckpoint() error:", e), this.setStage("error"), this.emit({
					type: "error",
					error: e instanceof Error ? e : Error(String(e))
				}));
			} finally {
				this.operationEpoch === t && (c.getState().setSessionStreaming(e.sessionId, !1), this.publishInvocation(""), this.setStage("idle"), this.activeSessionId = null, e.onSettled?.(e.sessionId, r));
			}
		})(), !0;
	}
	resumeAguiInterrupt(e) {
		if (this._stage !== "idle") return !1;
		let t = e.sessionId || this.aguiThreadSessionId;
		if (!t) return !1;
		let n = this.getAguiClient(t);
		if (!n) return !1;
		let r = ++this.operationEpoch;
		this.activeSessionId = t;
		let i = rn();
		return this.publishInvocation(i), this.setStage("connecting"), this.emit({
			type: "activity",
			phase: "提交人工确认",
			status: "connecting",
			countEvent: !1
		}), (async () => {
			let a = "unknown";
			try {
				this.setStage("streaming");
				let t = await n.resume(i, {
					interruptId: e.interruptId,
					status: e.status,
					payload: e.payload
				}), r = e.payload && typeof e.payload == "object" ? e.payload : {}, o = String(r.decision || r.type || "").toLowerCase();
				if (this.emit({
					type: "approval_resolved",
					approvalRequestId: e.interruptId,
					decision: e.status === "cancelled" ? "cancelled" : o === "reject" || o === "rejected" ? "rejected" : "approved"
				}), t.status === "interrupted") {
					a = "cancelled", this.setStage("completing"), this.emit({ type: "stream_ended" });
					return;
				}
				if (t.status !== "completed") {
					a = "failed", this.setStage("error"), this.emit({
						type: "activity",
						phase: "人工确认恢复失败",
						status: "failed",
						countEvent: !1
					});
					return;
				}
				this.setStage("completing"), a = "completed", this.emit({
					type: "activity",
					phase: "运行完成",
					status: "completed",
					countEvent: !1
				}), this.emit({ type: "stream_ended" });
			} catch (e) {
				a = e instanceof DOMException && e.name === "AbortError" ? "cancelled" : "failed", this.setStage("error"), this.emit({
					type: "error",
					error: e instanceof Error ? e : Error(String(e))
				});
			} finally {
				this.operationEpoch === r && (this.publishInvocation(""), this.setStage("idle"), this.activeSessionId = null, e.onSettled?.(t, a));
			}
		})(), !0;
	}
	async createSession(e) {
		let t = await this.api.createSession(this.config.agentId, { signal: this.abortController?.signal });
		this.abortController?.signal.throwIfAborted();
		let n = t.SessionId || null;
		if (!n) throw Error("运行时未返回会话身份，请确认创建结果后重试。");
		return this.activeSessionId = n, e.onSessionCreated?.(n), e.onSessionUpsert?.(n), n;
	}
	async getConversationBootstrap(e) {
		let t = this.config.conversationClient;
		if (!t) return null;
		try {
			return await t.getSurface(this.config.agentId, e, { signal: this.abortController?.signal });
		} catch (e) {
			if (e instanceof j && e.code === "conversation_http_error" && e.status === 404) return null;
			throw e;
		}
	}
	async buildCanonicalConversationInput(e, t, n, r) {
		let i = [], a = r.text.trim();
		a && i.push({
			kind: "text",
			text: a
		});
		for (let t of r.attachments) {
			let n = t.type.startsWith("image/") ? "attachment.image" : "attachment.file";
			if (!A(e.surface, n)) throw new j("conversation_input_unsupported", "Conversation attachment is not declared by the active surface.", { capability: n });
		}
		r.attachments.length > 0 && i.push(...await this.uploadCanonicalAttachments(r.attachments));
		let o = Ht(this.config.thinkingMode), s = M({
			inputId: `input:${n}`,
			sessionId: t,
			idempotencyKey: `conversation:${n}`,
			parts: i,
			...this.config.selectedModel && A(e.surface, "model.select") ? { modelRef: this.config.selectedModel } : {},
			...o !== "auto" && A(e.surface, "reasoning.effort") ? { reasoning: o } : {},
			extensions: {
				...this.config.permissionMode && A(e.surface, "approval") ? { "ksadk.approval": this.config.permissionMode } : {},
				...r.executionMode === "plan" ? { "ksadk.collaboration": "plan" } : {},
				...r.executionMode === "goal" && a ? { "ksadk.goal": a } : {}
			}
		});
		return k(e.surface, s);
	}
	async uploadCanonicalAttachments(e) {
		this.setStage("uploading-files");
		let t = [];
		for (let n of e) {
			if (n.size > 100 * 1024 * 1024) throw new j("conversation_input_unsupported", "Conversation attachment exceeds the Hosted UI upload limit.", { capability: n.type.startsWith("image/") ? "attachment.image" : "attachment.file" });
			let e = new FormData();
			e.append("file", n), e.append("AgentId", this.config.agentId);
			let r;
			try {
				r = await this.api.uploadFile(e, { signal: this.abortController?.signal });
			} catch (e) {
				throw new j("conversation_http_error", "Conversation attachment upload failed.", { cause: e });
			}
			let i = r?.FileData?.fileUri;
			if (!i) throw new j("conversation_contract_mismatch", "Conversation attachment upload did not return an attachment reference.");
			t.push({
				kind: "attachment",
				attachmentRef: i,
				mediaType: r.FileData.mimeType || n.type || "application/octet-stream",
				name: r.FileData.displayName || n.name
			});
		}
		return t;
	}
	async uploadFiles(e, t) {
		let n = [];
		if (t || e.attachments.length === 0) return n;
		this.setStage("uploading-files");
		for (let t of e.attachments) {
			if (t.size > 100 * 1024 * 1024) {
				this.emit({
					type: "system_message",
					content: `【系统提示】文件 ${t.name} 超过 100MB 限制，未发送。`
				});
				continue;
			}
			if (t.type.startsWith("image/")) {
				try {
					n.push({
						type: "input_image",
						image_url: await this.imageFileToDataUrl(t)
					});
				} catch (e) {
					this.emit({
						type: "system_message",
						content: `【系统提示】图片 ${t.name} 读取失败，原因: ${Bt(e)}`
					});
				}
				continue;
			}
			let e = new FormData();
			e.append("file", t), e.append("AgentId", this.config.agentId);
			try {
				let r = await this.api.uploadFile(e, { signal: this.abortController?.signal });
				r?.FileData?.fileUri && n.push({
					type: "input_file",
					filename: r.FileData.displayName || t.name,
					file_url: r.FileData.fileUri
				});
			} catch (e) {
				this.emit({
					type: "system_message",
					content: `【系统提示】文件 ${t.name} 上传失败，原因: ${Bt(e)}`
				});
			}
		}
		return n;
	}
	async imageFileToDataUrl(e) {
		let t = new Uint8Array(await e.arrayBuffer()), n = "", r = 32768;
		for (let e = 0; e < t.length; e += r) n += String.fromCharCode(...t.subarray(e, e + r));
		return `data:${e.type || "application/octet-stream"};base64,${btoa(n)}`;
	}
	buildRequestBody(e, t, n, r, i, a) {
		let o = this.buildExecutionMetadata(r), s = {
			AgentId: this.config.agentId,
			SessionId: e,
			InvocationId: a,
			Stream: !0,
			...this.config.kernelSessionEventsEnabled ? { Background: !0 } : {},
			...this.config.kernelSessionEventsEnabled && this.config.presentationProfile === "agent-block-v1" ? { Extensions: { "ksadk.presentation": { profile: "agent-block-v1" } } } : {},
			ApiFormat: t,
			Model: this.config.selectedModel || void 0,
			ModelMetadata: this.config.selectedModelMetadata || void 0,
			ModelOptions: Ut(Ht(this.config.thinkingMode)),
			Metadata: { agentengine: {
				tool_approval_mode: this.config.permissionMode || "risk",
				...o
			} }
		};
		if (n) s.ResponsesInput = r.responsesInput, s.PreviousResponseId = r.previousResponseId;
		else {
			let e = [{
				type: "input_text",
				text: r.text.trim()
			}];
			e.push(...i), t === "responses" && (s.ResponsesInput = [{
				role: "user",
				content: e
			}]), s.Messages = [{
				role: "user",
				content: e
			}];
		}
		return s;
	}
	buildExecutionMetadata(e) {
		let t = e.executionMode;
		if (!t) return {};
		let n = this.config.runtimeCapabilityMatrix?.[t];
		if (!n?.supported || n.mode === "unavailable") return {};
		if (t === "plan") return { collaboration_mode: "plan" };
		if (t === "goal") {
			let t = e.text.trim();
			return t ? {
				collaboration_mode: "default",
				goal_objective: t
			} : {};
		}
		return {};
	}
	async consumeKernelRunEvents(e, t, n, r = "flat-v1") {
		if (t.status === "rejected" || t.status === "unsupported") return this.setStage("error"), this.emit({
			type: "error",
			error: Error(t.error?.message || `运行提交被拒绝（${t.status}）`)
		}), {
			terminalStatus: "failed",
			submissionAccepted: !1
		};
		if (t.status === "queue_full") return this.setStage("error"), this.emit({
			type: "rate_limited",
			message: "运行队列已满，请稍后重试"
		}), {
			terminalStatus: "failed",
			submissionAccepted: !1
		};
		t.status === "persistence_uncertain" && this.emit({
			type: "system_message",
			content: "提交结果未知，正在从事件流确认运行状态…"
		}), this.emit({
			type: "activity",
			phase: "已提交运行，订阅事件流",
			status: "running",
			countEvent: !1
		});
		let i = new ae(e), a = r === "agent-block-v1" && t.presentationProfile === "agent-block-v1" ? "agent-block-v1" : "flat-v1", o = new N(e, void 0, a), s = !t.commandId, c = t.runId || "";
		c && (this.publishInvocation(c), n?.(c));
		let l, u = 0;
		for (; l === void 0 && u < 6;) try {
			let r = this.lastSeqId, d = await this.api.subscribeSessionEvents(e, r, { signal: this.abortController?.signal });
			u = 0;
			let f = d.getReader(), p = new TextDecoder(), m = "";
			for (; l === void 0;) {
				let { value: r, done: u } = await f.read();
				if (u) break;
				m += p.decode(r, { stream: !0 });
				let d = zt(m);
				m = d.remainder;
				for (let r of d.chunks) if (r.trim()) for (let u of Z(r)) {
					let r = u.data;
					if (!r || typeof r != "object") continue;
					let d = Number(r.seq);
					if (Number.isFinite(d) && d > 0 && this.recordCursor(d), !s) {
						s = r.event_type === "control.command_accepted" && r.command_id === t.commandId;
						continue;
					}
					let f = String(r.run_id || "");
					if (!c && f && (c = f, this.publishInvocation(c), n?.(c)), f && c !== f) continue;
					if (r.schema_version === 2 && r.family === "runtime" && o.apply(r)) {
						let t = o.snapshot();
						this.emit({
							type: "conversation_snapshot",
							sessionId: e,
							result: {
								state: t,
								presentation: P(t, { profile: a }),
								runId: c,
								cursor: this.lastSeqId
							}
						});
					}
					let p = i.translate(r);
					if (p && (this.emit({
						type: "stream_event",
						event: p,
						sessionId: e
					}), p.EventType === "run_status")) {
						let e = String(p.Content?.status || "").toLowerCase();
						e !== "interrupted" && en.has(e) && (l = e);
					}
				}
			}
			l === void 0 && await new Promise((e) => setTimeout(e, 3e3));
		} catch (e) {
			if (e instanceof DOMException && e.name === "AbortError") return { terminalStatus: "cancelled" };
			if (u += 1, u >= 6) break;
			await new Promise((e) => setTimeout(e, 800 * u));
		}
		let d = l !== void 0;
		return l === void 0 && (l = "interrupted"), {
			terminalStatus: l,
			submissionAccepted: d || t.status === "accepted" || t.status === "duplicate"
		};
	}
	async consumeStream(e, t, n, r, i) {
		let a = e.getReader(), o = new TextDecoder(), s = "", c = !1, l = 0, u, d = /* @__PURE__ */ new Set(), f = () => ({
			terminalStatus: u,
			awaitingInput: d.size > 0 && (!u || u === "incomplete")
		});
		for (;;) {
			let { value: e, done: p } = await a.read();
			if (p) break;
			l += e.byteLength, c || (c = !0, this.emit({
				type: "assistant_message_created",
				messageId: r,
				invocationId: i
			})), s += o.decode(e, { stream: !0 });
			let { chunks: m, remainder: h } = zt(s);
			s = h;
			for (let e of m) {
				if (!e.trim()) continue;
				if (this.isCompactionChunk(e)) {
					let t = Z(e);
					for (let e of t) e.eventName.startsWith("response.compaction") && this.upsertCompactionMessage({
						...e.data,
						phase: e.eventName.split(".").pop()
					});
					continue;
				}
				let i = Z(e), o = !1;
				for (let e of i) {
					if (e.eventName === "__done__") {
						o = !0;
						continue;
					}
					let i = nn(e.eventName, e.data);
					i && !(d.size > 0 && (e.eventName === "response.incomplete" || e.data?.type === "response.incomplete")) && this.emit({
						type: "activity",
						...i
					});
					let a = t.parse(e, n);
					for (let e of a) e.type === "approval_request" && d.add(e.approvalRequestId), e.type === "canonical_interaction" && d.add(e.interactionId), e.type === "approval_resolved" && d.delete(e.approvalRequestId), this.dispatchAction(e, r), e.type === "terminal" && (u = e.status);
					if (Rt(a)) {
						o = !0;
						let e = a.find((e) => e.type === "terminal");
						u = e && "status" in e ? String(e.status || "") : void 0;
					}
				}
				if (o) return a.cancel().catch(() => {}), {
					...f(),
					submissionAccepted: !!u
				};
			}
		}
		if (l === 0) throw Error("运行时返回了空响应流，请稍后重试；若问题持续，请检查运行时状态。");
		if (u || d.size > 0) return {
			...f(),
			submissionAccepted: !!u
		};
		throw TypeError("运行时连接已结束，但尚未收到执行终态；请查询原任务状态。");
	}
	isCompactionChunk(e) {
		return e.includes("response.compaction.start") || e.includes("response.compaction.done") || e.includes("response.compaction.failed");
	}
	dispatchAction(e, t) {
		switch (e.type) {
			case "canonical_interaction":
				this.emit({
					type: "stream_event",
					event: e.event,
					sessionId: e.event.SessionId
				});
				break;
			case "text_delta":
				this.emit({
					type: "text_delta",
					messageId: t,
					delta: e.text
				});
				break;
			case "text_final":
				this.emit({
					type: "text_final",
					messageId: t,
					text: e.text
				});
				break;
			case "reasoning_delta":
				this.emit({
					type: "reasoning_delta",
					messageId: t,
					delta: e.text,
					itemId: e.itemId,
					source: e.source
				});
				break;
			case "reasoning_done":
				this.emit({
					type: "reasoning_done",
					messageId: t,
					text: e.text,
					itemId: e.itemId
				});
				break;
			case "tool_upsert":
				this.emit({
					type: "tool_upsert",
					messageId: t,
					name: e.name,
					args: e.args,
					status: e.status,
					extra: e.extra
				});
				break;
			case "tool_result":
				this.emit({
					type: "tool_result",
					messageId: t,
					name: e.name,
					output: e.output,
					callId: e.callId
				});
				break;
			case "approval_request":
				this.emit({
					type: "approval_requested",
					messageId: t,
					approvalRequestId: e.approvalRequestId,
					protocol: "responses",
					runId: e.runId,
					name: e.name || "人工确认",
					args: e.args || "",
					message: e.message || "本次运行需要人工审批后才能继续。"
				});
				break;
			case "approval_resolved":
				this.emit({
					type: "approval_resolved",
					approvalRequestId: e.approvalRequestId,
					decision: e.decision,
					revision: e.revision
				});
				break;
			case "incomplete": break;
			case "failed":
				this.emit({
					type: "text_final",
					messageId: t,
					text: `生成失败：${e.message}`
				});
				break;
			case "terminal":
				this.emit({
					type: "terminal",
					status: e.status
				});
				break;
			case "compaction":
				this.emit({
					type: "compaction",
					phase: e.phase,
					trigger: e.trigger,
					compactedUntilSeqId: e.compactedUntilSeqId
				});
				break;
			case "a2ui_surface_begin":
				this.emit({
					type: "a2ui_surface_begin",
					surfaceId: e.surfaceId,
					surface: e.surface
				});
				break;
			case "a2ui_surface_update":
				this.emit({
					type: "a2ui_surface_update",
					surfaceId: e.surfaceId,
					surface: e.surface
				});
				break;
			case "a2ui_surface_end":
				this.emit({
					type: "a2ui_surface_end",
					surfaceId: e.surfaceId
				});
				break;
			case "a2ui_interaction":
				this.emit({
					type: "a2ui_interaction",
					surfaceId: e.surfaceId,
					interactionId: e.interactionId,
					kind: e.kind,
					inputSchema: e.inputSchema
				});
				break;
		}
	}
	upsertCompactionMessage(e) {
		let t = typeof e.eventName == "string" ? e.eventName.split(".").pop() : void 0, n = String(e.phase || t || "start");
		this.emit({
			type: "compaction",
			phase: n,
			trigger: e.trigger ? String(e.trigger) : void 0,
			compactedUntilSeqId: e.compacted_until_seq_id ? Number(e.compacted_until_seq_id) : void 0
		}), n !== "start" && (this.activeCompactionId = null);
	}
	failCompaction() {
		this.activeCompactionId &&= (this.emit({
			type: "compaction",
			phase: "failed"
		}), null);
	}
};
//#endregion
//#region src/utils/recovered-run.ts
function sn(e, t, n) {
	let r = e.filter((e) => e.role === "model" && e.invocationId === n), i = le(t).filter((e) => e.role === "model"), a = i.map((e) => ({
		...e,
		id: !e.itemId && i.length === 1 ? r[0]?.id || `${n}:assistant` : e.id,
		invocationId: n,
		blocks: ce({
			content: e.content,
			reasoning: e.reasoning,
			tools: e.tools
		})
	}));
	if (a.length === 0) return e;
	let o = e.findIndex((e) => e.role === "model" && e.invocationId === n), s = e.filter((e) => !(e.role === "model" && e.invocationId === n)), c = o < 0 ? s.length : Math.min(o, s.length);
	return [
		...s.slice(0, c),
		...a,
		...s.slice(c)
	];
}
//#endregion
//#region src/core/run/dispatcher.ts
var cn = "连接断开或生成出错，请重试";
function ln(e) {
	let t = String(e.message || "").trim();
	return /runtime agent kernel is not ready/i.test(t) ? "云端运行时尚未就绪，请检查部署状态后重试" : !t || /failed to fetch|networkerror/i.test(t) ? cn : t.length <= 240 ? t : cn;
}
var un = new Set(["completed"]), dn = new Set([
	"failed",
	"error",
	"cancelled",
	"canceled",
	"aborted",
	"incomplete"
]), fn = /* @__PURE__ */ new Map();
function Q(e, t) {
	E.getState().patchMessages((n) => {
		if (n.some((t) => t.id === e)) return t ? n.map((n) => n.id === e ? {
			...n,
			invocationId: t
		} : n) : n;
		let r = -1;
		for (let e = n.length - 1; e >= 0; --e) if (n[e]?.eventType === "optimistic_assistant_placeholder") {
			r = e;
			break;
		}
		return r >= 0 ? n.map((n, i) => i === r ? {
			...n,
			id: e,
			eventType: void 0,
			invocationId: t
		} : n) : [...n, {
			id: e,
			role: "model",
			content: "",
			timestamp: Date.now(),
			reasoning: "",
			invocationId: t
		}];
	});
}
function pn(e) {
	return e.filter((e) => e.eventType !== "optimistic_assistant_placeholder");
}
function mn(e) {
	let t = String(e || "").trim().toLowerCase(), n = un.has(t) ? "completed" : dn.has(t) ? "error" : null;
	n && E.getState().patchMessages((e) => e.map((e) => {
		if (!e.tools) return e;
		let t = !1, r = Object.fromEntries(Object.entries(e.tools).map(([e, r]) => r.status === "running" ? (t = !0, [e, {
			...r,
			status: n
		}]) : [e, r]));
		return t ? {
			...e,
			tools: r
		} : e;
	}));
}
function hn(e, t) {
	!e.sessionId && t?.draftId && (e = {
		...e,
		sessionId: t.draftId
	});
	let n = t ? !t.visible : !!(e.sessionId && a.getState().currentSessionId !== e.sessionId);
	if (n && ![
		"activity",
		"stage_changed",
		"stream_ended",
		"error",
		"rate_limited",
		"terminal",
		"approval_requested",
		"approval_resolved",
		"stream_event",
		"conversation_snapshot"
	].includes(e.type)) return;
	let r = E.getState(), i = (e) => {
		e && c.getState().updateActivity({ sessionId: e });
	};
	switch (e.type) {
		case "activity":
			c.getState().updateActivity({
				sessionId: e.sessionId,
				visible: !n,
				source: e.source,
				status: e.status,
				phase: e.phase,
				detail: e.detail,
				countEvent: e.countEvent
			});
			break;
		case "user_message_added":
			c.getState().setBanner(null), r.patchMessages((t) => [...t, {
				id: e.messageId,
				role: "user",
				content: "",
				timestamp: Date.now()
			}]);
			break;
		case "assistant_message_created":
			Q(e.messageId, e.invocationId);
			break;
		case "text_delta":
			Q(e.messageId), i(e.sessionId), r.patchMessages((t) => t.map((t) => t.id === e.messageId ? {
				...t,
				content: t.content + e.delta,
				blocks: me(t.blocks, e.delta)
			} : t));
			break;
		case "text_final":
			Q(e.messageId), i(e.sessionId), r.patchMessages((t) => t.map((t) => t.id === e.messageId ? (() => {
				let n = !!(e.text && !t.content && t.reasoning?.endsWith(e.text)), r = n ? t.reasoning.slice(0, -e.text.length) : t.reasoning, i = n ? xe(t.blocks, e.text) : t.blocks;
				return {
					...t,
					reasoning: r,
					content: e.text,
					blocks: I(i, e.text)
				};
			})() : t));
			break;
		case "reasoning_delta":
			Q(e.messageId), i(e.sessionId), r.patchMessages((t) => t.map((t) => t.id === e.messageId ? {
				...t,
				reasoning: (t.reasoning || "") + e.delta,
				blocks: de(t.blocks, e.delta, {
					itemId: e.itemId,
					source: e.source
				})
			} : t));
			break;
		case "reasoning_done":
			r.patchMessages((t) => t.map((t) => t.id === e.messageId ? {
				...t,
				blocks: se(t.blocks, e.itemId, e.text)
			} : t));
			break;
		case "tool_upsert":
			Q(e.messageId), i(e.sessionId), r.patchMessages((t) => t.map((t) => {
				if (t.id !== e.messageId) return t;
				let n = String(e.extra?.callId || e.extra?.call_id || e.name), r = t.tools?.[n], i = r?.approvalStatus === "approved" || r?.approvalStatus === "rejected" || r?.approvalStatus === "cancelled", a = e.status, o = r?.approvalStatus === "rejected" || r?.approvalStatus === "cancelled" ? "completed" : r?.status === "error" && a !== "error" ? "error" : a;
				return {
					...t,
					blocks: L(t.blocks, e.name, {
						args: e.args,
						status: o,
						extra: e.extra
					}),
					tools: {
						...t.tools || {},
						[n]: {
							...r || {
								name: e.name,
								args: ""
							},
							name: e.name,
							args: e.args,
							status: o,
							...e.extra || {},
							...e.extra?.approvalRequestId && !i ? { approvalStatus: "pending" } : {}
						}
					}
				};
			}));
			break;
		case "tool_result":
			Q(e.messageId), i(e.sessionId), r.patchMessages((t) => t.map((t) => {
				if (t.id !== e.messageId) return t;
				let n = D(e.output) ? "error" : "completed", r = e.callId || e.name;
				return {
					...t,
					blocks: L(t.blocks, e.name, {
						output: e.output,
						status: n,
						...e.callId ? { extra: { callId: e.callId } } : {}
					}),
					tools: {
						...t.tools || {},
						[r]: {
							...t.tools?.[r] || {
								name: e.name,
								args: ""
							},
							...e.callId ? { callId: e.callId } : {},
							output: e.output,
							status: n
						}
					}
				};
			}));
			break;
		case "approval_requested":
			if (xt({
				approvalRequestId: e.approvalRequestId,
				protocol: e.protocol,
				runId: e.runId,
				name: e.name,
				message: e.message,
				args: e.args,
				approvalLevel: e.approvalLevel,
				sessionId: e.sessionId
			}), n) break;
			Q(e.messageId), r.patchMessages((t) => t.map((t) => {
				if (t.id !== e.messageId) return t;
				let n = t.tools?.[e.approvalRequestId], r = n?.approvalStatus === "approved" || n?.approvalStatus === "rejected" || n?.approvalStatus === "cancelled", i = {
					approvalRequestId: e.approvalRequestId,
					approvalProtocol: e.protocol,
					approvalStatus: r ? n.approvalStatus : "pending",
					...e.message ? { approvalMessage: e.message } : {},
					...e.approvalLevel ? { approvalLevel: e.approvalLevel } : {}
				}, a = r ? n.status : "paused";
				return {
					...t,
					blocks: L(t.blocks, e.name, {
						args: e.args,
						status: a,
						extra: i
					}),
					tools: {
						...t.tools || {},
						[e.approvalRequestId]: {
							...n || {},
							name: e.name,
							args: e.args,
							status: a,
							...i
						}
					}
				};
			}));
			break;
		case "approval_resolved":
			if (St({
				approvalRequestId: e.approvalRequestId,
				decision: e.decision,
				revision: e.revision,
				sessionId: e.sessionId
			}), n) break;
			r.patchMessages((t) => t.map((t) => {
				if (!t.tools) return t;
				let n = !1, r = Object.fromEntries(Object.entries(t.tools).map(([t, r]) => {
					if (r.approvalRequestId !== e.approvalRequestId) return [t, r];
					n = !0;
					let i = e.decision === "rejected" || e.decision === "cancelled" ? "completed" : r.status === "paused" ? "running" : r.status;
					return [t, {
						...r,
						status: i,
						approvalStatus: e.decision
					}];
				}));
				return n ? {
					...t,
					tools: r,
					blocks: t.blocks?.map((t) => {
						if (t.type !== "tool" || t.extra?.approvalRequestId !== e.approvalRequestId) return t;
						let n = e.decision === "rejected" || e.decision === "cancelled" ? "completed" : t.status === "paused" ? "running" : t.status;
						return {
							...t,
							status: n,
							extra: {
								...t.extra,
								approvalStatus: e.decision
							}
						};
					})
				} : t;
			}));
			break;
		case "system_message":
			r.patchMessages((t) => [...t, {
				id: String(Date.now() + Math.random()),
				role: "system",
				content: e.content,
				timestamp: Date.now()
			}]);
			break;
		case "compaction": {
			let t = `compaction-${Date.now()}`, n = e.phase === "start" ? "running" : e.phase === "failed" ? "failed" : "completed", i = he({
				id: t,
				timestamp: Date.now(),
				status: n,
				trigger: e.trigger,
				compactedUntilSeqId: e.compactedUntilSeqId
			});
			r.patchMessages((e) => e.findIndex((e) => e.id === t) < 0 ? [...e, i] : e.map((e) => e.id === t ? {
				...e,
				...i
			} : e));
			break;
		}
		case "stage_changed":
			e.stage === "streaming" || e.stage === "connecting" ? c.getState().setSessionStreaming(e.sessionId, !0) : (e.stage === "completing" || e.stage === "error" || e.stage === "cancelled") && c.getState().setSessionStreaming(e.sessionId, !1);
			break;
		case "stream_ended":
			c.getState().setSessionStreaming(e.sessionId, !1), n || E.getState().patchMessages((t) => pn(t).map((t) => !(!e.runId || t.runId === e.runId || t.invocationId === e.runId) || t.role !== "model" || !t.blocks?.some((e) => e.status === "streaming") ? t : {
				...t,
				blocks: ye(t.blocks.map((e) => e.type === "text" && e.status === "streaming" ? {
					...e,
					status: "done"
				} : e))
			})), globalThis.setTimeout(() => {
				let t = c.getState();
				t.getSessionActivity(e.sessionId)?.status === "completed" && t.clearSessionActivity(e.sessionId);
			}, 2400);
			break;
		case "error": {
			let t = ln(e.error);
			c.getState().setSessionStreaming(e.sessionId, !1), c.getState().updateActivity({
				sessionId: e.sessionId,
				visible: !n,
				status: "failed",
				phase: "运行失败",
				detail: t,
				countEvent: !1
			}), n || (c.getState().setBanner({
				kind: "error",
				message: t,
				sessionId: e.sessionId
			}), r.patchMessages((e) => [...pn(e), {
				id: String(Date.now()),
				role: "model",
				content: `运行失败：${t}`,
				timestamp: Date.now()
			}]));
			break;
		}
		case "rate_limited":
			c.getState().setSessionStreaming(e.sessionId, !1), c.getState().updateActivity({
				sessionId: e.sessionId,
				visible: !n,
				status: "failed",
				phase: "请求被限流",
				countEvent: !1
			}), n || (c.getState().setBanner({
				kind: "rate_limited",
				message: e.message || "请求过于频繁，请稍后重试",
				retryAfterSec: e.retryAfterSec,
				sessionId: e.sessionId
			}), r.patchMessages(pn));
			break;
		case "terminal":
			e.sessionId && String(e.status || "").trim().toLowerCase() !== "incomplete" && X.markSessionTerminal(e.sessionId), n || mn(e.status);
			break;
		case "stream_event": {
			let t = e.sessionId || e.event.SessionId;
			bt(e.event, t || void 0);
			let r = e.event.SeqId;
			!n && typeof r == "number" && r > 0 && c.getState().setLastSeqId(r), t && c.getState().updateActivity({
				sessionId: t,
				visible: !n
			});
			let i = String(e.event.InvocationId || "").trim();
			if (!n && t && i) {
				let n = `${t}:${i}`, r = ge(fn.get(n) || [], [e.event]);
				fn.set(n, r), E.getState().patchMessages((e) => e.some((e) => e.eventType === "conversation_item_v1" && e.runId === i) ? e : sn(e, r, i)), re(e.event) && fn.delete(n);
			}
			e.event.EventType === "run_checkpoint" && t && b.getState().upsertSessionCheckpoint(t, e.event);
			{
				let r = ie(e.event);
				r === "completed" ? c.getState().updateActivity({
					sessionId: t,
					visible: !n,
					status: "completed",
					phase: "后台长任务已完成",
					countEvent: !1
				}) : r === "cancelled" || r === "canceled" || r === "aborted" ? c.getState().updateActivity({
					sessionId: t,
					visible: !n,
					status: "stopped",
					phase: "后台长任务已取消",
					countEvent: !1
				}) : (r === "failed" || r === "error") && c.getState().updateActivity({
					sessionId: t,
					visible: !n,
					status: "failed",
					phase: "后台长任务失败",
					countEvent: !1
				});
			}
			break;
		}
		case "conversation_snapshot": {
			let t = F(e.result);
			for (let e of t.interactions) X.upsert(e);
			if (n) break;
			r.patchMessages((t) => be(t, e.result, e.optimisticMessageId)), i(e.sessionId);
			break;
		}
		case "a2ui_surface_begin": {
			let t = `a2ui-${e.surfaceId}`;
			E.getState().patchMessages((n) => [...n.filter((e) => e.id !== t), {
				id: t,
				role: "a2ui",
				content: "",
				timestamp: Date.now(),
				a2ui: {
					surfaceId: e.surfaceId,
					surface: e.surface
				}
			}]);
			break;
		}
		case "a2ui_surface_update": {
			let t = `a2ui-${e.surfaceId}`;
			E.getState().patchMessages((n) => n.map((n) => n.id === t && n.a2ui ? {
				...n,
				a2ui: {
					...n.a2ui,
					surface: e.surface
				}
			} : n));
			break;
		}
		case "a2ui_surface_end": {
			let t = `a2ui-${e.surfaceId}`;
			E.getState().patchMessages((e) => e.map((e) => e.id === t && e.a2ui ? {
				...e,
				a2ui: {
					...e.a2ui,
					ended: !0
				}
			} : e));
			break;
		}
		case "a2ui_interaction": {
			let t = `a2ui-${e.surfaceId}`;
			E.getState().patchMessages((n) => n.map((n) => n.id === t && n.a2ui ? {
				...n,
				a2ui: {
					...n.a2ui,
					pendingInteraction: {
						interactionId: e.interactionId,
						kind: e.kind,
						inputSchema: e.inputSchema
					}
				}
			} : n));
			break;
		}
		case "agui_activity": {
			let t = `agui-a2ui-${e.surfaceId}`;
			E.getState().patchMessages((n) => {
				let r = {
					surfaceId: e.surfaceId,
					messages: e.messages
				}, i = !1, a = n.map((t) => {
					if (t.id !== e.messageId) return t;
					i = !0;
					let n = [...(t.aguiActivities || []).filter((t) => t.surfaceId !== e.surfaceId), r];
					return {
						...t,
						aguiActivities: n
					};
				});
				if (i) return a;
				let o = n.find((e) => e.id === t), s = {
					id: t,
					role: "a2ui",
					content: "",
					timestamp: o?.timestamp || Date.now(),
					aguiActivity: r
				};
				return o ? n.map((e) => e.id === t ? s : e) : [...n, s];
			});
			break;
		}
	}
}
function gn() {
	fn.clear();
}
//#endregion
//#region src/hooks/useRunAgent.ts
var _n = 64;
function vn(t) {
	let n = B(/* @__PURE__ */ new Map()), r = B(/* @__PURE__ */ new Set()), i = R((e) => r.current.has(e), []), o = R((e) => {
		let t = n.current;
		if (!(t.size <= _n)) for (let [n, r] of t) {
			if (t.size <= _n) break;
			n === e || r.engine.stage !== "idle" || r.queue.length > 0 || r.isVisible() || t.delete(n);
		}
	}, []), l = Se(() => new ne({ rendererCatalog: te }), []), u = t.conversationClient === void 0 ? t.uiCapabilities.ConversationSurface == null ? null : l : t.conversationClient, { agentId: d, apiFormats: f, agentFramework: p, selectedModel: m, selectedModelMetadata: h, thinkingMode: g, permissionMode: _, currentSessionIdRef: v, conversationIdRef: y, queuedDraftRef: b, onRunSettled: x, onSessionCreated: S, waitForPendingSessionCreation: C, uiCapabilities: w, outbox: T } = t, D = Se(() => ({
		agentId: d,
		apiFormats: f,
		agentFramework: p,
		selectedModel: m,
		selectedModelMetadata: h,
		thinkingMode: w.Thinking ? g : "auto",
		permissionMode: _,
		runtimeCapabilityMatrix: w.RuntimeCapabilityMatrix,
		hostedChatTransport: e(w, { requireResumableRun: !!(w.RunLifecycle?.Enabled && w.RunLifecycle.Resume) }),
		checkpointResumePreviewEnabled: !!w.RunLifecycle?.CheckpointResumePreview,
		kernelSessionEventsEnabled: w.KernelSessionEvents === !0,
		presentationProfile: ee(w.ConversationSurface, te),
		conversationClient: u || void 0
	}), [
		d,
		f,
		p,
		m,
		h,
		g,
		_,
		w,
		u
	]), O = R((e = v.current) => {
		let r = t.conversationIdRef?.current, i = JSON.stringify([d, r || e || "new-session"]), a = n.current.get(i);
		if (!a) {
			o(i);
			let s = () => t.agentIdRef.current === d && (t.conversationIdRef ? t.conversationIdRef.current === r : v.current === a.sessionId), c = new on(t.api, {
				isVisible: s,
				draftId: r
			});
			a = {
				key: i,
				agentId: d,
				conversationId: r,
				sessionId: e || null,
				engine: c,
				queue: [],
				isVisible: s
			}, c.subscribe((e) => hn(e, {
				visible: s(),
				draftId: r
			})), n.current.set(i, a);
		}
		return a;
	}, [
		d,
		t.agentIdRef,
		t.api,
		t.conversationIdRef,
		v,
		o
	]), k = R((e) => {
		let t = O(e);
		return t.engine.stage === "idle" && t.engine.updateConfig(D), t.engine;
	}, [D, O]), A = R((e) => {
		if (!e.isVisible()) return;
		let t = e.queue.map((e) => e.draft);
		b.current = t, s.getState().setQueuedDrafts(t);
	}, [b]), j = R((e) => {
		let t = e.queue[0];
		!t || e.engine.stage !== "idle" || (e.queue.shift(), A(e), queueMicrotask(() => {
			t.launch() || (e.queue.unshift(t), A(e));
		}));
	}, [A]);
	z(() => {
		let e = JSON.stringify([d, t.conversationId || y?.current || t.currentSessionId || "new-session"]), r = n.current.get(e);
		r ? A(r) : (b.current = [], s.getState().setQueuedDrafts([]));
	}, [
		d,
		t.currentSessionId,
		t.conversationId,
		y,
		A,
		b
	]);
	let M = R((e) => {
		let t = e.text.trim(), n = e.attachments.map((e) => ({
			name: e.name,
			url: URL.createObjectURL(e),
			type: e.type || "application/octet-stream"
		}));
		if (!t && n.length === 0) return;
		let r = `optimistic-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
		return E.getState().patchMessages((e) => [...e, {
			id: r,
			role: "user",
			content: t,
			timestamp: Date.now(),
			eventType: "optimistic_user_message",
			attachments: n.length ? n : void 0
		}]), r;
	}, []), N = R((e) => {
		let t = `optimistic-assistant-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
		return E.getState().patchMessages((n) => {
			let r = n.findIndex((t) => t.id === e), i = r < 0 ? n.length : r + 1;
			return [
				...n.slice(0, i),
				{
					id: t,
					role: "model",
					content: "",
					reasoning: "",
					timestamp: Date.now(),
					eventType: "optimistic_assistant_placeholder"
				},
				...n.slice(i)
			];
		}), t;
	}, []), P = R(async (e, t, i, o, l, u) => {
		if (u && r.current.has(u)) return !1;
		let d = O();
		A(d);
		let f = {
			text: e,
			attachments: [...t],
			responsesInput: i,
			previousResponseId: o,
			executionMode: l,
			optimisticMessageId: M({
				text: e,
				attachments: t
			})
		}, p = i === void 0 && d.conversationId && T ? T : void 0, m = d.conversationId && p ? p.enqueue({
			requestId: u,
			conversationId: d.conversationId,
			agentId: d.agentId,
			text: e,
			attachments: t.map((e) => ({
				name: e.name,
				type: e.type,
				size: e.size
			})),
			executionMode: l
		}) : void 0;
		m && p && (r.current.add(m.requestId), p.setRuntimeAttachments(m.requestId, t));
		let h;
		try {
			h = await C?.();
		} catch (e) {
			throw m && p && (r.current.delete(m.requestId), p.update(m.requestId, {
				status: "unknown",
				error: "创建会话的结果待确认。"
			})), e;
		}
		!d.sessionId && h && (d.sessionId = h);
		let g = !1, _, y = i === void 0 ? null : new Promise((e) => {
			_ = e;
		}), b = () => {
			if (d.engine.stage !== "idle") return !1;
			d.engine.updateConfig(D), m && p && p.markSending(m.requestId), d.isVisible() && (s.getState().setMobileActionsOpen(!1), N(f.optimisticMessageId)), c.getState().setSessionStreaming(d.sessionId || d.conversationId, !0);
			let e = d.engine.start({
				...f,
				sessionId: d.sessionId,
				onInvocationCreated: (e) => {
					m && p && p.update(m.requestId, { invocationId: e });
				},
				onSessionCreated: (e) => {
					let t = d.isVisible(), r = d.sessionId || d.conversationId;
					d.sessionId = e, m && p && p.update(m.requestId, { nativeSessionId: e }), c.getState().setSessionStreaming(e, !0), r !== e && c.getState().setSessionStreaming(r, !1), d.conversationId || n.current.set(JSON.stringify([d.agentId, e]), d), S?.(e, d.conversationId, d.agentId), !S && t && (a.getState().upsertSessions([{
						SessionId: e,
						UpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
					}]), v.current = e, a.getState().setCurrentSessionId(e)), t && Ze(d.agentId, e);
				},
				onSessionUpsert: () => {},
				onDispatchResult: (e) => {
					g = e, _?.(e);
				},
				onSettled: (e, t = "unknown", n) => {
					m && r.current.delete(m.requestId), m && p && p.update(m.requestId, { status: t === "completed" || t === "awaiting-input" ? "completed" : t === "cancelled" ? "cancelled" : t === "failed" ? n?.accepted || g ? "delivered" : "failed" : "unknown" }), x?.(e, d.agentId, t), t === "completed" && j(d);
				}
			});
			return e || c.getState().setSessionStreaming(d.sessionId || d.conversationId, !1), e;
		}, w = b();
		return !w && i === void 0 ? (d.queue.push({
			draft: f,
			launch: b
		}), A(d), !0) : y ? (w || _?.(!1), y) : w;
	}, [
		N,
		M,
		D,
		v,
		j,
		O,
		x,
		S,
		T,
		A,
		C
	]), F = R(() => {
		k(v.current).stop();
	}, [v, k]), I = R(() => {
		k(v.current).disconnect();
	}, [v, k]), re = R((e) => {
		let t = O(e.sessionId), n = k(e.sessionId);
		if (n.stage !== "idle") return !1;
		gn(), s.getState().setMobileActionsOpen(!1), c.getState().setSessionStreaming(e.sessionId, !0);
		let r = n.resumeCheckpoint({
			...e,
			onSettled: (e, n) => {
				x?.(e, t.agentId, n), n === "completed" && j(t);
			}
		});
		return r || c.getState().setSessionStreaming(e.sessionId, !1), r;
	}, [
		j,
		k,
		O,
		x
	]), L = R(() => {
		gn();
	}, []);
	return {
		submitDraft: P,
		isOutboxRequestActive: i,
		stopGeneration: F,
		disconnectRun: I,
		resumeCheckpoint: re,
		submitAguiAction: R((e) => {
			let t = e.userAction;
			if (!t) return !1;
			let n = t.context || {}, r = String(n.interruptId || n.interrupt_id || "");
			if (!r) return !1;
			let i = v.current;
			if (!i) return !1;
			let a = O(i), o = k(i), s = n.status === "cancelled" ? "cancelled" : "resolved", c = Object.prototype.hasOwnProperty.call(n, "payload") ? n.payload : {
				action: t.name,
				sourceComponentId: t.sourceComponentId,
				context: n
			};
			return o.resumeAguiInterrupt({
				sessionId: i,
				interruptId: r,
				status: s,
				payload: c,
				onSettled: (e) => {
					x?.(e, a.agentId), j(a);
				}
			});
		}, [
			v,
			j,
			k,
			O,
			x
		]),
		respondToAguiApproval: R((e) => {
			if (!e.interruptId) return !1;
			let t = v.current;
			if (!t) return !1;
			let n = O(t), r = k(t);
			if (r.stage !== "idle") return !1;
			c.getState().setSessionStreaming(t, !0);
			let i = r.resumeAguiInterrupt({
				sessionId: t,
				interruptId: e.interruptId,
				status: "resolved",
				payload: { decision: e.approve ? "approve" : "reject" },
				onSettled: (e) => {
					x?.(e, n.agentId), j(n);
				}
			});
			return i || c.getState().setSessionStreaming(t, !1), i;
		}, [
			v,
			j,
			k,
			O,
			x
		]),
		resetCompaction: L
	};
}
//#endregion
//#region src/utils/messages.js
var yn = {
	running: "running",
	completed: "completed",
	failed: "error",
	paused: "paused",
	approved: "completed",
	denied: "completed"
}, bn = {
	paused: "pending",
	approved: "approved",
	denied: "rejected"
};
function xn(e) {
	if (typeof e == "number" && Number.isFinite(e)) return e > 0 && e < 1e11 ? e * 1e3 : e;
	if (typeof e == "string") {
		let t = Number(e.trim());
		if (e.trim() && Number.isFinite(t)) return t > 0 && t < 1e11 ? t * 1e3 : t;
		let n = Date.parse(e);
		if (Number.isFinite(n)) return n;
	}
	return Date.now();
}
function Sn(e) {
	if (typeof e == "string") return e;
	if (e && typeof e == "object") {
		if (typeof e.text == "string") return e.text;
		if (Array.isArray(e.parts)) return e.parts.map((e) => e && typeof e == "object" && typeof e.text == "string" ? e.text : "").join("");
	}
	return "";
}
function Cn(e) {
	let t = {}, n = /* @__PURE__ */ new Map();
	for (let t of e ?? []) t?.Name && n.set(t.Name, (n.get(t.Name) || 0) + 1);
	for (let r of e ?? []) {
		if (!r?.Name) continue;
		let e = yn[String(r.Status ?? "completed").toLowerCase()] ?? "completed", i = {
			name: r.Name,
			...r.ToolCallId ? { callId: String(r.ToolCallId) } : {},
			...O(r.ToolDisplay) ? { toolDisplay: O(r.ToolDisplay) } : {},
			args: r.Args === void 0 ? "" : typeof r.Args == "string" ? r.Args : JSON.stringify(r.Args),
			status: e
		};
		r.Result !== void 0 && (i.output = typeof r.Result == "string" ? r.Result : JSON.stringify(r.Result)), r.ApprovalRequestId && (i.approvalRequestId = r.ApprovalRequestId, i.approvalStatus = bn[String(r.Status ?? "paused").toLowerCase()] ?? "pending", i.approvalProtocol = String(r.Protocol ?? "").toLowerCase() === "ag-ui" ? "ag-ui" : "responses", r.ApprovalMessage && (i.approvalMessage = String(r.ApprovalMessage)), r.ApprovalLevel && (i.approvalLevel = String(r.ApprovalLevel))), r.ToolCallId && (i.previousResponseId = r.ToolCallId);
		let a = n.get(r.Name) > 1 && r.ToolCallId ? r.ToolCallId : r.Name;
		t[a] = i;
	}
	return t;
}
function wn(e) {
	if (Array.isArray(e)) return e.map((e) => ({
		name: e.name || "",
		url: e.url || "",
		type: e.mime || "",
		fileUri: e.file_uri
	}));
}
function Tn(e) {
	return e == null ? "" : typeof e == "string" ? e : JSON.stringify(e);
}
function En(e) {
	if (!(!Array.isArray(e) || !e.length)) return e.flatMap((e, t) => {
		let n = String(e?.Type || "").toLowerCase(), r = e?.SeqId ?? t;
		if (n === "thinking" || n === "text") {
			let t = String(e?.Content || "");
			return t ? [{
				id: `history-${n}-${r}`,
				type: n,
				content: t,
				status: "done"
			}] : [];
		}
		if (n !== "tool") return [];
		let i = yn[String(e?.Status || "completed").toLowerCase()] ?? "completed";
		return [{
			id: `history-tool-${r}`,
			type: "tool",
			toolName: String(e?.Name || "tool"),
			args: Tn(e?.Args),
			...e?.Result === void 0 ? {} : { output: Tn(e.Result) },
			status: i,
			extra: {
				...e?.ToolCallId ? {
					callId: String(e.ToolCallId),
					previousResponseId: String(e.ToolCallId)
				} : {},
				...O(e?.ToolDisplay) ? { toolDisplay: O(e.ToolDisplay) } : {}
			}
		}];
	});
}
function Dn(e) {
	let t = e.Role === "assistant" ? "model" : e.Role || "user", n = e.ToolEvents?.length ? Cn(e.ToolEvents) : void 0, r = wn(e.Attachments), i = En(e.Blocks), a = e.Reasoning?.length ? e.Reasoning.map((e) => e.text).join("") : void 0, o = {
		id: e.MessageId || `msg-${e.SeqId ?? Math.random().toString(36).slice(2)}`,
		role: t,
		content: Sn(e.Content),
		timestamp: xn(e.Timestamp),
		eventType: t === "user" ? "user_message" : "assistant_message",
		reasoning: a,
		tools: n,
		attachments: r
	};
	return t === "model" && (o.blocks = i ?? ce({
		reasoning: a,
		tools: n,
		content: o.content
	})), e.MessageId && (o.eventId = e.MessageId), e.InvocationId && (o.invocationId = e.InvocationId), e.ResponseId && (o.responseId = e.ResponseId), e.TraceId && (o.traceId = e.TraceId), e.RootSpanId && (o.rootSpanId = e.RootSpanId), o;
}
function On(e) {
	return Array.isArray(e.Activities) ? e.Activities.flatMap((t, n) => {
		let r = String(t?.SurfaceId || "");
		if (!r) return [];
		let i = t?.Content, a = Array.isArray(i?.a2ui_operations) ? i.a2ui_operations : Array.isArray(i) ? i : [];
		if (!a.length || r.startsWith("approval-") && a.some((e) => {
			let t = e?.updateComponents?.components || e?.update_components?.components;
			return Array.isArray(t) && t.some((e) => e?.component === "ApprovalBar");
		})) return [];
		let o = String(t.MessageId || "");
		return [{
			id: o && o !== String(e.MessageId || "") ? o : `${o || e.MessageId || e.SeqId || "message"}:a2ui:${r}:${n}`,
			role: "a2ui",
			content: "",
			timestamp: xn(e.Timestamp),
			aguiActivity: {
				surfaceId: r,
				messages: l(a)
			}
		}];
	}) : [];
}
function kn(e) {
	return e.flatMap((e) => [Dn(e), ...On(e)]);
}
//#endregion
//#region src/utils/restored-runtime-conversation.ts
var An = class {
	ingress;
	sessionId;
	runId;
	hasRunStart = !1;
	profile;
	constructor(e, t, n, r) {
		this.sessionId = e, this.runId = t, this.profile = r, this.ingress = new N(e, void 0, r), [...n].sort((e, t) => Number(e.SeqId || 0) - Number(t.SeqId || 0)).forEach((e) => {
			let t = this.frame(e);
			t && (t.event_type === "run.started" && !t.parent_scope_id && (this.hasRunStart = !0), this.ingress.apply(t));
		});
	}
	frame(e) {
		if (e.SessionId && e.SessionId !== this.sessionId || e.InvocationId && e.InvocationId !== this.runId) return null;
		let t = _e(e);
		return t?.schema_version === 2 && t.run_id === this.runId ? t : null;
	}
	apply(e, t) {
		let n = this.frame(e);
		if (!n || (n.event_type === "run.started" && !n.parent_scope_id && (this.hasRunStart = !0), !this.ingress.apply(n))) return t;
		let r = this.ingress.snapshot(), i = F({
			state: r,
			runId: this.runId,
			cursor: Number(e.SeqId || 0),
			presentation: P(r, { profile: this.profile })
		}).messages, a = new Map(i.map((e) => [e.id, e])), o = new Set(r.items.map((e) => `conversation:${e.runId}:${e.itemId}`)), s = this.hasRunStart && i.some((e) => e.role === "model"), c = t.flatMap((e) => {
			if (s && e.role === "model" && e.eventType !== "conversation_item_v1" && (e.runId || e.invocationId) === this.runId) return [];
			if (e.eventType !== "conversation_item_v1" || e.runId !== this.runId) return [e];
			let t = a.get(e.id);
			return t ? (a.delete(e.id), [{
				...e,
				...t,
				invocationId: this.runId,
				timestamp: e.timestamp
			}]) : o.has(e.id) ? [] : [e];
		}), l = c.length;
		for (let e = c.length - 1; e >= 0; --e) if ((c[e].runId || c[e].invocationId) === this.runId) {
			l = e + 1;
			break;
		}
		return c.splice(l, 0, ...[...a.values()].map((e) => ({
			...e,
			invocationId: this.runId
		}))), c;
	}
}, jn = class extends Error {
	seq;
	constructor(e) {
		super(`Session event seq ${e} was received twice with conflicting content`), this.name = "SessionEventConflictError", this.seq = e;
	}
};
function Mn(e) {
	return Array.isArray(e) ? `[${e.map(Mn).join(",")}]` : e && typeof e == "object" ? `{${Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e < t ? -1 : +(e > t)).map(([e, t]) => `${JSON.stringify(e)}:${Mn(t)}`).join(",")}}` : JSON.stringify(e) ?? "null";
}
var Nn = new Set(["runtime"]), Pn = class {
	eventsBySeq = /* @__PURE__ */ new Map();
	lastSeqValue = 0;
	accept(e) {
		let t = Ue(e);
		if (!t.ok) throw t.error;
		let n = t.value, r = this.eventsBySeq.get(n.seq);
		if (r) {
			if (Mn(r) !== Mn(n)) throw new jn(n.seq);
			return;
		}
		this.eventsBySeq.set(n.seq, n), this.lastSeqValue = Math.max(this.lastSeqValue, n.seq);
	}
	get lastSeq() {
		return this.lastSeqValue;
	}
	reconnectAfterSeq() {
		return this.lastSeqValue;
	}
	displayableEvents() {
		return [...this.eventsBySeq.values()].filter((e) => Nn.has(e.family)).sort((e, t) => e.seq - t.seq);
	}
};
function Fn() {
	return new Pn();
}
//#endregion
//#region src/hooks/useSessionLifecycle.ts
var In = 500, Ln = 30, Rn = 50, zn = 200, Bn = 8, Vn = 128, Hn = 1800 * 1e3;
function $(e, t, n, r, i = Vn) {
	for (e.delete(t), e.set(t, n); e.size > i;) {
		let t = [...e.keys()].find((e) => e !== r);
		if (!t) break;
		e.delete(t);
	}
}
function Un(e) {
	return new Promise((t) => {
		if (e.aborted) {
			t();
			return;
		}
		let n = globalThis.setTimeout(t, In);
		e.addEventListener("abort", () => {
			globalThis.clearTimeout(n), t();
		}, { once: !0 });
	});
}
var Wn = new Set([
	"in_progress",
	"running",
	"resuming",
	"starting"
]);
function Gn(e) {
	let t = e.ActiveRunUpdatedAt || e.UpdatedAt, n = typeof t == "number" ? t > 1e11 ? t : t * 1e3 : Date.parse(String(t || ""));
	return Number.isFinite(n) && n <= Date.now() + Hn && Date.now() - n <= Hn;
}
function Kn(e) {
	let t = ie(e);
	return t ? t === "completed" ? {
		status: "completed",
		phase: "后台长任务已完成"
	} : t === "cancelled" || t === "canceled" || t === "aborted" ? {
		status: "stopped",
		phase: "后台长任务已取消"
	} : t === "interrupted" ? {
		status: "stopped",
		phase: "后台长任务已中断"
	} : t === "failed" || t === "error" ? {
		status: "failed",
		phase: "后台长任务失败"
	} : t === "resume_failed" ? {
		status: "failed",
		phase: "后台长任务恢复失败"
	} : null : null;
}
function qn(e) {
	let { agentId: t, api: n, isMobile: r, resetCompaction: i, uiCapabilities: l, disconnectRun: u, restoreSession: d = !0 } = e, f = B(e.currentSessionId), p = B(e.agentId), m = B(null), h = B(Fn()), g = B(0), _ = B(null), y = B(null), x = B(/* @__PURE__ */ new Map()), C = B(/* @__PURE__ */ new Map()), w = B(/* @__PURE__ */ new Map()), T = B(/* @__PURE__ */ new Map()), D = B(/* @__PURE__ */ new Map()), O = B(/* @__PURE__ */ new Map()), k = B(/* @__PURE__ */ new Map()), A = B(null), j = B(null), M = B(null), N = B(null), P = R(async (e, t, r) => {
		let i = r.filter((e) => v(e, !1, !1));
		if (!i.length) return;
		let a = await Promise.all(i.map(async (r) => {
			try {
				let i = await n.getResponseFeedback({
					AgentId: e,
					SessionId: t,
					ResponseId: r.responseId,
					EventId: r.eventId
				}), a = i?.Feedback ? S(i.Feedback) : null;
				return a ? {
					messageId: r.id,
					feedback: a
				} : null;
			} catch (e) {
				return console.error("Failed to load response feedback:", e), null;
			}
		}));
		if (f.current !== t) return;
		let o = new Map(a.filter((e) => !!e).map((e) => [e.messageId, e.feedback]));
		o.size && E.getState().patchMessages((e) => e.map((e) => o.has(e.id) ? {
			...e,
			feedback: o.get(e.id)
		} : e));
	}, [n]), F = R(async (e) => {
		m.current?.abort();
		let t = new AbortController();
		m.current = t;
		let r = !1, i = !1, a = !1, o = e.afterSeqId, s, l = () => m.current === t && f.current === e.sessionId;
		try {
			for (c.getState().setCurrentRunId(e.invocationId), c.getState().setActiveInvocationId(e.invocationId), c.getState().setSessionStreaming(e.sessionId, !0), c.getState().updateActivity({
				sessionId: e.sessionId,
				status: "running",
				phase: "后台长任务运行中",
				detail: e.invocationId,
				countEvent: !1
			}); !i && l();) {
				try {
					let a = await n.subscribeRunEvents({
						sessionId: e.sessionId,
						invocationId: e.invocationId,
						afterSeqId: o
					}, { signal: t.signal });
					if (!l()) {
						t.abort();
						return;
					}
					let u = a.getReader(), d = new TextDecoder(), f = "";
					for (; !i && l();) {
						let { value: t, done: n } = await u.read();
						if (n) break;
						f += d.decode(t, { stream: !0 });
						let a = zt(f);
						f = a.remainder;
						for (let t of a.chunks) if (t.trim()) {
							for (let n of Z(t)) {
								if (n.eventName === "__ping__") {
									c.getState().updateActivity({
										sessionId: e.sessionId,
										status: "running",
										countEvent: !1
									});
									continue;
								}
								if (n.eventName === "__done__") {
									i = !0, r = !0;
									break;
								}
								if (!n.data || typeof n.data != "object") continue;
								let t = n.data;
								if (!l()) break;
								if (t.InvocationId && t.InvocationId !== e.invocationId) continue;
								if (typeof t.seq == "number") {
									try {
										h.current.accept(t);
									} catch (e) {
										console.error("[SessionLifecycle] session event cursor conflict:", e);
									}
									o = Math.max(o, h.current.reconnectAfterSeq()), hn({
										type: "stream_event",
										sessionId: e.sessionId,
										event: t
									}), i ||= re(t), r ||= i;
									let n = Kn(t);
									n && c.getState().updateActivity({
										sessionId: e.sessionId,
										status: n.status,
										phase: n.phase,
										detail: e.invocationId,
										countEvent: !1
									});
									continue;
								}
								let a = Number(t.SeqId || 0);
								Number.isFinite(a) && (o = Math.max(o, a));
								let u = E.getState().messages, d = _e(t);
								(d?.schema_version === 2 && d.run_id === e.invocationId || u.some((t) => t.eventType === "conversation_item_v1" && t.runId === e.invocationId)) && (s ??= new An(e.sessionId, e.invocationId, O.current.get(e.sessionId)?.events || [], T.current.get(e.sessionId) || "flat-v1"), E.getState().patchMessages((e) => s.apply(t, e))), hn({
									type: "stream_event",
									sessionId: e.sessionId,
									event: t
								}), i ||= re(t), r ||= i;
								let f = Kn(t);
								if (f && c.getState().updateActivity({
									sessionId: e.sessionId,
									status: f.status,
									phase: f.phase,
									detail: e.invocationId,
									countEvent: !1
								}), i) break;
							}
							if (i) break;
						}
					}
					i && u.cancel().catch(() => {});
				} catch (n) {
					if (n instanceof DOMException && n.name === "AbortError" || n instanceof U || t.signal.aborted) {
						i = !0, a = !0, l() && c.getState().stopSessionActivity(e.sessionId, "恢复事件订阅已取消。");
						break;
					}
					if (!l()) break;
					if (n instanceof H && n.code >= 400 && n.code < 500 && n.code !== 408 && n.code !== 429) {
						i = !0, r = !1, hn({
							type: "error",
							sessionId: e.sessionId,
							error: n
						});
						break;
					}
					console.warn("Run event subscription disconnected; retrying:", n), c.getState().updateActivity({
						sessionId: e.sessionId,
						status: "waiting",
						phase: "恢复连接中",
						detail: e.invocationId,
						countEvent: !1
					});
				}
				!i && l() && await Un(t.signal);
			}
			i && !a && l() && hn({
				type: "stream_ended",
				sessionId: e.sessionId
			});
		} catch (e) {
			e instanceof DOMException && e.name === "AbortError" || console.error("Failed to subscribe run events:", e);
		} finally {
			let n = m.current === t;
			n && (m.current = null), n && f.current === e.sessionId && (c.getState().setCurrentRunId(""), c.getState().setActiveInvocationId(""), r && M.current?.(e.sessionId), N.current?.(p.current, e.sessionId));
		}
	}, [n]), ne = R((e) => {
		!l.RunLifecycle.Enabled || !e.runId || p.current !== t || f.current !== e.sessionId || m.current || F({
			sessionId: e.sessionId,
			invocationId: e.runId,
			afterSeqId: pe(O.current.get(e.sessionId)?.events || [])
		});
	}, [
		t,
		F,
		l.RunLifecycle.Enabled
	]), I = R(async (e) => {
		j.current = null;
		let t = K.getState(), o = ee((t.agentId === p.current ? t.capabilities : l).ConversationSurface, te);
		T.current.set(e, o);
		let u = f.current, d = ++g.current;
		_.current = d, y.current = null;
		let h = (e, t) => {
			$(w.current, e, t, f.current, Bn);
		}, v = w.current.get(e);
		u && u !== e && (h(u, E.getState().messages), E.getState().setMessages(v || []), a.getState().clearSessionMessageHistory(e), b.getState().setSessionCheckpoints(e, []), b.getState().setSessionToolReceipts(e, []), c.getState().setCurrentRunId(""), c.getState().clearActivity()), f.current = e;
		let x = () => f.current === e && g.current === d;
		a.getState().setCurrentSessionId(e), a.getState().setSessionInitialMessageHistoryLoading(e, !v), i(), m.current?.abort(), r && s.getState().setMobileSidebarOpen(!1);
		try {
			let t = {
				limit: Rn,
				includeReasoning: !0,
				includeToolEvents: !0,
				includeAttachments: !0
			}, r;
			try {
				r = await n.listSessionMessages(e, t);
			} catch (i) {
				if (i instanceof U) throw i;
				if (await new Promise((e) => globalThis.setTimeout(e, 180)), !x()) return;
				r = await n.listSessionMessages(e, t);
			}
			if (!x()) return;
			let i = kn(r.Messages);
			$(D.current, e, i, f.current);
			let s = i, c = 0, u = [];
			v || (E.getState().setMessages(i), h(e, i)), a.getState().setSessionMessageHistory(e, {
				nextCursor: r.NextCursor,
				hasMore: r.HasMore
			}), a.getState().setSessionInitialMessageHistoryLoading(e, !1);
			try {
				let t = await n.listSessionEvents(e, {
					offset: 0,
					limit: zn
				});
				if (!x()) return;
				let l = {
					events: t.Events || [],
					loadedCount: t.Events?.length || 0,
					total: Math.max(0, Number(t.Total ?? t.Events?.length ?? 0) || 0)
				};
				if ($(O.current, e, l, f.current), a.getState().setSessionMessageHistory(e, {
					nextCursor: r.NextCursor,
					hasMore: !!(r.HasMore || l.loadedCount < l.total)
				}), l.events.length > 0) {
					c = pe(l.events);
					for (let t of l.events) bt(t, e);
					let t = fe(i, l.events, e, o);
					u = t.canonicalRunIds, s = t.messages;
				}
			} catch (e) {
				x() && (y.current = {
					generation: d,
					message: "完整事件历史读取失败，请刷新会话后重新查找。当前结果只包含已读取的正文。"
				}), console.warn("[SessionLifecycle] canonical history replay failed:", e);
			}
			if (!x()) return;
			$(C.current, e, new Set(u), f.current), E.getState().setMessages(s), h(e, s), _.current = null, P(p.current, e, s);
			let m = Math.max(r.LatestSeqId || 0, c), g = K.getState().capabilities || l;
			if (g.RunLifecycle.Enabled && g.RunLifecycle.Checkpoints ? (n.listSessionCheckpoints({
				agentId: p.current,
				sessionId: e
			}).then((t) => {
				x() && b.getState().setSessionCheckpoints(e, t.Checkpoints || []);
			}).catch((t) => {
				x() && (console.warn("[SessionLifecycle] checkpoint load failed:", t), b.getState().setSessionCheckpoints(e, []));
			}), n.listToolReceipts({
				agentId: p.current,
				sessionId: e
			}).then((t) => {
				x() && b.getState().setSessionToolReceipts(e, t.ToolReceipts || []);
			}).catch((t) => {
				x() && (console.warn("[SessionLifecycle] tool receipt load failed:", t), b.getState().setSessionToolReceipts(e, []));
			})) : b.getState().clearSessionCheckpoints(e), g.RunLifecycle.Enabled && g.RunLifecycle.Resume) try {
				let t = await n.getSession(e);
				if (!x()) return;
				let r = String(t.ActiveRunStatus || "").toLowerCase();
				t.ActiveInvocationId && (Wn.has(r) || r === "" && Gn(t)) && F({
					sessionId: e,
					invocationId: t.ActiveInvocationId,
					afterSeqId: m
				});
			} catch (e) {
				console.warn("[SessionLifecycle] getSession for reconnect failed:", e);
			}
		} catch (e) {
			x() && (y.current = {
				generation: d,
				message: "会话历史读取失败，请刷新会话后重新查找。"
			}), console.error("Failed to load session messages:", e);
		} finally {
			_.current === d && (_.current = null), x() && a.getState().setSessionInitialMessageHistoryLoading(e, !1);
		}
	}, [
		n,
		r,
		P,
		i,
		F,
		l
	]), L = R(async (e = "default-agent", t = null) => {
		let r = a.getState();
		r.sessionsAgentId && r.sessionsAgentId !== e && r.resetSessionPagination(e);
		let i = a.getState().sessionsGeneration, o = () => K.getState().agentId === e && a.getState().sessionsGeneration === i;
		try {
			a.getState().setLoadingSessions(!0);
			let r = await n.listSessions(e, {
				page: 1,
				pageSize: Ln
			});
			if (!o()) return;
			let i = r.Sessions || [];
			for (let e of i) k.current.delete(e.SessionId);
			let s = new Set(Array.from(k.current.entries()).filter(([, t]) => t === e).map(([e]) => e)), c = $e(i, a.getState().sessions, s);
			if (a.getState().upsertSessions(c, {
				agentId: e,
				total: Number(r.Total ?? r.Sessions?.length ?? 0),
				page: Number(r.Page ?? 1),
				pageSize: Number(r.PageSize ?? Ln),
				replace: !0
			}), A.current || j.current === e) return;
			let l = a.getState().sessions, u = f.current, p = u || (d ? Qe(l, t || Xe(e)) : null);
			p && p !== u && I(p);
		} catch (e) {
			if (e instanceof U) return;
			console.error("Failed to fetch sessions:", e);
		} finally {
			o() && a.getState().setLoadingSessions(!1);
		}
	}, [
		n,
		I,
		d
	]), ie = R(async () => {
		let e = a.getState();
		if (e.isLoadingSessions || !e.hasMoreSessions) return;
		let t = o({
			total: e.sessionsTotal,
			pageSize: e.sessionsPageSize || Ln,
			loadedPages: e.loadedPages
		});
		if (!t) return;
		let r = e.sessionsPageSize || Ln, i = e.sessionsAgentId || p.current || "default-agent", s = () => K.getState().agentId === i && a.getState().sessionsGeneration === e.sessionsGeneration;
		try {
			a.getState().setLoadingSessions(!0);
			let o = await n.listSessions(i, {
				page: t,
				pageSize: r
			});
			if (!s()) return;
			a.getState().upsertSessions(o.Sessions || [], {
				agentId: i,
				total: Number(o.Total ?? e.sessionsTotal),
				page: Number(o.Page ?? t),
				pageSize: Number(o.PageSize ?? r)
			});
		} catch (e) {
			if (e instanceof U) return;
			console.error("Failed to load more sessions:", e);
		} finally {
			s() && a.getState().setLoadingSessions(!1);
		}
	}, [n]);
	z(() => {
		M.current = I;
	}, [I]), z(() => {
		N.current = L;
	}, [L]);
	let ae = R((e, t = !1) => {
		j.current = null, g.current += 1, m.current?.abort(), k.current.set(e, p.current), a.getState().upsertSessions([{
			SessionId: e,
			UpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}]), f.current = e, a.getState().setCurrentSessionId(e), t || (E.getState().setMessages([]), c.getState().setCurrentRunId(""), c.getState().clearActivity()), a.getState().clearSessionMessageHistory(e), b.getState().setSessionCheckpoints(e, []), b.getState().setSessionToolReceipts(e, []), r && (s.getState().setMobileSidebarOpen(!1), s.getState().setMobileActionsOpen(!1));
	}, [r]), oe = R(() => {
		j.current = p.current, g.current += 1, m.current?.abort(), f.current = null, a.getState().setCurrentSessionId(null), E.getState().setMessages([]), c.getState().setCurrentRunId(""), c.getState().clearActivity(), r && s.getState().setMobileSidebarOpen(!1);
	}, [r]), se = R(async () => {
		if (A.current) {
			await A.current;
			return;
		}
		g.current += 1, m.current?.abort(), f.current = null, a.getState().setCurrentSessionId(null), E.getState().setMessages([]);
		let e = n.createSession(t).then((e) => {
			let n = e.SessionId || null;
			return n && K.getState().agentId === t && ae(n, E.getState().messages.some((e) => e.eventType === "optimistic_user_message" || e.eventType === "optimistic_assistant_placeholder")), n;
		}).catch((e) => (e instanceof U || console.error("Failed to create session:", e), null));
		A.current = e;
		try {
			await e;
		} finally {
			A.current === e && (A.current = null);
		}
	}, [
		ae,
		t,
		n
	]), ce = R(async () => {
		let e = A.current;
		return e ? await e : f.current;
	}, []), le = R(async (e) => {
		try {
			let r = await n.deleteSession(e);
			return K.getState().agentId === t ? r.Deleted === !1 ? (s.getState().pushToast("会话暂未删除，云端运行时仍在同步，请稍后重试。", "error"), L(t, f.current ?? void 0), !1) : (a.getState().removeSession(e), a.getState().clearSessionMessageHistory(e), w.current.delete(e), D.current.delete(e), T.current.delete(e), O.current.delete(e), C.current.delete(e), k.current.delete(e), f.current === e && (g.current += 1, m.current?.abort(), u?.(), f.current = null, E.getState().setMessages([]), b.getState().clearSessionCheckpoints(e), a.getState().setCurrentSessionId(null), c.getState().setCurrentRunId(""), c.getState().clearActivity(), L(t)), !0) : r.Deleted !== !1;
		} catch (e) {
			return e instanceof U ? !1 : (console.error("Failed to delete session", e), s.getState().pushToast("删除会话失败，请稍后重试。", "error"), !1);
		}
	}, [
		t,
		n,
		u,
		L
	]), ue = R(async (e, t) => {
		t?.throwIfAborted();
		let r = a.getState().messageHistory[e], i = O.current.get(e), o = !!(r?.hasMore && r.nextCursor !== null), s = !!(i && i.loadedCount < i.total);
		if (!r || r.isLoadingOlder || !o && !s) return;
		let c = g.current, l = Symbol(e);
		x.current.set(e, l);
		try {
			a.getState().setSessionMessageHistoryLoading(e, !0);
			let [u, d] = await Promise.all([o ? n.listSessionMessages(e, {
				signal: t,
				beforeSeqId: r.nextCursor ?? void 0,
				limit: Rn,
				includeReasoning: !0,
				includeToolEvents: !0,
				includeAttachments: !0
			}) : Promise.resolve(null), s && i ? n.listSessionEvents(e, {
				signal: t,
				offset: i.loadedCount,
				limit: zn
			}) : Promise.resolve(null)]);
			if (t?.throwIfAborted(), f.current !== e || g.current !== c || x.current.get(e) !== l) return;
			let m = u ? kn(u.Messages) : [], h = new Set(m.map((e) => e.id)), _ = [...m, ...(D.current.get(e) || []).filter((e) => !h.has(e.id))];
			$(D.current, e, _, f.current);
			let v = i?.events || [], y = i?.loadedCount || 0, b = i?.total || 0;
			if (d) {
				let t = d.Events || [];
				v = ge(t, v), b = Math.max(b, Number(d.Total ?? 0) || 0), y = t.length > 0 ? Math.min(b, y + t.length) : b, $(O.current, e, {
					events: v,
					loadedCount: y,
					total: b
				}, f.current);
				for (let n of t) bt(n, e);
			}
			let S = fe(_, v, e, T.current.get(e) || "flat-v1"), ee = S.messages;
			$(C.current, e, new Set(S.canonicalRunIds), f.current), E.getState().setMessages(ee), $(w.current, e, ee, f.current, Bn), a.getState().setSessionMessageHistory(e, {
				nextCursor: u ? u.NextCursor : r.nextCursor,
				hasMore: !!(u && u.HasMore || y < b)
			}), P(p.current, e, m);
		} catch (e) {
			if (t) throw e;
			e instanceof U || console.error("Failed to load older session messages:", e);
		} finally {
			x.current.get(e) === l && (x.current.delete(e), a.getState().setSessionMessageHistoryLoading(e, !1));
		}
	}, [n, P]);
	return {
		historySearchSnapshot: R(() => {
			let e = f.current || "", t = a.getState().messageHistory[e], n = O.current.get(e);
			return {
				owner: JSON.stringify([
					p.current,
					e,
					g.current
				]),
				messages: E.getState().messages,
				hasMore: !!t?.hasMore,
				loading: !!(_.current === g.current || a.getState().isLoadingSessions || t?.isLoadingInitial || t?.isLoadingOlder),
				checkpoint: `${t?.nextCursor}:${n?.loadedCount}`,
				error: y.current?.generation === g.current ? y.current.message : void 0
			};
		}, []),
		followAcceptedInteraction: ne,
		fetchSessions: L,
		loadMoreSessions: ie,
		loadSession: I,
		loadOlderSessionMessages: ue,
		createNewSession: se,
		startNewConversation: oe,
		adoptCreatedSession: ae,
		waitForPendingSessionCreation: ce,
		deleteSession: le,
		currentSessionIdRef: f,
		agentIdRef: p,
		runSubscriptionAbortRef: m
	};
}
//#endregion
export { Ue as A, Ze as C, We as D, W as E, Me as M, Ne as N, Le as O, it as S, Ge as T, _t as _, vn as a, ot as b, Ht as c, Lt as d, At as f, vt as g, Ct as h, Fn as i, Ae as j, G as k, Z as l, Et as m, jn as n, on as o, Dt as p, Pn as r, Kt as s, qn as t, zt as u, gt as v, K as w, at as x, ct as y };
