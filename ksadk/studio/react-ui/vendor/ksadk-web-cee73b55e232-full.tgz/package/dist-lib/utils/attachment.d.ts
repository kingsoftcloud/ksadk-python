export declare function fileFingerprint(file: File): string;
export declare function mergeAttachmentFiles(current: File[], incoming: File[]): File[];
export declare function extractClipboardFiles(event: React.ClipboardEvent<HTMLTextAreaElement>): File[];
//# sourceMappingURL=attachment.d.ts.map