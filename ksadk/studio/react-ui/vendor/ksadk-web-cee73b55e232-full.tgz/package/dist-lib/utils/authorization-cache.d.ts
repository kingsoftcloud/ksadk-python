/** UI cache namespace only. Never use this value as authorization evidence. */
export class AuthorizationCache {
    initialized: boolean;
    /** @type {string | undefined} */
    scope: string | undefined;
    blocked: boolean;
    /** @param {string | undefined} scope */
    enter(scope: string | undefined): "reload" | "ready";
    /** @param {string | undefined} scope */
    matches(scope: string | undefined): boolean;
    key(legacyKey: any): any;
    get writable(): boolean;
}
export const authorizationCache: AuthorizationCache;
//# sourceMappingURL=authorization-cache.d.ts.map