export function normalizeCapabilities(bootstrap: any): any;
export function isHostedChatEnabled(capabilities: any): any;
export function isNativeDashboardEnabled(capabilities: any): any;
export function isNativeTerminalEnabled(capabilities: any): any;
export function resolveHostedChatTransport(capabilities: any, options?: {}): any;
//# sourceMappingURL=capabilities.d.ts.map