import type { Message } from '../components/chat/types.js';
/** Whether a model row is another activity from the preceding assistant turn. */
export declare function continuesAssistantTurn(previous: Message | undefined, current: Message): boolean;
//# sourceMappingURL=chat-message-grouping.d.ts.map