export type ScrollMetrics = {
    scrollHeight: number;
    scrollTop: number;
    clientHeight: number;
};
/**
 * Keep the jump control quiet during small layout shifts near the end of the
 * transcript. This mirrors the shared chat rule that auto-follow remains
 * attached until the reader has deliberately moved away from the latest turn.
 */
export declare const SCROLL_TO_BOTTOM_REVEAL_DISTANCE = 96;
export declare function distanceFromBottom({ scrollHeight, scrollTop, clientHeight, }: ScrollMetrics): number;
export declare function shouldShowScrollToBottom(metrics: ScrollMetrics): boolean;
//# sourceMappingURL=chat-scroll.d.ts.map