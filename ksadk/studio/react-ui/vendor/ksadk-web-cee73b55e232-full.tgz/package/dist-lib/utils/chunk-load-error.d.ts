export declare function isChunkLoadError(error: unknown): boolean;
//# sourceMappingURL=chunk-load-error.d.ts.map