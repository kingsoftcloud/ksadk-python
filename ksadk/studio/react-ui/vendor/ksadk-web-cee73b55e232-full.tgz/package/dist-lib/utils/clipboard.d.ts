/**
 * 浏览器复制能力在不同运行环境里差异很大：
 * - `navigator.clipboard.writeText` 最理想，但可能因为权限/上下文失败
 * - 本地调试或某些嵌入容器里，只能退回到 `document.execCommand('copy')`
 *
 * 这里统一做一层兜底，让 UI 只关心“最终有没有复制成功”。
 */
export function copyTextToClipboard(text: any, env?: typeof globalThis): Promise<boolean>;
//# sourceMappingURL=clipboard.d.ts.map