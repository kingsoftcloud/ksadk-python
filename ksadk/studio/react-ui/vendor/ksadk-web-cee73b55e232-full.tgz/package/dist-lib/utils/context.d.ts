/**
 * 这些函数是输入框右下角“上下文状态”的纯计算层。
 * 单独抽出来有两个目的：
 * 1. 前端 UI 只负责展示，不在组件里塞一堆口径判断。
 * 2. 可以直接被 node --test 回归，避免每次都靠人工看页面。
 */
export function coercePositiveNumber(value: any): number | null;
export function estimateTextTokens(text: any): number;
export function estimateMessageContextTokens(message: any): number;
export function resolveContextWindowTokens(model: any): number | null;
export function resolveAutoCompactThresholdPercent(model: any): number;
export function buildComposerContextIndicator({ selectedModel, contextUsage }: {
    selectedModel: any;
    contextUsage: any;
}): {
    contextWindowTokens: number | undefined;
    contextWindowSource: string | undefined;
    label: string;
    phase: string;
} | {
    contextWindowTokens: number | undefined;
    contextWindowSource: string | undefined;
    label: string;
    phase: string;
    percent: number | undefined;
    usedTokens: number;
};
//# sourceMappingURL=context.d.ts.map