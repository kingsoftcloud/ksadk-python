/**
 * @param {unknown} value
 * @returns {ChatMessageFeedback | null}
 */
export function normalizeFeedback(value: unknown): ChatMessageFeedback | null;
/**
 * @param {ChatMessage | null | undefined} message
 * @param {boolean} isStreaming
 * @param {boolean} isLastMessage
 */
export function shouldRenderFeedbackControls(message: ChatMessage | null | undefined, isStreaming: boolean, isLastMessage: boolean): boolean;
/**
 * @param {{ agentId: string; sessionId: string; message: ChatMessage | null | undefined }} options
 */
export function buildGetFeedbackPayload({ agentId, sessionId, message }: {
    agentId: string;
    sessionId: string;
    message: ChatMessage | null | undefined;
}): {
    AgentId: string;
    SessionId: string;
    ResponseId: string;
};
/**
 * @param {{
 *   agentId: string;
 *   sessionId: string;
 *   message: ChatMessage | null | undefined;
 *   rating: string;
 *   comment?: string;
 * }} options
 */
export function buildUpsertFeedbackPayload({ agentId, sessionId, message, rating, comment, }: {
    agentId: string;
    sessionId: string;
    message: ChatMessage | null | undefined;
    rating: string;
    comment?: string;
}): {
    Rating: string;
    Comment: string;
    TraceId: string;
    RootSpanId: string;
    AgentId: string;
    SessionId: string;
    ResponseId: string;
};
/**
 * @param {ChatMessage[]} messages
 * @param {{ messageId: string; rating: string; comment?: string }} options
 * @returns {{ nextMessages: ChatMessage[]; previousFeedback: ChatMessageFeedback | null }}
 */
export function applyOptimisticFeedback(messages: ChatMessage[], { messageId, rating, comment }: {
    messageId: string;
    rating: string;
    comment?: string;
}): {
    nextMessages: ChatMessage[];
    previousFeedback: ChatMessageFeedback | null;
};
/**
 * @param {ChatMessage[]} messages
 * @param {{ messageId: string; feedback: unknown }} options
 * @returns {ChatMessage[]}
 */
export function markFeedbackSaved(messages: ChatMessage[], { messageId, feedback }: {
    messageId: string;
    feedback: unknown;
}): ChatMessage[];
/**
 * @param {ChatMessage[]} messages
 * @param {{ messageId: string; previousFeedback: ChatMessageFeedback | null }} options
 * @returns {ChatMessage[]}
 */
export function rollbackFeedback(messages: ChatMessage[], { messageId, previousFeedback }: {
    messageId: string;
    previousFeedback: ChatMessageFeedback | null;
}): ChatMessage[];
/**
 * @param {ChatMessage[]} messages
 * @param {{ messageId: string }} options
 * @returns {ChatMessage[]}
 */
export function clearFeedback(messages: ChatMessage[], { messageId }: {
    messageId: string;
}): ChatMessage[];
export type ChatMessage = import("../components/chat/types.js").Message;
export type ChatMessageFeedback = NonNullable<ChatMessage["feedback"]>;
//# sourceMappingURL=feedback.d.ts.map