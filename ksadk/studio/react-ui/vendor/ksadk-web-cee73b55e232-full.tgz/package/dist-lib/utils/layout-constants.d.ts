import type { RuntimeApiFormat } from '../types/api.js';
declare const DEFAULT_WORKSPACE_PANEL_WIDTH = 820;
declare const MIN_WORKSPACE_PANEL_WIDTH = 420;
declare const MAX_WORKSPACE_PANEL_WIDTH = 1280;
declare const MIN_CHAT_PANEL_WIDTH = 360;
declare const DESKTOP_SIDEBAR_WIDTH = 280;
export { DEFAULT_WORKSPACE_PANEL_WIDTH, MIN_WORKSPACE_PANEL_WIDTH, MAX_WORKSPACE_PANEL_WIDTH, MIN_CHAT_PANEL_WIDTH, DESKTOP_SIDEBAR_WIDTH, };
export declare function resolveRunAgentApiFormat(options: {
    agentFramework: string;
    apiFormats: RuntimeApiFormat[];
}): RuntimeApiFormat;
export declare function clampWorkspacePanelWidth(width: number, viewportWidth: number, sidebarWidth: number): number;
//# sourceMappingURL=layout-constants.d.ts.map