export function alignTableHeaderColumns(text: any): string;
export function preprocessMarkdown(text: any): any;
//# sourceMappingURL=markdown.d.ts.map