export function mapBackendMessage(msg: any): {
    id: any;
    role: any;
    content: any;
    timestamp: number;
    eventType: string;
    reasoning: any;
    tools: {} | undefined;
    attachments: {
        name: any;
        url: any;
        type: any;
        fileUri: any;
    }[] | undefined;
};
export function mapBackendMessages(messages: any): any;
//# sourceMappingURL=messages.d.ts.map