export function isMobileViewportWidth(width: any, breakpoint?: number): boolean;
export function resolveSidebarVisibility({ isMobile, desktopSidebarOpen, mobileSidebarOpen, }: {
    isMobile: any;
    desktopSidebarOpen: any;
    mobileSidebarOpen: any;
}): {
    desktopSidebarVisible: boolean;
    mobileDrawerVisible: boolean;
};
export function resolveComposerMaxHeight({ isMobile, viewportHeight, desktopMaxHeight, }: {
    isMobile: any;
    viewportHeight: any;
    desktopMaxHeight?: number | undefined;
}): number;
export const MOBILE_BREAKPOINT: 768;
export const DESKTOP_COMPOSER_MAX_HEIGHT: 160;
export const MOBILE_COMPOSER_MIN_HEIGHT: 120;
export const MOBILE_COMPOSER_HEIGHT_RATIO: 0.28;
//# sourceMappingURL=mobile-layout.d.ts.map