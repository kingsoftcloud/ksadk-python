/**
 * @param {unknown} value
 * @returns {ThinkingMode}
 */
export function normalizeThinkingMode(value: unknown): ThinkingMode;
/**
 * @param {unknown} value
 */
export function buildModelOptionsFromThinkingMode(value: unknown): {
    thinking: {
        type: string;
    };
} | undefined;
export type ThinkingMode = "auto" | "enabled" | "disabled";
//# sourceMappingURL=model-options.d.ts.map