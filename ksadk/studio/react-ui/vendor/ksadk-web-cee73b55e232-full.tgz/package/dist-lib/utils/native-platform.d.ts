export function resolveNativeManagementLink({ agentFramework, accessMode, origin }: {
    agentFramework: any;
    accessMode: any;
    origin: any;
}): {
    href: string;
    label: string;
    title: string;
} | null;
export function resolveNativeManagementLinkFromCapability({ capability, agentFramework, accessMode, origin }: {
    capability: any;
    agentFramework: any;
    accessMode: any;
    origin: any;
}): {
    href: string;
    label: any;
    title: string;
} | null;
//# sourceMappingURL=native-platform.d.ts.map