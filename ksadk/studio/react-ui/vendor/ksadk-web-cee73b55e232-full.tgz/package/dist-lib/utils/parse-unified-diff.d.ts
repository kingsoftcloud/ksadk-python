export interface DiffFileSection {
    oldPath?: string;
    path: string;
    lines: string[];
}
/** 解析 unified diff 字符串成文件分段(照抄 wework parseUnifiedDiff,纯函数)。 */
export declare function parseUnifiedDiff(diff: string): DiffFileSection[];
/** 统计一个文件分段的新增/删除行数(用于行尾 +N −M 标记)。 */
export declare function summarizeDiffSection(section: DiffFileSection): {
    added: number;
    removed: number;
};
/** 判断 tool output 是否是 unified diff(以 diff --git 开头)。 */
export declare function isUnifiedDiff(text: string): boolean;
//# sourceMappingURL=parse-unified-diff.d.ts.map