import type { Message } from '../components/chat/types.js';
import { type KernelSessionEventFrame } from '../core/stream/kernel-events.js';
import type { SessionEventRecord } from '../types/session-events.js';
export type PersistedSessionEventRecord = SessionEventRecord & {
    Content?: SessionEventRecord['Content'] & {
        runtime_event?: Record<string, unknown>;
        runtimeEvent?: Record<string, unknown>;
        session_event?: Record<string, unknown>;
        sessionEvent?: Record<string, unknown>;
        conversationItem?: unknown;
    };
};
/**
 * Extract the canonical RuntimeEvent/v2 frame persisted inside a
 * ListSessionEvents record. The server stores both the SessionEvent envelope
 * and a flattened runtime_event projection; the latter already carries the
 * unified Session seq used by replay cursors.
 */
export declare function persistedRuntimeFrame(raw: PersistedSessionEventRecord): KernelSessionEventFrame | null;
/**
 * Rebuild the transcript for runs that have canonical RuntimeEvent/v2
 * history. Cumulative ListSessionMessages rows remain only a compatibility
 * fallback for legacy runs; they never co-own a canonical run.
 */
export declare function rebuildPersistedSessionHistory(fallbackMessages: Message[], records: PersistedSessionEventRecord[], sessionId: string, profile?: 'flat-v1' | 'agent-block-v1'): {
    messages: Message[];
    canonicalRunIds: string[];
    translatedEvents: SessionEventRecord[];
};
//# sourceMappingURL=persisted-session-history.d.ts.map