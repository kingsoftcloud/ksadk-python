import type { Message } from '../components/chat/types.js';
import type { SessionEventRecord } from '../types/session-events.js';
export declare function mergeRecoveredRunMessages(messages: Message[], events: SessionEventRecord[], invocationId: string): Message[];
//# sourceMappingURL=recovered-run.d.ts.map