export function createResponsesStreamState(): {
    toolNames: Map<any, any>;
    toolArguments: Map<any, any>;
    callIds: Map<any, any>;
    currentResponseId: string;
    sawTextDelta: boolean;
    sawReasoningDelta: boolean;
    seenEvents: Set<any>;
    itemCallIds: Map<any, any>;
};
export function textFromUnknown(value: any): any;
export function normalizeResponsesStreamEvent({ eventName, data, state }: {
    eventName: any;
    data: any;
    state: any;
}): any[];
export { RuntimeItemReducer, responsesEventToItemOperations, projectRuntimeItems } from "../core/stream/runtime-items.ts";
//# sourceMappingURL=responses-stream.d.ts.map