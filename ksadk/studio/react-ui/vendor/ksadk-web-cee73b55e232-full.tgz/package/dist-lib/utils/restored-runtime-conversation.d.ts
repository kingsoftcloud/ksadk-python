import type { Message } from '../components/chat/types.js';
import { type PersistedSessionEventRecord } from './persisted-session-history.js';
/** Continue the same canonical presentation after loading its durable history. */
export declare class RestoredRuntimeConversation {
    private readonly ingress;
    private readonly sessionId;
    private readonly runId;
    private hasRunStart;
    private readonly profile;
    constructor(sessionId: string, runId: string, history: PersistedSessionEventRecord[], profile: 'flat-v1' | 'agent-block-v1');
    private frame;
    apply(record: PersistedSessionEventRecord, messages: Message[]): Message[];
}
//# sourceMappingURL=restored-runtime-conversation.d.ts.map