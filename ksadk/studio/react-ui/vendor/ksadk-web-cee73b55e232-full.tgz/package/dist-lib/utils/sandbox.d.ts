type SandboxOptions = {
    channelId?: string;
    basePath?: string;
};
/**
 * Build a sandboxed HTML document for iframe srcdoc.
 * Injects CSP and link click interception.
 * When basePath is provided, sibling workspace assets may load through the
 * workspace route, while XHR/fetch/websocket connections stay disabled.
 */
export declare function buildSandboxedHtml(html: string, options?: SandboxOptions | string): string;
/**
 * React hook: listen for postMessage link clicks from a sandboxed iframe
 * and open them in a new window. Validates event.source against the
 * provided iframe ref to prevent message spoofing.
 */
export declare function useIframeMessageHandler(iframeRef: React.RefObject<HTMLIFrameElement | null>, channelId?: string): void;
export {};
//# sourceMappingURL=sandbox.d.ts.map