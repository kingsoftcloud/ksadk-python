import type { SessionEventRecord } from '../types/session-events.js';
export type ListSessionEventsPage = {
    Events?: unknown[];
    Total?: number;
    Offset?: number;
    Limit?: number;
};
export type ListSessionEventsFn = (sessionId: string, opts?: {
    offset?: number;
    limit?: number;
}) => Promise<ListSessionEventsPage>;
export declare function resolveOlderSessionEventPage(cache: {
    offset: number;
    total: number;
}, pageSize: number): {
    offset: number;
    limit: number;
} | null;
export declare function loadCompleteSessionEventHistory(sessionId: string, listSessionEvents: ListSessionEventsFn, options?: {
    pageSize?: number;
    shouldContinue?: () => boolean;
}): Promise<{
    events: SessionEventRecord[];
    total: number;
    offset: number;
    limit: number;
} | null>;
import { type SessionEventEnvelope } from '../types/agent-control.js';
/** Two events sharing a seq but differing in content are a protocol error. */
export declare class SessionEventConflictError extends Error {
    seq: number;
    constructor(seq: number);
}
/**
 * Deduplication/ordering state keyed strictly by the Session seq.
 *
 * Internal event ids from Responses/AG-UI/A2A projections are never used as a
 * reconnect cursor. Refresh replays are folded in before live events: an
 * exact duplicate seq is ignored, a conflicting one raises
 * {@link SessionEventConflictError}.
 */
export declare class SessionEventCursor {
    private eventsBySeq;
    private lastSeqValue;
    /** Fold one raw kernel envelope into the cursor. */
    accept(raw: unknown): void;
    get lastSeq(): number;
    /** Cursor value for SubscribeSessionEvents(after_seq) reconnects. */
    reconnectAfterSeq(): number;
    /** Events safe to project into the transcript, ordered by seq. */
    displayableEvents(): SessionEventEnvelope[];
}
export declare function createSessionEventCursor(): SessionEventCursor;
//# sourceMappingURL=session-event-history.d.ts.map