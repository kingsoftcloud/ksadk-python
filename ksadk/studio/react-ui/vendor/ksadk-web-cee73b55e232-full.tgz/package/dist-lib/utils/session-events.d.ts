/**
 * Reduce a list of session events into an identity-aware item snapshot.
 * Canonical `Metadata.RuntimeItem` events keep their full identity; legacy
 * `assistant_stream_snapshot`/`assistant_message` collapse onto the synthesized
 * per-invocation assistant item (snapshot -> replace, message -> complete).
 */
export function buildRuntimeItemsFromSessionEvents(events?: any[]): import("../core/stream/runtime-items.ts").RuntimeItemSnapshot;
export function sessionEventRunStatus(event: any): string;
export function parseMessageContent(event: any): {
    text: string;
    attachments: any[] | undefined;
};
/**
 * @param {{
 *   id: string;
 *   timestamp: number;
 *   status?: Message['status'];
 *   trigger?: string;
 *   compactedUntilSeqId?: number;
 *   summary?: string;
 *   historical?: boolean;
 * }} options
 * @returns {Message}
 */
export function buildCompactionMessage(options: {
    id: string;
    timestamp: number;
    status?: Message["status"];
    trigger?: string;
    compactedUntilSeqId?: number;
    summary?: string;
    historical?: boolean;
}): Message;
/**
 * @param {import('../types/session-events.js').SessionEventRecord} event
 * @returns {Message | null}
 */
export function buildMessageFromSessionEvent(event: import("../types/session-events.js").SessionEventRecord): Message | null;
/**
 * @param {import('../types/session-events.js').SessionEventRecord[]} [events]
 * @returns {Message[]}
 */
export function buildMessagesFromSessionEvents(events?: import("../types/session-events.js").SessionEventRecord[]): Message[];
export function mergeSessionEventRecords(baseEvents?: any[], incomingEvents?: any[]): any[];
export function maxSeqIdFromEvents(events?: any[]): any;
export function eventHasTerminalRunStatus(event: any): boolean;
export type Message = import("../components/chat/types.js").Message;
export { RuntimeItemReducer, sessionEventToItemOperation, legacyAssistantIdentity, projectRuntimeItems } from "../core/stream/runtime-items.ts";
//# sourceMappingURL=session-events.d.ts.map