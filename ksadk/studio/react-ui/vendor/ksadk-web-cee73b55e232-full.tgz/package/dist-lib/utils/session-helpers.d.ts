import type { Session } from '../components/chat/types.js';
export declare function sessionUpdatedAtValue(session: Session): number;
export declare function upsertSessions(current: Session[], incoming: Session[]): Session[];
export declare function sessionTitle(session: Session): string;
export declare function formatDate(ts?: string | number | null): string;
//# sourceMappingURL=session-helpers.d.ts.map