export function isSessionRunning(session: any): boolean;
export function normalizeSidebarSessions(sessions?: any[], query?: string, options?: {}): any[];
export function formatSessionModelLabel(session: any): string;
export function formatSessionContextLabel(session: any): string;
export function resolveCompactSessionMeta(session: any, options?: {}): {
    running: boolean;
    failed: boolean;
    label: string;
};
//# sourceMappingURL=session-list.d.ts.map