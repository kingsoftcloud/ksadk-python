export declare function ownsOlderMessageScrollRequest(options: {
    requestedSessionId: string;
    activeSessionId: string | null;
    requestToken: symbol;
    activeRequestToken: symbol | null;
}): boolean;
//# sourceMappingURL=session-message-history.d.ts.map