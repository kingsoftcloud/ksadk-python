export function mergeLoadedPages(current?: Set<any>, pages?: any[]): Set<any>;
export function buildSessionPaginationState({ sessionsLength, total, page, pageSize, loadedPages, }?: {
    sessionsLength?: number | undefined;
    total?: number | undefined;
    page?: number | undefined;
    pageSize?: number | undefined;
    loadedPages?: Set<any> | undefined;
}): {
    total: number;
    page: number;
    pageSize: number;
    loadedPages: Set<any>;
    hasMore: boolean;
};
export function resolveNextSessionsPage({ total, pageSize, loadedPages, }?: {
    total?: number | undefined;
    pageSize?: number | undefined;
    loadedPages?: Set<any> | undefined;
}): number | null;
//# sourceMappingURL=session-pagination.d.ts.map