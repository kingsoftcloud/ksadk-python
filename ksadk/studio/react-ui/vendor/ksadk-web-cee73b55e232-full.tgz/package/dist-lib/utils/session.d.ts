export function buildSessionStorageKey(agentId: any): any;
export function readPersistedSessionId(agentId: any, storage: any): string | null;
export function writePersistedSessionId(agentId: any, sessionId: any, storage: any): void;
export function resolveSessionToRestore(sessions: any, preferredSessionId: any): string | null;
export function mergePendingSessions(listedSessions: any, currentSessions: any, pendingSessionIds: any): any[];
//# sourceMappingURL=session.d.ts.map