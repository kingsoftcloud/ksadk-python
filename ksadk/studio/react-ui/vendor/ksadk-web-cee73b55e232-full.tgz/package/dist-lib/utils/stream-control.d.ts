export function shouldStopReadingRunStream(actions?: any[]): boolean;
//# sourceMappingURL=stream-control.d.ts.map