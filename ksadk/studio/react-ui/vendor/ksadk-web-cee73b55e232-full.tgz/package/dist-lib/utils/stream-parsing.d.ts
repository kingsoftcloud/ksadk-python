export declare function textFromUnknown(value: unknown): string;
export declare function objectRecord(value: unknown): Record<string, unknown>;
export declare function extractChatCompletionsStreamDelta(data: unknown): {
    content: string;
    reasoning: string;
    finalText: string;
};
//# sourceMappingURL=stream-parsing.d.ts.map