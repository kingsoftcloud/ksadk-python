export function buildCreateTerminalSessionPayload(options?: {}): {
    mode: string;
    cols: any;
    rows: any;
};
export function buildTerminalSessionsUrl(options: {} | undefined, locationLike: any): string;
export function normalizeTerminalSessions(payload: any): any;
export function buildTerminalAttachUrl(path: string | undefined, terminalSessionId: any, locationLike: any): string;
export function sanitizeTerminalInputForPty(data: any): string;
export const TERMINAL_SESSIONS_ENDPOINT: "/_ksadk/terminal/sessions";
//# sourceMappingURL=terminal-session.d.ts.map