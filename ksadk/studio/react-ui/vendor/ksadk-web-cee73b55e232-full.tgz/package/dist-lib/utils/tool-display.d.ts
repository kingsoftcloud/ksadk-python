export function isFailedToolOutput(value: any): any;
export function formatToolPayload(value: any): string;
/** Only host-issued display metadata, never a key inside raw tool output. */
export function publicToolDisplay(value: any): any;
//# sourceMappingURL=tool-display.d.ts.map