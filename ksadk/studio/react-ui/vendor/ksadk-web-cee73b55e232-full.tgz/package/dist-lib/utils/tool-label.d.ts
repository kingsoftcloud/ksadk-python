export declare function toolDisplayLabel(name: string): string;
//# sourceMappingURL=tool-label.d.ts.map