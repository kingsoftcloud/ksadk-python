interface HastNode {
    type: string;
    tagName?: string;
    value?: string;
    children?: HastNode[];
    properties?: Record<string, unknown>;
}
/** Turn file paths appearing in markdown prose into preview links.
 * Paths inside code blocks, existing links, and headings' raw HTML are left
 * untouched so code samples keep their literal text. */
export declare function rehypeWorkspaceFilePaths(): (tree: HastNode) => void;
export declare const WORKSPACE_FILE_PATH_RE: RegExp;
export type WorkspaceFilePathSegment = {
    type: "text";
    value: string;
} | {
    type: "file";
    value: string;
};
/** Split plain text (tool logs, command output) into text and file-path
 * segments so hosts can render paths as preview links outside markdown. */
export declare function splitWorkspaceFilePaths(value: string): WorkspaceFilePathSegment[];
export {};
//# sourceMappingURL=workspace-file-paths.d.ts.map