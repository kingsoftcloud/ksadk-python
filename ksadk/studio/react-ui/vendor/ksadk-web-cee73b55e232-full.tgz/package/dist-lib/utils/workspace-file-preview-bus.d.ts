/** Request the host app to show the workspace file preview modal. */
export declare function openWorkspaceFilePreview(path: string): void;
export declare function onWorkspaceFilePreviewRequest(handler: (path: string | null) => void): () => void;
//# sourceMappingURL=workspace-file-preview-bus.d.ts.map