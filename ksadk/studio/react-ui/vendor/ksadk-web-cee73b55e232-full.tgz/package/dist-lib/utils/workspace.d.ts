export function normalizeWorkspacePath(path: any): string;
export function buildWorkspaceFileUrl(path: any): string;
export function buildWorkspaceFileBaseUrl(path: any): string;
export function isWorkspaceRootPath(path: any): boolean;
export function formatWorkspacePathLabel(path: any, rootLabel?: string): string;
export function formatWorkspaceDirectoryPathLabel(path: any): string;
export function buildWorkspaceBreadcrumbs(path: any, rootLabel?: string): {
    label: string;
    path: string;
}[];
export function resolveWorkspacePreviewKind({ path, mimeType }: {
    path: any;
    mimeType: any;
}): "text" | "html" | "markdown" | "pdf" | "image" | "unsupported";
export function resolveWorkspaceEditKind({ path, mimeType }: {
    path: any;
    mimeType: any;
}): "code" | "text" | "html" | "markdown" | null;
/**
 * @param {{ isMobile: boolean }} options
 * @returns {{
 *   renderMode: 'sheet' | 'inline';
 *   modal: boolean;
 *   showOverlay: boolean;
 *   preventOutsideClose: boolean;
 *   side: 'top' | 'bottom' | 'left' | 'right';
 * }}
 */
export function resolveWorkspacePanelPresentation({ isMobile }: {
    isMobile: boolean;
}): {
    renderMode: "sheet" | "inline";
    modal: boolean;
    showOverlay: boolean;
    preventOutsideClose: boolean;
    side: "top" | "bottom" | "left" | "right";
};
export function createWorkspacePreviewRequestTracker(): {
    next(path: any): {
        path: any;
        version: number;
    };
    invalidate(): void;
    isCurrent(token: any): boolean;
};
export function canAccessWorkspaceFiles({ workspaceFiles, accessMode }: {
    workspaceFiles: any;
    accessMode: any;
}): boolean;
export const WORKSPACE_ROOT_PATH: ".";
export const WORKSPACE_FILES_BASE_PATH: "/_ksadk/workspace/v1/files";
//# sourceMappingURL=workspace.d.ts.map