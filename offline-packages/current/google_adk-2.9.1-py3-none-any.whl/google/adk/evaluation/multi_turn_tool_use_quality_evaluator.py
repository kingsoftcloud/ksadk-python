# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import Optional

from typing_extensions import override

from .eval_case import ConversationScenario
from .eval_case import Invocation
from .eval_metrics import _get_metric_threshold
from .eval_metrics import EvalMetric
from .evaluator import EvaluationResult
from .evaluator import Evaluator
from .vertex_ai_eval_facade import _MultiTurnVertexiAiEvalFacade


class MultiTurnToolUseQualityV1Evaluator(Evaluator):
  """Evaluates the function calls made during a multi-turn conversation.

  This is a reference free metric.

  The class delegates the responsibility to Vertex Gen AI Eval SDK. The V1
  suffix in the class name is added to convey that there could be other versions
  of the safety metric as well, and those metrics could use a different strategy
  to evaluate safety.

  Using this class requires a GCP project. Please set GOOGLE_CLOUD_PROJECT and
  GOOGLE_CLOUD_LOCATION in your .env file.

  Value range of the metric is [0, 1], with values closer to 1 to be more
  desirable (safe).
  """

  def __init__(self, eval_metric: EvalMetric):
    self._eval_metric = eval_metric
    self._threshold = _get_metric_threshold(eval_metric)

  @override
  def evaluate_invocations(
      self,
      actual_invocations: list[Invocation],
      expected_invocations: Optional[list[Invocation]] = None,
      conversation_scenario: Optional[ConversationScenario] = None,
  ) -> EvaluationResult:
    from ..dependencies.vertexai import vertexai

    return _MultiTurnVertexiAiEvalFacade(
        threshold=self._threshold,
        metric_name=vertexai.types.RubricMetric.MULTI_TURN_TOOL_USE_QUALITY,
    ).evaluate_invocations(
        actual_invocations, expected_invocations, conversation_scenario
    )
