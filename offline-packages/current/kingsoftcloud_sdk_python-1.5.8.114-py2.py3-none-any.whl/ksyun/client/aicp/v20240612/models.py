from ksyun.common.abstract_model import AbstractModel

class CreateResourcePoolRequest(AbstractModel):
    """CreateResourcePool请求参数结构体
    """

    def __init__(self):
        r"""创建资源池
        :param ResourcePoolName: 资源组名称
        :type PathPrefix: String
        :param Description: 描述
        :type PathPrefix: String
        :param VpcId: 虚拟私有网络ID
        :type PathPrefix: String
        :param ResourcePoolType: 资源组类型
        :type PathPrefix: String
        :param ClusterId: 集群ID
        :type PathPrefix: String
        :param EnableKPFSPerformance: 开启性能型KPFS
        :type PathPrefix: Boolean
        :param FileSystemId: 文件系统id
        :type PathPrefix: String
        :param EnableKlog: 开启Klog
        :type PathPrefix: String
        :param LogProjectName: Klog工程名
        :type PathPrefix: String
        :param Overallocate: 配额超发
        :type PathPrefix: Boolean
        :param Components: 组件
        :type PathPrefix: Array
        :param EnableVolume: 是否支持挂载云盘, true代表开启
        :type PathPrefix: Boolean
        :param VolumeChargeType: 云盘计费方式，有效值：
- HourlyInstantSettlement（后付费，按小时实时结算）
- Daily（后付费，按日月结）
        :type PathPrefix: String
        :param ProjectId: 项目制ID
        :type PathPrefix: String
        """
        self.ResourcePoolName = None
        self.Description = None
        self.VpcId = None
        self.ResourcePoolType = None
        self.ClusterId = None
        self.EnableKPFSPerformance = None
        self.FileSystemId = None
        self.EnableKlog = None
        self.LogProjectName = None
        self.Overallocate = None
        self.Components = None
        self.EnableVolume = None
        self.VolumeChargeType = None
        self.ProjectId = None

    def _deserialize(self, params):
        if params.get("ResourcePoolName"):
            self.ResourcePoolName = params.get("ResourcePoolName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("VpcId"):
            self.VpcId = params.get("VpcId")
        if params.get("ResourcePoolType"):
            self.ResourcePoolType = params.get("ResourcePoolType")
        if params.get("ClusterId"):
            self.ClusterId = params.get("ClusterId")
        if params.get("EnableKPFSPerformance"):
            self.EnableKPFSPerformance = params.get("EnableKPFSPerformance")
        if params.get("FileSystemId"):
            self.FileSystemId = params.get("FileSystemId")
        if params.get("EnableKlog"):
            self.EnableKlog = params.get("EnableKlog")
        if params.get("LogProjectName"):
            self.LogProjectName = params.get("LogProjectName")
        if params.get("Overallocate"):
            self.Overallocate = params.get("Overallocate")
        if params.get("Components"):
            self.Components = params.get("Components")
        if params.get("EnableVolume"):
            self.EnableVolume = params.get("EnableVolume")
        if params.get("VolumeChargeType"):
            self.VolumeChargeType = params.get("VolumeChargeType")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")


class CreateStorageConfigRequest(AbstractModel):
    """CreateStorageConfig请求参数结构体
    """

    def __init__(self):
        r"""创建存储配置
        :param StorageConfigName: 存储配置名称, 1-64个字符，允许字母 中文 数字 - _ . / ( )
        :type PathPrefix: String
        :param Description: 存储配置描述
        :type PathPrefix: String
        :param Type: 存储类型 
 有效值： 
 - KPFS 
 - KS3
        :type PathPrefix: String
        :param MountPath: 挂载路径, 不能覆盖关键系统目录，包括：/、/bin、/sbin、/usr、/etc、/proc、/sys、/home等，子目录可以
        :type PathPrefix: String
        :param KpfsInfo: KPFS存储信息 (当Type为KPFS时必填)
        :type PathPrefix: Object
        :param Ks3Info: KS3存储信息 (当Type为KS3时必填)
        :type PathPrefix: Object
        :param Users: 子账号权限信息列表
        :type PathPrefix: Array
        :param DatasetPermission: 存储配置权限，枚举值：
- Private，私有
- Specified，指定范围（默认）
指定范围权限下，权限取决于Users和SharedGroupList
        :type PathPrefix: String
        :param SharedGroupList: 权限组共享列表，DatasetPermission为Specified时，Users或SharedGroupList至少传一个
        :type PathPrefix: Array
        :param Prefetch: 开启预取。当选择的文件系统是容量型/标准型KPFS时,可设置开启预取，开启后能提升连续读性能，但可能降低随机读性能。
        :type PathPrefix: Boolean
        :param Ak: 访问密钥ID,除性能型KPFS外，其余存储类型均需要填写
        :type PathPrefix: String
        :param Sk: 访问密钥Secret,除性能型KPFS外，其余存储类型均需要填写
        :type PathPrefix: String
        """
        self.StorageConfigName = None
        self.Description = None
        self.Type = None
        self.MountPath = None
        self.KpfsInfo = None
        self.Ks3Info = None
        self.Users = None
        self.DatasetPermission = None
        self.SharedGroupList = None
        self.Prefetch = None
        self.Ak = None
        self.Sk = None

    def _deserialize(self, params):
        if params.get("StorageConfigName"):
            self.StorageConfigName = params.get("StorageConfigName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("Type"):
            self.Type = params.get("Type")
        if params.get("MountPath"):
            self.MountPath = params.get("MountPath")
        if params.get("KpfsInfo"):
            self.KpfsInfo = params.get("KpfsInfo")
        if params.get("Ks3Info"):
            self.Ks3Info = params.get("Ks3Info")
        if params.get("Users"):
            self.Users = params.get("Users")
        if params.get("DatasetPermission"):
            self.DatasetPermission = params.get("DatasetPermission")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")
        if params.get("Prefetch"):
            self.Prefetch = params.get("Prefetch")
        if params.get("Ak"):
            self.Ak = params.get("Ak")
        if params.get("Sk"):
            self.Sk = params.get("Sk")


class ModifyStorageConfigRequest(AbstractModel):
    """ModifyStorageConfig请求参数结构体
    """

    def __init__(self):
        r"""修改存储配置
        :param StorageConfigId: 存储配置ID
        :type PathPrefix: String
        :param StorageConfigName: 存储配置名称, 1-64个字符，允许字母 中文 数字 - _ . / ( )
        :type PathPrefix: String
        :param Description: 存储配置存储配置描述
        :type PathPrefix: String
        :param MountPath: 挂载路径, 不能覆盖关键系统目录，包括：/、/bin、/sbin、/usr、/etc、/proc、/sys、/home等，子目录可以
        :type PathPrefix: String
        :param Ks3Info: KS3存储信息 (修改BucketName或BucketPath时需填入)
        :type PathPrefix: Object
        :param Users: 子账号权限信息列表（若传入，会进行全量覆盖式修改）
        :type PathPrefix: Array
        :param DatasetPermission: 存储配置权限，枚举值：
- Private，私有
- Specified，指定范围。不传表示不修改
指定范围权限下，权限取决于Users和SharedGroupList
        :type PathPrefix: String
        :param SharedGroupList: 权限组共享列表（若传入，会进行全量覆盖式修改）
        :type PathPrefix: Array
        :param Prefetch: 开启预取。当选择的文件系统是容量型/标准型KPFS时,可设置开启预取，开启后能提升连续读性能，但可能降低随机读性能。
        :type PathPrefix: Boolean
        :param Ak: 访问密钥ID,对于KPFS类型的存储配置,需要用户自行保证AK/SK的有效性
        :type PathPrefix: String
        :param Sk: 访问密钥Secret,对于KPFS类型的存储配置,需要用户自行保证AK/SK的有效性
        :type PathPrefix: String
        """
        self.StorageConfigId = None
        self.StorageConfigName = None
        self.Description = None
        self.MountPath = None
        self.Ks3Info = None
        self.Users = None
        self.DatasetPermission = None
        self.SharedGroupList = None
        self.Prefetch = None
        self.Ak = None
        self.Sk = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")
        if params.get("StorageConfigName"):
            self.StorageConfigName = params.get("StorageConfigName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("MountPath"):
            self.MountPath = params.get("MountPath")
        if params.get("Ks3Info"):
            self.Ks3Info = params.get("Ks3Info")
        if params.get("Users"):
            self.Users = params.get("Users")
        if params.get("DatasetPermission"):
            self.DatasetPermission = params.get("DatasetPermission")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")
        if params.get("Prefetch"):
            self.Prefetch = params.get("Prefetch")
        if params.get("Ak"):
            self.Ak = params.get("Ak")
        if params.get("Sk"):
            self.Sk = params.get("Sk")


class DescribeStorageConfigsRequest(AbstractModel):
    """DescribeStorageConfigs请求参数结构体
    """

    def __init__(self):
        r"""查询存储配置
        :param StorageConfigId: 多个存储配置的ID
        :type PathPrefix: Filter
        :param Filter: 筛选Filter
        :type PathPrefix: Filter
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param Page: 页码
        :type PathPrefix: Int
        """
        self.StorageConfigId = None
        self.Filter = None
        self.PageSize = None
        self.Page = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Page"):
            self.Page = params.get("Page")


class DeleteStorageConfigRequest(AbstractModel):
    """DeleteStorageConfig请求参数结构体
    """

    def __init__(self):
        r"""删除存储配置
        :param StorageConfigId: 存储配置ID
        :type PathPrefix: String
        """
        self.StorageConfigId = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")


class SaveNotebookImageRequest(AbstractModel):
    """SaveNotebookImage请求参数结构体
    """

    def __init__(self):
        r"""保存开发任务镜像
        :param ImageName: 镜像名称
        :type PathPrefix: String
        :param Description: 描述
        :type PathPrefix: String
        :param ImageType: 镜像类型 Personal-个人版实例，Official-企业版实例
        :type PathPrefix: String
        :param Namespace: 命名空间
        :type PathPrefix: String
        :param NamespacePermission: 命名空间权限，Public-公有 / Private-私有
        :type PathPrefix: String
        :param ImageRepo: 镜像仓库
>长度为2-30位,支持填写小写英文字母、数字、分隔符"_"和"-"(分隔符不能在首位或末位)
        :type PathPrefix: String
        :param ImageVersion: 版本号
        :type PathPrefix: String
        :param OfficialInstance: 企业版实例ID，当ImageType=Official 必填
        :type PathPrefix: String
        :param UserName: 用户名
        :type PathPrefix: String
        :param Password: 密码
        :type PathPrefix: String
        :param ImagePermission: 可见性 Public- 公开可见 / Private-仅自己可见
        :type PathPrefix: String
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param ImageDomain: 镜像仓库域名(参数已废弃)
        :type PathPrefix: String
        """
        self.ImageName = None
        self.Description = None
        self.ImageType = None
        self.Namespace = None
        self.NamespacePermission = None
        self.ImageRepo = None
        self.ImageVersion = None
        self.OfficialInstance = None
        self.UserName = None
        self.Password = None
        self.ImagePermission = None
        self.NotebookId = None
        self.ImageDomain = None

    def _deserialize(self, params):
        if params.get("ImageName"):
            self.ImageName = params.get("ImageName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ImageType"):
            self.ImageType = params.get("ImageType")
        if params.get("Namespace"):
            self.Namespace = params.get("Namespace")
        if params.get("NamespacePermission"):
            self.NamespacePermission = params.get("NamespacePermission")
        if params.get("ImageRepo"):
            self.ImageRepo = params.get("ImageRepo")
        if params.get("ImageVersion"):
            self.ImageVersion = params.get("ImageVersion")
        if params.get("OfficialInstance"):
            self.OfficialInstance = params.get("OfficialInstance")
        if params.get("UserName"):
            self.UserName = params.get("UserName")
        if params.get("Password"):
            self.Password = params.get("Password")
        if params.get("ImagePermission"):
            self.ImagePermission = params.get("ImagePermission")
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("ImageDomain"):
            self.ImageDomain = params.get("ImageDomain")


class ModifyNotebookRequest(AbstractModel):
    """ModifyNotebook请求参数结构体
    """

    def __init__(self):
        r"""修改开发任务
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param NotebookName: 开发任务名称
        :type PathPrefix: String
        :param Description: 描述信息
        :type PathPrefix: String
        :param ImageId: 镜像ID
        :type PathPrefix: String
        :param QueueName: 队列名称
        :type PathPrefix: String
        :param GPUType: GPU类型
        :type PathPrefix: String
        :param GPUNumber: GPU卡数，允许范围为0~10000
        :type PathPrefix: String
        :param CPUNum: CPU核数，允许范围为0~10000
        :type PathPrefix: Int
        :param Memory: 内存Gi，允许范围为0~10000	
        :type PathPrefix: Int
        :param AccessType: 可见范围:
• Creator ：个人私有
• QueueMember ：队列内共享

        :type PathPrefix: String
        :param EnablePublicNetworkSsh: 是否开启公网SSH访问模式，当EnableSsh=true时可设置该参数
        :type PathPrefix: Boolean
        :param SshAuthorizedKeys: SSH公钥，当EnableSsh=true时必传该参数
        :type PathPrefix: String
        :param StorageConfigs: 存储配置列表
（覆盖修改，需要传入全量的配置列表）
        :type PathPrefix: Array
        :param ServiceConfigs: 服务开放端口列表
        :type PathPrefix: Array
        :param AutoSave: 自动保存镜像。当值为true时，开发任务停止前会执行自动保存镜像。
        :type PathPrefix: Boolean
        :param RunOnCPU: 仅调度CPU
        :type PathPrefix: String
        :param EnableSSH: 是否开启SSH访问
        :type PathPrefix: String
        :param SSHPort: SSH端口，范围为1~65535
        :type PathPrefix: Int
        :param SSHAuthorizedKeys: SSH公钥，当EnableSsh=true时必传该参数
        :type PathPrefix: String
        :param EnablePublicNetworkSSH: 是否开启公网SSH访问模式，当EnableSsh=true时可设置该参数
        :type PathPrefix: Boolean
        :param AllocationId: 弹性IP ID，当EnablePublicNetworkSsh=true时，此参数必传
        :type PathPrefix: String
        :param ImageTagId: 第三方镜像版本ID
        :type PathPrefix: String
        :param ImageSource: 镜像来源，当改变镜像来源时，需传入该值。
- Official 官方镜像
- Personal 自定义镜像
- ThirdParty 第三方镜像

当修改镜像类型为第三方镜像时，需同时传入"ImageRegistryId", "ImageRepoId", "ImageTagId"三个入参

        :type PathPrefix: String
        :param ImageRepoId: 第三方镜像仓库ID
        :type PathPrefix: String
        :param ImageRegistryId: 第三方镜像配置ID
        :type PathPrefix: String
        :param AutoSaveConfig: 自动保存镜像配置
        :type PathPrefix: Object
        :param Envs: 环境变量列表（全量替换）
        :type PathPrefix: Array
        """
        self.NotebookId = None
        self.NotebookName = None
        self.Description = None
        self.ImageId = None
        self.QueueName = None
        self.GPUType = None
        self.GPUNumber = None
        self.CPUNum = None
        self.Memory = None
        self.AccessType = None
        self.EnablePublicNetworkSsh = None
        self.SshAuthorizedKeys = None
        self.StorageConfigs = None
        self.ServiceConfigs = None
        self.AutoSave = None
        self.RunOnCPU = None
        self.EnableSSH = None
        self.SSHPort = None
        self.SSHAuthorizedKeys = None
        self.EnablePublicNetworkSSH = None
        self.AllocationId = None
        self.ImageTagId = None
        self.ImageSource = None
        self.ImageRepoId = None
        self.ImageRegistryId = None
        self.AutoSaveConfig = None
        self.Envs = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("NotebookName"):
            self.NotebookName = params.get("NotebookName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("QueueName"):
            self.QueueName = params.get("QueueName")
        if params.get("GPUType"):
            self.GPUType = params.get("GPUType")
        if params.get("GPUNumber"):
            self.GPUNumber = params.get("GPUNumber")
        if params.get("CPUNum"):
            self.CPUNum = params.get("CPUNum")
        if params.get("Memory"):
            self.Memory = params.get("Memory")
        if params.get("AccessType"):
            self.AccessType = params.get("AccessType")
        if params.get("EnablePublicNetworkSsh"):
            self.EnablePublicNetworkSsh = params.get("EnablePublicNetworkSsh")
        if params.get("SshAuthorizedKeys"):
            self.SshAuthorizedKeys = params.get("SshAuthorizedKeys")
        if params.get("StorageConfigs"):
            self.StorageConfigs = params.get("StorageConfigs")
        if params.get("ServiceConfigs"):
            self.ServiceConfigs = params.get("ServiceConfigs")
        if params.get("AutoSave"):
            self.AutoSave = params.get("AutoSave")
        if params.get("RunOnCPU"):
            self.RunOnCPU = params.get("RunOnCPU")
        if params.get("EnableSSH"):
            self.EnableSSH = params.get("EnableSSH")
        if params.get("SSHPort"):
            self.SSHPort = params.get("SSHPort")
        if params.get("SSHAuthorizedKeys"):
            self.SSHAuthorizedKeys = params.get("SSHAuthorizedKeys")
        if params.get("EnablePublicNetworkSSH"):
            self.EnablePublicNetworkSSH = params.get("EnablePublicNetworkSSH")
        if params.get("AllocationId"):
            self.AllocationId = params.get("AllocationId")
        if params.get("ImageTagId"):
            self.ImageTagId = params.get("ImageTagId")
        if params.get("ImageSource"):
            self.ImageSource = params.get("ImageSource")
        if params.get("ImageRepoId"):
            self.ImageRepoId = params.get("ImageRepoId")
        if params.get("ImageRegistryId"):
            self.ImageRegistryId = params.get("ImageRegistryId")
        if params.get("AutoSaveConfig"):
            self.AutoSaveConfig = params.get("AutoSaveConfig")
        if params.get("Envs"):
            self.Envs = params.get("Envs")


class DeleteNotebookRequest(AbstractModel):
    """DeleteNotebook请求参数结构体
    """

    def __init__(self):
        r"""删除开发任务
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param VolumeReclaimPolicy: 云盘回收策略，有效值：delete、reclaim（保留）
        :type PathPrefix: String
        """
        self.NotebookId = None
        self.VolumeReclaimPolicy = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("VolumeReclaimPolicy"):
            self.VolumeReclaimPolicy = params.get("VolumeReclaimPolicy")


class DescribeNotebooksRequest(AbstractModel):
    """DescribeNotebooks请求参数结构体
    """

    def __init__(self):
        r"""查询开发任务
        :param NotebookId: 多个开发任务的ID
        :type PathPrefix: Filter
        :param Name: 开发任务名称
        :type PathPrefix: String
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param Filter: 条件过滤
        :type PathPrefix: Filter
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param EnableVolume: 是否支持挂载云盘
        :type PathPrefix: Boolean
        """
        self.NotebookId = None
        self.Name = None
        self.Page = None
        self.PageSize = None
        self.Filter = None
        self.QueueId = None
        self.EnableVolume = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("EnableVolume"):
            self.EnableVolume = params.get("EnableVolume")


class CreateNotebookRequest(AbstractModel):
    """CreateNotebook请求参数结构体
    """

    def __init__(self):
        r"""创建开发任务
        :param NotebookName: 开发任务名称
        :type PathPrefix: String
        :param Description: 描述信息
        :type PathPrefix: String
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param QueueName: 队列名称
        :type PathPrefix: String
        :param GPUType: GPU类型
        :type PathPrefix: String
        :param GPUNumber: GPU卡数，当GPUType不为空时，此值有效且必传，允许范围为0~10000, 如果可虚拟化，支持[0.1,0.9]
        :type PathPrefix: String
        :param CPUNum: CPU核数，允许范围为0~10000
        :type PathPrefix: Int
        :param Memory: 内存Gi，允许范围为0~10000
        :type PathPrefix: Int
        :param AccessType: 可见范围，Creator(个人私有)，QueueMember（队列内共享）
        :type PathPrefix: String
        :param StorageConfigs: 存储配置列表
        :type PathPrefix: Array
        :param AutoSave: 自动保存镜像。当值为true时，开发任务停止前会执行自动保存镜像
        :type PathPrefix: Boolean
        :param ServiceConfigs: 自定义服务配置
        :type PathPrefix: Array
        :param ImageSource: 镜像来源
- 官方镜像 Official
- 自定义镜像 Personal
- 第三方镜像 ThirdParty

当传入值为ThirdParty时，"ImageRegistryId", "ImageRepoId", "ImageTagId"必须传入
        :type PathPrefix: String
        :param ImageId: 镜像ID
当镜像来源为第三方来源时，此参数不传递，其他镜像来源，此参数为必填项
        :type PathPrefix: String
        :param ImageRegistryId: 第三方镜像配置ID
        :type PathPrefix: String
        :param ImageRepoId: 第三方镜像仓库ID
        :type PathPrefix: String
        :param ImageTagId: 第三方镜像版本ID
        :type PathPrefix: String
        :param EnableSSH: 是否开启SSH
        :type PathPrefix: Boolean
        :param SSHAuthorizedKeys: SSH公钥，当EnableSsh=true时必传该参数
        :type PathPrefix: String
        :param SSHPort: SSH端口，默认为22，范围为1~65535
        :type PathPrefix: Int
        :param EnablePublicNetworkSSH: 是否开启公网SSH访问模式，当EnableSsh=true时可设置该参数
        :type PathPrefix: Boolean
        :param AllocationId: 弹性IP ID，当EnablePublicNetworkSsh=true时，此参数必传
        :type PathPrefix: String
        :param RunOnCPU: 仅调度到CPU节点。当GPUNumber为空或值为0时此值有效
        :type PathPrefix: String
        :param AutoSaveConfig: 自动保存镜像配置
        :type PathPrefix: Object
        :param EnableVolume: 是否挂载云盘
        :type PathPrefix: Boolean
        :param VolumeConfig: 云盘配置，当EnableVolume=true时必传
        :type PathPrefix: Object
        :param Envs: 环境变量列表
        :type PathPrefix: Array
        """
        self.NotebookName = None
        self.Description = None
        self.ResourcePoolId = None
        self.QueueName = None
        self.GPUType = None
        self.GPUNumber = None
        self.CPUNum = None
        self.Memory = None
        self.AccessType = None
        self.StorageConfigs = None
        self.AutoSave = None
        self.ServiceConfigs = None
        self.ImageSource = None
        self.ImageId = None
        self.ImageRegistryId = None
        self.ImageRepoId = None
        self.ImageTagId = None
        self.EnableSSH = None
        self.SSHAuthorizedKeys = None
        self.SSHPort = None
        self.EnablePublicNetworkSSH = None
        self.AllocationId = None
        self.RunOnCPU = None
        self.AutoSaveConfig = None
        self.EnableVolume = None
        self.VolumeConfig = None
        self.Envs = None

    def _deserialize(self, params):
        if params.get("NotebookName"):
            self.NotebookName = params.get("NotebookName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("QueueName"):
            self.QueueName = params.get("QueueName")
        if params.get("GPUType"):
            self.GPUType = params.get("GPUType")
        if params.get("GPUNumber"):
            self.GPUNumber = params.get("GPUNumber")
        if params.get("CPUNum"):
            self.CPUNum = params.get("CPUNum")
        if params.get("Memory"):
            self.Memory = params.get("Memory")
        if params.get("AccessType"):
            self.AccessType = params.get("AccessType")
        if params.get("StorageConfigs"):
            self.StorageConfigs = params.get("StorageConfigs")
        if params.get("AutoSave"):
            self.AutoSave = params.get("AutoSave")
        if params.get("ServiceConfigs"):
            self.ServiceConfigs = params.get("ServiceConfigs")
        if params.get("ImageSource"):
            self.ImageSource = params.get("ImageSource")
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("ImageRegistryId"):
            self.ImageRegistryId = params.get("ImageRegistryId")
        if params.get("ImageRepoId"):
            self.ImageRepoId = params.get("ImageRepoId")
        if params.get("ImageTagId"):
            self.ImageTagId = params.get("ImageTagId")
        if params.get("EnableSSH"):
            self.EnableSSH = params.get("EnableSSH")
        if params.get("SSHAuthorizedKeys"):
            self.SSHAuthorizedKeys = params.get("SSHAuthorizedKeys")
        if params.get("SSHPort"):
            self.SSHPort = params.get("SSHPort")
        if params.get("EnablePublicNetworkSSH"):
            self.EnablePublicNetworkSSH = params.get("EnablePublicNetworkSSH")
        if params.get("AllocationId"):
            self.AllocationId = params.get("AllocationId")
        if params.get("RunOnCPU"):
            self.RunOnCPU = params.get("RunOnCPU")
        if params.get("AutoSaveConfig"):
            self.AutoSaveConfig = params.get("AutoSaveConfig")
        if params.get("EnableVolume"):
            self.EnableVolume = params.get("EnableVolume")
        if params.get("VolumeConfig"):
            self.VolumeConfig = params.get("VolumeConfig")
        if params.get("Envs"):
            self.Envs = params.get("Envs")


class EnableKlogRequest(AbstractModel):
    """EnableKlog请求参数结构体
    """

    def __init__(self):
        r"""开启或者关闭klog服务
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param EnableKlog: 是否开启klog
        :type PathPrefix: Boolean
        :param LogProjectName: 日志工程名
        :type PathPrefix: String
        """
        self.ResourcePoolId = None
        self.EnableKlog = None
        self.LogProjectName = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("EnableKlog"):
            self.EnableKlog = params.get("EnableKlog")
        if params.get("LogProjectName"):
            self.LogProjectName = params.get("LogProjectName")


class CreateImageRequest(AbstractModel):
    """CreateImage请求参数结构体
    """

    def __init__(self):
        r"""新建自定义镜像
        :param ImageName: 自定义镜像名称
        :type PathPrefix: String
        :param Description: 描述信息
        :type PathPrefix: String
        :param ImageType: 镜像类型
        :type PathPrefix: String
        :param Namespace: 命名空间
        :type PathPrefix: String
        :param NamespacePermission: 命名空间权限
        :type PathPrefix: String
        :param ImageRepo: 镜像仓库
        :type PathPrefix: String
        :param ImageVersion: 镜像版本
        :type PathPrefix: String
        :param OfficialInstance: 企业镜像实例，当ImageType=Official不能为空
        :type PathPrefix: String
        :param UserName: 用户名，当ImageType=Official不能为空
        :type PathPrefix: String
        :param Password: 密码，当ImageType=Official不能为空
        :type PathPrefix: String
        :param ImagePermission: 镜像权限，枚举值：
- Public，公开可见
- Private，仅自己可见
- Specified，指定范围
        :type PathPrefix: String
        :param AccessList: 用户权限列表
        :type PathPrefix: Array
        :param SharedGroupList: 权限组共享列表
        :type PathPrefix: Array
        """
        self.ImageName = None
        self.Description = None
        self.ImageType = None
        self.Namespace = None
        self.NamespacePermission = None
        self.ImageRepo = None
        self.ImageVersion = None
        self.OfficialInstance = None
        self.UserName = None
        self.Password = None
        self.ImagePermission = None
        self.AccessList = None
        self.SharedGroupList = None

    def _deserialize(self, params):
        if params.get("ImageName"):
            self.ImageName = params.get("ImageName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ImageType"):
            self.ImageType = params.get("ImageType")
        if params.get("Namespace"):
            self.Namespace = params.get("Namespace")
        if params.get("NamespacePermission"):
            self.NamespacePermission = params.get("NamespacePermission")
        if params.get("ImageRepo"):
            self.ImageRepo = params.get("ImageRepo")
        if params.get("ImageVersion"):
            self.ImageVersion = params.get("ImageVersion")
        if params.get("OfficialInstance"):
            self.OfficialInstance = params.get("OfficialInstance")
        if params.get("UserName"):
            self.UserName = params.get("UserName")
        if params.get("Password"):
            self.Password = params.get("Password")
        if params.get("ImagePermission"):
            self.ImagePermission = params.get("ImagePermission")
        if params.get("AccessList"):
            self.AccessList = params.get("AccessList")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")


class DeleteImageRequest(AbstractModel):
    """DeleteImage请求参数结构体
    """

    def __init__(self):
        r"""删除自定义镜像
        :param ImageId: 自定义镜像ID
        :type PathPrefix: String
        """
        self.ImageId = None

    def _deserialize(self, params):
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")


class ModifyImageRequest(AbstractModel):
    """ModifyImage请求参数结构体
    """

    def __init__(self):
        r"""修改自定义镜像
        :param ImageId: 自定义镜像ID
        :type PathPrefix: String
        :param ImageName: 镜像名称
        :type PathPrefix: String
        :param ImagePermission: 镜像权限，枚举值：
- Public，公开可见
- Private，仅自己可见
- Specified，指定范围。不传表示不修改
        :type PathPrefix: String
        :param AccessList: 用户权限列表（若传入，会进行全量覆盖式修改）
        :type PathPrefix: Array
        :param SharedGroupList: 权限组共享列表（若传入，会进行全量覆盖式修改）
        :type PathPrefix: Array
        """
        self.ImageId = None
        self.ImageName = None
        self.ImagePermission = None
        self.AccessList = None
        self.SharedGroupList = None

    def _deserialize(self, params):
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("ImageName"):
            self.ImageName = params.get("ImageName")
        if params.get("ImagePermission"):
            self.ImagePermission = params.get("ImagePermission")
        if params.get("AccessList"):
            self.AccessList = params.get("AccessList")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")


class DescribeImagesRequest(AbstractModel):
    """DescribeImages请求参数结构体
    """

    def __init__(self):
        r"""查询镜像列表
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param ImageSource: 镜像来源
        :type PathPrefix: String
        :param ImageStatus: 镜像状态
        :type PathPrefix: String
        :param ImageType: 镜像类型
        :type PathPrefix: String
        :param ApplicationScenario: 适用场景
        :type PathPrefix: String
        :param ImageId: 镜像ID
        :type PathPrefix: Filter
        :param ImageName: 镜像名称
        :type PathPrefix: String
        :param Filter: 筛选Filter
        :type PathPrefix: Filter
        """
        self.Page = None
        self.PageSize = None
        self.ImageSource = None
        self.ImageStatus = None
        self.ImageType = None
        self.ApplicationScenario = None
        self.ImageId = None
        self.ImageName = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("ImageSource"):
            self.ImageSource = params.get("ImageSource")
        if params.get("ImageStatus"):
            self.ImageStatus = params.get("ImageStatus")
        if params.get("ImageType"):
            self.ImageType = params.get("ImageType")
        if params.get("ApplicationScenario"):
            self.ApplicationScenario = params.get("ApplicationScenario")
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("ImageName"):
            self.ImageName = params.get("ImageName")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class CreateInferenceRequest(AbstractModel):
    """CreateInference请求参数结构体
    """

    def __init__(self):
        r"""创建推理服务
        :param InferenceName: 推理服务名称
名称仅支持字母、中文、数字、下划线_、中划线-、小数点.、斜杠/、括号()，长度最大64
        :type PathPrefix: String
        :param Description: 描述
限制字符数 0-200
        :type PathPrefix: String
        :param ResourcePoolId: 资源池ID
        :type PathPrefix: String
        :param QueueName: 队列名称
        :type PathPrefix: String
        :param Replicas: 副本数
默认1 ，取值范围1-500
        :type PathPrefix: Int
        :param AccessType: 任务可见性
-  Creator (创建人)
-  QueueMember （队列成员）
        :type PathPrefix: String
        :param DeploymentType: 部署类型
> • 自定义部署需要镜像相关参数
• 模型部署需要模型相关参数

• Custom（自定义部署）
• Predefine（模型部署）

        :type PathPrefix: String
        :param Engine: 模型推理引擎

> 部署类型为 模型部署 时，必填
- vLLM
- SGLang
        :type PathPrefix: String
        :param ModelName: 模型名称 
> 部署类型为 模型部署 时，必填
（通过接口GetInferenceModels获取模型信息）
        :type PathPrefix: String
        :param CmdOptions: 模型部署启动参数
> 仅为模型部署时，此参数才生效
        :type PathPrefix: Array
        :param ModelStorageEnabled: 模型预加载
> 模型部署参数，当开启预加载时，需填入 ModelStoragePath 模型预加载路径
        :type PathPrefix: Boolean
        :param ModelStoragePath: 模型预加载路径
> 开启模型预加载时，必填
        :type PathPrefix: String
        :param EntryPoint: 服务启动命令
> 自定义部署时，需传入此参数
        :type PathPrefix: String
        :param ImageSource: 镜像类型
> 自定义部署参数,仅自定义部署时生效且**必填**

• Personal 自定义镜像
• Official 官方镜像
• ThirdParty 第三方镜像
        :type PathPrefix: String
        :param ImageId: 镜像Id
> 自定义部署参数，仅自定义部署时生效

当ImageSource（镜像类型）为Personal（自定义镜像）和Official（官方镜像）时必填。
        :type PathPrefix: String
        :param ImageRegistryId: 仓库连接 Id
> 自定义部署参数，仅自定义部署时有效。

当ImageSource（镜像类型）为ThirdParty（第三方镜像）时，此值有效且必填。
        :type PathPrefix: String
        :param ImageRepoId: 第三方镜像仓库Id
> 自定义部署参数，仅自定义部署有效

当ImageSource（镜像类型）为ThirdParty（第三方镜像）时，此值有效且必填。
        :type PathPrefix: String
        :param ImageTagId: 第三方镜像tagId
> 自定义部署参数，仅自定义部署时有效

当ImageSource（镜像类型）为ThirdParty（第三方镜像）时，此值有效且必填
        :type PathPrefix: String
        :param SubnetId: 子网ID
        :type PathPrefix: String
        :param Port: 端口
        :type PathPrefix: Int
        :param Env: 环境变量
        :type PathPrefix: Array
        :param GPUType: GPU卡类型
> 不填代表不使用GPU卡
        :type PathPrefix: String
        :param GPUNum: Gpu卡数
> 取值范围： 0-8
        :type PathPrefix: String
        :param CPUNum: CPU数
> 取值范围 1- 1000
        :type PathPrefix: Int
        :param Memory: 内存大小
> 取值范围 ： 1-1000
单位：Gi
        :type PathPrefix: Int
        :param AutoScaleEnable: 开启自动扩缩容
        :type PathPrefix: Boolean
        :param AutoScaleStrategy: 自动扩缩容配置
> 自动扩缩容开启时，需传入此配置
        :type PathPrefix: Object
        :param RunOnCPU: 仅运行在CPU节点
        :type PathPrefix: Boolean
        :param Distributed: 是否支持多机部署
        :type PathPrefix: Boolean
        :param NodeNum: 支持多机部署的节点数
> 模型部署参数，仅模型部署时值有效

Distributed（多机部署）为true时，有效且必填
        :type PathPrefix: Boolean
        :param StorageConfigs: 存储配置
> 自定义部署时，必须传Model模型存储配置
        :type PathPrefix: Array
        """
        self.InferenceName = None
        self.Description = None
        self.ResourcePoolId = None
        self.QueueName = None
        self.Replicas = None
        self.AccessType = None
        self.DeploymentType = None
        self.Engine = None
        self.ModelName = None
        self.CmdOptions = None
        self.ModelStorageEnabled = None
        self.ModelStoragePath = None
        self.EntryPoint = None
        self.ImageSource = None
        self.ImageId = None
        self.ImageRegistryId = None
        self.ImageRepoId = None
        self.ImageTagId = None
        self.SubnetId = None
        self.Port = None
        self.Env = None
        self.GPUType = None
        self.GPUNum = None
        self.CPUNum = None
        self.Memory = None
        self.AutoScaleEnable = None
        self.AutoScaleStrategy = None
        self.RunOnCPU = None
        self.Distributed = None
        self.NodeNum = None
        self.StorageConfigs = None

    def _deserialize(self, params):
        if params.get("InferenceName"):
            self.InferenceName = params.get("InferenceName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("QueueName"):
            self.QueueName = params.get("QueueName")
        if params.get("Replicas"):
            self.Replicas = params.get("Replicas")
        if params.get("AccessType"):
            self.AccessType = params.get("AccessType")
        if params.get("DeploymentType"):
            self.DeploymentType = params.get("DeploymentType")
        if params.get("Engine"):
            self.Engine = params.get("Engine")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("CmdOptions"):
            self.CmdOptions = params.get("CmdOptions")
        if params.get("ModelStorageEnabled"):
            self.ModelStorageEnabled = params.get("ModelStorageEnabled")
        if params.get("ModelStoragePath"):
            self.ModelStoragePath = params.get("ModelStoragePath")
        if params.get("EntryPoint"):
            self.EntryPoint = params.get("EntryPoint")
        if params.get("ImageSource"):
            self.ImageSource = params.get("ImageSource")
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("ImageRegistryId"):
            self.ImageRegistryId = params.get("ImageRegistryId")
        if params.get("ImageRepoId"):
            self.ImageRepoId = params.get("ImageRepoId")
        if params.get("ImageTagId"):
            self.ImageTagId = params.get("ImageTagId")
        if params.get("SubnetId"):
            self.SubnetId = params.get("SubnetId")
        if params.get("Port"):
            self.Port = params.get("Port")
        if params.get("Env"):
            self.Env = params.get("Env")
        if params.get("GPUType"):
            self.GPUType = params.get("GPUType")
        if params.get("GPUNum"):
            self.GPUNum = params.get("GPUNum")
        if params.get("CPUNum"):
            self.CPUNum = params.get("CPUNum")
        if params.get("Memory"):
            self.Memory = params.get("Memory")
        if params.get("AutoScaleEnable"):
            self.AutoScaleEnable = params.get("AutoScaleEnable")
        if params.get("AutoScaleStrategy"):
            self.AutoScaleStrategy = params.get("AutoScaleStrategy")
        if params.get("RunOnCPU"):
            self.RunOnCPU = params.get("RunOnCPU")
        if params.get("Distributed"):
            self.Distributed = params.get("Distributed")
        if params.get("NodeNum"):
            self.NodeNum = params.get("NodeNum")
        if params.get("StorageConfigs"):
            self.StorageConfigs = params.get("StorageConfigs")


class GetInferenceModelsRequest(AbstractModel):
    """GetInferenceModels请求参数结构体
    """

    def __init__(self):
        r"""获取预定义模型列表
        """

    def _deserialize(self, params):
        return


class GetInferenceLogsRequest(AbstractModel):
    """GetInferenceLogs请求参数结构体
    """

    def __init__(self):
        r"""查询推理服务日志
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        :param PodName: Pod名称
        :type PathPrefix: String
        :param SinceSeconds: 返回从指定时间（秒）开始的日志
        :type PathPrefix: Int
        :param TailLines: 返回日志的最后几行
        :type PathPrefix: Int
        """
        self.InferenceId = None
        self.PodName = None
        self.SinceSeconds = None
        self.TailLines = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("PodName"):
            self.PodName = params.get("PodName")
        if params.get("SinceSeconds"):
            self.SinceSeconds = params.get("SinceSeconds")
        if params.get("TailLines"):
            self.TailLines = params.get("TailLines")


class StopNotebookRequest(AbstractModel):
    """StopNotebook请求参数结构体
    """

    def __init__(self):
        r"""停止开发任务
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        """
        self.NotebookId = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")


class StartNotebookRequest(AbstractModel):
    """StartNotebook请求参数结构体
    """

    def __init__(self):
        r"""启动开发任务
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        """
        self.NotebookId = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")


class GetWebIdeUrlRequest(AbstractModel):
    """GetWebIdeUrl请求参数结构体
    """

    def __init__(self):
        r"""获取开发任务连接地址
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param ExpirationMinute: 过期时间（分钟），默认时间是720分钟
        :type PathPrefix: String
        """
        self.NotebookId = None
        self.ExpirationMinute = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("ExpirationMinute"):
            self.ExpirationMinute = params.get("ExpirationMinute")


class DescribeNotebookEventsRequest(AbstractModel):
    """DescribeNotebookEvents请求参数结构体
    """

    def __init__(self):
        r"""查询开发任务事件列表
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param Sort: 排序字段，默认DESC
- DESC 倒序
- ASC 正序
        :type PathPrefix: String
        :param SortKey: 排序字段，默认 LastSeen
- LastSeen 最后出现时间
- FirstSeen 首次出现时间
        :type PathPrefix: String
        """
        self.NotebookId = None
        self.Sort = None
        self.SortKey = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("Sort"):
            self.Sort = params.get("Sort")
        if params.get("SortKey"):
            self.SortKey = params.get("SortKey")


class DescribeNotebookLogRequest(AbstractModel):
    """DescribeNotebookLog请求参数结构体
    """

    def __init__(self):
        r"""查看开发机的pod日志
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        :param SinceSeconds: 日志默认显示时间，单位秒；比如10分钟内的，值为600
        :type PathPrefix: Int
        :param TailLines: 日志显示行数，比如显示30行，值为30
        :type PathPrefix: String
        """
        self.NotebookId = None
        self.SinceSeconds = None
        self.TailLines = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")
        if params.get("SinceSeconds"):
            self.SinceSeconds = params.get("SinceSeconds")
        if params.get("TailLines"):
            self.TailLines = params.get("TailLines")


class ModifyComponentsRequest(AbstractModel):
    """ModifyComponents请求参数结构体
    """

    def __init__(self):
        r"""修改资源池控件
        :param ResourcePoolId: 	
资源池ID
        :type PathPrefix: String
        :param Components: 安装组件列表
        :type PathPrefix: Array
        """
        self.ResourcePoolId = None
        self.Components = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("Components"):
            self.Components = params.get("Components")


class GetInferenceAutoScaleStrategyRequest(AbstractModel):
    """GetInferenceAutoScaleStrategy请求参数结构体
    """

    def __init__(self):
        r"""获取推理服务自动扩缩容规则
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        """
        self.InferenceId = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")


class ModifyTerminatePolicyRequest(AbstractModel):
    """ModifyTerminatePolicy请求参数结构体
    """

    def __init__(self):
        r"""修改队列关停策略
        :param Name: 名称。若不传入则保持原值
        :type PathPrefix: String
        :param InstanceIds: 资源ID列表，当 TerminatePolicyType = WhiteList时，可传。若不传入则保持原值，传入则覆盖式修改
        :type PathPrefix: Array
        :param UseRatePolicy: 资源利用率配置，TerminatePolicyType = ResourceUseRate 可传
        :type PathPrefix: Object
        :param TerminatePolicyId: 关停策略ID
        :type PathPrefix: String
        """
        self.Name = None
        self.InstanceIds = None
        self.UseRatePolicy = None
        self.TerminatePolicyId = None

    def _deserialize(self, params):
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("InstanceIds"):
            self.InstanceIds = params.get("InstanceIds")
        if params.get("UseRatePolicy"):
            self.UseRatePolicy = params.get("UseRatePolicy")
        if params.get("TerminatePolicyId"):
            self.TerminatePolicyId = params.get("TerminatePolicyId")


class DescribeTerminatePolicyRequest(AbstractModel):
    """DescribeTerminatePolicy请求参数结构体
    """

    def __init__(self):
        r"""查询队列关停策略
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param TerminatePolicyId: 关停策略ID
        :type PathPrefix: Filter
        :param CreateUser: 创建者ID
        :type PathPrefix: String
        :param Filter: 过滤器
        :type PathPrefix: Filter
        :param PageSize: 单页查询数
        :type PathPrefix: Int
        :param Page: 页数
        :type PathPrefix: Int
        """
        self.QueueId = None
        self.TerminatePolicyId = None
        self.CreateUser = None
        self.Filter = None
        self.PageSize = None
        self.Page = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("TerminatePolicyId"):
            self.TerminatePolicyId = params.get("TerminatePolicyId")
        if params.get("CreateUser"):
            self.CreateUser = params.get("CreateUser")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Page"):
            self.Page = params.get("Page")


class CreateTerminatePolicyRequest(AbstractModel):
    """CreateTerminatePolicy请求参数结构体
    """

    def __init__(self):
        r"""创建队列关停策略
        :param Name: 名称
        :type PathPrefix: String
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param TerminatePolicyType: 关停策略类型
	- ResourceUseRate 资源使用率
	- WhiteList 白名单

        :type PathPrefix: String
        :param TerminatePolicyTarget: 策略对象
	- Notebook 开发任务
        :type PathPrefix: String
        :param InstanceIds: 资源ID列表，当 TerminatePolicyType = WhiteList时，可为空
        :type PathPrefix: Array
        :param UseRatePolicy: 资源利用率配置，TerminatePolicyType = ResourceUseRate 必传
        :type PathPrefix: Object
        """
        self.Name = None
        self.QueueId = None
        self.TerminatePolicyType = None
        self.TerminatePolicyTarget = None
        self.InstanceIds = None
        self.UseRatePolicy = None

    def _deserialize(self, params):
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("TerminatePolicyType"):
            self.TerminatePolicyType = params.get("TerminatePolicyType")
        if params.get("TerminatePolicyTarget"):
            self.TerminatePolicyTarget = params.get("TerminatePolicyTarget")
        if params.get("InstanceIds"):
            self.InstanceIds = params.get("InstanceIds")
        if params.get("UseRatePolicy"):
            self.UseRatePolicy = params.get("UseRatePolicy")


class DeleteTerminatePolicyRequest(AbstractModel):
    """DeleteTerminatePolicy请求参数结构体
    """

    def __init__(self):
        r"""删除队列关停策略
        :param TerminatePolicyId: 关停策略ID
        :type PathPrefix: String
        """
        self.TerminatePolicyId = None

    def _deserialize(self, params):
        if params.get("TerminatePolicyId"):
            self.TerminatePolicyId = params.get("TerminatePolicyId")


class StopNotebookSavingImageRequest(AbstractModel):
    """StopNotebookSavingImage请求参数结构体
    """

    def __init__(self):
        r"""终止开发任务镜像保存
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        """
        self.NotebookId = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")


class EnableApikeyStatusRequest(AbstractModel):
    """EnableApikeyStatus请求参数结构体
    """

    def __init__(self):
        r"""启用 API Key
        :param KeyId: API Key的ID
        :type PathPrefix: String
        :param Status: 启禁用状态：1启用，2禁用
        :type PathPrefix: String
        """
        self.KeyId = None
        self.Status = None

    def _deserialize(self, params):
        if params.get("KeyId"):
            self.KeyId = params.get("KeyId")
        if params.get("Status"):
            self.Status = params.get("Status")


class ModifyApikeyRequest(AbstractModel):
    """ModifyApikey请求参数结构体
    """

    def __init__(self):
        r"""编辑API Key
        :param KeyId: 
        :type PathPrefix: String
        :param Name: API Key 名称
        :type PathPrefix: String
        :param Description: API Key 描述
        :type PathPrefix: String
        :param AssociatedModelIds: API Key 关联的模型列表
        :type PathPrefix: Array
        :param AllAssociatedModel: 是否全选
        :type PathPrefix: Boolean
        :param AllowEndpoints: 接入点列表
        :type PathPrefix: Array
        :param AllAssociatedProjectResources: 项目下所有资源全选
        :type PathPrefix: Boolean
        :param AllAssociatedEndpoint: 接入点全选
        :type PathPrefix: Boolean
        :param LowPriceModels: 低价池(标准池)模型名称列表
        :type PathPrefix: Array
        :param HighPriceModels: 高价池模型名称列表
        :type PathPrefix: Array
        :param AllowedIps: IP白名单列表，有值则启用白名单
        :type PathPrefix: Array
        :param ProjectId: 项目制ID
        :type PathPrefix: String
        """
        self.KeyId = None
        self.Name = None
        self.Description = None
        self.AssociatedModelIds = None
        self.AllAssociatedModel = None
        self.AllowEndpoints = None
        self.AllAssociatedProjectResources = None
        self.AllAssociatedEndpoint = None
        self.LowPriceModels = None
        self.HighPriceModels = None
        self.AllowedIps = None
        self.ProjectId = None

    def _deserialize(self, params):
        if params.get("KeyId"):
            self.KeyId = params.get("KeyId")
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("AssociatedModelIds"):
            self.AssociatedModelIds = params.get("AssociatedModelIds")
        if params.get("AllAssociatedModel"):
            self.AllAssociatedModel = params.get("AllAssociatedModel")
        if params.get("AllowEndpoints"):
            self.AllowEndpoints = params.get("AllowEndpoints")
        if params.get("AllAssociatedProjectResources"):
            self.AllAssociatedProjectResources = params.get("AllAssociatedProjectResources")
        if params.get("AllAssociatedEndpoint"):
            self.AllAssociatedEndpoint = params.get("AllAssociatedEndpoint")
        if params.get("LowPriceModels"):
            self.LowPriceModels = params.get("LowPriceModels")
        if params.get("HighPriceModels"):
            self.HighPriceModels = params.get("HighPriceModels")
        if params.get("AllowedIps"):
            self.AllowedIps = params.get("AllowedIps")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")


class ActivateApiServiceRequest(AbstractModel):
    """ActivateApiService请求参数结构体
    """

    def __init__(self):
        r"""开通模型API服务
        :param Status: 状态：1 表示开通服务
        :type PathPrefix: String
        """
        self.Status = None

    def _deserialize(self, params):
        if params.get("Status"):
            self.Status = params.get("Status")


class DeleteApikeyRequest(AbstractModel):
    """DeleteApikey请求参数结构体
    """

    def __init__(self):
        r"""删除API Key
        :param KeyId: KeyId，例如：API-KEY-1158133806039134208
        :type PathPrefix: String
        """
        self.KeyId = None

    def _deserialize(self, params):
        if params.get("KeyId"):
            self.KeyId = params.get("KeyId")


class DescribeModelsRequest(AbstractModel):
    """DescribeModels请求参数结构体
    """

    def __init__(self):
        r"""查询模型列表(支持分页)
        :param Marker: 分页页码，从1开始
        :type PathPrefix: Int
        :param MaxResults: 分页页长，最大100
        :type PathPrefix: Int
        :param ModelCategory: 模型类别筛选项
        :type PathPrefix: Filter
        :param Provider: 模型供应商
        :type PathPrefix: Filter
        :param ContextLength: 模型上下文长度
1 - 128k及以下
2 - 128k到256k
3 - 256k以上
        :type PathPrefix: Filter
        :param ModelName: 模型名称关键词
        :type PathPrefix: String
        :param Capabilities: 模型能力筛选项
        :type PathPrefix: Filter
        :param Status: 模型状态筛选：0-初始化，1-在线，2-下线，3-已废弃，4-灰度在线
        :type PathPrefix: Int
        :param ContextLengthRanges: 模型上下文长度区间筛选 例如:"32-128","256-1024"
        :type PathPrefix: Filter
        """
        self.Marker = None
        self.MaxResults = None
        self.ModelCategory = None
        self.Provider = None
        self.ContextLength = None
        self.ModelName = None
        self.Capabilities = None
        self.Status = None
        self.ContextLengthRanges = None

    def _deserialize(self, params):
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("ModelCategory"):
            self.ModelCategory = params.get("ModelCategory")
        if params.get("Provider"):
            self.Provider = params.get("Provider")
        if params.get("ContextLength"):
            self.ContextLength = params.get("ContextLength")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("Capabilities"):
            self.Capabilities = params.get("Capabilities")
        if params.get("Status"):
            self.Status = params.get("Status")
        if params.get("ContextLengthRanges"):
            self.ContextLengthRanges = params.get("ContextLengthRanges")


class CreateApikeyRequest(AbstractModel):
    """CreateApikey请求参数结构体
    """

    def __init__(self):
        r"""创建API Key
        :param Name: API Key 名称
        :type PathPrefix: String
        :param Description: API Key 描述
        :type PathPrefix: String
        :param ProjectId: 项目ID
        :type PathPrefix: Long
        :param AssociatedModelIds: 关联的模型列表
        :type PathPrefix: Array
        :param AllAssociatedModel: 是否全选
        :type PathPrefix: Boolean
        :param AllowedIps: IP白名单，空数组表示不设置白名单
        :type PathPrefix: Array
        :param AllowEndpoints: 允许的接入点列表
        :type PathPrefix: Array
        :param AllAssociatedEndpoint: 是否全选接入点
        :type PathPrefix: Boolean
        :param AllAssociatedProjectResources: 是否项目下资源全选
        :type PathPrefix: Boolean
        :param LowPriceModels: 低价池(标准池)模型名称列表
        :type PathPrefix: Array
        :param HighPriceModels: 高价池模型名称列表
        :type PathPrefix: Array
        """
        self.Name = None
        self.Description = None
        self.ProjectId = None
        self.AssociatedModelIds = None
        self.AllAssociatedModel = None
        self.AllowedIps = None
        self.AllowEndpoints = None
        self.AllAssociatedEndpoint = None
        self.AllAssociatedProjectResources = None
        self.LowPriceModels = None
        self.HighPriceModels = None

    def _deserialize(self, params):
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")
        if params.get("AssociatedModelIds"):
            self.AssociatedModelIds = params.get("AssociatedModelIds")
        if params.get("AllAssociatedModel"):
            self.AllAssociatedModel = params.get("AllAssociatedModel")
        if params.get("AllowedIps"):
            self.AllowedIps = params.get("AllowedIps")
        if params.get("AllowEndpoints"):
            self.AllowEndpoints = params.get("AllowEndpoints")
        if params.get("AllAssociatedEndpoint"):
            self.AllAssociatedEndpoint = params.get("AllAssociatedEndpoint")
        if params.get("AllAssociatedProjectResources"):
            self.AllAssociatedProjectResources = params.get("AllAssociatedProjectResources")
        if params.get("LowPriceModels"):
            self.LowPriceModels = params.get("LowPriceModels")
        if params.get("HighPriceModels"):
            self.HighPriceModels = params.get("HighPriceModels")


class GetModelDetailRequest(AbstractModel):
    """GetModelDetail请求参数结构体
    """

    def __init__(self):
        r"""查询模型详情
        :param ModelId: 
        :type PathPrefix: String
        """
        self.ModelId = None

    def _deserialize(self, params):
        if params.get("ModelId"):
            self.ModelId = params.get("ModelId")


class DescribeApikeysRequest(AbstractModel):
    """DescribeApikeys请求参数结构体
    """

    def __init__(self):
        r"""查询API Key列表（分页）
        :param Marker: 分页页码，从1开始
        :type PathPrefix: Int
        :param MaxResults: 每页条数，最多100
        :type PathPrefix: Int
        :param AssociatedModelId: 通过模型查关联的API Key
        :type PathPrefix: Filter
        :param Status: 按状态过滤查询
        :type PathPrefix: Filter
        :param Namekeyword: 名称搜索关键词
        :type PathPrefix: String
        :param DefaultKey: 是否默认只查默认Key
        :type PathPrefix: Boolean
        :param SelfCreated: 是否筛选创建用户
- true 筛选我创建的
- false 不筛选
        :type PathPrefix: Boolean
        :param SortOrder: 排序顺序
- asc 按照创建时间升序排列
- 其他情况 按照创建时间降序排列
        :type PathPrefix: String
        """
        self.Marker = None
        self.MaxResults = None
        self.AssociatedModelId = None
        self.Status = None
        self.Namekeyword = None
        self.DefaultKey = None
        self.SelfCreated = None
        self.SortOrder = None

    def _deserialize(self, params):
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("AssociatedModelId"):
            self.AssociatedModelId = params.get("AssociatedModelId")
        if params.get("Status"):
            self.Status = params.get("Status")
        if params.get("Namekeyword"):
            self.Namekeyword = params.get("Namekeyword")
        if params.get("DefaultKey"):
            self.DefaultKey = params.get("DefaultKey")
        if params.get("SelfCreated"):
            self.SelfCreated = params.get("SelfCreated")
        if params.get("SortOrder"):
            self.SortOrder = params.get("SortOrder")


class QueryTokenDataRequest(AbstractModel):
    """QueryTokenData请求参数结构体
    """

    def __init__(self):
        r"""查询模型API token用量
        :param StartTimestamp: 开始时间，毫秒时间戳
        :type PathPrefix: Long
        :param EndTimestamp: 截止时间，毫秒时间戳
        :type PathPrefix: Long
        :param LastKey: 分页用的游标，表示上次已经获取到的数据，当前请求可以取上次返回结果的LastKey，首页时不传
        :type PathPrefix: String
        :param MaxResults: 分页页长，最大10000
        :type PathPrefix: Int
        :param ModelKeyword: model 搜索关键词
        :type PathPrefix: String
        :param Keyword: 搜索关键词
        :type PathPrefix: String
        :param GroupBy: 分组字段：model、keyId、endpointId
        :type PathPrefix: String
        :param ReasoningType: 推理类型：normal-在线，batch-批量，web-在线体验，为空表示全部。
        :type PathPrefix: String
        :param Marker: 页码，从1开始。
        :type PathPrefix: Int
        :param ModelName: 模型名称
- 当按照模型分组时，Keyword优先，Keyword为空再以该字段筛选
- 当按照APIKEY分组时，该字段始终生效
        :type PathPrefix: String
        :param SortField: 排序字段
InputToken、OutputToken、TotalToken
        :type PathPrefix: String
        :param SortOrder: asc desc
与SortField配合
        :type PathPrefix: String
        :param KeyId: APIKEY ID，响应数据需按APIKEY 筛选时需要
        :type PathPrefix: String
        """
        self.StartTimestamp = None
        self.EndTimestamp = None
        self.LastKey = None
        self.MaxResults = None
        self.ModelKeyword = None
        self.Keyword = None
        self.GroupBy = None
        self.ReasoningType = None
        self.Marker = None
        self.ModelName = None
        self.SortField = None
        self.SortOrder = None
        self.KeyId = None

    def _deserialize(self, params):
        if params.get("StartTimestamp"):
            self.StartTimestamp = params.get("StartTimestamp")
        if params.get("EndTimestamp"):
            self.EndTimestamp = params.get("EndTimestamp")
        if params.get("LastKey"):
            self.LastKey = params.get("LastKey")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("ModelKeyword"):
            self.ModelKeyword = params.get("ModelKeyword")
        if params.get("Keyword"):
            self.Keyword = params.get("Keyword")
        if params.get("GroupBy"):
            self.GroupBy = params.get("GroupBy")
        if params.get("ReasoningType"):
            self.ReasoningType = params.get("ReasoningType")
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("SortField"):
            self.SortField = params.get("SortField")
        if params.get("SortOrder"):
            self.SortOrder = params.get("SortOrder")
        if params.get("KeyId"):
            self.KeyId = params.get("KeyId")


class DisableApikeyStatusRequest(AbstractModel):
    """DisableApikeyStatus请求参数结构体
    """

    def __init__(self):
        r"""禁用API Key
        :param KeyId: API Key的ID
        :type PathPrefix: String
        :param Status: 启禁用状态：1启用，2禁用
        :type PathPrefix: String
        """
        self.KeyId = None
        self.Status = None

    def _deserialize(self, params):
        if params.get("KeyId"):
            self.KeyId = params.get("KeyId")
        if params.get("Status"):
            self.Status = params.get("Status")


class GetApiServiceRequest(AbstractModel):
    """GetApiService请求参数结构体
    """

    def __init__(self):
        r"""查询API服务开通状态
        """

    def _deserialize(self, params):
        return


class GetBatchInferenceJobsFinalResultDownloadUrlRequest(AbstractModel):
    """GetBatchInferenceJobsFinalResultDownloadUrl请求参数结构体
    """

    def __init__(self):
        r"""查询批量推理任务最终结果下载链接
        :param BatchId: 
        :type PathPrefix: String
        """
        self.BatchId = None

    def _deserialize(self, params):
        if params.get("BatchId"):
            self.BatchId = params.get("BatchId")


class DescribeInferenceJobsKs3AuthInfoRequest(AbstractModel):
    """DescribeInferenceJobsKs3AuthInfo请求参数结构体
    """

    def __init__(self):
        r"""查询批量推理任务Ks3鉴权信息
        """

    def _deserialize(self, params):
        return


class StopBatchInferenceJobRequest(AbstractModel):
    """StopBatchInferenceJob请求参数结构体
    """

    def __init__(self):
        r"""终止批量推理任务
        :param BatchId: 
        :type PathPrefix: String
        """
        self.BatchId = None

    def _deserialize(self, params):
        if params.get("BatchId"):
            self.BatchId = params.get("BatchId")


class CreateBatchInferenceJobRequest(AbstractModel):
    """CreateBatchInferenceJob请求参数结构体
    """

    def __init__(self):
        r"""创建批量推理任务
        :param JobName: 
        :type PathPrefix: String
        :param JobDesc: 
        :type PathPrefix: String
        :param ApikeyId: 
        :type PathPrefix: String
        :param Model: 模型名，如：deepseek-r1-0528
        :type PathPrefix: String
        :param ExecuteTimeoutMs: 
        :type PathPrefix: Long
        :param InputDataType: 文件类型：user_ks3 用户ks3;upload_ks3 上传文件
        :type PathPrefix: String
        :param Ks3Region: 
        :type PathPrefix: String
        :param Ks3Ak: 
        :type PathPrefix: String
        :param Ks3Sk: 
        :type PathPrefix: String
        :param InBucket: 
        :type PathPrefix: String
        :param OutBucket: 
        :type PathPrefix: String
        :param InObjectName: 
        :type PathPrefix: String
        :param OutObjectName: 
        :type PathPrefix: String
        """
        self.JobName = None
        self.JobDesc = None
        self.ApikeyId = None
        self.Model = None
        self.ExecuteTimeoutMs = None
        self.InputDataType = None
        self.Ks3Region = None
        self.Ks3Ak = None
        self.Ks3Sk = None
        self.InBucket = None
        self.OutBucket = None
        self.InObjectName = None
        self.OutObjectName = None

    def _deserialize(self, params):
        if params.get("JobName"):
            self.JobName = params.get("JobName")
        if params.get("JobDesc"):
            self.JobDesc = params.get("JobDesc")
        if params.get("ApikeyId"):
            self.ApikeyId = params.get("ApikeyId")
        if params.get("Model"):
            self.Model = params.get("Model")
        if params.get("ExecuteTimeoutMs"):
            self.ExecuteTimeoutMs = params.get("ExecuteTimeoutMs")
        if params.get("InputDataType"):
            self.InputDataType = params.get("InputDataType")
        if params.get("Ks3Region"):
            self.Ks3Region = params.get("Ks3Region")
        if params.get("Ks3Ak"):
            self.Ks3Ak = params.get("Ks3Ak")
        if params.get("Ks3Sk"):
            self.Ks3Sk = params.get("Ks3Sk")
        if params.get("InBucket"):
            self.InBucket = params.get("InBucket")
        if params.get("OutBucket"):
            self.OutBucket = params.get("OutBucket")
        if params.get("InObjectName"):
            self.InObjectName = params.get("InObjectName")
        if params.get("OutObjectName"):
            self.OutObjectName = params.get("OutObjectName")


class ModifyBatchInferenceJobRequest(AbstractModel):
    """ModifyBatchInferenceJob请求参数结构体
    """

    def __init__(self):
        r"""更新批量推理任务（修改jobName和jobDesc）
        :param BatchId: 
        :type PathPrefix: String
        :param JobName: 
        :type PathPrefix: String
        :param JobDesc: 
        :type PathPrefix: String
        """
        self.BatchId = None
        self.JobName = None
        self.JobDesc = None

    def _deserialize(self, params):
        if params.get("BatchId"):
            self.BatchId = params.get("BatchId")
        if params.get("JobName"):
            self.JobName = params.get("JobName")
        if params.get("JobDesc"):
            self.JobDesc = params.get("JobDesc")


class DescribeBatchInferenceJobsRequest(AbstractModel):
    """DescribeBatchInferenceJobs请求参数结构体
    """

    def __init__(self):
        r"""查询批量推理任务(支持分页，按创建用户过滤)
        :param Marker: 页码，从1开始，默认是1
        :type PathPrefix: Int
        :param MaxResults: 页长，默认和最大都是100
        :type PathPrefix: Int
        :param JobNameKeyword: 任务名称模糊查询条件
        :type PathPrefix: String
        :param Status: 按状态过滤查询
init、queuing、running、terminated、completed、failed、timeout
        :type PathPrefix: Filter
        :param BatchId: 
        :type PathPrefix: String
        """
        self.Marker = None
        self.MaxResults = None
        self.JobNameKeyword = None
        self.Status = None
        self.BatchId = None

    def _deserialize(self, params):
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("JobNameKeyword"):
            self.JobNameKeyword = params.get("JobNameKeyword")
        if params.get("Status"):
            self.Status = params.get("Status")
        if params.get("BatchId"):
            self.BatchId = params.get("BatchId")


class DeleteBatchInferenceJobRequest(AbstractModel):
    """DeleteBatchInferenceJob请求参数结构体
    """

    def __init__(self):
        r"""删除批量推理任务
        :param BatchId: 
        :type PathPrefix: String
        """
        self.BatchId = None

    def _deserialize(self, params):
        if params.get("BatchId"):
            self.BatchId = params.get("BatchId")


class EnableModelsRequest(AbstractModel):
    """EnableModels请求参数结构体
    """

    def __init__(self):
        r"""开通模型，支持批量
        :param ModelIds: 
        :type PathPrefix: Array
        """
        self.ModelIds = None

    def _deserialize(self, params):
        if params.get("ModelIds"):
            self.ModelIds = params.get("ModelIds")


class DescribeModelQuotasRequest(AbstractModel):
    """DescribeModelQuotas请求参数结构体
    """

    def __init__(self):
        r"""查询模型配额列表
        :param Marker: 分页页码，从1开始
        :type PathPrefix: Int
        :param MaxResults: 分页页长，最大100
        :type PathPrefix: Int
        :param Keyword: 模型搜索关键词
        :type PathPrefix: String
        :param Type: 文本模型/视觉模型
        :type PathPrefix: String
        """
        self.Marker = None
        self.MaxResults = None
        self.Keyword = None
        self.Type = None

    def _deserialize(self, params):
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("Keyword"):
            self.Keyword = params.get("Keyword")
        if params.get("Type"):
            self.Type = params.get("Type")


class DisableModelsRequest(AbstractModel):
    """DisableModels请求参数结构体
    """

    def __init__(self):
        r"""禁用对应模型
        :param ModelIds: 
        :type PathPrefix: Array
        """
        self.ModelIds = None

    def _deserialize(self, params):
        if params.get("ModelIds"):
            self.ModelIds = params.get("ModelIds")


class EnableOverFreeLimitRequest(AbstractModel):
    """EnableOverFreeLimit请求参数结构体
    """

    def __init__(self):
        r"""免费配额用完后禁用对应模型
        :param ModelIds: 
        :type PathPrefix: Array
        """
        self.ModelIds = None

    def _deserialize(self, params):
        if params.get("ModelIds"):
            self.ModelIds = params.get("ModelIds")


class DisableOverFreeLimitRequest(AbstractModel):
    """DisableOverFreeLimit请求参数结构体
    """

    def __init__(self):
        r"""即免费配额用完后继续使用计费配额
        :param ModelIds: 
        :type PathPrefix: Array
        """
        self.ModelIds = None

    def _deserialize(self, params):
        if params.get("ModelIds"):
            self.ModelIds = params.get("ModelIds")


class DescribeTrainJobEventsRequest(AbstractModel):
    """DescribeTrainJobEvents请求参数结构体
    """

    def __init__(self):
        r"""查询训练任务pod事件
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        """
        self.ResourcePoolId = None
        self.TrainJobId = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")


class StopTrainJobRequest(AbstractModel):
    """StopTrainJob请求参数结构体
    """

    def __init__(self):
        r"""关停训练任务
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        """
        self.TrainJobId = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")


class StartTrainJobRequest(AbstractModel):
    """StartTrainJob请求参数结构体
    """

    def __init__(self):
        r"""启动训练任务
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        """
        self.TrainJobId = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")


class DeleteTrainJobRequest(AbstractModel):
    """DeleteTrainJob请求参数结构体
    """

    def __init__(self):
        r"""删除训练任务
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        """
        self.TrainJobId = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")


class ModifyTrainJobRequest(AbstractModel):
    """ModifyTrainJob请求参数结构体
    """

    def __init__(self):
        r"""修改训练任务
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        :param Priority: 优先级，可选值：
 - kaic-high 高优先级
 - kaic-normal 中优先级
 - kaic-low 低优先级
        :type PathPrefix: String
        :param HoldingTimeMinutes: 实例保留时长（分钟）
        :type PathPrefix: Int
        """
        self.TrainJobId = None
        self.Priority = None
        self.HoldingTimeMinutes = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")
        if params.get("Priority"):
            self.Priority = params.get("Priority")
        if params.get("HoldingTimeMinutes"):
            self.HoldingTimeMinutes = params.get("HoldingTimeMinutes")


class DescribeTrainJobPodLogsRequest(AbstractModel):
    """DescribeTrainJobPodLogs请求参数结构体
    """

    def __init__(self):
        r"""查询训练任务pod日志
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        :param PodName: Pod名称
        :type PathPrefix: String
        :param SinceSeconds: 日志时间范围，即查询多长时间以内的日志，单位秒
        :type PathPrefix: Int
        :param TailLines: 行数
        :type PathPrefix: Int
        """
        self.ResourcePoolId = None
        self.TrainJobId = None
        self.PodName = None
        self.SinceSeconds = None
        self.TailLines = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")
        if params.get("PodName"):
            self.PodName = params.get("PodName")
        if params.get("SinceSeconds"):
            self.SinceSeconds = params.get("SinceSeconds")
        if params.get("TailLines"):
            self.TailLines = params.get("TailLines")


class DescribeTrainJobPodsRequest(AbstractModel):
    """DescribeTrainJobPods请求参数结构体
    """

    def __init__(self):
        r"""查询训练任务pod列表
        :param Marker: 页码，后续废弃，改用Page
        :type PathPrefix: String
        :param MaxResults: 单次调用返回的最大条目，后续废弃，改用PageSize
        :type PathPrefix: String
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        :param Filter: 筛选器
        :type PathPrefix: Filter
        """
        self.Marker = None
        self.MaxResults = None
        self.TrainJobId = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class DescribeInferencesRequest(AbstractModel):
    """DescribeInferences请求参数结构体
    """

    def __init__(self):
        r"""查询模型在线服务
        :param InferenceId: 多个模型在线服务的ID
        :type PathPrefix: Filter
        :param Filter: 筛选Filter
        :type PathPrefix: Filter
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param Page: 页码
        :type PathPrefix: Int
        """
        self.InferenceId = None
        self.Filter = None
        self.PageSize = None
        self.Page = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Page"):
            self.Page = params.get("Page")


class SetInferenceAutoScaleStrategyRequest(AbstractModel):
    """SetInferenceAutoScaleStrategy请求参数结构体
    """

    def __init__(self):
        r"""配置自动扩缩容配置
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        :param AutoScaleEnable: 是否启用自动扩缩容
        :type PathPrefix: Boolean
        :param AutoScaleStrategy: 自动扩缩容策略
        :type PathPrefix: Object
        """
        self.InferenceId = None
        self.AutoScaleEnable = None
        self.AutoScaleStrategy = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("AutoScaleEnable"):
            self.AutoScaleEnable = params.get("AutoScaleEnable")
        if params.get("AutoScaleStrategy"):
            self.AutoScaleStrategy = params.get("AutoScaleStrategy")


class DeleteInferenceRequest(AbstractModel):
    """DeleteInference请求参数结构体
    """

    def __init__(self):
        r"""删除模型在线服务
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        """
        self.InferenceId = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")


class StopInferenceRequest(AbstractModel):
    """StopInference请求参数结构体
    """

    def __init__(self):
        r"""停止模型在线服务
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        """
        self.InferenceId = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")


class GetInferenceDetailRequest(AbstractModel):
    """GetInferenceDetail请求参数结构体
    """

    def __init__(self):
        r"""获取模型在线服务详情
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        """
        self.InferenceId = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")


class StartInferenceRequest(AbstractModel):
    """StartInference请求参数结构体
    """

    def __init__(self):
        r"""启动模型在线服务
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        """
        self.InferenceId = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")


class ModifyInferenceRequest(AbstractModel):
    """ModifyInference请求参数结构体
    """

    def __init__(self):
        r"""修改模型在线服务信息
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        :param InferenceName: 推理服务名称
        :type PathPrefix: String
        :param Description: 描述（限长200）
        :type PathPrefix: String
        :param EntryPoint: 启动命令
        :type PathPrefix: String
        :param ImageSource: 镜像来源（自定义部署时，镜像来源类型）
        :type PathPrefix: String
        :param ImageId: 镜像ID（自定义部署时，官方镜像、自定义镜像参数）
        :type PathPrefix: String
        :param ImageRegistryId: 镜像仓库ID（自定义部署时，第三方镜像参数）
        :type PathPrefix: String
        :param ImageRepoId: 镜像仓库ID（自定义部署时，第三方镜像参数）
        :type PathPrefix: String
        :param ImageTagId: 镜像标签ID（自定义部署时，第三方镜像参数）
        :type PathPrefix: String
        :param Env: 环境变量列表
        :type PathPrefix: Array
        :param CmdOptions: 启动参数（模型部署类型参数）
        :type PathPrefix: Array
        :param HostNetworkEnabled: 是否启用主机网络
        :type PathPrefix: Boolean
        """
        self.InferenceId = None
        self.InferenceName = None
        self.Description = None
        self.EntryPoint = None
        self.ImageSource = None
        self.ImageId = None
        self.ImageRegistryId = None
        self.ImageRepoId = None
        self.ImageTagId = None
        self.Env = None
        self.CmdOptions = None
        self.HostNetworkEnabled = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("InferenceName"):
            self.InferenceName = params.get("InferenceName")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("EntryPoint"):
            self.EntryPoint = params.get("EntryPoint")
        if params.get("ImageSource"):
            self.ImageSource = params.get("ImageSource")
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("ImageRegistryId"):
            self.ImageRegistryId = params.get("ImageRegistryId")
        if params.get("ImageRepoId"):
            self.ImageRepoId = params.get("ImageRepoId")
        if params.get("ImageTagId"):
            self.ImageTagId = params.get("ImageTagId")
        if params.get("Env"):
            self.Env = params.get("Env")
        if params.get("CmdOptions"):
            self.CmdOptions = params.get("CmdOptions")
        if params.get("HostNetworkEnabled"):
            self.HostNetworkEnabled = params.get("HostNetworkEnabled")


class SetInferenceReplicasRequest(AbstractModel):
    """SetInferenceReplicas请求参数结构体
    """

    def __init__(self):
        r"""手动扩缩容
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        :param Replicas: 副本数
        :type PathPrefix: Int
        """
        self.InferenceId = None
        self.Replicas = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("Replicas"):
            self.Replicas = params.get("Replicas")


class DescribeResourcePoolsRequest(AbstractModel):
    """DescribeResourcePools请求参数结构体
    """

    def __init__(self):
        r"""查询资源组列表
        :param Sort: 排序方式：默认倒序
- DESC 倒序
- ASC 正序
        :type PathPrefix: String
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用所返回的最大实例数目，默认1000， 范围[5-1000]。
        :type PathPrefix: Int
        :param ResourcePoolName: 资源池名称，可模糊匹配
        :type PathPrefix: String
        :param Component: 组件名称:
- spark
- ray
        :type PathPrefix: String
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: Filter
        :param Filter: 一个或者多个过滤器
        :type PathPrefix: Filter
        :param EnableVolume: 是否支持挂载云盘
        :type PathPrefix: Boolean
        """
        self.Sort = None
        self.Page = None
        self.PageSize = None
        self.ResourcePoolName = None
        self.Component = None
        self.ResourcePoolId = None
        self.Filter = None
        self.EnableVolume = None

    def _deserialize(self, params):
        if params.get("Sort"):
            self.Sort = params.get("Sort")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("ResourcePoolName"):
            self.ResourcePoolName = params.get("ResourcePoolName")
        if params.get("Component"):
            self.Component = params.get("Component")
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("EnableVolume"):
            self.EnableVolume = params.get("EnableVolume")


class DescribeResourcePoolInstancesRequest(AbstractModel):
    """DescribeResourcePoolInstances请求参数结构体
    """

    def __init__(self):
        r"""查询资源组节点列表
        :param ResourcePoolId: 	
资源组d
        :type PathPrefix: String
        :param PageSize: 单次调用所返回的最大实例数目，默认1000, 范围值为[5, 1000]
        :type PathPrefix: Int
        :param Page: 页码
        :type PathPrefix: Int
        :param InstanceName: 实例名称，可模糊匹配


        :type PathPrefix: String
        :param InstanceId: 	
实例ID
        :type PathPrefix: Filter
        :param ProjectId: 项目制
        :type PathPrefix: Filter
        :param Filter: 一个或者多个过滤器
        :type PathPrefix: Filter
        """
        self.ResourcePoolId = None
        self.PageSize = None
        self.Page = None
        self.InstanceName = None
        self.InstanceId = None
        self.ProjectId = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("InstanceName"):
            self.InstanceName = params.get("InstanceName")
        if params.get("InstanceId"):
            self.InstanceId = params.get("InstanceId")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class EnableKpfsComponentRequest(AbstractModel):
    """EnableKpfsComponent请求参数结构体
    """

    def __init__(self):
        r"""开启安装kpfs组件
        :param ResourcePoolId: 资源组id
        :type PathPrefix: String
        :param FileSystemId: 文件系统id
        :type PathPrefix: String
        """
        self.ResourcePoolId = None
        self.FileSystemId = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("FileSystemId"):
            self.FileSystemId = params.get("FileSystemId")


class CreateInferenceEndpointRequest(AbstractModel):
    """CreateInferenceEndpoint请求参数结构体
    """

    def __init__(self):
        r"""创建接入点
        :param EndpointName: 推理接入点名称,1-64个字符，允许字母中文，数字，特殊字符-_、()
        :type PathPrefix: String
        :param ProjectId: 项目制Id
        :type PathPrefix: String
        :param ModelName: 默认绑定的模型名称
        :type PathPrefix: String
        :param RateLimit : 接入点限流配置
        :type PathPrefix: Object
        :param ModelId: ModelId 模型名称
        :type PathPrefix: String
        :param QuotaLimit: 限额
        :type PathPrefix: Object
        """
        self.EndpointName = None
        self.ProjectId = None
        self.ModelName = None
        self.RateLimit_ = None
        self.ModelId = None
        self.QuotaLimit = None

    def _deserialize(self, params):
        if params.get("EndpointName"):
            self.EndpointName = params.get("EndpointName")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("RateLimit "):
            self.RateLimit_ = params.get("RateLimit ")
        if params.get("ModelId"):
            self.ModelId = params.get("ModelId")
        if params.get("QuotaLimit"):
            self.QuotaLimit = params.get("QuotaLimit")


class DescribeInferenceEndpointsRequest(AbstractModel):
    """DescribeInferenceEndpoints请求参数结构体
    """

    def __init__(self):
        r"""查询接入点
        :param EndpointId: 推理接入点 ID列表，范围为1-100
        :type PathPrefix: Filter
        :param EndpointName: 
        :type PathPrefix: String
        :param Marker: 
        :type PathPrefix: Int
        :param MaxResults: 
        :type PathPrefix: Int
        :param ProjectId: 
        :type PathPrefix: Filter
        :param Filter: 条件过滤，支持按照state状态和project过滤
        :type PathPrefix: Array
        """
        self.EndpointId = None
        self.EndpointName = None
        self.Marker = None
        self.MaxResults = None
        self.ProjectId = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("EndpointName"):
            self.EndpointName = params.get("EndpointName")
        if params.get("Marker"):
            self.Marker = params.get("Marker")
        if params.get("MaxResults"):
            self.MaxResults = params.get("MaxResults")
        if params.get("ProjectId"):
            self.ProjectId = params.get("ProjectId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class EnableEndpointRateLimitRequest(AbstractModel):
    """EnableEndpointRateLimit请求参数结构体
    """

    def __init__(self):
        r"""开启接入点限流
        :param EndpointId: 接入点id
        :type PathPrefix: String
        :param RateLimit: 
        :type PathPrefix: Object
        """
        self.EndpointId = None
        self.RateLimit = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("RateLimit"):
            self.RateLimit = params.get("RateLimit")


class StartInferenceEndpointRequest(AbstractModel):
    """StartInferenceEndpoint请求参数结构体
    """

    def __init__(self):
        r"""开启接入点
        :param EndpointId: 
        :type PathPrefix: String
        """
        self.EndpointId = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")


class StopInferenceEndpointRequest(AbstractModel):
    """StopInferenceEndpoint请求参数结构体
    """

    def __init__(self):
        r"""关闭接入点
        :param EndpointId: 推理接入点名称
        :type PathPrefix: String
        """
        self.EndpointId = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")


class DeleteInferenceEndpointRequest(AbstractModel):
    """DeleteInferenceEndpoint请求参数结构体
    """

    def __init__(self):
        r"""删除接入点
        :param EndpointId: 
        :type PathPrefix: String
        """
        self.EndpointId = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")


class DisableEndpointRateLimitRequest(AbstractModel):
    """DisableEndpointRateLimit请求参数结构体
    """

    def __init__(self):
        r"""关闭接入点限流
        :param EndpointId: 
        :type PathPrefix: String
        """
        self.EndpointId = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")


class DescribeResourcePoolInstanceTasksRequest(AbstractModel):
    """DescribeResourcePoolInstanceTasks请求参数结构体
    """

    def __init__(self):
        r"""查询节点上运行的任务
        :param ResourcePoolId: 节点所在资源组ID
        :type PathPrefix: String
        :param InstanceId: 节点ID
        :type PathPrefix: String
        :param TaskType: 任务类型：
- Notebook，开发任务
- TrainJob，训练任务
- Inference，模型在线服务
- DataJob，数据处理任务
        :type PathPrefix: String
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param Page: 页码
        :type PathPrefix: Int
        :param UseIdleResource: 是否使用闲时资源
        :type PathPrefix: Boolean
        """
        self.ResourcePoolId = None
        self.InstanceId = None
        self.TaskType = None
        self.PageSize = None
        self.Page = None
        self.UseIdleResource = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("InstanceId"):
            self.InstanceId = params.get("InstanceId")
        if params.get("TaskType"):
            self.TaskType = params.get("TaskType")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("UseIdleResource"):
            self.UseIdleResource = params.get("UseIdleResource")


class SetKcrPersonalTokenRequest(AbstractModel):
    """SetKcrPersonalToken请求参数结构体
    """

    def __init__(self):
        r"""配置个人版镜像仓库访问凭证
        :param UserName: 用户名
        :type PathPrefix: String
        :param Password: 密码
        :type PathPrefix: String
        """
        self.UserName = None
        self.Password = None

    def _deserialize(self, params):
        if params.get("UserName"):
            self.UserName = params.get("UserName")
        if params.get("Password"):
            self.Password = params.get("Password")


class DescribeQueuesRequest(AbstractModel):
    """DescribeQueues请求参数结构体
    """

    def __init__(self):
        r"""查询资源组队列
        :param QueueId: 队列ID列表
        :type PathPrefix: Filter
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        :param Filter: 筛选Filter
        :type PathPrefix: Filter
        """
        self.QueueId = None
        self.Page = None
        self.PageSize = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class CreateQueueRequest(AbstractModel):
    """CreateQueue请求参数结构体
    """

    def __init__(self):
        r"""创建资源组队列
        :param ResourcePoolId: 资源池ID
        :type PathPrefix: String
        :param QueueName: 允许小写字母、数字、"."、"-",以字母、数字开头和结尾 且"-"和"."不可相邻, 长度 1-64
        :type PathPrefix: String
        :param QueueType: 队列类型：
- normal，普通队列
- physical，物理队列
普通队列必填 Capability；物理队列必填 NodeSelectType 和 NodeSpec
        :type PathPrefix: String
        :param NodeSelectType: 节点选择类型：
- random，随机分配
- specify，指定节点分配
仅当队列为物理队列类型时有效
        :type PathPrefix: String
        :param Capability: 资源配额，GPU、CPU、内存等。普通队列必填，物理队列非必填
        :type PathPrefix: Object
        :param NodeSpec: 物理队列节点规格信息，仅当 QueueType 为 physical 时有效。同一队列内同一 HostType 只能配置一项
        :type PathPrefix: Array
        :param AllowBorrowing: 是否允许向其他队列借资源
        :type PathPrefix: Boolean
        :param Description: 队列描述, 长度最大200
        :type PathPrefix: String
        :param AccessList: 访问控制列表（子账号权限信息）。同一角色（writer管理员/reader成员）只能来自 AccessList 或 SharedGroupList 其中之一，不能同时来自两者
        :type PathPrefix: Array
        :param SharedGroupList: 权限组共享列表。同一角色（writer管理员/reader成员）只能来自 AccessList 或 SharedGroupList 其中之一，不能同时来自两者
        :type PathPrefix: Array
        :param WorkloadType: 支持负载类型，默认不传表示不限制使用类型 
- Notebook（开发任务）
- TrainJob（训练任务）
- Inference（推理任务）
- DataJob（数据处理任务）
        :type PathPrefix: Array
        :param ResourceReservation: 资源预留配置。不传或 Enabled=false 表示不开启资源预留
        :type PathPrefix: Object
        """
        self.ResourcePoolId = None
        self.QueueName = None
        self.QueueType = None
        self.NodeSelectType = None
        self.Capability = None
        self.NodeSpec = None
        self.AllowBorrowing = None
        self.Description = None
        self.AccessList = None
        self.SharedGroupList = None
        self.WorkloadType = None
        self.ResourceReservation = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("QueueName"):
            self.QueueName = params.get("QueueName")
        if params.get("QueueType"):
            self.QueueType = params.get("QueueType")
        if params.get("NodeSelectType"):
            self.NodeSelectType = params.get("NodeSelectType")
        if params.get("Capability"):
            self.Capability = params.get("Capability")
        if params.get("NodeSpec"):
            self.NodeSpec = params.get("NodeSpec")
        if params.get("AllowBorrowing"):
            self.AllowBorrowing = params.get("AllowBorrowing")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("AccessList"):
            self.AccessList = params.get("AccessList")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")
        if params.get("WorkloadType"):
            self.WorkloadType = params.get("WorkloadType")
        if params.get("ResourceReservation"):
            self.ResourceReservation = params.get("ResourceReservation")


class ModifyQueueRequest(AbstractModel):
    """ModifyQueue请求参数结构体
    """

    def __init__(self):
        r"""修改资源组队列
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param Capability: 资源配额，不传该字段表示不修改，若传入，则CPU、Memory、GPUInfos会全量覆盖
        :type PathPrefix: Object
        :param AllowBorrowing: 是否允许向其他队列借资源，不传该字段表示不修改
        :type PathPrefix: Boolean
        :param Description: 队列描述，不传该字段表示不修改
        :type PathPrefix: String
        :param AccessList: 访问控制列表，若传入会进行全量覆盖式修改。传入空数组代表清理全部已授权子用户。同一角色（writer管理员/reader成员）只能来自 AccessList 或 SharedGroupList 其中之一，不能同时来自两者
        :type PathPrefix: Array
        :param SharedGroupList: 权限组共享列表（若传入，会进行全量覆盖式修改）。同一角色（writer管理员/reader成员）只能来自 AccessList 或 SharedGroupList 其中之一，不能同时来自两者
        :type PathPrefix: Array
        :param WorkloadType: 支持负载类型，不传该字段表示不修改，传空数组表示修改为不限制 
- Notebook（开发任务）
- TrainJob（训练任务）
- Inference（推理任务）
- DataJob（数据处理任务）
        :type PathPrefix: Array
        :param NodeSpec: 物理队列节点规格信息，不传该字段表示不修改。仅物理队列有效，同一队列内同一 HostType 只能配置一项
        :type PathPrefix: Array
        :param NodeSelectType: 节点选择类型：
- random，随机分配
- specify，指定节点分配
不传该字段表示不修改，仅物理队列有效。变更时需同时传入 NodeSpec
        :type PathPrefix: String
        :param ResourceReservation: 资源预留配置。不传或 Enabled=false 表示不开启资源预留)
        :type PathPrefix: Object
        """
        self.QueueId = None
        self.Capability = None
        self.AllowBorrowing = None
        self.Description = None
        self.AccessList = None
        self.SharedGroupList = None
        self.WorkloadType = None
        self.NodeSpec = None
        self.NodeSelectType = None
        self.ResourceReservation = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("Capability"):
            self.Capability = params.get("Capability")
        if params.get("AllowBorrowing"):
            self.AllowBorrowing = params.get("AllowBorrowing")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("AccessList"):
            self.AccessList = params.get("AccessList")
        if params.get("SharedGroupList"):
            self.SharedGroupList = params.get("SharedGroupList")
        if params.get("WorkloadType"):
            self.WorkloadType = params.get("WorkloadType")
        if params.get("NodeSpec"):
            self.NodeSpec = params.get("NodeSpec")
        if params.get("NodeSelectType"):
            self.NodeSelectType = params.get("NodeSelectType")
        if params.get("ResourceReservation"):
            self.ResourceReservation = params.get("ResourceReservation")


class DeleteQueueRequest(AbstractModel):
    """DeleteQueue请求参数结构体
    """

    def __init__(self):
        r"""删除队列接口
        :param QueueId: 队列ID
        :type PathPrefix: String
        """
        self.QueueId = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")


class AddQueueAccessUserRequest(AbstractModel):
    """AddQueueAccessUser请求参数结构体
    """

    def __init__(self):
        r"""添加队列成员
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param SubAccountId: 子账号ID
        :type PathPrefix: String
        :param Permission: 权限类型，有效值：
- writer，管理员
- reader，队列成员
        :type PathPrefix: String
        """
        self.QueueId = None
        self.SubAccountId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("SubAccountId"):
            self.SubAccountId = params.get("SubAccountId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class RemoveQueueAccessUserRequest(AbstractModel):
    """RemoveQueueAccessUser请求参数结构体
    """

    def __init__(self):
        r"""移出队列成员
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param SubAccountId: 子账号ID
        :type PathPrefix: String
        """
        self.QueueId = None
        self.SubAccountId = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("SubAccountId"):
            self.SubAccountId = params.get("SubAccountId")


class DescribeModelTypesRequest(AbstractModel):
    """DescribeModelTypes请求参数结构体
    """

    def __init__(self):
        r"""查询模型类别
        """

    def _deserialize(self, params):
        return


class EnableEndpointQuotaLimitRequest(AbstractModel):
    """EnableEndpointQuotaLimit请求参数结构体
    """

    def __init__(self):
        r"""开启配额限制
        :param EndpointId: 接入点ID
        :type PathPrefix: String
        :param QuotaLimitCycle: 限额周期：
daily, weekly, monthly, custom
        :type PathPrefix: String
        :param CustomCycle: 自定义周期，当QuotaLimitCycle为custom时必传
        :type PathPrefix: Int
        :param QuotaLimitAmount: 限额数量
        :type PathPrefix: Long
        """
        self.EndpointId = None
        self.QuotaLimitCycle = None
        self.CustomCycle = None
        self.QuotaLimitAmount = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("QuotaLimitCycle"):
            self.QuotaLimitCycle = params.get("QuotaLimitCycle")
        if params.get("CustomCycle"):
            self.CustomCycle = params.get("CustomCycle")
        if params.get("QuotaLimitAmount"):
            self.QuotaLimitAmount = params.get("QuotaLimitAmount")


class DisableEndpointQuotaLimitRequest(AbstractModel):
    """DisableEndpointQuotaLimit请求参数结构体
    """

    def __init__(self):
        r"""关闭配额限制
        :param EndpointId: 接入点ID
        :type PathPrefix: String
        :param QuotaLimitCycle: 限额周期：
daily, weekly, monthly, custom
        :type PathPrefix: String
        :param CustomCycle: 自定义周期，QuotaLimitCycle为custom时必填
        :type PathPrefix: String
        :param QuotaLimitAmount: 限额数量
        :type PathPrefix: String
        """
        self.EndpointId = None
        self.QuotaLimitCycle = None
        self.CustomCycle = None
        self.QuotaLimitAmount = None

    def _deserialize(self, params):
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("QuotaLimitCycle"):
            self.QuotaLimitCycle = params.get("QuotaLimitCycle")
        if params.get("CustomCycle"):
            self.CustomCycle = params.get("CustomCycle")
        if params.get("QuotaLimitAmount"):
            self.QuotaLimitAmount = params.get("QuotaLimitAmount")


class GetQueueMemberRequest(AbstractModel):
    """GetQueueMember请求参数结构体
    """

    def __init__(self):
        r"""查询队列子用户资源使用信息
        :param QueueId: 队列ID
        :type PathPrefix: String
        :param SubAccountId: 子账号ID
        :type PathPrefix: String
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用可返回的最大条目数量。可选范围5-1000
        :type PathPrefix: Int
        """
        self.QueueId = None
        self.SubAccountId = None
        self.Page = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("SubAccountId"):
            self.SubAccountId = params.get("SubAccountId")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class DescribeInferencePodsRequest(AbstractModel):
    """DescribeInferencePods请求参数结构体
    """

    def __init__(self):
        r"""查询模型在线服务Pod列表
        :param InferenceId: 推理任务ID
        :type PathPrefix: String
        :param Filter: 过滤器
        :type PathPrefix: Filter
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用返回最大条目个数
        :type PathPrefix: Int
        """
        self.InferenceId = None
        self.Filter = None
        self.Page = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class ListSkillVersionsRequest(AbstractModel):
    """ListSkillVersions请求参数结构体
    """

    def __init__(self):
        r"""skill版本列表
        :param SkillId: skill 名称
        :type PathPrefix: String
        :param PageNumber: 页号
        :type PathPrefix: Int
        :param PageSize: 页大小
        :type PathPrefix: Int
        """
        self.SkillId = None
        self.PageNumber = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")
        if params.get("PageNumber"):
            self.PageNumber = params.get("PageNumber")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class GetSkillRequest(AbstractModel):
    """GetSkill请求参数结构体
    """

    def __init__(self):
        r"""获取skill
        :param SkillId: skill id
        :type PathPrefix: String
        """
        self.SkillId = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")


class ListSkillsRequest(AbstractModel):
    """ListSkills请求参数结构体
    """

    def __init__(self):
        r"""skill 列表
        :param SkillId: skill id
        :type PathPrefix: String
        :param Name: skill 名称
        :type PathPrefix: String
        :param Status: skill 状态

枚举：
CREATING 创建中
AVAILABLE 可用
UNAVAILABLE 不可用
UPDATING 更新中
DELETING 删除中


        :type PathPrefix: String
        :param PageNumber: 页号
        :type PathPrefix: Int
        :param PageSize: 页大小
        :type PathPrefix: Int
        """
        self.SkillId = None
        self.Name = None
        self.Status = None
        self.PageNumber = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("Status"):
            self.Status = params.get("Status")
        if params.get("PageNumber"):
            self.PageNumber = params.get("PageNumber")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class ListSkillSpacesRequest(AbstractModel):
    """ListSkillSpaces请求参数结构体
    """

    def __init__(self):
        r"""skill空间列表
        :param SkillspaceId: skill 空间id
        :type PathPrefix: String
        :param Name: skill 空间名称
        :type PathPrefix: String
        :param PageNumber: 页号
        :type PathPrefix: Int
        :param PageSize: 页大小
        :type PathPrefix: Int
        """
        self.SkillspaceId = None
        self.Name = None
        self.PageNumber = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("SkillspaceId"):
            self.SkillspaceId = params.get("SkillspaceId")
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("PageNumber"):
            self.PageNumber = params.get("PageNumber")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class ListSkillsBySkillSpaceRequest(AbstractModel):
    """ListSkillsBySkillSpace请求参数结构体
    """

    def __init__(self):
        r"""分页获取skill空间下的skill
        :param SkillspaceId: skill 空间id
        :type PathPrefix: String
        :param PageNumber: 页号
        :type PathPrefix: Int
        :param PageSize: 页大小
        :type PathPrefix: Int
        """
        self.SkillspaceId = None
        self.PageNumber = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("SkillspaceId"):
            self.SkillspaceId = params.get("SkillspaceId")
        if params.get("PageNumber"):
            self.PageNumber = params.get("PageNumber")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class CreateSkillRequest(AbstractModel):
    """CreateSkill请求参数结构体
    """

    def __init__(self):
        r"""创建skill
        :param SourceType: skill 来源，填KS3则从KS3读取
        :type PathPrefix: String
        :param SourceUrl: skill数据源url，ks3地址


        :type PathPrefix: String
        :param SkillSpaces: 加入的skill 空间id列表
        :type PathPrefix: Array
        """
        self.SourceType = None
        self.SourceUrl = None
        self.SkillSpaces = None

    def _deserialize(self, params):
        if params.get("SourceType"):
            self.SourceType = params.get("SourceType")
        if params.get("SourceUrl"):
            self.SourceUrl = params.get("SourceUrl")
        if params.get("SkillSpaces"):
            self.SkillSpaces = params.get("SkillSpaces")


class CreateSkillVersionRequest(AbstractModel):
    """CreateSkillVersion请求参数结构体
    """

    def __init__(self):
        r"""创建skill版本
        :param SourceType: KS3：直接从ks3读取
        :type PathPrefix: String
        :param SourceUrl: skill数据源url，ks3地址


        :type PathPrefix: String
        :param SkillSpaces: 加入的skill空间id列表
        :type PathPrefix: Array
        """
        self.SourceType = None
        self.SourceUrl = None
        self.SkillSpaces = None

    def _deserialize(self, params):
        if params.get("SourceType"):
            self.SourceType = params.get("SourceType")
        if params.get("SourceUrl"):
            self.SourceUrl = params.get("SourceUrl")
        if params.get("SkillSpaces"):
            self.SkillSpaces = params.get("SkillSpaces")


class GetSkillUploadUrlRequest(AbstractModel):
    """GetSkillUploadUrl请求参数结构体
    """

    def __init__(self):
        r"""获取skill上传ks3地址
        :param FileName: skill压缩包的文件名称
        :type PathPrefix: String
        :param SkillName: skill 名称
        :type PathPrefix: String
        """
        self.FileName = None
        self.SkillName = None

    def _deserialize(self, params):
        if params.get("FileName"):
            self.FileName = params.get("FileName")
        if params.get("SkillName"):
            self.SkillName = params.get("SkillName")


class DeleteSkillVersionRequest(AbstractModel):
    """DeleteSkillVersion请求参数结构体
    """

    def __init__(self):
        r"""删除skill版本
        :param SkillId: skill id
        :type PathPrefix: String
        :param VersionId: skill 版本id
        :type PathPrefix: String
        """
        self.SkillId = None
        self.VersionId = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")
        if params.get("VersionId"):
            self.VersionId = params.get("VersionId")


class DeleteSkillRequest(AbstractModel):
    """DeleteSkill请求参数结构体
    """

    def __init__(self):
        r"""删除skill
        :param SkillId: skill id
        :type PathPrefix: String
        """
        self.SkillId = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")


class UpdateSkillSpaceSkillVersionRequest(AbstractModel):
    """UpdateSkillSpaceSkillVersion请求参数结构体
    """

    def __init__(self):
        r"""更新skill空间中skill的版本
        :param SpaceId: skill 空间id
        :type PathPrefix: String
        :param SkillId: skill id
        :type PathPrefix: String
        :param VersionName: skill 版本名称
        :type PathPrefix: String
        """
        self.SpaceId = None
        self.SkillId = None
        self.VersionName = None

    def _deserialize(self, params):
        if params.get("SpaceId"):
            self.SpaceId = params.get("SpaceId")
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")
        if params.get("VersionName"):
            self.VersionName = params.get("VersionName")


class RemoveSkillFromSpaceRequest(AbstractModel):
    """RemoveSkillFromSpace请求参数结构体
    """

    def __init__(self):
        r"""从skill空间中移除skill
        :param SpaceId: skill 空间id
        :type PathPrefix: String
        :param SkillId: skill id
        :type PathPrefix: String
        """
        self.SpaceId = None
        self.SkillId = None

    def _deserialize(self, params):
        if params.get("SpaceId"):
            self.SpaceId = params.get("SpaceId")
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")


class DeleteSkillSpaceRequest(AbstractModel):
    """DeleteSkillSpace请求参数结构体
    """

    def __init__(self):
        r"""删除skill空间
        :param SkillSpaceId: skill 空间id
        :type PathPrefix: String
        """
        self.SkillSpaceId = None

    def _deserialize(self, params):
        if params.get("SkillSpaceId"):
            self.SkillSpaceId = params.get("SkillSpaceId")


class CreateSkillSpaceRequest(AbstractModel):
    """CreateSkillSpace请求参数结构体
    """

    def __init__(self):
        r"""创建skill空间
        :param Name: skill 空间名称
        :type PathPrefix: String
        :param Description: skill 空间描述
        :type PathPrefix: String
        :param Skills: skill 空间内的skill
id列表
        :type PathPrefix: Array
        """
        self.Name = None
        self.Description = None
        self.Skills = None

    def _deserialize(self, params):
        if params.get("Name"):
            self.Name = params.get("Name")
        if params.get("Description"):
            self.Description = params.get("Description")
        if params.get("Skills"):
            self.Skills = params.get("Skills")


class ModifyResourcePoolRequest(AbstractModel):
    """ModifyResourcePool请求参数结构体
    """

    def __init__(self):
        r"""修改资源组
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param ResourcePoolName: 资源组名称
        :type PathPrefix: String
        :param Overallocate: 配额超发
        :type PathPrefix: Boolean
        """
        self.ResourcePoolId = None
        self.ResourcePoolName = None
        self.Overallocate = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("ResourcePoolName"):
            self.ResourcePoolName = params.get("ResourcePoolName")
        if params.get("Overallocate"):
            self.Overallocate = params.get("Overallocate")


class GetSkillDownloadUrlRequest(AbstractModel):
    """GetSkillDownloadUrl请求参数结构体
    """

    def __init__(self):
        r"""获取Skill版本下载地址
        :param SkillId: skill 的id
        :type PathPrefix: String
        :param VersionId: skill 版本的id
        :type PathPrefix: String
        """
        self.SkillId = None
        self.VersionId = None

    def _deserialize(self, params):
        if params.get("SkillId"):
            self.SkillId = params.get("SkillId")
        if params.get("VersionId"):
            self.VersionId = params.get("VersionId")


class DescribeResourcePoolInstanceSpecsRequest(AbstractModel):
    """DescribeResourcePoolInstanceSpecs请求参数结构体
    """

    def __init__(self):
        r"""查询资源组节点配置
        :param ResourcePoolId: 资源组ID
        :type PathPrefix: String
        :param GPUModel: GPU型号筛选：
- 不传：返回所有节点规格
- 空字符串：返回非GPU（CPU）节点规格
- 具体型号：返回指定GPU型号的节点规格
        :type PathPrefix: String
        :param OnlyCPU: 是否仅返回CPU节点规格：
- true：仅返回非GPU节点规格
- false或不传：返回所有节点规格
优先级高于 GPUModel
        :type PathPrefix: Boolean
        """
        self.ResourcePoolId = None
        self.GPUModel = None
        self.OnlyCPU = None

    def _deserialize(self, params):
        if params.get("ResourcePoolId"):
            self.ResourcePoolId = params.get("ResourcePoolId")
        if params.get("GPUModel"):
            self.GPUModel = params.get("GPUModel")
        if params.get("OnlyCPU"):
            self.OnlyCPU = params.get("OnlyCPU")


class AddSkillsToSkillSpaceRequest(AbstractModel):
    """AddSkillsToSkillSpace请求参数结构体
    """

    def __init__(self):
        r"""添加skill到skill空间
        :param SkillSpaceId: skill 空间id
        :type PathPrefix: String
        :param Skills: 
        :type PathPrefix: Object
        """
        self.SkillSpaceId = None
        self.Skills = None

    def _deserialize(self, params):
        if params.get("SkillSpaceId"):
            self.SkillSpaceId = params.get("SkillSpaceId")
        if params.get("Skills"):
            self.Skills = params.get("Skills")


class DescribeInferenceAndPodEventsRequest(AbstractModel):
    """DescribeInferenceAndPodEvents请求参数结构体
    """

    def __init__(self):
        r"""查询模型在线服务及Pod事件列表
        :param InferenceId: 推理服务ID
        :type PathPrefix: String
        :param PodNames: Pod名称列表，不传则查询所有Pod事件
        :type PathPrefix: Array
        :param SortKey: 排序关键字
        :type PathPrefix: String
        :param Sort: 排序方式
        :type PathPrefix: String
        """
        self.InferenceId = None
        self.PodNames = None
        self.SortKey = None
        self.Sort = None

    def _deserialize(self, params):
        if params.get("InferenceId"):
            self.InferenceId = params.get("InferenceId")
        if params.get("PodNames"):
            self.PodNames = params.get("PodNames")
        if params.get("SortKey"):
            self.SortKey = params.get("SortKey")
        if params.get("Sort"):
            self.Sort = params.get("Sort")


class DescribeTrainJobAndPodEventsRequest(AbstractModel):
    """DescribeTrainJobAndPodEvents请求参数结构体
    """

    def __init__(self):
        r"""查询训练任务及Pod事件列表
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        :param PodNames: Pod名称列表，不传则查询所有Pod事件
        :type PathPrefix: Array
        :param SortKey: 排序关键字
        :type PathPrefix: String
        :param Sort: 排序方式
        :type PathPrefix: String
        """
        self.TrainJobId = None
        self.PodNames = None
        self.SortKey = None
        self.Sort = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")
        if params.get("PodNames"):
            self.PodNames = params.get("PodNames")
        if params.get("SortKey"):
            self.SortKey = params.get("SortKey")
        if params.get("Sort"):
            self.Sort = params.get("Sort")


class DescribeFineTuneJobAndPodEventsRequest(AbstractModel):
    """DescribeFineTuneJobAndPodEvents请求参数结构体
    """

    def __init__(self):
        r"""查询模型微调任务及Pod事件列表
        :param FineTuneJobId: 微调任务ID
        :type PathPrefix: String
        :param PodNames: Pod名称列表，不传则查询所有Pod事件
        :type PathPrefix: Array
        :param SortKey: 排序关键字
        :type PathPrefix: String
        :param Sort: 排序方式
        :type PathPrefix: String
        """
        self.FineTuneJobId = None
        self.PodNames = None
        self.SortKey = None
        self.Sort = None

    def _deserialize(self, params):
        if params.get("FineTuneJobId"):
            self.FineTuneJobId = params.get("FineTuneJobId")
        if params.get("PodNames"):
            self.PodNames = params.get("PodNames")
        if params.get("SortKey"):
            self.SortKey = params.get("SortKey")
        if params.get("Sort"):
            self.Sort = params.get("Sort")


class DescribeTerminateStopRecordsRequest(AbstractModel):
    """DescribeTerminateStopRecords请求参数结构体
    """

    def __init__(self):
        r"""查询清理策略记录列表
        :param QueueId: 队列ID，与TerminatePolicyIds、NotebookIds不能同时为空
        :type PathPrefix: String
        :param TerminatePolicyIds: 关停策略ID列表，与QueueId、NotebookIds不能同时为空
        :type PathPrefix: Array
        :param NotebookIds: 任务ID列表，与QueueId、TerminatePolicyIds不能同时为空
        :type PathPrefix: Array
        :param StartTime: 查询开始时间，格式：yyyy-MM-dd HH:mm:ss
        :type PathPrefix: String
        :param EndTime: 查询结束时间，格式：yyyy-MM-dd HH:mm:ss
        :type PathPrefix: String
        :param Page: 页码
        :type PathPrefix: Int
        :param PageSize: 单次调用可返回的最大条目数量
        :type PathPrefix: Int
        """
        self.QueueId = None
        self.TerminatePolicyIds = None
        self.NotebookIds = None
        self.StartTime = None
        self.EndTime = None
        self.Page = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("QueueId"):
            self.QueueId = params.get("QueueId")
        if params.get("TerminatePolicyIds"):
            self.TerminatePolicyIds = params.get("TerminatePolicyIds")
        if params.get("NotebookIds"):
            self.NotebookIds = params.get("NotebookIds")
        if params.get("StartTime"):
            self.StartTime = params.get("StartTime")
        if params.get("EndTime"):
            self.EndTime = params.get("EndTime")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class CreateAccessGroupRequest(AbstractModel):
    """CreateAccessGroup请求参数结构体
    """

    def __init__(self):
        r"""创建星流权限组
        :param AccessGroupName: 权限组名称，1-64位，支持中文、字母、数字和_-./()
        :type PathPrefix: String
        :param AccessGroupDescription: 权限组描述，最长200字符
        :type PathPrefix: String
        :param Users: 成员列表
        :type PathPrefix: Array
        """
        self.AccessGroupName = None
        self.AccessGroupDescription = None
        self.Users = None

    def _deserialize(self, params):
        if params.get("AccessGroupName"):
            self.AccessGroupName = params.get("AccessGroupName")
        if params.get("AccessGroupDescription"):
            self.AccessGroupDescription = params.get("AccessGroupDescription")
        if params.get("Users"):
            self.Users = params.get("Users")


class ModifyAccessGroupRequest(AbstractModel):
    """ModifyAccessGroup请求参数结构体
    """

    def __init__(self):
        r"""修改星流权限组
        :param AccessGroupId: 权限组ID，36位，字母/数字/-
        :type PathPrefix: String
        :param AccessGroupName: 权限组名称，1-64位，支持中文、字母、数字和_-./()。不传表示不修改
        :type PathPrefix: String
        :param AccessGroupDescription: 权限组描述，最长200字符。不传表示不修改；
        :type PathPrefix: String
        :param Users: 成员列表（全量替换）。不传(null)表示不修改；传空列表表示清空；传非空列表表示全量替换
        :type PathPrefix: Array
        """
        self.AccessGroupId = None
        self.AccessGroupName = None
        self.AccessGroupDescription = None
        self.Users = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("AccessGroupName"):
            self.AccessGroupName = params.get("AccessGroupName")
        if params.get("AccessGroupDescription"):
            self.AccessGroupDescription = params.get("AccessGroupDescription")
        if params.get("Users"):
            self.Users = params.get("Users")


class DescribeAccessGroupsRequest(AbstractModel):
    """DescribeAccessGroups请求参数结构体
    """

    def __init__(self):
        r"""查询星流权限组
        :param AccessGroupId: 权限组ID，支持传入多个，按权限组ID筛选
        :type PathPrefix: Filter
        :param Filter: 过滤器，按权限组名称筛选，Name有效值：access-group-name
        :type PathPrefix: Filter
        :param Page: 页码，默认1
        :type PathPrefix: Int
        :param PageSize: 每页数量，范围5-1000，默认20
        :type PathPrefix: Int
        """
        self.AccessGroupId = None
        self.Filter = None
        self.Page = None
        self.PageSize = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("Filter"):
            self.Filter = params.get("Filter")
        if params.get("Page"):
            self.Page = params.get("Page")
        if params.get("PageSize"):
            self.PageSize = params.get("PageSize")


class DescribeAccessGroupAssociatedPermissionRequest(AbstractModel):
    """DescribeAccessGroupAssociatedPermission请求参数结构体
    """

    def __init__(self):
        r"""查询权限组关联权限
        :param AccessGroupId: 权限组ID，36位
        :type PathPrefix: String
        :param ResourceType: 资源类型，枚举值：
- Queue，队列
- Dataset，存储配置
- Image，镜像
- Model，模型
- ImageRegistry，第三方镜像配置
        :type PathPrefix: String
        """
        self.AccessGroupId = None
        self.ResourceType = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("ResourceType"):
            self.ResourceType = params.get("ResourceType")


class DeleteAccessGroupRequest(AbstractModel):
    """DeleteAccessGroup请求参数结构体
    """

    def __init__(self):
        r"""删除星流权限组
        :param AccessGroupId: 权限组ID，36位
        :type PathPrefix: String
        """
        self.AccessGroupId = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")


class AddAccessGroupMembersRequest(AbstractModel):
    """AddAccessGroupMembers请求参数结构体
    """

    def __init__(self):
        r"""添加权限组成员
        :param AccessGroupId: 权限组ID，36位
        :type PathPrefix: String
        :param Users: 待添加成员列表，至少1项
        :type PathPrefix: Array
        """
        self.AccessGroupId = None
        self.Users = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("Users"):
            self.Users = params.get("Users")


class RemoveAccessGroupMembersRequest(AbstractModel):
    """RemoveAccessGroupMembers请求参数结构体
    """

    def __init__(self):
        r"""移除权限组成员
        :param AccessGroupId: 权限组ID，36位
        :type PathPrefix: String
        :param UserIds: 待移除的子账号ID列表，至少1项
        :type PathPrefix: Array
        """
        self.AccessGroupId = None
        self.UserIds = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("UserIds"):
            self.UserIds = params.get("UserIds")


class ModifyAccessGroupMemberRoleRequest(AbstractModel):
    """ModifyAccessGroupMemberRole请求参数结构体
    """

    def __init__(self):
        r"""修改权限组成员角色
        :param AccessGroupId: 权限组ID，36位
        :type PathPrefix: String
        :param UserId: 目标子账号ID
        :type PathPrefix: String
        :param Permission: 新角色，枚举值：
- writer，管理员
- reader，普通成员
        :type PathPrefix: String
        """
        self.AccessGroupId = None
        self.UserId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class DeleteAccessGroupAssociatedPermissionRequest(AbstractModel):
    """DeleteAccessGroupAssociatedPermission请求参数结构体
    """

    def __init__(self):
        r"""删除权限组关联权限
        :param AccessGroupId: 权限组ID
        :type PathPrefix: String
        :param AssociatedResourceId: 关联资源ID，与AssociatedPermissionId二选一；
        :type PathPrefix: String
        """
        self.AccessGroupId = None
        self.AssociatedResourceId = None

    def _deserialize(self, params):
        if params.get("AccessGroupId"):
            self.AccessGroupId = params.get("AccessGroupId")
        if params.get("AssociatedResourceId"):
            self.AssociatedResourceId = params.get("AssociatedResourceId")


class GetAccountBillRulesRequest(AbstractModel):
    """GetAccountBillRules请求参数结构体
    """

    def __init__(self):
        r"""获取用户报价规则
        """

    def _deserialize(self, params):
        return


class CreateUsageDownloadTaskRequest(AbstractModel):
    """CreateUsageDownloadTask请求参数结构体
    """

    def __init__(self):
        r"""创建查询用量任务
        :param StartTimestamp: 查询任务数据起始时间（UTC Unix 时间戳，单位：秒），需校验：StartTimestamp≤EndTimestamp

        :type PathPrefix: Long
        :param EndTimestamp: 查询任务数据结束时间（UTC Unix 时间戳，单位：秒），需校验：EndTimestamp ≤ 当前时间；EndTimestamp - StartTimestamp ≤ 86400（最大时间跨度1天）
        :type PathPrefix: Long
        :param Filter: 
        :type PathPrefix: Object
        """
        self.StartTimestamp = None
        self.EndTimestamp = None
        self.Filter = None

    def _deserialize(self, params):
        if params.get("StartTimestamp"):
            self.StartTimestamp = params.get("StartTimestamp")
        if params.get("EndTimestamp"):
            self.EndTimestamp = params.get("EndTimestamp")
        if params.get("Filter"):
            self.Filter = params.get("Filter")


class GetUsageDownloadTaskRequest(AbstractModel):
    """GetUsageDownloadTask请求参数结构体
    """

    def __init__(self):
        r"""下载查询用量任务
        :param TaskId: 导出任务ID
        :type PathPrefix: String
        """
        self.TaskId = None

    def _deserialize(self, params):
        if params.get("TaskId"):
            self.TaskId = params.get("TaskId")


class AddStorageConfigAccessRequest(AbstractModel):
    """AddStorageConfigAccess请求参数结构体
    """

    def __init__(self):
        r"""存储配置添加权限用户
        :param StorageConfigId: 存储配置ID
        :type PathPrefix: String
        :param UserId: 要添加的子用户ID
        :type PathPrefix: String
        :param SharedGroupId: 要添加的权限组ID
        :type PathPrefix: String
        :param Permission: 权限类型
KPFS存储配置权限枚举值：
- writer_mnt_w 管理员（读写）
- writer 管理员（只读）
- reader_mnt_w 普通成员（读写）
- reader普通成员（只读）

KS3存储配置权限枚举值：
- writer 管理员
- reader普通成员
        :type PathPrefix: String
        """
        self.StorageConfigId = None
        self.UserId = None
        self.SharedGroupId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class ModifyStorageConfigAccessRoleRequest(AbstractModel):
    """ModifyStorageConfigAccessRole请求参数结构体
    """

    def __init__(self):
        r"""修改存储配置用户/权限组权限
        :param StorageConfigId: 存储配置ID
        :type PathPrefix: String
        :param UserId: 要移除权限组的子账号ID
        :type PathPrefix: String
        :param SharedGroupId: 要移除权限的权限组ID
        :type PathPrefix: String
        :param Permission: 权限类型
KPFS存储配置权限枚举值：
- writer_mnt_w 管理员（读写）
- writer 管理员（只读）
- reader_mnt_w 普通成员（读写）
- reader普通成员（只读）

KS3存储配置权限枚举值：
- writer 管理员
- reader普通成员
        :type PathPrefix: String
        """
        self.StorageConfigId = None
        self.UserId = None
        self.SharedGroupId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class RemoveStorageConfigAccessRequest(AbstractModel):
    """RemoveStorageConfigAccess请求参数结构体
    """

    def __init__(self):
        r"""移除成员/权限组权限
        :param StorageConfigId: 存储配置ID
        :type PathPrefix: String
        :param UserId: 子用户ID（要被移除的子用户ID）
        :type PathPrefix: String
        :param SharedGroupId: 权限组ID（要被移除权限的权限组ID）
        :type PathPrefix: String
        """
        self.StorageConfigId = None
        self.UserId = None
        self.SharedGroupId = None

    def _deserialize(self, params):
        if params.get("StorageConfigId"):
            self.StorageConfigId = params.get("StorageConfigId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")


class CheckKlogServiceStatusRequest(AbstractModel):
    """CheckKlogServiceStatus请求参数结构体
    """

    def __init__(self):
        r"""获取Klog服务状态
        """

    def _deserialize(self, params):
        return


class CreateLogPoolConfigRequest(AbstractModel):
    """CreateLogPoolConfig请求参数结构体
    """

    def __init__(self):
        r"""创建日志池投递配置
        :param ProjectName: 日志工程名
        :type PathPrefix: String
        :param LogPoolName: 日志池名称
        :type PathPrefix: String
        :param ModelName: 模型名称,与接入点id二选一传入
        :type PathPrefix: String
        :param EndpointId: 接入点id,与模型名称二选一传入
        :type PathPrefix: String
        :param Region: 
        :type PathPrefix: String
        """
        self.ProjectName = None
        self.LogPoolName = None
        self.ModelName = None
        self.EndpointId = None
        self.Region = None

    def _deserialize(self, params):
        if params.get("ProjectName"):
            self.ProjectName = params.get("ProjectName")
        if params.get("LogPoolName"):
            self.LogPoolName = params.get("LogPoolName")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("Region"):
            self.Region = params.get("Region")


class DeleteLogPoolConfigRequest(AbstractModel):
    """DeleteLogPoolConfig请求参数结构体
    """

    def __init__(self):
        r"""删除日志池投递配置
        :param ProjectName: 日志工程名称
        :type PathPrefix: String
        :param LogPoolName: 日志池名称
        :type PathPrefix: String
        :param ModelName: 模型名称,与接入点id二选一传入
        :type PathPrefix: String
        :param EndpointId: 	
接入点id,与模型名称二选一传入


        :type PathPrefix: String
        :param Region: 
        :type PathPrefix: String
        """
        self.ProjectName = None
        self.LogPoolName = None
        self.ModelName = None
        self.EndpointId = None
        self.Region = None

    def _deserialize(self, params):
        if params.get("ProjectName"):
            self.ProjectName = params.get("ProjectName")
        if params.get("LogPoolName"):
            self.LogPoolName = params.get("LogPoolName")
        if params.get("ModelName"):
            self.ModelName = params.get("ModelName")
        if params.get("EndpointId"):
            self.EndpointId = params.get("EndpointId")
        if params.get("Region"):
            self.Region = params.get("Region")


class AddImageAccessRequest(AbstractModel):
    """AddImageAccess请求参数结构体
    """

    def __init__(self):
        r"""为用户/权限组添加镜像权限
        :param ImageId: 镜像ID
        :type PathPrefix: String
        :param UserId: 用户ID，与 SharedGroupId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        :param SharedGroupId: 权限组ID，与 UserId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        :param Permission: 镜像访问权限，有效值：
- writer 管理员
- reader 普通成员
        :type PathPrefix: String
        """
        self.ImageId = None
        self.UserId = None
        self.SharedGroupId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class ModifyImageAccessRoleRequest(AbstractModel):
    """ModifyImageAccessRole请求参数结构体
    """

    def __init__(self):
        r"""修改用户/权限组镜像权限
        :param ImageId: 镜像ID
        :type PathPrefix: String
        :param UserId: 用户ID，与 SharedGroupId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        :param SharedGroupId: 权限组ID，与 UserId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        :param Permission: 镜像访问权限，有效值：
- writer 管理员
- reader 普通成员
        :type PathPrefix: String
        """
        self.ImageId = None
        self.UserId = None
        self.SharedGroupId = None
        self.Permission = None

    def _deserialize(self, params):
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")
        if params.get("Permission"):
            self.Permission = params.get("Permission")


class RemoveImageAccessRequest(AbstractModel):
    """RemoveImageAccess请求参数结构体
    """

    def __init__(self):
        r"""移除用户/权限组镜像权限
        :param ImageId: 镜像ID
        :type PathPrefix: String
        :param UserId: 用户ID，与 SharedGroupId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        :param SharedGroupId: 权限组ID，与 UserId 二选一，不可同时为空或同时非空
        :type PathPrefix: String
        """
        self.ImageId = None
        self.UserId = None
        self.SharedGroupId = None

    def _deserialize(self, params):
        if params.get("ImageId"):
            self.ImageId = params.get("ImageId")
        if params.get("UserId"):
            self.UserId = params.get("UserId")
        if params.get("SharedGroupId"):
            self.SharedGroupId = params.get("SharedGroupId")


class DescribeNotebookTimeLineRequest(AbstractModel):
    """DescribeNotebookTimeLine请求参数结构体
    """

    def __init__(self):
        r"""查询开发任务生命周期时间线
        :param NotebookId: 开发任务ID
        :type PathPrefix: String
        """
        self.NotebookId = None

    def _deserialize(self, params):
        if params.get("NotebookId"):
            self.NotebookId = params.get("NotebookId")


class DescribeTrainJobTimeLineRequest(AbstractModel):
    """DescribeTrainJobTimeLine请求参数结构体
    """

    def __init__(self):
        r"""查询训练任务生命周期时间线
        :param TrainJobId: 训练任务ID
        :type PathPrefix: String
        """
        self.TrainJobId = None

    def _deserialize(self, params):
        if params.get("TrainJobId"):
            self.TrainJobId = params.get("TrainJobId")


