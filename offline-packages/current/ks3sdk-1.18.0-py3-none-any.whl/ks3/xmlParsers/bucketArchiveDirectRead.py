# coding:utf-8
"""
归档直读(Archive Direct Read)相关的 XML 解析器类

示例:
    # 创建配置
    config = ArchiveDirectReadConfiguration(enabled=True)

    # 生成 XML
    xml = config.to_xml()
"""

from ks3.responseResult import ResponseMetadata


class ArchiveDirectReadConfiguration:
    """归档直读配置"""
    def __init__(self, enabled=None, *args, **kwargs):
        self.enabled = enabled
        self.response_metadata = ResponseMetadata(**kwargs)

    def to_xml(self):
        s = '<ArchiveDirectReadConfiguration>'
        if self.enabled is not None:
            s += '<Enabled>%s</Enabled>' % ('true' if self.enabled else 'false')
        s += '</ArchiveDirectReadConfiguration>'
        return s

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'Enabled':
            self.enabled = value.lower() == 'true'
