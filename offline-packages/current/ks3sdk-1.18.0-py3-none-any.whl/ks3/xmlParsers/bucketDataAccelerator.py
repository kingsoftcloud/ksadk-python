# coding:utf-8
"""
缓存加速器(Data Accelerator)相关的 XML 解析器类

支持以下配置：
- BucketDataAccelerator: 缓存加速器配置
- AcceleratePath: 加速路径配置

示例:
    # 创建配置
    config = BucketDataAccelerator(
        available_zone="cn-beijing-e",
        quota=500
    )
    config.add_accelerate_path(AcceleratePath("images/", sync_warmup=True))
    config.add_accelerate_path(AcceleratePath("videos/", sync_warmup=False))

    # 生成 XML
    xml = config.to_xml()
"""

from ks3.responseResult import ResponseMetadata


class AcceleratePath:
    """加速路径配置"""
    def __init__(self, prefix=None, sync_warmup=None):
        self.prefix = prefix
        self.sync_warmup = sync_warmup

    def to_xml(self):
        s = '<Path>'
        if self.prefix is not None:
            s += '<Prefix>%s</Prefix>' % self.prefix
        if self.sync_warmup is not None:
            s += '<SyncWarmup>%s</SyncWarmup>' % ('true' if self.sync_warmup else 'false')
        s += '</Path>'
        return s

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'Prefix':
            self.prefix = value
        elif name == 'SyncWarmup':
            self.sync_warmup = value.lower() == 'true'


class BucketDataAccelerator:
    """缓存加速器配置"""
    def __init__(self, available_zone=None, quota=None, accelerate_paths=None, *args, **kwargs):
        self.available_zone = available_zone
        self.quota = quota
        self.accelerate_paths = accelerate_paths if accelerate_paths is not None else []
        self.response_metadata = ResponseMetadata(**kwargs)

    def add_accelerate_path(self, path):
        """添加加速路径"""
        if path is not None:
            self.accelerate_paths.append(path)

    def to_xml(self):
        s = '<DataAcceleratorConfiguration>'
        if self.available_zone is not None:
            s += '<AvailableZone>%s</AvailableZone>' % self.available_zone
        if self.quota is not None:
            s += '<Quota>%s</Quota>' % self.quota
        if self.accelerate_paths:
            s += '<AcceleratePaths>'
            for path in self.accelerate_paths:
                s += path.to_xml()
            s += '</AcceleratePaths>'
        s += '</DataAcceleratorConfiguration>'
        return s

    def startElement(self, name, attrs, connection):
        if name == 'Path':
            path = AcceleratePath()
            self.accelerate_paths.append(path)
            return path
        return None

    def endElement(self, name, value, connection):
        if name == 'AvailableZone':
            self.available_zone = value
        elif name == 'Quota':
            self.quota = value
        setattr(self, name, value)
