# coding:utf-8
"""
桶 HTTP/2 协议配置相关的 XML 解析器类

示例:
    # 创建配置
    config = Http2Configuration(status=Http2Configuration.ENABLED)

    # 生成 XML
    xml = config.to_xml()
"""

from ks3.responseResult import ResponseMetadata


class Http2Configuration(object):
    """桶 HTTP/2 协议配置"""
    ENABLED = 'Enabled'
    DISABLED = 'Disabled'

    def __init__(self, status=None, *args, **kwargs):
        """
        :param status: Enabled 或者 Disabled
        """
        self.status = status
        self.response_metadata = ResponseMetadata(**kwargs)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'Status':
            self.status = value
        else:
            setattr(self, name, value)

    def to_xml(self):
        s = '<Http2Configuration>'
        if self.status is not None:
            s += '<Status>%s</Status>' % self.status
        s += '</Http2Configuration>'
        return s
