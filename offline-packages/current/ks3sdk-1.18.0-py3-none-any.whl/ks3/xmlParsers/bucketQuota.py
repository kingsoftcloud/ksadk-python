from ks3.responseResult import ResponseMetadata


class TransferQuota(object):
    """
    传输配额类，用于表示每日或每月的传输配额

    支持的字段：
    - IntranetFlowUp: 内网上行流量
    - IntranetFlowDown: 内网下行流量
    - ExtranetFlowUp: 外网上行流量
    - ExtranetFlowDown: 外网下行流量
    - CDNFlowUp: CDN上行流量
    - CDNFlowDown: CDN下行流量
    - Put: PUT请求数
    - Get: GET请求数
    - List: LIST请求数
    """

    def __init__(self, intranet_flow_up=None, intranet_flow_down=None,
                 extranet_flow_up=None, extranet_flow_down=None,
                 cdn_flow_up=None, cdn_flow_down=None,
                 put_requests=None, get_requests=None, list_requests=None,
                 *args, **kwargs):
        self.intranet_flow_up = intranet_flow_up
        self.intranet_flow_down = intranet_flow_down
        self.extranet_flow_up = extranet_flow_up
        self.extranet_flow_down = extranet_flow_down
        self.cdn_flow_up = cdn_flow_up
        self.cdn_flow_down = cdn_flow_down
        self.put_requests = put_requests
        self.get_requests = get_requests
        self.list_requests = list_requests

        self.response_metadata = ResponseMetadata(**kwargs)

    def __repr__(self):
        return '<TransferQuota: intranet=%s/%s, extranet=%s/%s>' % (
            self.intranet_flow_up, self.intranet_flow_down,
            self.extranet_flow_up, self.extranet_flow_down)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'IntranetFlowUp':
            self.intranet_flow_up = value
        elif name == 'IntranetFlowDown':
            self.intranet_flow_down = value
        elif name == 'ExtranetFlowUp':
            self.extranet_flow_up = value
        elif name == 'ExtranetFlowDown':
            self.extranet_flow_down = value
        elif name == 'CDNFlowUp':
            self.cdn_flow_up = value
        elif name == 'CDNFlowDown':
            self.cdn_flow_down = value
        elif name == 'Put':
            self.put_requests = value
        elif name == 'Get':
            self.get_requests = value
        elif name == 'List':
            self.list_requests = value
        else:
            setattr(self, name, value)

    def to_xml(self, tag_name='TransferQuota'):
        """生成传输配额的 XML 表示"""
        s = '<%s>' % tag_name
        if self.intranet_flow_up is not None:
            s += '<IntranetFlowUp>%s</IntranetFlowUp>' % self.intranet_flow_up
        if self.intranet_flow_down is not None:
            s += '<IntranetFlowDown>%s</IntranetFlowDown>' % self.intranet_flow_down
        if self.extranet_flow_up is not None:
            s += '<ExtranetFlowUp>%s</ExtranetFlowUp>' % self.extranet_flow_up
        if self.extranet_flow_down is not None:
            s += '<ExtranetFlowDown>%s</ExtranetFlowDown>' % self.extranet_flow_down
        if self.cdn_flow_up is not None:
            s += '<CDNFlowUp>%s</CDNFlowUp>' % self.cdn_flow_up
        if self.cdn_flow_down is not None:
            s += '<CDNFlowDown>%s</CDNFlowDown>' % self.cdn_flow_down
        if self.put_requests is not None:
            s += '<Put>%s</Put>' % self.put_requests
        if self.get_requests is not None:
            s += '<Get>%s</Get>' % self.get_requests
        if self.list_requests is not None:
            s += '<List>%s</List>' % self.list_requests
        s += '</%s>' % tag_name
        return s


class BucketQuota(object):
    """
    Bucket 配额配置类

    支持以下配额类型：
    - StorageQuota: 存储配额
    - Day: 每日传输配额 (TransferQuota)
    - Month: 每月传输配额 (TransferQuota)
    """

    def __init__(self, quota=None, daily_quota=None, monthly_quota=None,
                 *args, **kwargs):
        self.quota = quota
        self.daily_quota = daily_quota
        self.monthly_quota = monthly_quota

        self.response_metadata = ResponseMetadata(**kwargs)

    def __repr__(self):
        return "<BucketQuota: storage=%s>" % self.quota

    def startElement(self, name, attrs, connection):
        if name == 'Day':
            self.daily_quota = TransferQuota()
            return self.daily_quota
        elif name == 'Month':
            self.monthly_quota = TransferQuota()
            return self.monthly_quota
        return None

    def endElement(self, name, value, connection):
        if name == 'StorageQuota':
            self.quota = value
        else:
            setattr(self, name, value)

    def to_xml(self):
        s = '<?xml version="1.0" encoding="UTF-8"?>'
        s += '<Quota>'
        if self.quota is not None:
            s += '<StorageQuota>%s</StorageQuota>' % self.quota
        if self.daily_quota is not None:
            s += self.daily_quota.to_xml(tag_name='Day')
        if self.monthly_quota is not None:
            s += self.monthly_quota.to_xml(tag_name='Month')
        s += '</Quota>'
        return s
