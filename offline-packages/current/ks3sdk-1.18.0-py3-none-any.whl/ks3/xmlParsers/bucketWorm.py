# coding:utf-8
"""
合规保留策略(WORM)相关的 XML 解析器类

支持以下配置：
- BucketWormConfiguration: WORM 合规保留策略配置

WORM 状态：
- InProgress: 策略已创建但未锁定，可以取消
- Locked: 策略已锁定，无法删除，只能延长保留期

示例:
    # 创建 WORM 配置
    config = BucketWormConfiguration(
        worm_id="worm-id-123",
        state="Locked",
        retention_period_days=30,
        creation_date="2024-01-01T00:00:00.000Z"
    )

    # 生成 XML
    xml = config.to_xml()
"""

from ks3.responseResult import ResponseMetadata


class BucketWormConfiguration(object):
    """
    WORM 合规保留策略配置类

    用于创建、获取和管理 Bucket 的合规保留策略
    """
    STATE_IN_PROGRESS = 'InProgress'
    STATE_LOCKED = 'Locked'

    def __init__(self, worm_id=None, state=None, retention_period_days=None,
                 creation_date=None, *args, **kwargs):
        """
        初始化 WORM 配置

        :param worm_id: WORM 策略 ID
        :param state: WORM 状态 (InProgress/Locked)
        :param retention_period_days: 保留期天数
        :param creation_date: 创建时间 (ISO 8601 格式)
        """
        self.worm_id = worm_id
        self.state = state
        self.retention_period_days = retention_period_days
        self.creation_date = creation_date

        self.response_metadata = ResponseMetadata(**kwargs)

    def __repr__(self):
        return '<BucketWormConfiguration: id=%s, state=%s, retention_days=%s>' % (
            self.worm_id, self.state, self.retention_period_days)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'WormId':
            self.worm_id = value
        elif name == 'State':
            self.state = value
        elif name == 'RetentionPeriodInDays':
            self.retention_period_days = int(value)
        elif name == 'CreationDate':
            self.creation_date = value
        else:
            setattr(self, name, value)

    def to_xml(self):
        """生成 WORM 配置的 XML 表示"""
        s = '<WormConfiguration>'
        if self.worm_id is not None:
            s += '<WormId>%s</WormId>' % self.worm_id
        if self.state is not None:
            s += '<State>%s</State>' % self.state
        if self.retention_period_days is not None:
            s += '<RetentionPeriodInDays>%s</RetentionPeriodInDays>' % self.retention_period_days
        if self.creation_date is not None:
            s += '<CreationDate>%s</CreationDate>' % self.creation_date
        s += '</WormConfiguration>'
        return s


class InitiateWormConfiguration(object):
    """
    新建 WORM 合规保留策略配置类

    用于创建 Bucket 的合规保留策略
    请求体 XML 格式: <InitiateWormConfiguration><RetentionPeriodInDays>365</RetentionPeriodInDays></InitiateWormConfiguration>
    """
    def __init__(self, retention_period_days=None, *args, **kwargs):
        """
        初始化新建 WORM 配置

        :param retention_period_days: 保留期天数
        """
        self.retention_period_days = retention_period_days

        self.response_metadata = ResponseMetadata(**kwargs)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'RetentionPeriodInDays':
            self.retention_period_days = int(value)
        else:
            setattr(self, name, value)

    def to_xml(self):
        """生成新建 WORM 配置的 XML 表示"""
        s = '<InitiateWormConfiguration>'
        if self.retention_period_days is not None:
            s += '<RetentionPeriodInDays>%s</RetentionPeriodInDays>' % self.retention_period_days
        s += '</InitiateWormConfiguration>'
        return s


class ExtendWormConfiguration(object):
    """
    延长 WORM 保留期配置类

    用于延长已锁定 WORM 策略的保留期
    """
    def __init__(self, retention_period_days=None, *args, **kwargs):
        """
        初始化延长 WORM 配置

        :param retention_period_days: 新的保留期天数（延长后的总天数）
        """
        self.retention_period_days = retention_period_days

        self.response_metadata = ResponseMetadata(**kwargs)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'RetentionPeriodInDays':
            self.retention_period_days = int(value)
        else:
            setattr(self, name, value)

    def to_xml(self):
        """生成延长 WORM 配置的 XML 表示"""
        s = '<ExtendWormConfiguration>'
        if self.retention_period_days is not None:
            s += '<RetentionPeriodInDays>%s</RetentionPeriodInDays>' % self.retention_period_days
        s += '</ExtendWormConfiguration>'
        return s
