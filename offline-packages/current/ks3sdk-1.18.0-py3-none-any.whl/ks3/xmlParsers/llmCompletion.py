# coding:utf-8
"""
智能媒体处理(LLM)相关的类和请求配置

支持以下功能：
- CompletionParam: LLM 文本生成参数
- CompletionRequest: LLM 文本生成请求

示例:
    # 创建 LLM 请求（简单文本）
    param = CompletionParam(
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello!"}
        ],
        stream=False
    )
    request = CompletionRequest(bucket_name="my-bucket", param=param)

    # 创建 LLM 请求（多模态）
    param = CompletionParam(
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": "ks3://bucket/image.jpg"}},
                    {"type": "text", "text": "描述这张图片"}
                ]
            }
        ],
        stream=False,
        stop="EOF"
    )
"""

import json
from ks3.responseResult import ResponseMetadata


class CompletionMessage(object):
    """
    LLM 消息类

    用于构建对话消息，支持文本和多模态内容
    """
    def __init__(self, role=None, content=None):
        """
        初始化消息

        :param role: 消息角色 (system/user/assistant)
        :param content: 消息内容，可以是字符串或数组（多模态）
        """
        self.role = role
        self.content = content

    def to_dict(self):
        """转换为字典格式"""
        result = {}
        if self.role is not None:
            result['role'] = self.role
        if self.content is not None:
            result['content'] = self.content
        return result

    @classmethod
    def from_dict(cls, data):
        """从字典创建消息对象"""
        return cls(
            role=data.get('role'),
            content=data.get('content')
        )


class CompletionParam(object):
    """
    LLM 文本生成参数类

    配置 LLM 文本生成的参数，支持多模态内容
    """
    def __init__(self, messages=None, stream=None, stop=None, **kwargs):
        """
        初始化 LLM 参数

        :param messages: 消息列表，格式为 [{"role": "user", "content": "..."}, ...]
                         content 可以是字符串或数组（多模态）
        :param stream: 是否使用流式响应 (True: SSE 模式, False: JSON 模式)
        :param stop: 停止词，当模型生成该字符串时停止生成
        """
        self.messages = messages or []
        self.stream = stream
        self.stop = stop
        # 其他可选参数
        self.extra_params = kwargs

    def add_message(self, role, content):
        """
        添加消息到消息列表（简单文本内容）

        :param role: 消息角色 (system/user/assistant)
        :param content: 消息内容（字符串）
        """
        self.messages.append({"role": role, "content": content})

    def add_multimodal_message(self, role, content_items):
        """
        添加多模态消息到消息列表

        :param role: 消息角色 (system/user/assistant)
        :param content_items: 内容项列表，每个项是字典
                              例如：[{"type": "text", "text": "描述"},
                                     {"type": "image_url", "image_url": {"url": "ks3://bucket/img.jpg"}}]
        """
        self.messages.append({"role": role, "content": content_items})

    def add_image_message(self, role, image_url):
        """
        添加图片消息

        :param role: 消息角色
        :param image_url: 图片 URL，支持 ks3:// 协议或 http(s)://
        """
        content_item = {"type": "image_url", "image_url": {"url": image_url}}
        self.messages.append({"role": role, "content": [content_item]})

    def add_video_message(self, role, video_url):
        """
        添加视频消息

        :param role: 消息角色
        :param video_url: 视频 URL，支持 ks3:// 协议或 http(s)://
        """
        content_item = {"type": "video_url", "video_url": {"url": video_url}}
        self.messages.append({"role": role, "content": [content_item]})

    def to_dict(self):
        """转换为字典格式"""
        result = {}
        if self.messages:
            result['messages'] = self.messages
        if self.stream is not None:
            result['stream'] = self.stream
        if self.stop is not None:
            result['stop'] = self.stop
        # 添加额外参数
        result.update(self.extra_params)
        return result

    def to_json(self):
        """转换为 JSON 字符串"""
        return json.dumps(self.to_dict())


class CompletionRequest(object):
    """
    LLM 文本生成请求类

    封装 LLM 文本生成的完整请求
    """
    def __init__(self, bucket_name, param):
        """
        初始化 LLM 请求

        :param bucket_name: 存储桶名称
        :param param: CompletionParam 对象
        """
        self.bucket_name = bucket_name
        self.param = param

    def to_dict(self):
        """转换为字典格式"""
        return {
            'bucket_name': self.bucket_name,
            'param': self.param.to_dict() if self.param else None
        }


class CompletionResult(object):
    """
    LLM 文本生成结果类

    封装 LLM 文本生成的响应结果
    返回格式:
        {
            "content": "生成的文本内容",
            "finishReason": "stop"
        }
    """
    def __init__(self, content=None, finishReason=None, **kwargs):
        """
        初始化 LLM 结果

        :param content: 生成的文本内容
        :param finishReason: 停止原因 (如 "stop")
        """
        self.content = content
        self.finishReason = finishReason

        self.response_metadata = ResponseMetadata(**kwargs)

    def __repr__(self):
        return '<CompletionResult: content=%s, finishReason=%s>' % (
            repr(self.content[:50] + '...' if self.content and len(self.content) > 50 else self.content),
            self.finishReason
        )

    @classmethod
    def from_json(cls, json_str, **kwargs):
        """从 JSON 字符串创建结果对象"""
        data = json.loads(json_str)
        return cls(
            content=data.get('content'),
            finishReason=data.get('finishReason'),
            **kwargs
        )

    def get_content(self):
        """
        获取生成的文本内容

        :return: 生成的文本内容，如果没有则返回 None
        """
        return self.content


class StreamingCompletionResult(object):
    """
    LLM 流式文本生成结果类

    封装 SSE (Server-Sent Events) 流式响应，支持迭代访问每个数据块
    SSE 格式: data: {...}\\n\\n
    """

    def __init__(self, response, **kwargs):
        """
        初始化流式响应结果

        :param response: KS3Response 对象
        :param kwargs: 响应元数据 (status, reason, headers)
        """
        self.response = response
        self.response_metadata = ResponseMetadata(**kwargs)

    def __iter__(self):
        """
        迭代 SSE 事件，每次 yield 一个 CompletionResult

        :yield: CompletionResult 对象
        """
        import logging
        logger = logging.getLogger(__name__)

        for line in self.response.raw_resp.iter_lines(decode_unicode=False):
            if line:
                try:
                    decoded = line.decode('utf-8') if isinstance(line, bytes) else line
                    logger.debug("SSE line: %s", decoded)
                    # 支持两种格式: "data: {...}" 和 "data:{...}"
                    if decoded.startswith('data:'):
                        # 去掉 "data:" 前缀，可能有空格也可能没有
                        data = decoded[5:].lstrip()
                        if data == '[DONE]':
                            break
                        if data:
                            yield CompletionResult.from_json(data)
                except Exception as e:
                    logger.warning("Failed to parse SSE line: %s, error: %s", line, e)
                    continue

    def close(self):
        """关闭响应连接"""
        if self.response and self.response.raw_resp:
            self.response.raw_resp.close()
