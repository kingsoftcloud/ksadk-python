from ks3.responseResult import ResponseMetadata

'''
block_type:
  阻止公网访问类型
  All：阻止所有公网访问
  ExcludeAuthorization：阻止公网访问，除有效鉴权
  ExcludeConsole：阻止公网访问，控制台除外
'''
class PublicNetworkBlock:
    def __init__(self, block_type=None, *args, **kwargs):
        self.block_type = block_type
        self.response_metadata = ResponseMetadata(**kwargs)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'BlockType':
            self.block_type = value
        else:
            setattr(self, name, value)

    def to_xml(self):
        s = u'<PublicNetworkBlockConfiguration>'
        if self.block_type is not None:
            s += '<BlockType>{0}</BlockType>'.format(self.block_type)
        s += '</PublicNetworkBlockConfiguration>'
        return s


class BucketPublicNetworkBlock:
    def __init__(self, block_type=None, *args, **kwargs):
        self.block_type = block_type
        self.response_metadata = ResponseMetadata(**kwargs)

    def startElement(self, name, attrs, connection):
        return None

    def endElement(self, name, value, connection):
        if name == 'BlockType':
            self.block_type = value
        else:
            setattr(self, name, value)

    def to_xml(self):
        s = u'<BucketPublicNetworkBlockConfiguration>'
        if self.block_type is not None:
            s += '<BlockType>{0}</BlockType>'.format(self.block_type)
        s += '</BucketPublicNetworkBlockConfiguration>'
        return s