"""
ksadk create - 创建项目模板
"""

import json
import platform
import re
import shlex
import shutil
from pathlib import Path

import click
import questionary
from rich.markup import escape

from ksadk.cli.cmd_config import custom_style
from ksadk.cli.ui import (
    print_error,
    print_info,
    print_kv,
    print_rule,
    print_success,
    print_title,
    print_warn,
)


def _quote_powershell_literal(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _quote_cmd_path(value: str) -> str:
    return '"' + str(value).replace('"', '""') + '"'


def _quick_start_command_lines(
    project_name: str,
    commands: list[str],
    *,
    system: str | None = None,
) -> list[str]:
    system_name = system or platform.system()
    normalized_commands = [str(command).strip() for command in commands if str(command).strip()]
    if not normalized_commands:
        return []

    if system_name == "Windows":
        cmd_chain = " && ".join(normalized_commands)
        return [
            "PowerShell:",
            f"Set-Location -LiteralPath {_quote_powershell_literal(project_name)}",
            *normalized_commands,
            "cmd.exe:",
            f"cd /d {_quote_cmd_path(project_name)} && {cmd_chain}",
        ]

    return [f"cd {shlex.quote(str(project_name))} && {' && '.join(normalized_commands)}"]


def _print_quick_start_commands(project_name: str, commands: list[str]) -> None:
    for line in _quick_start_command_lines(project_name, commands):
        print_info(line)


_RUNTIME_AGENT_NAME_MAX_LENGTH = 63


def _normalize_runtime_package_name(project_name: str) -> str:
    """Derive a portable package/runtime name from the project directory name."""
    package_name = re.sub(r"[^A-Za-z0-9_]", "_", project_name.replace("-", "_"))
    if not package_name:
        package_name = "agent"
    if not re.match(r"^[A-Za-z_]", package_name):
        package_name = f"agent_{package_name}"
    if len(package_name) > _RUNTIME_AGENT_NAME_MAX_LENGTH:
        raise ValueError(
            "生成的 Agent 名称 "
            f"'{package_name}' 超过运行时 {_RUNTIME_AGENT_NAME_MAX_LENGTH} 字符限制"
        )
    return package_name


def _runtime_package_name_or_exit(project_name: str) -> str:
    try:
        return _normalize_runtime_package_name(project_name)
    except ValueError as exc:
        print_error(str(exc))
        raise SystemExit(1) from exc


TEMPLATES = {
    "adk": {
        "agent.py": '''"""
{package_name} - ADK Agent
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm

model = LiteLlm(
    model=f"openai/{{os.getenv('OPENAI_MODEL_NAME', 'deepseek-v4.1-flash')}}",
    api_base=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    stream=True,  # 启用流式输出
)


def hello(name: str) -> dict:
    """问候工具

    Args:
        name: 名字

    Returns:
        问候语
    """
    return {{"message": f"你好, {{name}}!"}}


root_agent = Agent(
    name="{package_name}",
    model=model,
    description="ADK示例 Agent",
    instruction="你是一个友好的助手。请用中文回复。",
    tools=[hello],
)
''',
    },
    "langchain": {
        "agent.py": '''"""
{package_name} - LangChain Agent (create_agent)
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_NAME", "deepseek-v4.1-flash"),
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    streaming=True,
)


def hello(name: str) -> str:
    """问候工具

    Args:
        name: 名字

    Returns:
        问候语
    """
    return f"你好, {{name}}!"


# create_agent 是新版 LangChain 定义 agent 的推荐方式,自带工具调用;
# 可选 middleware=[HumanInTheLoopMiddleware(...)](人工审批 HITL)与
# checkpointer(会话持久化)。detector 将本项目判为 LANGCHAIN,
# 经 LangChainRunner 运行。
root_agent = create_agent(
    model=llm,
    tools=[hello],
    system_prompt="你是一个友好的助手。请用中文回复。",
)
''',
    },
    "langgraph": {
        "agent.py": '''"""
{package_name} - LangGraph Agent
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated
import operator

llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_NAME", "deepseek-v4.1-flash"),
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    streaming=True,
)


class State(TypedDict):
    messages: Annotated[list, operator.add]


def chat(state: State):
    messages = state["messages"]
    response = llm.invoke(messages)
    return {{"messages": [response]}}


graph = StateGraph(State)
graph.add_node("chat", chat)
graph.set_entry_point("chat")
graph.add_edge("chat", END)

root_agent = graph.compile()
''',
    },
    "deepagents": {
        "agent.py": '''"""
{package_name} - DeepAgents Agent
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

from deepagents import create_deep_agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL_NAME", "deepseek-v4.1-flash"),
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    streaming=True,
)

root_agent = create_deep_agent(model=llm)
''',
    },
    "openclaw": {
        "agent.py": '''"""
{package_name} - OpenClaw placeholder

OpenClaw 使用预构建容器运行，当前目录主要用于保存 .env 和 .agentengine.state。
此入口仅用于兼容项目模板结构。
"""

root_agent = None
''',
    },
}


def _detect_framework(content: str) -> str:
    """检测 Agent 文件使用的框架"""
    if (
        "from deepagents" in content
        or "import deepagents" in content
        or "create_deep_agent(" in content
    ):
        return "deepagents"
    elif "from langgraph" in content or "import langgraph" in content:
        return "langgraph"
    elif "from google.adk" in content or "import google.adk" in content:
        return "adk"
    elif "from langchain" in content or "import langchain" in content:
        return "langchain"
    return "unknown"


def _detect_agent_variable(content: str) -> str | None:
    """检测 Agent 变量名"""
    import re

    # 优先级匹配: root_agent > compiled graph > StateGraph > Agent()
    # Only module-level exports are valid entry variables. Service-style
    # projects often build a local `graph` inside init_agent_resources(), which
    # must not be treated as importable module state.
    patterns = [
        (r"^(root_agent)\s*=", "root_agent"),
        (r"^(root_agent)\s*:\s*[^=]+\s*=", "root_agent"),  # type annotated root_agent
        (r"^(\w+)\s*=\s*\w*graph\w*\.compile\(", None),  # e.g., agent = graph.compile()
        (r"^(\w+)\s*=\s*StateGraph", None),  # e.g., graph = StateGraph(...)
        (r"^(\w+)\s*=\s*Agent\(", None),  # ADK: agent = Agent(...)
        (r"^(\w+)\s*=\s*create_react_agent\(", None),  # create_react_agent
        (r"^(\w+)\s*=\s*create_deep_agent\(", None),  # deepagents create_deep_agent
        (r"^(\w+)\s*=\s*create_agent\(", None),  # langchain create_agent
        (r"^(\w+)\s*=\s*build_agent\(", None),  # adapter style build_agent
    ]

    for pattern, fixed_name in patterns:
        match = re.search(pattern, content, re.MULTILINE | re.IGNORECASE)
        if match:
            return fixed_name if fixed_name else match.group(1)

    return None


def _has_agent_variable(content: str, agent_var: str) -> bool:
    """Best-effort static check that a module exposes the configured agent variable."""
    import re

    if not agent_var:
        return False
    escaped = re.escape(agent_var)
    patterns = [
        rf"^{escaped}\s*=",
        rf"^{escaped}\s*:\s*[^=]+=",
        rf"^from\s+[\.\w]+\s+import\s+.*\b{escaped}\b",
        rf"^import\s+[\.\w]+\s+as\s+{escaped}\b",
    ]
    return any(re.search(pattern, content, re.MULTILINE) for pattern in patterns)


def _read_text_sig(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def _entry_exposes_variable(entry_path: Path, agent_var: str) -> bool:
    try:
        content = _read_text_sig(entry_path)
    except Exception:
        return False
    return _has_agent_variable(content, agent_var) or _detect_agent_variable(content) == agent_var


def _load_entry_from_agentengine_yaml(directory: Path) -> tuple[Path, str] | None:
    """
    从已有 agentengine.yaml 读取入口信息
    返回 (入口文件路径, Agent 变量名) 或 None
    """
    config_path = directory / "agentengine.yaml"
    if not config_path.exists():
        return None

    try:
        import yaml  # type: ignore

        config = yaml.safe_load(config_path.read_text(encoding="utf-8-sig")) or {}
    except Exception:
        return None

    entry_point = config.get("entry_point")
    if not entry_point or not isinstance(entry_point, str):
        return None

    # 兼容 Windows 路径分隔符
    entry_path = directory / Path(entry_point.replace("\\", "/"))
    if not entry_path.exists() or not entry_path.is_file():
        return None

    agent_var = config.get("agent_variable")
    if not isinstance(agent_var, str) or not agent_var.strip():
        agent_var = "root_agent"

    if not _entry_exposes_variable(entry_path, agent_var):
        return None

    return entry_path, agent_var


def _load_entry_from_langgraph_json(directory: Path) -> tuple[Path, str] | None:
    """Read LangGraph's graph spec and return the first valid local graph target."""
    config_path = directory / "langgraph.json"
    if not config_path.exists():
        return None

    try:
        config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return None

    graphs = config.get("graphs")
    if not isinstance(graphs, dict):
        return None

    for target in graphs.values():
        if not isinstance(target, str) or ":" not in target:
            continue
        path_part, agent_var = target.rsplit(":", 1)
        path_part = path_part.strip().removeprefix("./")
        agent_var = agent_var.strip() or "root_agent"
        entry_path = directory / Path(path_part.replace("\\", "/"))
        if (
            entry_path.exists()
            and entry_path.is_file()
            and _entry_exposes_variable(entry_path, agent_var)
        ):
            return entry_path, agent_var
    return None


def _load_framework_from_agentengine_yaml(directory: Path) -> str | None:
    """从已有 agentengine.yaml 读取 framework"""
    config_path = directory / "agentengine.yaml"
    if not config_path.exists():
        return None

    try:
        import yaml  # type: ignore

        config = yaml.safe_load(config_path.read_text(encoding="utf-8-sig")) or {}
    except Exception:
        return None

    framework = config.get("framework")
    if not isinstance(framework, str):
        return None
    framework = framework.strip().lower()
    if framework in {"adk", "langchain", "langgraph", "deepagents", "openclaw", "hermes", "codex"}:
        return framework
    return None


def _iter_python_files(directory: Path):
    """递归迭代目录下的 Python 文件（排除常见无关目录）"""
    excluded_dirs = {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".tox",
        "node_modules",
    }

    for py_file in directory.rglob("*.py"):
        rel_parts = py_file.relative_to(directory).parts
        if any(part in excluded_dirs or part.startswith(".venv") for part in rel_parts):
            continue
        yield py_file


def _find_entry_file(directory: Path) -> tuple[Path, str] | None:
    """
    在目录中查找入口文件
    返回 (入口文件路径, Agent 变量名) 或 None
    """
    # 1) 优先读取已有 agentengine.yaml（兼容已配置项目）
    config_entry = _load_entry_from_agentengine_yaml(directory)
    if config_entry:
        entry_path, configured_var = config_entry
        try:
            content = entry_path.read_text(encoding="utf-8")
            detected_var = _detect_agent_variable(content)
            return (entry_path, detected_var or configured_var)
        except Exception:
            return (entry_path, configured_var)

    # 2) LangGraph/DeepAgents Studio projects often declare the true graph in langgraph.json.
    graph_entry = _load_entry_from_langgraph_json(directory)
    if graph_entry:
        return graph_entry

    # 3) Service-style DeepAgents projects may only expose their graph through
    # async init_agent_resources() and FastAPI lifespan. Return the init module
    # so the wrapper can generate an AgentEngine adapter instead of pointing at
    # a non-existent top-level graph variable.
    service_entry = _find_deepagents_service_entry(directory)
    if service_entry:
        return service_entry

    # 4) 按候选文件名递归查找（agent.py/main.py/app.py/...）
    entry_candidates = ["agent.py", "main.py", "app.py", "agentengine_adapter.py", "__init__.py"]
    for candidate in entry_candidates:
        candidate_files = sorted(
            (p for p in _iter_python_files(directory) if p.name == candidate),
            key=lambda p: (len(p.relative_to(directory).parts), str(p)),
        )
        for entry_path in candidate_files:
            try:
                content = entry_path.read_text(encoding="utf-8")
            except Exception:
                continue
            agent_var = _detect_agent_variable(content)
            if agent_var:
                return (entry_path, agent_var)

    # 5) 全量扫描，按得分选择最可能入口
    best_match: tuple[int, Path, str] | None = None
    for py_file in _iter_python_files(directory):
        if py_file.name.startswith("_") and py_file.name != "__init__.py":
            continue
        try:
            content = py_file.read_text(encoding="utf-8")
        except Exception:
            continue

        agent_var = _detect_agent_variable(content)
        if not agent_var:
            continue

        rel = py_file.relative_to(directory)
        depth = len(rel.parts)
        score = 0
        if agent_var == "root_agent":
            score += 100
        if py_file.name in entry_candidates:
            score += 50
        if "src" in rel.parts:
            score += 20
        score -= depth

        if best_match is None or score > best_match[0]:
            best_match = (score, py_file, agent_var)

    if best_match:
        return (best_match[1], best_match[2])

    return None


def _fix_dotenv_paths_in_file(file_path: Path, depth: int = 1) -> bool:
    """
    修复单个文件中的 load_dotenv 路径
    depth: 文件相对于项目根目录的深度（用于确定需要多少个 .parent）
    返回是否修改了文件
    """
    import re

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception:
        return False

    # 构建替换的 parent 链
    parent_chain = ".parent" * depth

    # 匹配各种 load_dotenv 模式
    patterns = [
        # load_dotenv(Path(__file__).parent / ".env")
        (
            r'(load_dotenv\s*\(\s*Path\s*\(\s*__file__\s*\)\s*)\.parent(\s*/\s*["\']\.env["\'])',
            rf"\1{parent_chain}\2",
        ),
        # load_dotenv(Path(__file__).parent.parent / ".env") -> 根据 depth 调整
    ]

    modified = False
    new_content = content

    for pattern, replacement in patterns:
        new_content_temp = re.sub(pattern, replacement, new_content)
        if new_content_temp != new_content:
            new_content = new_content_temp
            modified = True

    if modified:
        file_path.write_text(new_content, encoding="utf-8")

    return modified


def _fix_dotenv_paths_recursive(directory: Path, depth: int = 1) -> int:
    """
    递归修复目录中所有 .py 文件的 load_dotenv 路径
    返回修复的文件数量
    """
    fixed_count = 0

    for py_file in directory.rglob("*.py"):
        # 计算相对深度
        rel_path = py_file.relative_to(directory)
        file_depth = len(rel_path.parts) + depth - 1  # 相对于项目根目录

        if _fix_dotenv_paths_in_file(py_file, file_depth):
            fixed_count += 1

    return fixed_count


def _fix_nested_imports(file_path: Path, subdirs: list[str]) -> bool:
    """
    修复文件中的嵌套目录导入

    当源目录包含子包目录（如 my_agent/）时，
    入口文件中的 `from my_agent import xxx` 需要改为 `from .my_agent import xxx`

    Args:
        file_path: 需要修复的文件
        subdirs: 同级子目录名列表

    Returns:
        是否修改了文件
    """
    import re

    if not subdirs:
        return False

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception:
        return False

    original = content

    # 为每个子目录生成修复规则
    for subdir in subdirs:
        # from my_agent import xxx -> from .my_agent import xxx
        pattern = rf"^(from\s+)({re.escape(subdir)})(\s+import\s+)"
        replacement = r"\1.\2\3"
        content = re.sub(pattern, replacement, content, flags=re.MULTILINE)

        # import my_agent -> from . import my_agent
        # 只处理独立的 import 语句
        pattern_import = rf"^import\s+({re.escape(subdir)})\s*$"
        replacement_import = r"from . import \1"
        content = re.sub(pattern_import, replacement_import, content, flags=re.MULTILINE)

    if content != original:
        file_path.write_text(content, encoding="utf-8")
        return True

    return False


def _generate_env_content(global_env: dict) -> str:
    """Generate project-local configuration without copying credentials.

    ``init`` may read a global profile to retain non-secret endpoint defaults, but
    it must not persist the caller's credentials in a newly created directory.
    """
    base_url = global_env.get("OPENAI_BASE_URL", "")
    model_name = global_env.get("OPENAI_MODEL_NAME", "")
    ks_region = global_env.get("KSYUN_REGION", "cn-beijing-6")

    env_content = """# 模型配置
# OPENAI_API_KEY=
"""
    if base_url:
        env_content += f"OPENAI_BASE_URL={base_url}\n"
    else:
        env_content += "# OPENAI_BASE_URL=\n"
    if model_name:
        env_content += f"OPENAI_MODEL_NAME={model_name}\n"
    else:
        env_content += "# OPENAI_MODEL_NAME=\n"

    env_content += """
# 金山云配置
"""
    env_content += "# KSYUN_ACCESS_KEY=\n"
    env_content += "# KSYUN_SECRET_KEY=\n"
    env_content += f"KSYUN_REGION={ks_region}\n"
    env_content += "# KSYUN_ACCOUNT_ID=\n"

    return env_content


def _generate_codex_env_content(global_env: dict) -> str:
    """Generate the intentionally small local-only environment for a Codex project.

    A ManagedRuntime manifest is declarative and must never acquire cloud, storage or
    observability credentials merely because the developer ran ``init``.  The three
    OpenAI-compatible values are enough for native ``ksadk web`` debugging.  The
    optional proxy knobs are documented rather than copied from the global profile,
    because their upstream key can be different from the model key.
    """
    base_url = global_env.get("OPENAI_BASE_URL", "")
    model_name = global_env.get("OPENAI_MODEL_NAME", "")
    lines = [
        "# 本地 Codex 模型配置（仅用于 ksadk web，不会进入 ManagedRuntime bundle）",
        "# OPENAI_API_KEY=",
        f"OPENAI_BASE_URL={base_url}" if base_url else "# OPENAI_BASE_URL=",
        f"OPENAI_MODEL_NAME={model_name}" if model_name else "# OPENAI_MODEL_NAME=deepseek-v4.1-flash",
        "",
        "# 可选：自定义上游仅支持 Chat Completions 时，强制启用协议转换代理",
        "# KSADK_CODEX_USE_PROXY=1",
        "# KSADK_PROXY_UPSTREAM_BASE=",
        "# KSADK_PROXY_UPSTREAM_KEY=",
        "",
    ]
    return "\n".join(lines)


def _generate_requirements_from_imports(directory: Path, framework: str) -> str:
    """
    扫描目录中的 Python 文件，从 import 语句生成 requirements.txt
    """
    import re

    # 常用包名到 PyPI 包名的映射
    import_to_package = {
        "langchain": "langchain",
        "langchain_openai": "langchain-openai",
        "langchain_anthropic": "langchain-anthropic",
        "langchain_core": "langchain-core",
        "langchain_community": "langchain-community",
        "langgraph": "langgraph",
        "deepagents": "deepagents",
        "openai": "openai",
        "anthropic": "anthropic",
        "dotenv": "python-dotenv",
        "pydantic": "pydantic",
        "httpx": "httpx",
        "requests": "requests",
        "google.adk": "google-adk",
        "google.genai": "google-genai",
        "tiktoken": "tiktoken",
        "faiss": "faiss-cpu",
        "chromadb": "chromadb",
        "tavily": "tavily-python",
    }

    found_packages = set()

    # 扫描所有 .py 文件
    for py_file in directory.rglob("*.py"):
        try:
            content = py_file.read_text(encoding="utf-8")
        except Exception:
            continue

        # 匹配 import 语句
        # from xxx import yyy
        # import xxx
        import_patterns = [
            r"^from\s+([\w\.]+)",
            r"^import\s+([\w\.]+)",
        ]

        for pattern in import_patterns:
            for match in re.finditer(pattern, content, re.MULTILINE):
                module = match.group(1).split(".")[0]  # 取顶级模块
                full_module = match.group(1)

                # 检查是否在映射中
                if full_module in import_to_package:
                    found_packages.add(import_to_package[full_module])
                elif module in import_to_package:
                    found_packages.add(import_to_package[module])
                # 检查常见的下划线包名
                elif module.replace("_", "-") in [
                    "langchain-openai",
                    "langchain-anthropic",
                    "langchain-core",
                    "langchain-community",
                ]:
                    found_packages.add(module.replace("_", "-"))

    # 确保框架相关的核心依赖在列表中
    if framework == "langgraph":
        found_packages.add("langgraph")
        found_packages.add("langchain")
        found_packages.add("langchain-openai")
    elif framework == "deepagents":
        found_packages.add("deepagents")
        found_packages.add("langgraph")
        found_packages.add("langchain")
        found_packages.add("langchain-openai")
    elif framework == "langchain":
        found_packages.add("langchain")
        found_packages.add("langchain-openai")
    elif framework == "adk":
        found_packages.add("google-adk")

    # 总是添加 python-dotenv
    found_packages.add("python-dotenv")

    # 按字母顺序排序
    sorted_packages = sorted(found_packages)
    return "\n".join(sorted_packages) + "\n"


def _analyze_langgraph_state(content: str) -> dict:
    """Best-effort LangGraph state shape detection for adapter scaffolding."""
    import re

    message_markers = (
        "MessagesState",
        "add_messages",
        'state["messages"]',
        "state['messages']",
        '"messages":',
        "'messages':",
        "messages:",
    )
    if any(marker in content for marker in message_markers):
        return {"kind": "messages", "input_field": None}

    state_keys = set(re.findall(r"state\s*\[\s*[\"']([A-Za-z_][A-Za-z0-9_]*)[\"']\s*\]", content))
    typed_fields = set(
        re.findall(
            r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(?:str|Optional\[str\]|list|dict|Any)",
            content,
            flags=re.MULTILINE,
        )
    )
    candidates = [key for key in [*state_keys, *typed_fields] if key != "messages"]
    preferred = ("query", "question", "prompt", "user_input", "input")
    input_field = next((field for field in preferred if field in candidates), None)

    if candidates and (
        "TypedDict" in content or "StateGraph(" in content or "langgraph" in content
    ):
        return {"kind": "custom", "input_field": input_field}
    if "StateGraph(" in content or "from langgraph" in content or "import langgraph" in content:
        return {"kind": "ambiguous", "input_field": input_field}
    return {"kind": "unknown", "input_field": None}


def _langgraph_analysis_for_path(path: Path) -> dict:
    if path.is_dir():
        chunks: list[str] = []
        skip_dirs = {".git", "__pycache__", ".venv", "venv", "env", ".mypy_cache", ".pytest_cache"}
        for py_file in sorted(path.rglob("*.py")):
            if any(part in skip_dirs for part in py_file.parts):
                continue
            try:
                chunks.append(py_file.read_text(encoding="utf-8"))
            except Exception:
                return {"kind": "ambiguous", "input_field": None}
        if chunks:
            return _analyze_langgraph_state("\n\n".join(chunks))
        return {"kind": "ambiguous", "input_field": None}

    try:
        content = path.read_text(encoding="utf-8")
    except Exception:
        return {"kind": "ambiguous", "input_field": None}
    return _analyze_langgraph_state(content)


def _generate_langgraph_adapter_content(
    *,
    import_module: str,
    agent_var: str,
    analysis: dict,
) -> str:
    input_field = analysis.get("input_field")
    if input_field:
        return_body = f"""    return {{
        "{input_field}": payload.get("input", ""),
    }}"""
    else:
        return_body = """    # TODO: Map AgentEngine's chat payload to your LangGraph State.
    # Common examples:
    # return {"query": payload.get("input", "")}
    # return {"question": payload.get("input", ""), "context": []}
    return dict(payload)"""

    return f'''"""
AgentEngine adapter generated for a LangGraph project.

Review ksadk_prepare_state if your graph uses a custom State TypedDict.
"""

from {import_module} import {agent_var} as root_agent


def ksadk_prepare_state(payload: dict, session_context: dict) -> dict:
    """Map AgentEngine chat input to the LangGraph State expected by root_agent."""
    _ = session_context
{return_body}
'''


def _write_langgraph_adapter(
    *,
    package_dir: Path,
    original_entry_relative: Path,
    agent_var: str,
    analysis: dict,
) -> Path | None:
    if analysis.get("kind") not in {"custom", "ambiguous"}:
        return None

    adapter_name = "agentengine_adapter.py"
    if original_entry_relative.as_posix() == adapter_name:
        adapter_name = "ksadk_agentengine_adapter.py"
    adapter_relative = Path(adapter_name)
    original_module = "." + ".".join(original_entry_relative.with_suffix("").parts)
    adapter_content = _generate_langgraph_adapter_content(
        import_module=original_module,
        agent_var=agent_var,
        analysis=analysis,
    )
    (package_dir / adapter_relative).write_text(adapter_content, encoding="utf-8")
    return adapter_relative


def _find_python_file_containing(directory: Path, needle: str) -> Path | None:
    skip_dirs = {".git", "__pycache__", ".venv", "venv", "env", ".mypy_cache", ".pytest_cache"}
    for py_file in sorted(directory.rglob("*.py")):
        if any(part in skip_dirs for part in py_file.relative_to(directory).parts):
            continue
        try:
            if needle in py_file.read_text(encoding="utf-8-sig"):
                return py_file
        except Exception:
            continue
    return None


def _collect_python_text(directory: Path) -> str:
    try:
        return "\n".join(
            py_file.read_text(encoding="utf-8-sig")
            for py_file in sorted(_iter_python_files(directory))
        )
    except Exception:
        return ""


def _find_deepagents_service_entry(directory: Path) -> tuple[Path, str] | None:
    init_file = _find_python_file_containing(directory, "init_agent_resources")
    if not init_file:
        return None

    project_text = _collect_python_text(directory)
    service_markers = ("FastAPI(", "lifespan=", "add_routes(", "DeepAgentRunnable")
    if "deepagents" not in project_text and "create_deep_agent(" not in project_text:
        return None
    if not any(marker in project_text for marker in service_markers):
        return None

    return init_file, "root_agent"


def _detect_deepagents_service_project(
    *,
    package_dir: Path,
    entry_relative: Path,
    agent_var: str,
) -> dict | None:
    """Detect service-style DeepAgents projects that initialize the graph in app lifespan."""
    entry_path = package_dir / entry_relative
    try:
        entry_content = _read_text_sig(entry_path)
    except Exception:
        entry_content = ""

    if _has_agent_variable(entry_content, agent_var):
        return None

    init_file = _find_python_file_containing(package_dir, "init_agent_resources")
    if not init_file:
        return None

    project_text = _collect_python_text(package_dir) or entry_content

    service_markers = ("FastAPI(", "lifespan=", "add_routes(", "DeepAgentRunnable")
    if "deepagents" not in project_text and "create_deep_agent(" not in project_text:
        return None
    if not any(marker in project_text for marker in service_markers):
        return None

    runnable_file = _find_python_file_containing(package_dir, "class DeepAgentRunnable")
    return {
        "init_module": "." + ".".join(init_file.relative_to(package_dir).with_suffix("").parts),
        "runnable_module": (
            "." + ".".join(runnable_file.relative_to(package_dir).with_suffix("").parts)
            if runnable_file
            else None
        ),
    }


def _generate_deepagents_service_adapter_content(analysis: dict) -> str:
    init_module = analysis["init_module"]
    runnable_module = analysis.get("runnable_module")
    runnable_module_constant = (
        f'RUNNABLE_MODULE = "{runnable_module}"' if runnable_module else "RUNNABLE_MODULE = None"
    )
    runnable_build = "        return None\n"
    if runnable_module:
        runnable_build = """        try:
            runnable_module = importlib.import_module(RUNNABLE_MODULE, __package__)
            deep_agent_runnable = getattr(runnable_module, "DeepAgentRunnable")
            return deep_agent_runnable(agent, _NullObservabilityManager())
        except Exception:
            return None
"""

    return f'''"""
AgentEngine adapter generated for a service-style DeepAgents project.

It preserves the user's async resource initialization and exposes a root_agent
object that ksadk can load through the DeepAgents/LangGraph runner.
"""

import asyncio
import importlib
from typing import Any

INIT_MODULE = "{init_module}"
{runnable_module_constant}

class _NullObservabilityManager:
    callback_handler = None


class AgentEngineDeepAgentsServiceAdapter:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._initialized = False
        self._agent = None
        self._runnable = None
        self._resources = ()

    async def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        async with self._lock:
            if self._initialized:
                return
            init_module = importlib.import_module(INIT_MODULE, __package__)
            init_agent_resources = getattr(init_module, "init_agent_resources")
            resources = await init_agent_resources()
            if isinstance(resources, tuple):
                self._agent = resources[0]
                self._resources = resources[1:]
            else:
                self._agent = resources
                self._resources = ()
            self._runnable = self._build_runnable(self._agent)
            self._initialized = True

    def _build_runnable(self, agent: Any) -> Any:
{runnable_build}

    @staticmethod
    def _message_from_payload(payload: Any) -> str:
        if isinstance(payload, dict):
            if payload.get("message") is not None:
                return str(payload.get("message") or "")
            if payload.get("input") is not None:
                return str(payload.get("input") or "")
            messages = payload.get("messages")
            if isinstance(messages, list) and messages:
                last = messages[-1]
                content = getattr(last, "content", None)
                if content is None and isinstance(last, dict):
                    content = last.get("content")
                return str(content or "")
        return str(payload or "")

    @staticmethod
    def _session_id_from_payload(payload: Any, config: dict | None) -> str | None:
        if isinstance(payload, dict):
            value = payload.get("session_id") or payload.get("thread_id")
            if value:
                return str(value)
        configurable = (config or {{}}).get("configurable", {{}})
        value = configurable.get("thread_id") if isinstance(configurable, dict) else None
        return str(value) if value else None

    @staticmethod
    def _normalize_result(result: Any) -> dict:
        if isinstance(result, dict):
            if "output" in result:
                return result
            if "response" in result:
                return {{"output": result.get("response"), "raw": result}}
            if "messages" in result and result["messages"]:
                last = result["messages"][-1]
                content = getattr(last, "content", None)
                if content is None and isinstance(last, dict):
                    content = last.get("content")
                return {{"output": content, "raw": result}}
        return {{"output": str(result) if result is not None else "", "raw": result}}

    async def ainvoke(self, payload: Any, config: dict | None = None, **kwargs: Any) -> dict:
        await self._ensure_initialized()
        message = self._message_from_payload(payload)
        session_id = self._session_id_from_payload(payload, config)
        service_payload = {{"message": message}}
        if session_id:
            service_payload["thread_id"] = session_id

        if self._runnable is not None and hasattr(self._runnable, "_ainvoke"):
            result = await self._runnable._ainvoke(service_payload, config=config, **kwargs)
            return self._normalize_result(result)

        if hasattr(self._agent, "ainvoke"):
            agent_payload = (
                {{"messages": payload.get("messages", [])}}
                if isinstance(payload, dict) and payload.get("messages")
                else payload
            )
            result = await self._agent.ainvoke(
                agent_payload, config=config, **kwargs
            )
            return self._normalize_result(result)
        result = self._agent.invoke(payload, config=config, **kwargs)
        return self._normalize_result(result)

    def invoke(self, payload: Any, config: dict | None = None, **kwargs: Any) -> dict:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.ainvoke(payload, config=config, **kwargs))
        raise RuntimeError(
            "Synchronous invoke cannot run while an event loop is already active; "
            "use ainvoke instead"
        )


def ksadk_prepare_state(payload: dict, session_context: dict) -> dict:
    message = payload.get("input") or payload.get("message") or ""
    return {{
        "message": message,
        "session_id": session_context.get("session_id"),
        "history": session_context.get("history", []),
    }}


root_agent = AgentEngineDeepAgentsServiceAdapter()
'''


def _write_deepagents_service_adapter(
    *,
    package_dir: Path,
    original_entry_relative: Path,
    agent_var: str,
) -> Path | None:
    analysis = _detect_deepagents_service_project(
        package_dir=package_dir,
        entry_relative=original_entry_relative,
        agent_var=agent_var,
    )
    if not analysis:
        return None

    adapter_name = "agentengine_adapter.py"
    if original_entry_relative.as_posix() == adapter_name:
        adapter_name = "ksadk_agentengine_adapter.py"
    adapter_relative = Path(adapter_name)
    adapter_content = _generate_deepagents_service_adapter_content(analysis)
    (package_dir / adapter_relative).write_text(adapter_content, encoding="utf-8")
    return adapter_relative


def _wrap_agent_file(from_agent_path: Path, project_name: str, framework: str, agent_var: str):
    """包装单个 Agent 文件到新项目"""
    project_path = Path(project_name)
    package_name = _runtime_package_name_or_exit(project_path.name)

    if project_path.exists():
        print_error(f"目录 '{project_name}' 已存在")
        raise SystemExit(1)

    print_title("包装 Agent 文件")
    print_kv("创建项目", project_name)
    print_kv("框架", framework)
    print_kv("包装文件", str(from_agent_path))
    print_kv("Agent 变量", agent_var)

    # 创建目录
    (project_path / package_name).mkdir(parents=True)

    # 复制源文件并修复 .env 路径
    source_filename = from_agent_path.name
    dest_path = project_path / package_name / source_filename

    # 读取源文件内容
    source_content = from_agent_path.read_text(encoding="utf-8")

    # 修复 load_dotenv 路径：parent -> parent.parent (因为文件被移到了子目录)
    fixed_content = re.sub(
        r'(load_dotenv\s*\(\s*Path\s*\(\s*__file__\s*\)\s*\.parent)(\s*/\s*["\']\.env["\'])',
        r"\1.parent\2",
        source_content,
    )

    if fixed_content != source_content:
        print_info("已自动修复 .env 加载路径")

    # 写入目标文件
    dest_path.write_text(fixed_content, encoding="utf-8")

    # 检测全局配置
    from ksadk.configs.global_config import (
        get_env_from_global_config,
        global_config_exists,
    )

    global_env = {}
    if global_config_exists():
        global_env = get_env_from_global_config()
        if global_env:
            print_info("检测到全局配置；项目 .env 仅保留非敏感默认值，凭证不会被复制")

    # 生成 .env
    (project_path / ".env").write_text(_generate_env_content(global_env), encoding="utf-8-sig")

    # LangGraph custom-state 项目生成 adapter，避免直接猜业务 State 语义。
    entry_relative = Path(source_filename)
    export_agent_var = agent_var
    if framework == "langgraph":
        analysis = _analyze_langgraph_state(fixed_content)
        if analysis["kind"] == "messages":
            print_info("LangGraph state 检测: messages-compatible")
        elif analysis["kind"] == "custom":
            adapter_relative = _write_langgraph_adapter(
                package_dir=project_path / package_name,
                original_entry_relative=entry_relative,
                agent_var=agent_var,
                analysis=analysis,
            )
            if adapter_relative:
                entry_relative = adapter_relative
                export_agent_var = "root_agent"
                print_info("LangGraph state 检测: custom-state adapter generated")
        elif analysis["kind"] == "ambiguous":
            adapter_relative = _write_langgraph_adapter(
                package_dir=project_path / package_name,
                original_entry_relative=entry_relative,
                agent_var=agent_var,
                analysis=analysis,
            )
            if adapter_relative:
                entry_relative = adapter_relative
                export_agent_var = "root_agent"
                print_warn("LangGraph state 检测: ambiguous adapter generated, review required")

    # 生成 agentengine.yaml
    entry_module = entry_relative.with_suffix("").name
    (project_path / "agentengine.yaml").write_text(
        f"""# AgentEngine 项目配置 (Wrapped)
name: {package_name}
version: "1.0.0"

framework: {framework}
entry_point: {package_name}/{entry_relative}
agent_variable: {export_agent_var}
""",
        encoding="utf-8-sig",
    )

    # 生成 __init__.py
    (project_path / package_name / "__init__.py").write_text(
        f'''"""
{project_name} - Wrapped Agent
"""
from .{entry_module} import {export_agent_var} as root_agent
__all__ = ["root_agent"]
''',
        encoding="utf-8-sig",
    )

    # 生成 requirements.txt
    reqs = ""
    if framework == "langchain":
        reqs = "langchain\nlangchain-openai\npython-dotenv\n"
    elif framework == "langgraph":
        reqs = "langchain\nlangchain-openai\nlanggraph\npython-dotenv\n"
    elif framework == "deepagents":
        reqs = "deepagents\nlangchain\nlangchain-openai\nlanggraph\npython-dotenv\n"
    elif framework == "adk":
        reqs = "google-adk\npython-dotenv\n"
    (project_path / "requirements.txt").write_text(reqs, encoding="utf-8")

    # 生成 README.md
    (project_path / "README.md").write_text(
        f"""# {project_name}

Wrapped Agent project (from `{from_agent_path.name}`).

## Quick Start

```bash
cd {project_name}
agentengine run -i .
```
""",
        encoding="utf-8-sig",
    )

    print_success("包装完成")
    print_rule("快速开始")
    _print_quick_start_commands(project_name, ["agentengine run -i ."])


def _wrap_agent_directory(
    from_agent_dir: Path, project_name: str, framework: str, entry_file: Path, agent_var: str
):
    """包装 Agent 目录到新项目"""

    project_path = Path(project_name)
    package_name = _runtime_package_name_or_exit(project_path.name)
    if project_path.exists():
        print_error(f"目录 '{project_name}' 已存在")
        raise SystemExit(1)

    print_title("包装 Agent 目录")
    print_kv("创建项目", project_name)
    print_kv("框架", framework)
    print_kv("包装目录", str(from_agent_dir))
    print_kv("入口文件", entry_file.name)
    print_kv("Agent 变量", agent_var)

    # 创建项目目录
    project_path.mkdir(parents=True)

    # 复制整个源目录到项目中（作为 package）
    dest_package_path = project_path / package_name
    ignore_names = {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".tox",
        "node_modules",
        ".idea",
        ".vscode",
        ".DS_Store",
    }

    def _ignore_copytree(_dir: str, names: list[str]):
        ignored = set()
        for name in names:
            if name in ignore_names or name.startswith(".venv"):
                ignored.add(name)
                continue
            if name.endswith((".pyc", ".pyo")):
                ignored.add(name)
        return ignored

    shutil.copytree(from_agent_dir, dest_package_path, ignore=_ignore_copytree)

    print_info(f"已复制 {sum(1 for _ in dest_package_path.rglob('*.py'))} 个 Python 文件")

    # 递归修复 .env 路径
    fixed_count = _fix_dotenv_paths_recursive(dest_package_path, depth=2)
    if fixed_count > 0:
        print_info(f"已自动修复 {fixed_count} 个文件的 .env 加载路径")

    # 修复嵌套目录导入路径
    # 查找源目录中的子目录（作为 Python 包）
    subdirs = [
        d.name
        for d in from_agent_dir.iterdir()
        if d.is_dir()
        and not d.name.startswith(".")
        and not d.name.startswith("_")
        and (d / "__init__.py").exists()
    ]

    if subdirs:
        # 修复入口文件中的导入
        dest_entry_file = dest_package_path / entry_file.relative_to(from_agent_dir)
        if _fix_nested_imports(dest_entry_file, subdirs):
            print_info(f"已修复嵌套目录导入: {', '.join(subdirs)}")

    # 检测全局配置
    from ksadk.configs.global_config import (
        get_env_from_global_config,
        global_config_exists,
    )

    global_env = {}
    if global_config_exists():
        global_env = get_env_from_global_config()
        if global_env:
            print_info("检测到全局配置；项目 .env 仅保留非敏感默认值，凭证不会被复制")

    # 生成 .env
    (project_path / ".env").write_text(_generate_env_content(global_env), encoding="utf-8-sig")

    # 生成 agentengine.yaml
    # entry_point 相对于项目根目录
    entry_relative = entry_file.relative_to(from_agent_dir)
    export_agent_var = agent_var
    if framework == "deepagents":
        adapter_relative = _write_deepagents_service_adapter(
            package_dir=dest_package_path,
            original_entry_relative=entry_relative,
            agent_var=agent_var,
        )
        if adapter_relative:
            entry_relative = adapter_relative
            export_agent_var = "root_agent"
            print_info("DeepAgents service adapter generated")

    if framework == "langgraph":
        analysis = _langgraph_analysis_for_path(dest_package_path)
        if analysis["kind"] == "messages":
            print_info("LangGraph state 检测: messages-compatible")
        elif analysis["kind"] == "custom":
            adapter_relative = _write_langgraph_adapter(
                package_dir=dest_package_path,
                original_entry_relative=entry_relative,
                agent_var=agent_var,
                analysis=analysis,
            )
            if adapter_relative:
                entry_relative = adapter_relative
                export_agent_var = "root_agent"
                print_info("LangGraph state 检测: custom-state adapter generated")
        elif analysis["kind"] == "ambiguous":
            adapter_relative = _write_langgraph_adapter(
                package_dir=dest_package_path,
                original_entry_relative=entry_relative,
                agent_var=agent_var,
                analysis=analysis,
            )
            if adapter_relative:
                entry_relative = adapter_relative
                export_agent_var = "root_agent"
                print_warn("LangGraph state 检测: ambiguous adapter generated, review required")

    (project_path / "agentengine.yaml").write_text(
        f"""# AgentEngine 项目配置 (Wrapped Directory)
name: {package_name}
version: "1.0.0"

framework: {framework}
entry_point: {package_name}/{entry_relative}
agent_variable: {export_agent_var}
""",
        encoding="utf-8-sig",
    )

    # 确保 __init__.py 正确导出 root_agent
    init_file = dest_package_path / "__init__.py"
    entry_module = ".".join(entry_relative.with_suffix("").parts)  # e.g. src.agentengine_adapter
    expected_export_line = f"from .{entry_module} import {export_agent_var} as root_agent"

    # 检查现有 __init__.py 是否已导出 root_agent
    init_has_export = False
    if init_file.exists():
        init_content = init_file.read_text(encoding="utf-8")
        if expected_export_line in init_content:
            init_has_export = True

    if not init_has_export:
        # 追加或创建导出语句
        export_code = f"""
# AgentEngine 导出 (自动添加)
{expected_export_line}
__all__ = ["root_agent"]
"""
        if init_file.exists():
            # 追加到现有文件
            with open(init_file, "a", encoding="utf-8") as f:
                f.write(export_code)
            print_info("已修复 __init__.py 导出")
        else:
            init_file.write_text(
                f'''"""
{project_name} - Wrapped Agent
"""
{expected_export_line}
__all__ = ["root_agent"]
''',
                encoding="utf-8-sig",
            )

    # 处理 requirements.txt
    source_requirements = from_agent_dir / "requirements.txt"
    dest_requirements = project_path / "requirements.txt"

    if source_requirements.exists():
        # 如果源目录有 requirements.txt，复制并补充必要的依赖
        import shutil as shutil_req

        shutil_req.copy(source_requirements, dest_requirements)
        print_info("已复制 requirements.txt")

        # 检查是否缺少必要依赖，追加
        existing_reqs = dest_requirements.read_text(encoding="utf-8").lower()
        missing = []
        if framework == "langgraph" and "langgraph" not in existing_reqs:
            missing.append("langgraph")
        if framework == "deepagents":
            if "deepagents" not in existing_reqs:
                missing.append("deepagents")
            if "langgraph" not in existing_reqs:
                missing.append("langgraph")
        if "python-dotenv" not in existing_reqs and "dotenv" not in existing_reqs:
            missing.append("python-dotenv")

        if missing:
            with open(dest_requirements, "a", encoding="utf-8") as f:
                f.write("\n# Added by agentengine\n")
                for pkg in missing:
                    f.write(f"{pkg}\n")
            print_info(f"已补充依赖: {', '.join(missing)}")
    else:
        # 自动根据 import 生成 requirements.txt
        reqs = _generate_requirements_from_imports(dest_package_path, framework)
        dest_requirements.write_text(reqs, encoding="utf-8")
        print_info(f"已自动生成 requirements.txt ({reqs.count(chr(10))} 个依赖)")

    # 生成 README.md
    (project_path / "README.md").write_text(
        f"""# {project_name}

Wrapped Agent project (from `{from_agent_dir.name}/`).

## Quick Start

```bash
cd {project_name}
agentengine run -i .
```
""",
        encoding="utf-8-sig",
    )

    # === 运行时验证 ===
    print_rule("验证 Agent 加载")
    import subprocess
    import sys

    verify_code = f"""
import sys
sys.path.insert(0, ".")
try:
    from {package_name} import root_agent
    print("TYPE:" + type(root_agent).__name__)
except Exception as e:
    print("ERROR:" + str(e))
    sys.exit(1)
"""

    result = subprocess.run(
        [sys.executable, "-c", verify_code],
        cwd=str(project_path),
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode == 0:
        output = result.stdout.strip()
        if output.startswith("TYPE:"):
            agent_type = output.split("TYPE:")[1]
            print_success(f"Agent 加载成功! 类型: {agent_type}")
        else:
            print_success("Agent 加载成功!")
    else:
        error_msg = result.stderr or result.stdout
        print_warn(f"Agent 加载警告: {error_msg[:200]}")
        print_info("提示: 请检查依赖是否已安装，或代码是否有错误")

    print_success("包装完成")
    print_rule("快速开始")
    _print_quick_start_commands(project_name, ["agentengine run -i ."])


def _write_hermes_project_config(project_path: Path, package_name: str) -> None:
    """Write the deployable Hermes config; the runtime image is platform-owned."""
    (project_path / "agentengine.yaml").write_text(
        f"""# AgentEngine Hermes project configuration
name: {package_name}
version: "1.0.0"

framework: hermes
artifact_type: Container

ui_profile: hermes
ui_path: /

deploy:
  resources:
    cpu: "2"
    memory: "4Gi"
  scaling:
    min_replicas: 1
    max_replicas: 1
    concurrency: 1000
""",
        encoding="utf-8-sig",
    )


def _write_codex_project_config(project_path: Path, package_name: str) -> None:
    """Write the minimal codex runtime project:yaml 驱动,无 package/agent.py。

    codex 的 agent 逻辑由 prompt 承载，所以只生成
    canonical agentengine.yaml(framework: codex,model+prompt)+ requirements +
    README。model/prompt 经 CodexRuntimeAdapter 传入 codex thread(开发者指令)。
    """
    (project_path / "agentengine.yaml").write_text(
        f"""# AgentEngine codex runtime 项目配置
name: {package_name}
version: "1.0.0"

# 框架:codex（本地和部署统一使用 CodexRuntimeAdapter）
framework: codex
artifact_type: ManagedRuntime

# 托管运行时版本可选；省略时云端由 Runtime catalog 选择默认值。
# 本地 `ksadk web` 会使用已安装的 openai-codex 并提示该版本未锁定。
runtime:
  name: codex

# codex 的模型与开发者指令（CodexRuntimeAdapter 传入 codex thread）
model: deepseek-v4.1-flash
prompt: |
  你是 codex 编码助手。简洁回答,能跑命令验证就跑(shell 工具),中文回复。
""",
        encoding="utf-8-sig",
    )
    (project_path / "requirements.txt").write_text(
        "ksadk[codex]\n",
        encoding="utf-8",  # 无 BOM:pip 解析 BOM 会报 Invalid requirement
    )
    (project_path / "README.md").write_text(
        f"""# {package_name} — codex runtime agent

## 快速开始

```bash
# 1. 编辑 .env 填 OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL_NAME
# 2. 本地运行(浏览器对话,codex 自动探测并启用代理)
agentengine web .
# 或
ksadk web .
```

## 说明

- codex 的 agent 逻辑由 `agentengine.yaml` 的 `prompt`(开发者指令)承载,无 agent.py。
- codex 自动探测模型协议:OpenAI 官方直连,星流 chat 模型自动启用转换代理。
- `agentengine build .` 只生成 YAML manifest bundle，不打包本机 Codex 二进制。若
  `runtime.version` 未指定，build 需要连接到已配置 Runtime catalog；离线构建请显式锁定版本。
- 部署时服务端解析 ManagedRuntime 版本和 Linux 镜像 digest。云端必须已发布 Runtime
  catalog、对应镜像和内联 manifest 控制面；未发布时请继续使用本地 `ksadk web`，不要把
  `runtime.version` 随意改成开发机版本，KsADK 不回退为 Code 部署。
""",
        encoding="utf-8-sig",
    )


@click.command(context_settings=dict(help_option_names=["-h", "--help"]))
@click.argument("project_name", required=False)
@click.option(
    "--framework",
    "-f",
    type=click.Choice(
        ["adk", "langchain", "langgraph", "deepagents", "openclaw", "hermes", "codex"]
    ),
    default="langgraph",
    help="框架类型 (default: langgraph)",
)
@click.option(
    "--from-agent",
    "from_agent_path",
    type=click.Path(exists=True),
    help="包装现有 Agent 文件或目录",
)
def create(project_name: str, framework: str, from_agent_path: str):
    """创建新的 Agent 项目

    PROJECT_NAME: 项目名称

    使用 --from-agent 可包装现有代码:
        agentengine init --from-agent ./my_agent.py      # 单文件
        agentengine init --from-agent ./my_agent/        # 目录
    """
    # === 包装模式 ===
    if from_agent_path:
        from_path = Path(from_agent_path)

        # === 目录模式 ===
        if from_path.is_dir():
            print_info(f"扫描目录: {from_path}")

            # 查找入口文件
            entry_result = _find_entry_file(from_path)
            if not entry_result:
                print_error(
                    "未找到有效的入口文件 (agent.py, main.py, __init__.py 或包含 Agent 定义的文件)"
                )
                raise SystemExit(1)

            entry_file, detected_var = entry_result
            print_info(f"检测到入口: {entry_file.name}")
            print_info(f"检测到变量: {detected_var}")

            # 检测框架：优先读取已有 agentengine.yaml
            detected_framework = _load_framework_from_agentengine_yaml(from_path) or "unknown"
            if detected_framework != "unknown":
                print_info(f"从 agentengine.yaml 检测到框架: {detected_framework}")
            else:
                entry_content = entry_file.read_text(encoding="utf-8")
                detected_framework = _detect_framework(entry_content)

            # 如果入口文件未检测到框架，扫描整个目录
            if detected_framework == "unknown":
                for py_file in _iter_python_files(from_path):
                    try:
                        content = py_file.read_text(encoding="utf-8")
                    except Exception:
                        continue
                    detected_framework = _detect_framework(content)
                    if detected_framework != "unknown":
                        break

            if detected_framework == "unknown":
                print_warn("无法自动检测框架，将使用默认 langgraph")
                detected_framework = "langgraph"
            else:
                print_info(f"检测到框架: {detected_framework}")

            # 如果没有指定项目名，使用目录名
            if not project_name:
                project_name = from_path.name.replace("_", "-")

            _wrap_agent_directory(
                from_path, project_name, detected_framework, entry_file, detected_var
            )
            return

        # === 单文件模式 ===
        else:
            content = from_path.read_text(encoding="utf-8")

            # 自动检测框架
            detected_framework = _detect_framework(content)
            if detected_framework == "unknown":
                print_warn("无法自动检测框架，将使用默认 langgraph")
                detected_framework = "langgraph"
            else:
                print_info(f"检测到框架: {detected_framework}")

            # 自动检测 Agent 变量
            detected_agent_var = _detect_agent_variable(content)
            if not detected_agent_var:
                print_warn("无法自动检测 Agent 变量，将使用默认 root_agent")
                detected_agent_var = "root_agent"
            else:
                print_info(f"检测到变量: {detected_agent_var}")

            # 如果没有指定项目名，使用文件名
            if not project_name:
                project_name = from_path.stem.replace("_", "-")

            _wrap_agent_file(from_path, project_name, detected_framework, detected_agent_var)
            return

    # === 正常模板模式 ===
    # 如果没有提供项目名称，进入交互模式
    if not project_name:
        print_title("初始化新项目")

        project_name = questionary.text("请输入项目名称:", style=custom_style).ask()

        if not project_name:
            print_error("取消创建")
            raise SystemExit(0)

        framework = questionary.select(
            "请选择开发框架:",
            choices=["langgraph", "langchain", "deepagents", "adk", "openclaw", "hermes", "codex"],
            default="langgraph",
            style=custom_style,
        ).ask()

        if not framework:
            print_error("取消创建")
            raise SystemExit(0)

    project_path = Path(project_name)

    if project_path.exists():
        print_error(f"目录 '{project_name}' 已存在")
        raise SystemExit(1)

    print_kv("创建项目", project_name)
    print_kv("框架", framework)

    package_name = _runtime_package_name_or_exit(project_path.name)
    project_path.mkdir(parents=True)
    if framework not in {"openclaw", "hermes", "codex"}:
        (project_path / package_name).mkdir(parents=True)

    # 检测全局配置
    from ksadk.configs.global_config import (
        get_env_from_global_config,
        global_config_exists,
    )

    global_env = {}
    if global_config_exists():
        global_env = get_env_from_global_config()
        if global_env:
            print_info("检测到全局配置；项目 .env 仅保留非敏感默认值，凭证不会被复制")

    # .env - 生成配置文件
    # 仅继承非敏感的 endpoint/model/region 默认值；绝不复制凭证。
    base_url = global_env.get("OPENAI_BASE_URL", "")
    model_name = global_env.get("OPENAI_MODEL_NAME", "")

    ks_region = global_env.get("KSYUN_REGION", "cn-beijing-6")

    # 构建 .env 内容
    if framework == "openclaw":
        env_content = f"""# ======================
# OpenClaw 标准部署最小配置
# ======================
# KSYUN_ACCESS_KEY=
# KSYUN_SECRET_KEY=
KSYUN_REGION={ks_region}
"""
        env_content += "# KSYUN_ACCOUNT_ID=your-account-id\n"

        env_content += "\n# OPENAI_API_KEY=\n"
        if base_url:
            env_content += f"OPENAI_BASE_URL={base_url}\n"
        else:
            env_content += "# OPENAI_BASE_URL=http://kspmas.ksyun.com/v1\n"

        if model_name:
            env_content += f"OPENAI_MODEL_NAME={model_name}\n"
        else:
            env_content += "# OPENAI_MODEL_NAME=deepseek-v4.1-flash\n"
    elif framework == "hermes":
        env_content = f"""# ======================
# Hermes 标准部署最小配置
# ======================
# KSYUN_ACCESS_KEY=
# KSYUN_SECRET_KEY=
KSYUN_REGION={ks_region}
"""
        env_content += "# KSYUN_ACCOUNT_ID=your-account-id\n"

        env_content += "\n# OPENAI_API_KEY=\n"
        if base_url:
            env_content += f"OPENAI_BASE_URL={base_url}\n"
        else:
            env_content += "# OPENAI_BASE_URL=http://kspmas.ksyun.com/v1\n"

        if model_name:
            env_content += f"OPENAI_MODEL_NAME={model_name}\n"
        else:
            env_content += "# OPENAI_MODEL_NAME=deepseek-v4.1-flash\n"

        env_content += """
# Hermes runtime
API_SERVER_ENABLED=true
API_SERVER_HOST=127.0.0.1
API_SERVER_PORT=8642
HERMES_DASHBOARD_HOST=127.0.0.1
HERMES_DASHBOARD_PORT=9119
PORT=8080
# HERMES_CONTEXT_LENGTH=200000
# HERMES_FALLBACK_MODEL=glm-5.3-flash
"""
        env_example_content = """# ======================
# Hermes 标准部署最小配置示例
# ======================
KSYUN_ACCESS_KEY=your-access-key
KSYUN_SECRET_KEY=your-secret-key
KSYUN_REGION=cn-beijing-6
# KSYUN_ACCOUNT_ID=your-account-id

OPENAI_API_KEY=your-model-api-key
OPENAI_BASE_URL=https://kspmas.ksyun.com/v1/
OPENAI_MODEL_NAME=deepseek-v4.1-flash

# Hermes runtime
API_SERVER_ENABLED=true
API_SERVER_HOST=127.0.0.1
API_SERVER_PORT=8642
HERMES_DASHBOARD_HOST=127.0.0.1
HERMES_DASHBOARD_PORT=9119
PORT=8080
# HERMES_CONTEXT_LENGTH=200000
# HERMES_FALLBACK_MODEL=glm-5.3-flash
"""
    elif framework == "codex":
        env_content = _generate_codex_env_content(global_env)
    else:
        env_content = """# ======================
# 模型配置 (必填, 可以从星流平台获取https://ksp.console.ksyun.com/#/apiKey)
# ======================
# OPENAI_API_KEY=
"""

        # 可选字段：如果有值则启用，否则注释掉
        if base_url:
            env_content += f"OPENAI_BASE_URL={base_url}\n"
        else:
            env_content += "# OPENAI_BASE_URL=http://kspmas.ksyun.com/v1\n"

        if model_name:
            env_content += f"OPENAI_MODEL_NAME={model_name}\n"
        else:
            env_content += "# OPENAI_MODEL_NAME=deepseek-v4.1-flash\n"

        env_content += """
# ======================
# 可观测性 (可选)
# ======================
"""
        env_content += "# OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf\n"
        env_content += "# OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=https://collector.example.com/v1/traces\n"
        env_content += "# OTEL_EXPORTER_OTLP_TRACES_HEADERS=Authorization=Bearer%20placeholder\n"

        env_content += """
# ======================
# 金山云配置 (可选,需要部署时必选)
# ======================
"""
        env_content += "# KSYUN_ACCESS_KEY=your-api-key-here\n"
        env_content += "# KSYUN_SECRET_KEY=your-api-secret-here\n"

        env_content += f"KSYUN_REGION={ks_region}\n"

        env_content += "# KSYUN_ACCOUNT_ID=your-account-id\n"

    # 使用 utf-8-sig 编码 (带 BOM)，确保 Windows 程序正确识别为 UTF-8
    (project_path / ".env").write_text(env_content, encoding="utf-8-sig")
    if framework == "hermes":
        (project_path / ".env.example").write_text(env_example_content, encoding="utf-8-sig")

    if framework == "openclaw":
        print_success("项目创建成功")
        print_rule("快速开始")
        print_info("快速开始 (复制并执行):")
        _print_quick_start_commands(project_name, ["agentengine openclaw deploy"])
        print_info("部署前如需覆盖模型/网关参数，可先编辑 .env")
        return
    if framework == "hermes":
        _write_hermes_project_config(project_path, package_name)
        print_success("项目创建成功")
        print_rule("快速开始")
        print_info("快速开始 (复制并执行):")
        _print_quick_start_commands(project_name, ["agentengine hermes deploy"])
        print_info("部署前如需覆盖模型/运行时参数，可先编辑 .env")
        return
    if framework == "codex":
        _write_codex_project_config(project_path, package_name)
        print_success("项目创建成功")
        print_rule("快速开始")
        print_info("快速开始 (复制并执行):")
        _print_quick_start_commands(project_name, ["ksadk web ."])
        print_info("编辑 .env 填星流 OPENAI_API_KEY/BASE/MODEL_NAME;codex 自动探测并启用代理")
        # codex 本地环境检测(不阻断):缺 openai-codex SDK 时提醒
        import importlib.util

        if importlib.util.find_spec("openai_codex") is None:
            print_warn(
                escape(
                    "缺少 codex runtime SDK:请先 `pip install 'ksadk[codex]'`"
                    "(内含 codex CLI 二进制)"
                )
            )
        return

    # agentengine.yaml - Agent 配置
    (project_path / "agentengine.yaml").write_text(
        f"""# AgentEngine 项目配置
name: {package_name}
version: "1.0.0"

# 框架类型: adk, langchain, langgraph, deepagents
framework: {framework}

# Agent 入口
entry_point: {package_name}/agent.py
agent_variable: root_agent

# 部署配置 (可选)
# deploy:
#   timeout: 300
#   memory: 512
""",
        encoding="utf-8-sig",
    )

    # __init__.py
    (project_path / package_name / "__init__.py").write_text(
        f'''"""
{project_name} - KsADK Agent
"""
from .agent import root_agent
__all__ = ["root_agent"]
''',
        encoding="utf-8-sig",
    )

    # agent.py
    template = TEMPLATES[framework]["agent.py"]
    (project_path / package_name / "agent.py").write_text(
        template.format(package_name=package_name), encoding="utf-8-sig"
    )

    # README.md
    if framework == "openclaw":
        readme = f"""# {project_name}

基于 AgentEngine 创建的 OpenClaw 项目。

## 快速开始

```bash
cd {project_name}

# 1. 编辑 .env（可选，覆盖模型/网关参数）
vim .env

# 2. 部署 OpenClaw（默认 trusted-proxy）
agentengine openclaw deploy

# 3. 打开 Dashboard
agentengine dashboard --share
```
"""
    else:
        readme = f"""# {project_name}

基于 AgentEngine 创建的 {framework.upper()} Agent.

## 快速开始

```bash
cd {project_name}

# 1. 编辑 .env 填写 API Key
vim .env

# 2. 运行
agentengine run -i .    # 交互式
agentengine web .       # API Server
agentengine deploy .    # 部署到云端
```

## 项目结构

```
{project_name}/
├── .env                 # 环境变量 (API Key 等)
├── agentengine.yaml      # Agent 配置
├── requirements.txt      # Python 依赖
├── {package_name}/
│   ├── __init__.py
│   └── agent.py         # Agent 实现
└── README.md
```
"""

    (project_path / "README.md").write_text(readme, encoding="utf-8-sig")

    # requirements.txt
    reqs = "requests_aws4auth\n"  # Minimum required for ksadk.common.auth
    if framework == "langchain":
        reqs += "langchain\nlangchain-openai\npython-dotenv\n"
    elif framework == "langgraph":
        reqs += "langchain\nlangchain-openai\nlanggraph\npython-dotenv\n"
    elif framework == "deepagents":
        reqs += "deepagents\nlangchain\nlangchain-openai\nlanggraph\npython-dotenv\n"
    elif framework == "adk":
        reqs += "google-adk\npython-dotenv\n"

    (project_path / "requirements.txt").write_text(reqs, encoding="utf-8")

    print_success("项目创建成功")
    print_rule("快速开始")

    print_info("快速开始 (复制并执行):")
    _print_quick_start_commands(project_name, ["agentengine config"])
    print_info("或直接运行 (环境变量中需包含模型 API Key):")
    _print_quick_start_commands(project_name, ["agentengine run -i ."])
