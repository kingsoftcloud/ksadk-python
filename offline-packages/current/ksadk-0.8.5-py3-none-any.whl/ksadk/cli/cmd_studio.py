"""agentengine studio - start the local-first Agent authoring control plane."""

from __future__ import annotations

import logging
import os
import secrets
import socket
import threading
import time
import webbrowser
from pathlib import Path

import click
import uvicorn

from ksadk.cli.env_options import load_env_file
from ksadk.cli.ui import print_info, print_kv, print_success, print_title
from ksadk.studio.api import create_studio_app
from ksadk.studio.service import StudioService

# veadk 风格：日志行带模块名与行号（filename:lineno），本地排障时能直接定位代码。
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(filename)s:%(lineno)d %(message)s"

_STUDIO_LOG_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {"format": _LOG_FORMAT},
        "access": {"format": _LOG_FORMAT},
    },
    "handlers": {
        "default": {
            "class": "logging.StreamHandler",
            "formatter": "default",
            "stream": "ext://sys.stderr",
        },
        "access": {
            "class": "logging.StreamHandler",
            "formatter": "access",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "uvicorn": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "uvicorn.error": {"level": "INFO"},
        "uvicorn.access": {"handlers": ["access"], "level": "INFO", "propagate": False},
    },
    "root": {"handlers": ["default"], "level": "INFO"},
}


# 模型环境变量白名单。OPENAI_BASE_URL 与 OPENAI_API_BASE 互为别名，两者都接受；
# 加载时做别名归一（见 studio()），运行时统一 OPENAI_BASE_URL 优先（与 cmd_config/cmd_model
# /api.py 一致，方案 §2.4 第 5 点）。
_MODEL_ENV_KEYS = (
    "OPENAI_BASE_URL",
    "OPENAI_API_BASE",
    "OPENAI_API_KEY",
    "OPENAI_MODEL_NAME",
)
# Explicit env-file credentials are process-only overrides. They are never
# copied into the workspace store or exposed as browser settings.
_CLOUD_CONTROL_ENV_KEYS = (
    "KSYUN_ACCESS_KEY",
    "KSYUN_SECRET_KEY",
    "KSYUN_ACCOUNT_ID",
    "KSYUN_REGION",
    "AGENTENGINE_REGION",
    "AGENTENGINE_SERVER_URL",
    "AGENTENGINE_STREAM_SERVER_URL",
    "AGENTENGINE_SIGN_SERVICE",
    "KS3_BUCKET",
    "KS3_ACCESS_KEY",
    "KS3_SECRET_KEY",
)
_WEB_SEARCH_ENV_KEYS = (
    "KSADK_WEB_SEARCH_PROVIDER",
    "KSADK_WEB_SEARCH_API_KEY",
    "KSADK_WEB_SEARCH_BASE_URL",
    "KSADK_WEB_SEARCH_SCOPE",
)
_STUDIO_ENV_FILE_KEYS = (*_MODEL_ENV_KEYS, *_CLOUD_CONTROL_ENV_KEYS, *_WEB_SEARCH_ENV_KEYS)
# 别名归一：两者任一有值时，把另一个也设上，保证下游无论读哪个都命中。
_MODEL_BASE_URL_ALIASES = ("OPENAI_BASE_URL", "OPENAI_API_BASE")


def _open_browser_when_ready(url: str, port: int, *, timeout: float = 90.0) -> None:
    """Open Studio only after Uvicorn accepts loopback connections."""

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                webbrowser.open(url)
                return
        except OSError:
            time.sleep(0.2)


@click.command(context_settings=dict(help_option_names=["-h", "--help"]))
@click.argument("workspace", default=".", type=click.Path())
@click.option("--port", "-p", default=8080, type=click.IntRange(1, 65535))
@click.option("--no-open", is_flag=True, help="仅打印 URL，不自动打开浏览器")
@click.option(
    "--env-file",
    type=click.Path(exists=True, dir_okay=False),
    help=(
        "本地模型、云端控制与搜索环境文件；只读取允许的 OPENAI/KSYUN/KS3/KSADK_WEB_SEARCH "
        "字段，且仅保留在 Studio 进程"
    ),
)
@click.option(
    "--codex-proxy",
    type=click.Choice(["inherit", "auto", "forced", "direct"]),
    default="inherit",
    show_default=True,
    help="Codex Responses→Chat 代理策略",
)
def studio(
    workspace: str,
    port: int,
    no_open: bool,
    env_file: str | None,
    codex_proxy: str,
) -> None:
    """启动本地 AgentKit Studio。

    \b
    WORKSPACE: Agent 工作区目录，目录不存在时自动初始化。
    """

    root = Path(workspace).expanduser().resolve()
    managed_keys = (*_STUDIO_ENV_FILE_KEYS, "KSADK_CODEX_USE_PROXY")
    previous = {key: os.environ.get(key) for key in managed_keys}
    previously_present = {key for key in managed_keys if key in os.environ}
    configuration_overrides: dict[str, str] = {}
    try:
        if env_file:
            try:
                values = load_env_file(env_file)
            except ValueError as exc:
                raise click.ClickException(str(exc)) from exc
            loaded_models = 0
            loaded_cloud_control = 0
            loaded_search = 0
            for key, value in values.items():
                if key not in _STUDIO_ENV_FILE_KEYS or not value:
                    continue
                if key in _MODEL_ENV_KEYS:
                    loaded_models += 1
                elif key in _WEB_SEARCH_ENV_KEYS:
                    loaded_search += 1
                else:
                    loaded_cloud_control += 1
                # An explicit --env-file is the operator's selected cloud
                # identity and model configuration; it overrides inherited
                # and saved values consistently for this process.
                os.environ[key] = value
                configuration_overrides[key] = os.environ[key]
            # 别名归一（方案 §2.4 第 5 点）：OPENAI_BASE_URL 与 OPENAI_API_BASE 互为别名。
            # 加载后任一有值则把另一个也设上，保证下游无论读哪个都命中；OPENAI_BASE_URL 优先。
            resolved_base_url = (
                configuration_overrides.get("OPENAI_BASE_URL")
                or configuration_overrides.get("OPENAI_API_BASE")
                or os.environ.get("OPENAI_BASE_URL")
                or os.environ.get("OPENAI_API_BASE")
            )
            if resolved_base_url:
                os.environ["OPENAI_BASE_URL"] = resolved_base_url
                os.environ["OPENAI_API_BASE"] = resolved_base_url
                if any(key in configuration_overrides for key in _MODEL_BASE_URL_ALIASES):
                    configuration_overrides.update(
                        dict.fromkeys(_MODEL_BASE_URL_ALIASES, resolved_base_url)
                    )
                # base_url 至少算一次，避免显示 0/4 误导。
                loaded_models = max(loaded_models, 2)
            print_kv(
                "模型环境",
                f"已安全加载 {loaded_models}/{len(_MODEL_ENV_KEYS)} 个字段",
            )
            if loaded_cloud_control:
                print_kv(
                    "云端控制",
                    "已安全加载 "
                    f"{loaded_cloud_control}/{len(_CLOUD_CONTROL_ENV_KEYS)} 个字段"
                    "（仅本地进程）",
                )
            if loaded_search:
                print_kv("联网搜索", f"已安全加载 {loaded_search} 个字段（仅本地进程）")
        if codex_proxy == "forced":
            os.environ["KSADK_CODEX_USE_PROXY"] = "1"
        elif codex_proxy == "direct":
            os.environ["KSADK_CODEX_USE_PROXY"] = "0"
        elif codex_proxy == "auto":
            os.environ.pop("KSADK_CODEX_USE_PROXY", None)
        if codex_proxy != "inherit":
            configuration_overrides["KSADK_CODEX_USE_PROXY"] = {
                "forced": "1",
                "direct": "0",
                "auto": "",
            }[codex_proxy]
        session_token = os.environ.get("KSADK_STUDIO_SESSION_TOKEN") or secrets.token_urlsafe(32)
        csrf_token = secrets.token_urlsafe(24)
        service = StudioService(root, configuration_overrides=configuration_overrides)
        app = create_studio_app(
            root,
            service=service,
            session_token=session_token,
            csrf_token=csrf_token,
            security_enabled=os.environ.get("KSADK_STUDIO_NO_SECURITY") != "1",
        )
        base_url = f"http://127.0.0.1:{port}/"
        launch_url = f"{base_url}#session={session_token}"

        print_title("启动 AgentKit Local Studio")
        print_kv("工作区", str(root))
        print_kv("访问地址", launch_url, value_style="#58a6ff")
        print_success("构建与运行均在本地执行")
        print_info("按 Ctrl+C 停止")
        if not no_open:
            threading.Thread(
                target=_open_browser_when_ready,
                args=(launch_url, port),
                daemon=True,
                name="studio-browser-launcher",
            ).start()
        # 业务日志（ksadk.*）走 root handler，同样带 filename:lineno。
        logging.basicConfig(level=logging.INFO, format=_LOG_FORMAT)
        uvicorn.run(
            app,
            host="127.0.0.1",
            port=port,
            log_level="info",
            # Lifespan cleanup releases local authority only after HTTP draining.
            # Bound long-lived/stalled streams so a restart can acquire that authority.
            timeout_graceful_shutdown=10,
            # Access logging stays enabled through the Studio log config while
            # retaining filename/line-number context for both API and business
            # logs.  This preserves master's observability intent and the
            # branch's richer diagnostic format.
            log_config=_STUDIO_LOG_CONFIG,
        )
    finally:
        for key in managed_keys:
            if key in previously_present:
                os.environ[key] = previous[key] or ""
            else:
                os.environ.pop(key, None)
