"""KnowledgeBaseClient - 金山云知识库检索客户端

封装 AICP RetrieveKnowledge API，通过 kingsoftcloud SDK 调用。
支持从环境变量自动配置，由各框架 Runner 自动集成。

环境变量:
    KSADK_KB_DATASET_ID: 知识库 ID (必填，存在即启用)
    KSADK_KB_ACCESS_KEY: AK (可选，默认取 KSYUN_ACCESS_KEY / KSYUN_ACCESS_KEY_ID)
    KSADK_KB_SECRET_KEY: SK (可选，默认取 KSYUN_SECRET_KEY / KSYUN_SECRET_ACCESS_KEY)
    KSADK_KB_SESSION_TOKEN: STS 临时会话 token (可选，默认取 KSYUN_SESSION_TOKEN)
    KSADK_KB_REGION: 区域 (默认 cn-beijing-6)
    KSADK_KB_ENDPOINT: API 端点 (默认 aicp.api.ksyun.com)
    KSADK_KB_TOP_K: 返回结果数 (默认 5)
    KSADK_KB_SEARCH_METHOD: 检索方法 (默认 intelligence_search)
    KSADK_KB_SCORE_THRESHOLD: 分数阈值 (可选)
    KSADK_KB_RERANKING_ENABLE: 是否启用重排序 (默认 false)

使用示例:
    # 自动从环境变量配置 (推荐)
    client = KnowledgeBaseClient.from_env()
    results = client.search("如何使用知识库？")

    # 手动创建
    client = KnowledgeBaseClient(
        dataset_id="your-kb-id",
        access_key="ak",
        secret_key="sk",
    )
"""

import json
import logging
import os
from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict

from ksadk.common.aicp_env import resolve_aicp_connection

logger = logging.getLogger(__name__)


class KnowledgeBaseResult(BaseModel):
    """单条知识库检索结果"""

    content: str = ""
    score: float = 0.0
    segment_id: str = ""
    document_id: str = ""
    document_name: str = ""
    position: int = 0
    answer: str = ""
    keywords: List[str] = []


class KnowledgeBaseClient(BaseModel):
    """金山云知识库检索客户端

    Attributes:
        dataset_id: 知识库 ID (DatasetId)
        access_key: 访问密钥 ID (AK)
        secret_key: 访问密钥 (SK)
        session_token: STS 临时会话 token
        region: API 区域
        endpoint: API 端点
        top_k: 返回结果数
        search_method: 检索方法
        score_threshold: 分数阈值
        score_threshold_enabled: 是否启用阈值过滤
        reranking_enable: 是否启用重排序
    """

    dataset_id: str
    access_key: str = ""
    secret_key: str = ""
    session_token: str = ""
    region: str = "cn-beijing-6"
    endpoint: str = "aicp.api.ksyun.com"
    scheme: str = "https"
    top_k: int = 5
    search_method: str = "intelligence_search"
    score_threshold: float = 0.0
    score_threshold_enabled: bool = False
    reranking_enable: bool = False
    # 最近一次检索失败原因（成功调用前置空，失败时填充）。供
    # KnowledgeBaseService.build_context 区分"后端吞错返空"与"真无结果"，
    # 避免错误伪装成"未找到"注入模型上下文。
    last_error: str = ""
    last_request_id: str = ""
    last_http_status: int | None = None

    _aicp_client: Any = None

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def model_post_init(self, __context: Any) -> None:
        if not self.dataset_id:
            raise ValueError("dataset_id is required for KnowledgeBaseClient")

        if not self.access_key or not self.secret_key:
            logger.warning(
                "KnowledgeBaseClient: AK/SK not provided, "
                "API calls will fail. Set KSADK_KB_ACCESS_KEY/KSADK_KB_SECRET_KEY "
                "or KSYUN_ACCESS_KEY/KSYUN_SECRET_KEY."
            )

    def _get_client(self):
        """懒加载 AICP 客户端"""
        if self._aicp_client is not None:
            return self._aicp_client

        try:
            from ksyun.common import credential  # type: ignore[import-untyped]
            from ksyun.common.profile.client_profile import (  # type: ignore[import-untyped]
                ClientProfile,
            )
            from ksyun.common.profile.http_profile import (  # type: ignore[import-untyped]
                HttpProfile,
            )
        except ImportError:
            raise ImportError(
                "kingsoftcloud-sdk-python is required for knowledge base. "
                "Install it with: pip install kingsoftcloud-sdk-python"
            )

        # 尝试导入 aicp client (多版本 fallback)
        aicp_module = None
        for version in ["v20251114", "v20251212", "v20240612"]:
            try:
                aicp_module = __import__(
                    f"ksyun.client.aicp.{version}.client",
                    fromlist=["AicpClient"],
                )
                logger.debug(f"Using aicp client version: {version}")
                break
            except ImportError:
                continue

        if aicp_module is None:
            raise ImportError(
                "Cannot import ksyun.client.aicp client. "
                "Ensure kingsoftcloud-sdk-python is installed and up to date."
            )

        cred = credential.Credential(self.access_key, self.secret_key, self.session_token or None)

        http_profile = HttpProfile()
        http_profile.endpoint = self.endpoint
        http_profile.reqMethod = "POST"
        http_profile.reqTimeout = 60
        http_profile.scheme = self.scheme

        client_profile = ClientProfile()
        client_profile.httpProfile = http_profile

        owner = self

        class ObservedAicpClient(aicp_module.AicpClient):
            def _check_status(self, response):
                # The upstream SDK discards HTTP status when raising its generic
                # ServerNetworkError. Capture only the status before delegation;
                # never infer authorization from exception text/response content.
                owner.last_http_status = response.status
                return super()._check_status(response)

        self._aicp_client = ObservedAicpClient(cred, self.region, profile=client_profile)

        # 强制覆写 API 版本为 RetrieveKnowledge 所需的 2025-11-14
        # SDK 的 _apiVersion 由导入的模块版本决定，可能不匹配
        self._aicp_client._apiVersion = "2025-11-14"

        logger.debug("KnowledgeBaseClient initialized")
        return self._aicp_client

    def _build_params(self, query: str, top_k: Optional[int] = None) -> dict:
        """构建 RetrieveKnowledge 请求参数 (JSON 嵌套格式)"""
        effective_top_k = top_k if top_k is not None else self.top_k

        retrieval_model: dict[str, Any] = {
            "SearchMethod": self.search_method,
            "TopK": effective_top_k,
            "RerankingEnable": self.reranking_enable,
        }
        params: dict[str, Any] = {
            "DatasetId": self.dataset_id,
            "Query": query,
            "RetrievalModel": retrieval_model,
        }

        if self.score_threshold_enabled:
            retrieval_model["ScoreThresholdEnabled"] = True
            retrieval_model["ScoreThreshold"] = self.score_threshold

        return params

    def _parse_response(self, response: str) -> List[KnowledgeBaseResult]:
        """解析 RetrieveKnowledge 响应"""
        try:
            data = json.loads(response) if isinstance(response, str) else response
        except (json.JSONDecodeError, TypeError):
            self.last_error = "Invalid knowledge response JSON"
            logger.error("Invalid knowledge response JSON")
            return []

        if not isinstance(data, dict):
            self.last_error = "Knowledge response must be an object"
            return []
        metadata = data.get("ResponseMetadata") or {}
        if not isinstance(metadata, dict):
            self.last_error = "Invalid knowledge response metadata"
            return []
        request_id = data.get("RequestId") or metadata.get("RequestId")
        self.last_request_id = (
            request_id if isinstance(request_id, str) and len(request_id) <= 256 else ""
        )
        code = data.get("Code")
        if "Code" in data:
            valid_code = (
                (type(code) is int and code in {0, 200})
                or (type(code) is str and code in {"0", "200"})
            )
            if not valid_code:
                self.last_error = "Knowledge service rejected the request"
                return []
        if data.get("Error") or metadata.get("Error"):
            self.last_error = "Knowledge service rejected the request"
            return []

        if "Records" not in data:
            self.last_error = "Knowledge response omitted records"
            return []
        records = data["Records"]
        if not isinstance(records, list):
            self.last_error = "Invalid knowledge records"
            return []
        results = []

        for record in records:
            segment = record.get("Segment", {})
            document = segment.get("Document", {})

            results.append(
                KnowledgeBaseResult(
                    content=segment.get("Content", ""),
                    score=record.get("Score", 0.0),
                    segment_id=segment.get("Id", ""),
                    document_id=segment.get("DocumentId", ""),
                    document_name=document.get("Name", ""),
                    position=segment.get("Position", 0),
                    answer=segment.get("Answer", ""),
                    keywords=segment.get("Keywords", []),
                )
            )

        return results

    def search(self, query: str, top_k: Optional[int] = None) -> List[KnowledgeBaseResult]:
        """检索知识库

        Args:
            query: 检索关键词
            top_k: 返回结果数 (覆盖默认值)

        Returns:
            匹配的文档片段列表
        """
        self.last_error = ""
        self.last_request_id = ""
        self.last_http_status = None
        try:
            client = self._get_client()
            params = self._build_params(query, top_k)
            response = client.call("RetrieveKnowledge", params, options={"IsPostJson": True})
            results = self._parse_response(response)
            logger.debug("Knowledge base returned %d results", len(results))
            return results
        except Exception as e:
            self.last_error = str(e)
            logger.error("Knowledge base search failed (%s)", type(e).__name__)
            raise

    @classmethod
    def from_env(cls) -> "KnowledgeBaseClient":
        """从环境变量创建 KnowledgeBaseClient

        Returns:
            KnowledgeBaseClient 实例

        Raises:
            ValueError: 如果 KSADK_KB_DATASET_ID 未设置
        """
        dataset_id = os.environ.get("KSADK_KB_DATASET_ID", "")
        if not dataset_id:
            raise ValueError(
                "KSADK_KB_DATASET_ID environment variable is required to enable knowledge base."
            )

        access_key = (
            os.environ.get("KSADK_KB_ACCESS_KEY")
            or os.environ.get("KSYUN_ACCESS_KEY")
            or os.environ.get("KSYUN_ACCESS_KEY_ID")
            or os.environ.get("KSYUN_SECRET_ID", "")
        )
        secret_key = (
            os.environ.get("KSADK_KB_SECRET_KEY")
            or os.environ.get("KSYUN_SECRET_KEY")
            or os.environ.get("KSYUN_SECRET_ACCESS_KEY", "")
        )
        session_token = os.environ.get("KSADK_KB_SESSION_TOKEN") or os.environ.get(
            "KSYUN_SESSION_TOKEN", ""
        )

        score_threshold_str = os.environ.get("KSADK_KB_SCORE_THRESHOLD", "")
        score_threshold = float(score_threshold_str) if score_threshold_str else 0.0
        score_threshold_enabled = bool(score_threshold_str)

        reranking_str = os.environ.get("KSADK_KB_RERANKING_ENABLE", "false")
        reranking_enable = reranking_str.lower() in ("true", "1", "yes")
        connection = resolve_aicp_connection("KSADK_KB")

        return cls(
            dataset_id=dataset_id,
            access_key=access_key,
            secret_key=secret_key,
            session_token=session_token,
            region=connection["region"],
            endpoint=connection["endpoint"],
            scheme=connection["scheme"],
            top_k=int(os.environ.get("KSADK_KB_TOP_K", "5")),
            search_method=os.environ.get("KSADK_KB_SEARCH_METHOD", "intelligence_search"),
            score_threshold=score_threshold,
            score_threshold_enabled=score_threshold_enabled,
            reranking_enable=reranking_enable,
        )

    @staticmethod
    def is_configured() -> bool:
        """检查环境变量是否已配置知识库"""
        return bool(os.environ.get("KSADK_KB_DATASET_ID"))
